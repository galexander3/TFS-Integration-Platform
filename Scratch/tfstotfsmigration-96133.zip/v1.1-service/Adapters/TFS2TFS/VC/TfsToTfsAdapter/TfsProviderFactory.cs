// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.IO;
using System.Xml.Serialization;
using Microsoft.Vsts.Rangers.Migration.TfsToTfs;

namespace Microsoft.Vsts.Rangers.Migration.TfsToTfs
{
    /// <summary>
    /// Provider factory to create TfsVersionControlTargetEndpoint instance
    /// </summary>
    public class TfsProviderFactory : IConfigFactory
    {
        #region IConfigFactory Members

        /// <summary>
        /// Create the source or target end point for TfsToTfs migration
        /// </summary>
        /// <param name="type">Type of the instance to be created</param>
        /// <param name="xmlFragment">Xml gragment of the instance</param>
        /// <returns></returns>
        public object CreateInstance(Type type, string xmlFragment)
        {
            if (type == typeof(IVersionControlEndpoint))
            {
                using (StringReader sr = new StringReader(xmlFragment))
                {
                    //Tfs Provider is of type TfsVersionControlTargetEndpoint which is already defined.
                    XmlSerializer xs = new XmlSerializer(typeof(TfsVersionControlTargetEndpoint));
                    return xs.Deserialize(sr);
                }
            }
            else if (type == typeof(IMigrationProvider))
            {
                return new Session();
            }

            return null;
        }

        #endregion
    }
}
