// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Xml;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Microsoft.TeamFoundation.Migration.WorkItemTracking.Wss
{
    using MigrationFileAttachmentOperation = SyncActionContainer<IMigrationFileAttachment>;

    internal sealed class WssWorkItemUpdatePackage : IWorkItemUpdatePackage
    {
        private WssHelper m_helper;                         //Wss helper
        private IMigrationWorkItem m_target;
        private Collection<MigrationRevision> m_revisions;  // List of revisions
        private Collection<MigrationFileAttachmentOperation> m_fileAttachments;// List of file attachment changes
        private XmlDocument m_doc;                          // XML document for generating update packages

        #region IWorkItemChangeList Members

        /// <summary>
        /// Gets explicitly defined revisions.
        /// </summary>
        public Collection<MigrationRevision> Revisions { get { return m_revisions; } }

        /// <summary>
        /// Gets explicitly defined file attachments changes.
        /// </summary>
        public Collection<MigrationFileAttachmentOperation> FileAttachmentOperations { get { return m_fileAttachments; } }

        /// <summary>
        /// Gets pending link operations.
        /// </summary>
        public Collection<SyncActionContainer<ILink>> LinkOperations
        {
            get { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Translates content of the change list into the set of atomic changes.
        /// </summary>
        /// <returns>Set of update statements</returns>
        public IEnumerable<IWorkItemUpdate> Translate()
        {
            List<IWorkItemUpdate> updates = new List<IWorkItemUpdate>(m_revisions.Count);
            MigrationRevision rev;
            //Translate the revisions. 
            for (int i = 0; i < m_revisions.Count; i++)
            {
                rev = m_revisions[i];
                updates.Add(new WssWorkItemUpdate(m_helper, rev, m_target == null? null : m_target.Watermark));
            }

            //Make an update to deal with the attachments
            if (m_fileAttachments.Count > 0)
            {
                updates.Add(new WssWorkItemUpdate(m_helper, m_fileAttachments));
            }

            return updates;
        }

        #endregion

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="helper">Wss helper</param>
        /// <param name="xdoc">Xml document for the updates</param>
        /// <param name="source">Source work item</param>
        /// <param name="target">Target work item</param>
        public WssWorkItemUpdatePackage(WssHelper helper, XmlDocument xdoc, IMigrationWorkItem target)
        {
            m_helper = helper;
            m_doc = xdoc;
            m_target = target;
            m_revisions = new Collection<MigrationRevision>();
            m_fileAttachments = new Collection<MigrationFileAttachmentOperation>();
        }
    }
}
