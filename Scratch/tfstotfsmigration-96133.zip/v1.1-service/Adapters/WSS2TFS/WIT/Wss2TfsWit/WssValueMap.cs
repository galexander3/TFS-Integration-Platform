// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.XPath;
using System.Globalization;

namespace Microsoft.TeamFoundation.Migration.WorkItemTracking.Wss
{
    /// <summary>
    /// Represents mapping between Wss and Other system values.
    /// </summary>
    internal sealed class WssValueMap
    {
        private Dictionary<string, string> m_wssToOther;    //Wss Other mapping
        private Dictionary<string, string> m_otherToWss;    //Other to Wss mapping

        /// <summary>
        /// Mapping of Wss values to values in the other system.  Wss values are the key.
        /// </summary>
        public Dictionary<string, string> WssToOther { get { return m_wssToOther; } }

        /// <summary>
        /// Mapping of values in the other system to Wss values.  Other system values are the key.
        /// </summary>
        public Dictionary<string, string> OtherToWss { get { return m_otherToWss; } }

        /// <summary>
        /// Constructor.
        /// </summary>
        internal WssValueMap()
        {
            m_wssToOther = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            m_otherToWss = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Adds a new value to the mapping.
        /// </summary>
        /// <param name="wssValue">Value on the Wss side</param>
        /// <param name="otherValue">Value on the other side</param>
        internal void AddMapping(string wssValue, string otherValue)
        {
            m_wssToOther.Add(wssValue, otherValue);
            m_otherToWss.Add(otherValue, wssValue);
        }

    }
}
