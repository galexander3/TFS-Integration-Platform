// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.WorkItemTracking.Wss
{
    /// <summary>
    /// Known WSS fields
    /// </summary>
    static class WssFields
    {
        private static string[] s_allFields;                // Array of all known fields

        // Field names
        public const string Id              = "ID";
        public const string Title           = "Title";
        public const string AssignedTo      = "AssignedTo";
        public const string Status          = "Status";
        public const string Priority        = "Priority";
        public const string StartDate       = "StartDate";
        public const string DueDate         = "DueDate";
        public const string PercentComplete = "PercentComplete";
        public const string Modified        = "Modified";
        public const string Editor          = "Editor";
        public const string Created         = "Created";
        public const string Author          = "Author";
        public const string Body            = "Body";
        public const string AttachmentCount = "AttachmentCount";

        /// <summary>
        /// Gets the list of all known fields
        /// </summary>
        public static string[] AllFields { get { return s_allFields; } }

        /// <summary>
        /// Checks whether the field is read only.
        /// </summary>
        /// <param name="field">Field name</param>
        /// <returns>True if the field is read only</returns>
        public static bool IsReadOnly(string field)
        {
            switch (field)
            {
                case Id:
                case Modified:
                case Editor:
                case Created:
                case Author:
                case AttachmentCount:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Determines whether the field is queryable.s
        /// </summary>
        /// <param name="field">Field name</param>
        /// <returns>True if queryable</returns>
        public static bool IsQueryable(string field)
        {
            switch (field)
            {
                case AttachmentCount: return false;
                default: return true;
            }
        }

        /// <summary>
        /// Static constructor.
        /// </summary>
        static WssFields()
        {
            s_allFields = new string[]
            {
                WssFields.Id, WssFields.Title, WssFields.AssignedTo, WssFields.Status, 
                WssFields.Priority, WssFields.StartDate, WssFields.DueDate, 
                WssFields.PercentComplete, WssFields.Modified, WssFields.Editor,
                WssFields.Created, WssFields.Author, WssFields.Body, WssFields.AttachmentCount,
            };
        }

    }
}
