// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.WorkItemTracking.Wss
{
    /// <summary>
    /// Store-specific exception class.
    /// </summary>
    [Serializable]
    public class WssStoreException: Exception
    {
        public WssStoreException()
        {
        }

        public WssStoreException(
            string message)
            : base(message)
        {
        }

        public WssStoreException(
            string message,
            Exception exception)
            : base(message, exception)
        {
        }

        protected WssStoreException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
