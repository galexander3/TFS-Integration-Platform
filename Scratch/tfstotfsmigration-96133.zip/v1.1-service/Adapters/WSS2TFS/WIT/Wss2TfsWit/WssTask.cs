// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.Migration.WorkItemTracking.Wss.Generated;

namespace Microsoft.TeamFoundation.Migration.WorkItemTracking.Wss
{
    /// <summary>
    /// A lightweight WSS task object.
    /// </summary>
    class WssTask
    {
        private WssHelper m_helper;                         // WSS helper object
        private Dictionary<string, object> m_fields;        // Fields and their values
        private int? m_id;                                  // Field id
        private string m_editor;                            // Editor
        private DateTime m_modified;                        // Time of the last change

        /// <summary>
        /// Gets the collection of fields.
        /// </summary>
        public Dictionary<string, object> Fields { get { return m_fields; } }

        /// <summary>
        /// Returns task id (existing tasks).
        /// </summary>
        public int? Id { get { return m_id; } internal set { m_id = value; } }

        /// <summary>
        /// Returns id in a string form.
        /// </summary>
        public string StringId 
        { 
            get 
            {
                return m_id.HasValue ? m_id.Value.ToString(CultureInfo.InvariantCulture) : string.Empty; 
            } 
        }

        /// <summary>
        /// Obtains author
        /// </summary>
        public string Editor { get { return m_editor; } }

        /// <summary>
        /// Obtains time of the last change.
        /// </summary>
        public DateTime Modified { get { return m_modified; } }

        /// <summary>
        /// Indicates that the task has attachments.
        /// </summary>
        public bool HasAttachments
        {
            get
            {
                object count;

                return m_fields.TryGetValue(WssFields.AttachmentCount, out count) ?
                    Convert.ToInt32(count, CultureInfo.InvariantCulture) != 0 : false;
            }
        }

        /// <summary>
        /// Constructor. Initializes a new item.
        /// </summary>
        /// <param name="helper">WSS helper</param>
        public WssTask(WssHelper helper)
        {
            m_helper = helper;
            m_fields = new Dictionary<string, object>(StringComparer.InvariantCulture);

            for (int i = 0; i < WssFields.AllFields.Length; i++)
            {
                m_fields.Add(WssFields.AllFields[i], null);
            }
        }

        /// <summary>
        /// Constructor for an existing task.
        /// </summary>
        /// <param name="helper">WSS helper object</param>
        /// <param name="row">WSS task data</param>
        public WssTask(WssHelper helper, row row)
            : this(helper)
        {
            Refresh(row);
        }

        /// <summary>
        /// Refreshes fields with results.
        /// </summary>
        /// <param name="row">WSS row</param>
        public void Refresh(row row)
        {
            Id = XmlConvert.ToInt32(row.ows_ID);
            Fields[WssFields.Id] = row.ows_ID;

            // Account fields
            Fields[WssFields.Editor] = m_editor = (string)m_helper.TranslateWssAccount(row.ows_Author);
            Fields[WssFields.AssignedTo] = m_helper.TranslateWssAccount(row.ows_AssignedTo);
            Fields[WssFields.Author] = m_helper.TranslateWssAccount(row.ows_Author);

            // Time fields
            Fields[WssFields.StartDate] = m_helper.TranslateWssDate(row.ows_StartDate);
            Fields[WssFields.DueDate] = m_helper.TranslateWssDate(row.ows_DueDate);
            Fields[WssFields.Modified] = m_modified = (DateTime)m_helper.TranslateWssDate(row.ows_Modified);
            Fields[WssFields.Created] = m_helper.TranslateWssDate(row.ows_Created);

            // Integer fields
            Fields[WssFields.AttachmentCount] = Convert.ToInt32(row.ows_Attachments);

            // Percent field
            Fields[WssFields.PercentComplete] = m_helper.TranslateWssPercent(row.ows_PercentComplete);

            // Plain string fields
            Fields[WssFields.Title] = row.ows_Title;
            Fields[WssFields.Status] = row.ows_Status;
            Fields[WssFields.Priority] = row.ows_Priority;
            Fields[WssFields.Body] = row.ows_Body;
        }

        /// <summary>
        /// Saves the task.
        /// </summary>
        public void Save()
        {
            m_helper.SaveTasks(this);
        }

        /// <summary>
        /// Gets all attachments.
        /// </summary>
        /// <returns></returns>
        public AttachmentsAttachment[] GetAttachments()
        {
            return m_helper.GetAttachments(StringId);
        }
    }
}
