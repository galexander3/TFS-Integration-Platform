// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.VersionControl.Client;
using System.IO;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    internal class TfsToWssAnalysisAlgorithms : TfsAnalysisAlgorithms
    {
        VersionControlSession m_session;

        public TfsToWssAnalysisAlgorithms(VersionControlSession session)
        {
            if (session == null)
            {
                throw new ArgumentNullException("session");
            }

            m_session = session;
        }

        private static char[] s_invalidWssPathChars = new char[] { '&', '%', '#', '{', '}', '~' };
        private static string s_inValidWssPathCharsDisplay = "& % # { } ~";

        private static void validateWssPath(string uriPath)
        {
            if (uriPath.IndexOfAny(s_invalidWssPathChars) != -1)
            {
                throw new VCInvalidPathException(
                    string.Format(WSS2TFSResources.Culture, WSS2TFSResources.PathContainsInvalidChar,
                    uriPath, s_inValidWssPathCharsDisplay
                    ));
            }


            // scan for path/filename..ext
            // if this were a file system path we could use Path.GetFileNameWithoutExtension and check
            // for "EndsWith(".") - but alas it's not.
            bool sawDot = false;
            bool done = false;
            for (int i = uriPath.Length - 1; !done && i > 0; i--)
            {
                switch (uriPath[i])
                {
                    case '/':
                    case ':':
                        done = true;
                        break;
                    case '.':
                        if (sawDot)
                        {
                            throw new VCInvalidPathException(
                                string.Format(WSS2TFSResources.Culture, WSS2TFSResources.WSSPathContainsDoubleDot,
                                uriPath
                                ));
                        }
                        break;
                    default:
                        done = sawDot;
                        break;
                }
            }

            if (uriPath.Length > 260)
            {
                throw new VCInvalidPathException(
                    string.Format(WSS2TFSResources.Culture, WSS2TFSResources.PathTooLong,
                    uriPath, 260
                    ));
            }

            Uri uri = new Uri(uriPath);
            foreach (string segment in uri.Segments)
            {
                if (segment.Length > 128)
                {
                    throw new VCInvalidPathException(
                        string.Format(WSS2TFSResources.Culture, WSS2TFSResources.PathSegmentTooLong,
                        uriPath, 128
                        ));
                }
            }
        }

        private string getWssPathFromTfsPath(string serverPath)
        {
            VersionControlMapping m = Util.FindAppropriateMappingForServerPath(serverPath, m_session);

            if (m != null)
            {
                string relativePath = serverPath.Substring(m.Target.Length).TrimStart(new char[] { '/' });
                string urlRoot = m.Source;
                if (!urlRoot.EndsWith("/"))
                {
                    urlRoot += "/";
                }

                string result = urlRoot + relativePath;
                validateWssPath(result);

                return result;
            }

            return null;
        }

        protected override bool IsItemMapped(Item tfsItem)
        {
            string wssPath = getWssPathFromTfsPath(tfsItem.ServerItem);

            if (!string.IsNullOrEmpty(wssPath))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Given a rename change, change the TargetTargetItem to a temp name that�s guaranteed to be unique on the system
        /// </summary>
        /// <param name="renameChange">The rename change to be revised</param>
        /// <param name="group">The ChangeGrouping</param>
        /// <returns>The revised rename change, it contains the new rename change and the original TargetTargetItem</returns>
        internal RevisedRename ReviseRename(Change renameChange, ChangeGrouping group)
        {
            IMigrationAction action = group.CreateAction();

            action.ItemType = renameChange.Item.ItemType;

            action.SourceItem = new TfsMigrationItem(renameChange.Item, Session);

            Item previous = renameChange.Item.VersionControlServer.GetItem(renameChange.Item.ItemId, renameChange.Item.ChangesetId - 1, false);

            action.TargetSourceItem = CreateItemIfMapped(previous);
            action.TargetTargetItem = CreateRevisedRenameMigrationItem(renameChange.Item);

            // if the source item of the rename is null it is not mapped.  If it's not mapped
            // we simply perform an add.
            if (action.TargetSourceItem != null)
            {
                action.Action = ChangeAction.Rename;
            }
            else
            {
                action.Action = ChangeAction.Add;
            }
            group.AddAction(action);

            return new RevisedRename(renameChange, (WssMigrationItem)action.TargetTargetItem);
        }

        /// <summary>
        /// Given a revised rename change, this method will add a new rename from the new unique TargetTargetItem to 
        /// the original TargetTargetItem
        /// </summary>
        /// <param name="revisedRename">The revised rename to be recovered</param>
        /// <param name="group">The ChangeGrouping</param>
        internal void RecoverRevisedRename(RevisedRename revisedRename, ChangeGrouping group)
        {
            IMigrationAction action = group.CreateAction();

            action.ItemType = revisedRename.RenameChange.Item.ItemType;

            action.SourceItem = new TfsMigrationItem(revisedRename.RenameChange.Item, Session);

            action.TargetSourceItem = revisedRename.TempItem;
            action.TargetTargetItem = CreateMigrationItem(revisedRename.RenameChange.Item);

            action.Action = ChangeAction.Rename;
            group.AddAction(action);

            if ((revisedRename.RenameChange.ChangeType & ChangeType.Edit)!= 0)
            {
                Edit(revisedRename.RenameChange, group);
            }
            if ((revisedRename.RenameChange.ChangeType & ChangeType.Branch)!= 0)
            {
                Branch(revisedRename.RenameChange, group);
            }
            if ((revisedRename.RenameChange.ChangeType & ChangeType.Merge)!= 0)
            {
                Merge(revisedRename.RenameChange, group);
            }
        }


        private IMigrationItem CreateRevisedRenameMigrationItem(Item tfsItem)
        {
            string wssPath = getWssPathFromTfsPath(tfsItem.ServerItem);

            if (!string.IsNullOrEmpty(wssPath))
            {
                string revisedWssPath = wssPath.Substring(0, wssPath.Length - 1) + Guid.NewGuid() + wssPath.Substring(wssPath.Length - 1);
                return new WssMigrationItem(revisedWssPath, -1);
            }

            return null;
        }

        protected override IMigrationItem CreateMigrationItem(Item tfsItem)
        {
            string wssPath = getWssPathFromTfsPath(tfsItem.ServerItem);

            if (!string.IsNullOrEmpty(wssPath))
            {
                return new WssMigrationItem(wssPath, -1);
            }

            return null;
        }

        protected override VersionControlSession Session
        {
            get 
            {
                return m_session;
            }
        }
        #region Override algorithms in base class
        /// <summary>
        /// Undelete on wss is simply treated as Add. So renameUndelete is just Add on WSS
        /// </summary>
        /// <param name="change">The change being processed</param>
        /// <param name="grouping">The change grouing this change is to be a part of</param>
        public override void RenameUndelete(Change change, ChangeGrouping grouping)
        {
            base.Add(change, grouping);
        }

        /// <summary>
        /// Undelete on wss is simply treated as Add. So EditUndelete is just Add on WSS
        /// </summary>
        /// <param name="change">The change being processed</param>
        /// <param name="grouping">The change grouing this change is to be a part of</param>
        public override void EditUndelete(Change change, ChangeGrouping grouping)
        {
            base.Add(change, grouping);
        }

        /// <summary>
        /// Undelete on wss is simply treated as Add. 
        /// </summary>
        /// <param name="change">The change being processed</param>
        /// <param name="grouping">The change grouing this change is to be a part of</param>
        public override void Undelete(Change change, ChangeGrouping grouping)
        {
            base.Add(change, grouping);
        }
        #endregion
    }
}
