-- Copyright (c) Microsoft Corporation. All rights reserved.

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* This table is the master record of the latest known WSS items for which have created
 * analysis actions (i.e. we don't need to consider any more */
 
CREATE TABLE [dbo].[WSSMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,		-- the ID of the row.
	[SessionID] [nvarchar](max) NOT NULL,	-- the active session
	[FileID] [int] NOT NULL,				-- ows_ID 
	[LatestVersion] int NOT NULL,			-- ows_owshiddenversion 
	[FilePath] [nvarchar](260) NOT NULL,	-- ows_FileRef
	[FileName] [nvarchar](128) NOT NULL,	-- ows_FileLeafRef
	[ParentPath] [nvarchar](260) NOT NULL,	-- ows_FileDirRef
	[FSObjectType] [int] NOT NULL,          -- ows_FSObjectType, 0-file, 1-folder
	[Modified] [datetime] NOT NULL,         -- ows_Modified
	[Editor][nvarchar](max) NOT NULL        -- ows_Editor
)
GO

/* this table represents the current actions the analysis engine has identified.  the delta
 * between this table and WSSMaster is the basis for the list of actions that need to be performed */

CREATE TABLE [dbo].[WSSCurrent](
	[ID] [int] IDENTITY(1,1) NOT NULL,		-- the ID of the row.
	[SessionID] [nvarchar](max) NOT NULL,	-- the active session
	[FileID] [int] NOT NULL,				-- ows_ID 
	[LatestVersion] int NOT NULL,			-- ows_owshiddenversion 
	[FilePath] [nvarchar](260) NOT NULL,	-- ows_FileRef
	[FileName] [nvarchar](128) NOT NULL,	-- ows_FileLeafRef
	[ParentPath] [nvarchar](260) NOT NULL,	-- ows_FileDirRef
	[FSObjectType] [int] NOT NULL,          -- ows_FSObjectType, 0-file, 1-folder
	[Modified] [datetime] NOT NULL,         -- ows_Modified
	[Editor][nvarchar](max) NOT NULL        -- ows_Editor
)
GO
