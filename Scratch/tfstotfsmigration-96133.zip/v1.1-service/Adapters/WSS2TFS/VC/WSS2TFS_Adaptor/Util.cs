// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.Teamfoundation.Migration.VersionControl.SharePoint.Versions;
using System.Data.SqlClient;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    internal static class Util
    {
        public static VersionControlMapping FindAppropriateMappingForDocumentUrl(string documentUrl, VersionControlSession session)
        {
            if (string.IsNullOrEmpty(documentUrl))
            {
                throw new ArgumentNullException("documentUrl");
            }

            if (session == null)
            {
                throw new ArgumentNullException("session");
            }

            VersionControlMapping mostSpecificMapping = null;

            foreach (VersionControlMapping current in session.Mappings)
            {
                if (documentUrl.StartsWith(
                    current.Source,
                    StringComparison.InvariantCultureIgnoreCase))
                {
                    // if it's the first option we've seen or if the mapping is more specific than
                    // the previously most specific - make it the most specific
                    if (mostSpecificMapping == null ||
                        current.Source.StartsWith(mostSpecificMapping.Source, StringComparison.InvariantCultureIgnoreCase))
                    {
                        mostSpecificMapping = current;
                    }

                }
            }

            if (mostSpecificMapping != null)
            {
                return mostSpecificMapping.Cloak ? null : mostSpecificMapping;
            }

            return null;
        }

        public static VersionControlMapping FindAppropriateMappingForServerPath(string serverPath, VersionControlSession session)
        {
            if (string.IsNullOrEmpty(serverPath))
            {
                throw new ArgumentNullException("serverPath");
            }

            if (session == null)
            {
                throw new ArgumentNullException("session");
            }

            VersionControlMapping mostSpecificMapping = null;

            foreach (VersionControlMapping current in session.Mappings)
            {
                if (TFStringComparer.VersionControlPath.StartsWith(serverPath, current.Target))
                {
                    // if it's the first option we've seen or if the mapping is more specific than
                    // the previously most specific - make it the most specific
                    if (mostSpecificMapping == null || 
                        current.Target.StartsWith(mostSpecificMapping.Target, StringComparison.InvariantCultureIgnoreCase))
                    {
                        mostSpecificMapping = current;
                    }
                }
            }

            if (mostSpecificMapping != null)
            {
                return mostSpecificMapping.Cloak ? null : mostSpecificMapping;
            }

            return null;
        }

        public static Versions GetVersionsServiceForUrl(string documentUrl, VersionControlSession session)
        {
            Versions vers = null;

            VersionControlMapping m = FindAppropriateMappingForDocumentUrl(documentUrl, session);

            if (m != null)
            {
                vers = new Versions(((WssProvider)(session.Source)).BaseUrl);
                vers.UseDefaultCredentials = true;
                vers.UnsafeAuthenticatedConnectionSharing = true;
            }

            return vers;
        }

        internal static void CreateWssSchema()
        {
            using (SqlConnection conn = DataAccessManager.Current.GetSqlConnection())
            {
                conn.Open();

                if (!SqlUtil.DoesProcExist("prc_iiCreateWssListItem", conn))
                {
                    SqlUtil.ExecuteNamedResource(
                        "Microsoft.TeamFoundation.Migration.VersionControl.Wss.SQL.WSSMigrationSchema.sql", conn);

                    SqlUtil.ExecuteNamedResource(
                        "Microsoft.TeamFoundation.Migration.VersionControl.Wss.SQL.WSSMigrationSprocs.sql", conn);
                }
            }
        }
    }
}
