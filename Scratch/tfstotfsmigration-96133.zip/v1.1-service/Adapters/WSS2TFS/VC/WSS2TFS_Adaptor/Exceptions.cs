// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Runtime.Serialization;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    [Serializable]
    class WssItemNotDownloadedException : VersionControlMigrationException
    {
        public WssItemNotDownloadedException()
            : base(WSS2TFSResources.UnableToDownloadWssItem)
        {
        }

        public WssItemNotDownloadedException(string message)
            : base(message)
        {
        }

        public WssItemNotDownloadedException(Exception innerException)
            : base(WSS2TFSResources.UnableToDownloadWssItem , innerException)
        {
        }

        public WssItemNotDownloadedException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected WssItemNotDownloadedException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
