// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Globalization;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    public static class XmlHelper
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
        public static T LoadAttribute<T>(XmlReader reader, string attribute, bool throwOnMissing, IFormatProvider culture)
        {
            if (reader.HasAttributes)
            {
                string attribString = reader.GetAttribute(attribute);
                if (attribString != null)
                {
                    return (T)Convert.ChangeType(attribString, typeof(T), culture);
                }
            }

            if (throwOnMissing)
            {
                throw new MigrationException("Missing attrbibute");
            }

            return default(T);
        }
    }
}
