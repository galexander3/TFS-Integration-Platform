// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Globalization;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    internal class DateTimeHighWaterMark : HighWaterMark<DateTime>
    {
        internal DateTimeHighWaterMark(VersionControlSession session, string name)
            : base(session, name, new DateTime(0, DateTimeKind.Utc))
        {
        }

        protected override string GetValueAsString(DateTime value)
        {
            if (value.Kind == DateTimeKind.Local)
            {
                value = value.ToUniversalTime();
            }

            return value.Ticks.ToString(CultureInfo.InvariantCulture);
        }

        protected override DateTime CreateValueFromString(string str)
        {
            return new DateTime(long.Parse(str, CultureInfo.InvariantCulture), DateTimeKind.Utc);
        }
    }
}
