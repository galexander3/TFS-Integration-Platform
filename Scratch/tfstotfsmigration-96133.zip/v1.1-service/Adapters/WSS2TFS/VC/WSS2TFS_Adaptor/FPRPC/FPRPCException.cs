// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Runtime.Serialization;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    [Serializable]
    public class FPRpcException : VersionControlMigrationException
    {
        public FPRpcException()
            : base(WSS2TFSResources.UnknownFPRPCException)
        {
        }

        public FPRpcException(string message)
            : base(message)
        {
        }

        public FPRpcException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public FPRpcException(VermeerRpcStatusResult result)
            : this((result != null) ? result.Message : WSS2TFSResources.UnknownFPRPCException, 
            result)
        {
        }

        public FPRpcException(string message, VermeerRpcStatusResult result)
            : base(message)
        {
            m_result = result;
        }

        protected FPRpcException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public VermeerRpcStatusResult StatusResult
        {
            get
            {
                return m_result;
            }
        }
        [NonSerializedAttribute]
        VermeerRpcStatusResult m_result;
    }
}
