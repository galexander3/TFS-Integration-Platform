// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    public class VermeerParagraph
    {
        internal VermeerParagraph(string name, string value)
        {
            m_name = name;
            m_value = value;
            m_lists = new Collection<VermeerList>();
        }

        public string Name
        {
            get
            {
                return m_name;
            }
        }

        public string Value
        {
            get
            {
                return m_value;
            }
        }

        public Collection<VermeerList> Lists
        {
            get
            {
                return m_lists;
            }
        }

        Collection<VermeerList> m_lists;
        string m_name;
        string m_value;
    }

    public class VermeerList
    {
        internal VermeerList(string name, bool isMetaInfo)
        {
            m_isMetaInfo = isMetaInfo;
            m_name = name;
            m_lists = new Collection<VermeerList>();
            m_items = new List<VermeerListItem>();
        }

        public string Name
        {
            get
            {
                return m_name;
            }
        }

        public Collection<VermeerList> Lists
        {
            get
            {
                return m_lists;
            }
        }

        public ReadOnlyCollection<VermeerListItem> Items
        {
            get
            {
                return m_items.AsReadOnly();
            }
        }

        internal VermeerListItem AddItem(string name, string value)
        {
            VermeerListItem item;

            if (m_isMetaInfo)
            {
                if (m_needMetaValue)
                {
                    m_currentMetaItem.Value = stripTypeIndicator(name);
                    m_needMetaValue = false;
                    m_currentMetaItem = null;
                }
                else
                {
                    m_currentMetaItem = new VermeerListItem(name, null);
                    m_items.Add(m_currentMetaItem);
                    m_needMetaValue = true;
                }

                item = m_currentMetaItem;
            }
            else
            {
                item = new VermeerListItem(name, value);
                m_items.Add(item);
            }

            return item;
        }

        private static string stripTypeIndicator(string metaValue)
        {
            if (string.IsNullOrEmpty(metaValue))
            {
                return string.Empty;
            }

            int pipeIndex = metaValue.IndexOf('|');
            Debug.Assert(pipeIndex != -1);

            if (pipeIndex != -1)
            {
                if (pipeIndex == metaValue.Length -1)
                {
                    metaValue = string.Empty;
                }
                else
                {
                    metaValue = metaValue.Substring(pipeIndex+1);
                }
            }

            return metaValue;
        }

        List<VermeerListItem> m_items;
        Collection<VermeerList> m_lists;
        string m_name;
        bool m_isMetaInfo;
        bool m_needMetaValue;
        VermeerListItem m_currentMetaItem;
    }

    public class VermeerListItem
    {
        internal VermeerListItem(string name, string value)
        {
            m_name = name;
            m_value = value;
        }

        public string Name
        {
            get
            {
                return m_name;
            }
        }

        public string Value
        {
            get
            {
                return m_value;
            }
            internal set
            {
                m_value = value;
            }
        }

        string m_name;
        string m_value;
    }
}
