// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Globalization;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    public class VermeerRpcStatusResult
    {
        public VermeerRpcStatusResult(VermeerRpcResult result)
        {
            if (result == null)
            {
                throw new ArgumentNullException("result");
            }
            if (result.IsStatusPacket)
            {
                load(result);
            }
            else
            {
                throw new FPRpcException(WSS2TFSResources.NotAStatusPacket);
            }
        }

        public int Status
        {
            get
            {
                return m_status;
            }
        }

        public int OSStatus
        {
            get
            {
                return m_osStatus;
            }
        }

        public string Message
        {
            get
            {
                return m_msg;
            }
        }

        public string OSMessage
        {
            get
            {
                return m_osMsg;
            }
        }

        public string Method
        {
            get
            {
                return m_method;
            }
        }

        private void load(VermeerRpcResult result)
        {
            foreach (VermeerParagraph p in result.Paragraphs)
            {
                if (p.Name == "method")
                {
                    m_method = p.Value;
                }
                else if (p.Name == "status")
                {
                    Debug.Assert(p.Lists != null);
                    Debug.Assert(p.Lists.Count == 1);
                    Debug.Assert(p.Lists[0].Items.Count == 4);

                    foreach (VermeerListItem item in p.Lists[0].Items)
                    {
                        switch (item.Name)
                        {
                            case "status":
                                if (!string.IsNullOrEmpty(item.Value))
                                {
                                    m_status = int.Parse(item.Value, CultureInfo.InvariantCulture);
                                }
                                break;
                            case "osstatus":
                                if (!string.IsNullOrEmpty(item.Value))
                                {
                                    m_osStatus = int.Parse(item.Value, CultureInfo.InvariantCulture);
                                }
                                break;
                            case "msg":
                                m_msg = item.Value;
                                break;
                            case "osmsg":
                                m_osMsg = item.Value;
                                break;
                            default:
                                throw new MigrationException(
                                    string.Format(CultureInfo.InvariantCulture, "Unexpected packet list item {0}={1}",
                                    item.Name, item.Value));
                        }
                    }
                }
            }
        }

        string m_method;
        int m_status;
        int m_osStatus;
        string m_msg;
        string m_osMsg;
    }
}
