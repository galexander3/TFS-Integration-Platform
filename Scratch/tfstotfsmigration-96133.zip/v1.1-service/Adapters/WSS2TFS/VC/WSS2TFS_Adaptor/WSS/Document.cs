// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Xml;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Collections.ObjectModel;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    public class Document
    {
        internal Document(XmlNode node, CultureInfo culture)
        {
            m_versions= new List<DocumentVersion>();
            m_culture = culture;
            try
            {
                using (XmlNodeReader reader = new XmlNodeReader(node))
                {
                    bool empty = reader.IsEmptyElement;
                    reader.Read();
                    if (!empty)
                    {
                        if (reader.Name == "results")
                        {
                            LoadFromXml(reader);
                        }
                    }
                }
            }
            catch (FormatException ex)
            {
                throw new VersionControlMigrationException(string.Format(WSS2TFSResources.Culture, WSS2TFSResources.ErrorLanguageId, culture.LCID), ex, false);
            }
        }

        private void LoadFromXml(XmlReader reader)
        {
            bool empty = reader.IsEmptyElement;
            if (reader.NodeType != XmlNodeType.Element)
            {
                throw new ArgumentException("Expected a node");
            }

            reader.Read();
            if (!empty)
            {
                while (reader.NodeType == XmlNodeType.Element)
                {
                    switch (reader.Name)
                    {
                        case "list":
                            LoadListFromXml(reader);
                            break;
                        case "versioning":
                            LoadVersioningFromXml(reader);
                            break;
                        case "settings":
                            LoadSettingsFromXml(reader);
                            break;
                        case "result":
                            Versions.Add(new DocumentVersion(reader, this));
                            break;
                        default:
                            throw new MigrationException("Unexpected name");
                    }

                    reader.Read();
                }
            }

            // sort so that versions are returned in action order
            m_versions.Sort(delegate(DocumentVersion lhs, DocumentVersion rhs)
            {
                return lhs.Version.CompareTo(rhs.Version);
            }
            );
        }

        private void LoadSettingsFromXml(XmlReader reader)
        {
            // <settings url="http://rhorvickdev/_layouts/1033/LstSetng.aspx?List={72FF4828-FF74-43BD-97F6-E6DEFC18D601}" />
            m_settingsUri = new Uri(XmlHelper.LoadAttribute<string>(reader, "url", true, Culture));
        }

        private void LoadVersioningFromXml(XmlReader reader)
        {
            // <versioning enabled="1" />
            m_versioning = XmlHelper.LoadAttribute<int>(reader, "enabled", true, Culture) == 1;
        }

        private void LoadListFromXml(XmlReader reader)
        {
            // <list id="{72FF4828-FF74-43BD-97F6-E6DEFC18D601}" />
            m_listId = XmlHelper.LoadAttribute<string>(reader, "id", true, Culture);
        }

        public IList<DocumentVersion> Versions
        {
            get
            {
                return m_versions;
            }
        }

        public bool Versioning
        {
            get
            {
                return m_versioning;
            }
        }

        public string ListId
        {
            get
            {
                return m_listId;
            }
        }

        public Uri SettingsUri
        {
            get
            {
                return m_settingsUri;
            }
        }

        public CultureInfo Culture
        {
            get
            {
                return m_culture;
            }
        }


        List<DocumentVersion> m_versions;
        bool m_versioning;
        string m_listId;
        Uri m_settingsUri;
        CultureInfo m_culture;


    }
}
