// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Xml.Serialization;
using System.IO;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    public class WssProviderFactory : IConfigFactory
    {
        #region IConfigFactory Members

        public object CreateInstance(Type type, string xmlFragment)
        {
            if (type == typeof(IVersionControlEndpoint))
            {
                using (StringReader sr = new StringReader(xmlFragment))
                {
                    XmlSerializer xs = new XmlSerializer(typeof(WssProvider));
                    return xs.Deserialize(sr);
                }
            }
            else if (type == typeof(IMigrationProvider))
            {
                return new Session();
            }

            return null;
        }

        #endregion
    }
}
