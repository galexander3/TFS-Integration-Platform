// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Globalization;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    public class DocumentVersion
    {
        public DocumentVersion(XmlReader reader, Document document)
        {
            m_document = document;
            LoadFromXml(reader);
        }

        private void LoadFromXml(XmlReader reader)
        {
            /* <result 
             *  version="@1" 
             *  url="http://rhorvickdev/Shared Documents/Folder2/Branching a directory tree with.doc" 
             *  created="6/19/2006 3:03 PM" 
             *  createdBy="NORTHAMERICA\\rhorvick" 
             *  size="44544" 
             *  comments="" />
             * 
             */
            m_uri = Uri.UnescapeDataString(XmlHelper.LoadAttribute<string>(reader, "url", true, Document.Culture));
            m_created = XmlHelper.LoadAttribute<DateTime>(reader, "created", true, Document.Culture);
            m_createdBy = XmlHelper.LoadAttribute<string>(reader, "createdBy", true, Document.Culture);
            m_size = XmlHelper.LoadAttribute<int>(reader, "size", true, Document.Culture);
            m_comment = XmlHelper.LoadAttribute<string>(reader, "comments", true, Document.Culture);

            string versionString = XmlHelper.LoadAttribute<string>(reader, "version", true, Document.Culture);
            if (versionString.StartsWith("@"))
            {
                m_isLatest = true;
                // MOSS 2007 uses "@1.0" format - parse with a double to work around that.
                m_version = (int)double.Parse(versionString.Substring(1), CultureInfo.InvariantCulture);
            }
            else
            {
                m_version = (int)double.Parse(versionString, CultureInfo.InvariantCulture);
            }
        }

        public string CreatedBy
        {
            get
            {
                return m_createdBy;
            }
        }

        public DateTime Created
        {
            get
            {
                return m_created;
            }
        }

        public int Version
        {
            get
            {
                return m_version;
            }
        }

        public bool IsLatest
        {
            get
            {
                return m_isLatest;
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings")]
        public string Url
        {
            get
            {
                return m_uri;
            }
        }

        public string Comment
        {
            get
            {
                return m_comment;
            }
        }

        public long Size
        {
            get
            {
                return m_size;
            }
        }

        public Document Document
        {
            get
            {
                return m_document;
            }
        }


        private string m_createdBy;
        private DateTime m_created;
        private int m_version;
        private bool m_isLatest;
        private string m_uri;
        private string m_comment;
        private long m_size;
        private Document m_document;

    }

}
