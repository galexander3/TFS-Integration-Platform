// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.Teamfoundation.Migration.VersionControl.SharePoint.Webs;

namespace Microsoft.TeamFoundation.Migration.VersionControl.Wss
{
    [XmlType("WSS")]
    public class WssProvider : IVersionControlEndpoint
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings")]
        public string BaseUrl
        {
            get
            {
                return m_baseUrl;
            }
            set
            {
                m_baseUrl = (value == null) ? null : Uri.EscapeUriString(value).TrimEnd(new char[] { '/' });
            }
        }

        public string DocumentLibrary
        {
            get
            {
                return m_documentLibrary;
            }
            set
            {
                m_documentLibrary = value;
            }
        }

        public string GmtOffset
        {
            get
            {
                return m_gmtOffset;
            }
            set
            {
                m_gmtOffset = value;
            }
        }
        private string m_baseUrl;
        private string m_documentLibrary;
        private string m_gmtOffset;
    }
}
