﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("TFS Migration and Synchronization Toolkit")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2007")]

[assembly: AssemblyVersion("1.1.31205.01")]
[assembly: AssemblyFileVersion("1.1.31205.01")]

#if EXCLUDE_ASSEMBLY_VERSION_INFO
#else
static class AssemblyVersionInfo
{
    public const string VersionString = "1.1.31205.01";
};
#endif
