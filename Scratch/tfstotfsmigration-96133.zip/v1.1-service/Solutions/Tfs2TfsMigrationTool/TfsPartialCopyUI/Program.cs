using System;
using System.Collections.Generic;
using System.Configuration;
using System.Windows.Forms;
using System.Threading;
using System.Security.Principal;
using Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Common;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);

            try
            {
                // if user disables UAC, this check will detect permission conflict
                if (!IsRunByAdmin())
                {
                    string message = String.Format("{0} must be run by administrator", Application.ProductName);
                    string caption = String.Format("{0} - Error", Application.ProductName);
                    MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.DisplayExceptionToUser(ex, "Error Starting Application.", "Error Starting Application.");
                return;              
            }

            try
            {
                Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                bool selfHost = bool.Parse(config.AppSettings.Settings["SelfHostService"].Value.ToString());

                if (selfHost)
                {
                    string typeName = config.AppSettings.Settings["ServiceAssemblyQualifiedName"].Value;
                    Type type = Type.GetType(typeName);
                    LocalServiceHost.StartService(type);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.DisplayExceptionToUser(ex, "Error Starting Service.", "Error Starting Service.   If you are running on Windows Vista, you must start the program by Right Clicking and selecting 'Run as Administrator'\n\n");
                return;
            }

            try
            {

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MigrationHome());
            }
            catch (Exception ex)
            {
                ExceptionManager.DisplayExceptionToUser(ex, "Error Starting Application.", "Error Starting Application.");
                return;
            }
        }

        static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            ExceptionManager.DisplayExceptionToUser(e.Exception, "Exception Has Occurred.", "");
        }

        static bool IsRunByAdmin()
        {
            AppDomain.CurrentDomain.SetPrincipalPolicy(PrincipalPolicy.WindowsPrincipal);
            WindowsPrincipal principal = Thread.CurrentPrincipal as WindowsPrincipal;
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
    }
}