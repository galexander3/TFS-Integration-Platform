namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client
{
    partial class MigrationHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.grpStartType = new System.Windows.Forms.GroupBox();
            this.optOneWay = new System.Windows.Forms.RadioButton();
            this.optTwoWay = new System.Windows.Forms.RadioButton();
            this.lblSessionList = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chkRefreshEnabled = new System.Windows.Forms.CheckBox();
            this.chkIncludeCompleted = new System.Windows.Forms.CheckBox();
            this.lvwEvents = new System.Windows.Forms.ListView();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader8 = new System.Windows.Forms.ColumnHeader();
            this.btnStopSession = new System.Windows.Forms.Button();
            this.btnGetSessions = new System.Windows.Forms.Button();
            this.lvwRunningSessions = new System.Windows.Forms.ListView();
            this.sessionIdentifier = new System.Windows.Forms.ColumnHeader();
            this.startTime = new System.Windows.Forms.ColumnHeader();
            this.runningTime = new System.Windows.Forms.ColumnHeader();
            this.status = new System.Windows.Forms.ColumnHeader();
            this.startType = new System.Windows.Forms.ColumnHeader();
            this.button2 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.timerRefresh = new System.Windows.Forms.Timer(this.components);
            this.sessionId = new System.Windows.Forms.ColumnHeader();
            this.sessionType = new System.Windows.Forms.ColumnHeader();
            this.sourceProject = new System.Windows.Forms.ColumnHeader();
            this.destProject = new System.Windows.Forms.ColumnHeader();
            this.lvwSessions = new System.Windows.Forms.ListView();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStartMirror = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btnNew = new System.Windows.Forms.Button();
            this.tabMain.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.grpStartType.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabPage1);
            this.tabMain.Controls.Add(this.tabPage2);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(731, 329);
            this.tabMain.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabMain.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(723, 303);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Session Configuration";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // grpStartType
            // 
            this.grpStartType.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.SetColumnSpan(this.grpStartType, 2);
            this.grpStartType.Controls.Add(this.optOneWay);
            this.grpStartType.Controls.Add(this.optTwoWay);
            this.grpStartType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpStartType.Location = new System.Drawing.Point(495, 253);
            this.grpStartType.Margin = new System.Windows.Forms.Padding(2);
            this.grpStartType.Name = "grpStartType";
            this.grpStartType.Padding = new System.Windows.Forms.Padding(2);
            this.grpStartType.Size = new System.Drawing.Size(222, 41);
            this.grpStartType.TabIndex = 11;
            this.grpStartType.TabStop = false;
            this.grpStartType.Text = "Direction";
            this.grpStartType.Enter += new System.EventHandler(this.grpStartType_Enter);
            // 
            // optOneWay
            // 
            this.optOneWay.AutoSize = true;
            this.optOneWay.Checked = true;
            this.optOneWay.Location = new System.Drawing.Point(11, 17);
            this.optOneWay.Margin = new System.Windows.Forms.Padding(2);
            this.optOneWay.Name = "optOneWay";
            this.optOneWay.Size = new System.Drawing.Size(70, 17);
            this.optOneWay.TabIndex = 13;
            this.optOneWay.TabStop = true;
            this.optOneWay.Text = "One-Way";
            this.optOneWay.UseVisualStyleBackColor = true;
            // 
            // optTwoWay
            // 
            this.optTwoWay.AutoSize = true;
            this.optTwoWay.Location = new System.Drawing.Point(83, 17);
            this.optTwoWay.Margin = new System.Windows.Forms.Padding(2);
            this.optTwoWay.Name = "optTwoWay";
            this.optTwoWay.Size = new System.Drawing.Size(77, 17);
            this.optTwoWay.TabIndex = 14;
            this.optTwoWay.Text = "Both Ways";
            this.optTwoWay.UseVisualStyleBackColor = true;
            // 
            // lblSessionList
            // 
            this.lblSessionList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSessionList.AutoSize = true;
            this.lblSessionList.Location = new System.Drawing.Point(3, 7);
            this.lblSessionList.Name = "lblSessionList";
            this.lblSessionList.Size = new System.Drawing.Size(98, 13);
            this.lblSessionList.TabIndex = 5;
            this.lblSessionList.Text = "Migration Sessions:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tableLayoutPanel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(723, 303);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Migration Activity";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // chkRefreshEnabled
            // 
            this.chkRefreshEnabled.AutoSize = true;
            this.chkRefreshEnabled.Checked = true;
            this.chkRefreshEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRefreshEnabled.Location = new System.Drawing.Point(243, 268);
            this.chkRefreshEnabled.Name = "chkRefreshEnabled";
            this.chkRefreshEnabled.Size = new System.Drawing.Size(88, 17);
            this.chkRefreshEnabled.TabIndex = 14;
            this.chkRefreshEnabled.Text = "Auto-Refresh";
            this.chkRefreshEnabled.UseVisualStyleBackColor = true;
            this.chkRefreshEnabled.CheckedChanged += new System.EventHandler(this.chkRefreshEnabled_CheckedChanged);
            // 
            // chkIncludeCompleted
            // 
            this.chkIncludeCompleted.AutoSize = true;
            this.chkIncludeCompleted.Location = new System.Drawing.Point(3, 268);
            this.chkIncludeCompleted.Name = "chkIncludeCompleted";
            this.chkIncludeCompleted.Size = new System.Drawing.Size(159, 17);
            this.chkIncludeCompleted.TabIndex = 13;
            this.chkIncludeCompleted.Text = "Include Completed Sessions";
            this.chkIncludeCompleted.UseVisualStyleBackColor = true;
            // 
            // lvwEvents
            // 
            this.lvwEvents.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.tableLayoutPanel2.SetColumnSpan(this.lvwEvents, 4);
            this.lvwEvents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwEvents.FullRowSelect = true;
            this.lvwEvents.Location = new System.Drawing.Point(3, 136);
            this.lvwEvents.MultiSelect = false;
            this.lvwEvents.Name = "lvwEvents";
            this.lvwEvents.ShowItemToolTips = true;
            this.lvwEvents.Size = new System.Drawing.Size(713, 126);
            this.lvwEvents.TabIndex = 12;
            this.lvwEvents.UseCompatibleStateImageBehavior = false;
            this.lvwEvents.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Event Type";
            this.columnHeader6.Width = 126;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Description";
            this.columnHeader7.Width = 227;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Event Time";
            this.columnHeader8.Width = 197;
            // 
            // btnStopSession
            // 
            this.btnStopSession.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnStopSession.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStopSession.Location = new System.Drawing.Point(607, 268);
            this.btnStopSession.Name = "btnStopSession";
            this.btnStopSession.Size = new System.Drawing.Size(109, 24);
            this.btnStopSession.TabIndex = 11;
            this.btnStopSession.Text = "&Stop Session";
            this.btnStopSession.UseVisualStyleBackColor = true;
            this.btnStopSession.Click += new System.EventHandler(this.btnStopSession_Click);
            // 
            // btnGetSessions
            // 
            this.btnGetSessions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnGetSessions.Location = new System.Drawing.Point(483, 268);
            this.btnGetSessions.Name = "btnGetSessions";
            this.btnGetSessions.Size = new System.Drawing.Size(118, 24);
            this.btnGetSessions.TabIndex = 1;
            this.btnGetSessions.Text = "&Refresh";
            this.btnGetSessions.UseVisualStyleBackColor = true;
            this.btnGetSessions.Click += new System.EventHandler(this.btnGetSessions_Click);
            // 
            // lvwRunningSessions
            // 
            this.lvwRunningSessions.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.sessionIdentifier,
            this.startTime,
            this.runningTime,
            this.status,
            this.startType});
            this.tableLayoutPanel2.SetColumnSpan(this.lvwRunningSessions, 4);
            this.lvwRunningSessions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwRunningSessions.FullRowSelect = true;
            this.lvwRunningSessions.HideSelection = false;
            this.lvwRunningSessions.Location = new System.Drawing.Point(3, 3);
            this.lvwRunningSessions.MultiSelect = false;
            this.lvwRunningSessions.Name = "lvwRunningSessions";
            this.lvwRunningSessions.Size = new System.Drawing.Size(713, 127);
            this.lvwRunningSessions.TabIndex = 0;
            this.lvwRunningSessions.UseCompatibleStateImageBehavior = false;
            this.lvwRunningSessions.View = System.Windows.Forms.View.Details;
            this.lvwRunningSessions.SelectedIndexChanged += new System.EventHandler(this.lvwRunningSessions_SelectedIndexChanged);
            // 
            // sessionIdentifier
            // 
            this.sessionIdentifier.Text = "Session ID";
            this.sessionIdentifier.Width = 79;
            // 
            // startTime
            // 
            this.startTime.Text = "Start Time";
            this.startTime.Width = 127;
            // 
            // runningTime
            // 
            this.runningTime.Text = "Running Time";
            this.runningTime.Width = 128;
            // 
            // status
            // 
            this.status.Text = "Current Status";
            this.status.Width = 101;
            // 
            // startType
            // 
            this.startType.Text = "Start Type";
            this.startType.Width = 112;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(7, 17);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "&Retreive Sessions";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listView1.Location = new System.Drawing.Point(6, 46);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(574, 174);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Session ID";
            this.columnHeader1.Width = 89;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Session Type";
            this.columnHeader2.Width = 110;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Start Time";
            this.columnHeader3.Width = 127;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Running Time";
            this.columnHeader4.Width = 128;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Start Type";
            this.columnHeader5.Width = 112;
            // 
            // timerRefresh
            // 
            this.timerRefresh.Enabled = true;
            this.timerRefresh.Interval = 3000;
            this.timerRefresh.Tick += new System.EventHandler(this.timerRefresh_Tick);
            // 
            // sessionId
            // 
            this.sessionId.Text = "Session";
            this.sessionId.Width = 108;
            // 
            // sessionType
            // 
            this.sessionType.Text = "Type";
            this.sessionType.Width = 128;
            // 
            // sourceProject
            // 
            this.sourceProject.Text = "Source";
            this.sourceProject.Width = 228;
            // 
            // destProject
            // 
            this.destProject.Text = "Destination";
            this.destProject.Width = 234;
            // 
            // lvwSessions
            // 
            this.lvwSessions.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lvwSessions.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.sessionId,
            this.sessionType,
            this.sourceProject,
            this.destProject});
            this.tableLayoutPanel1.SetColumnSpan(this.lvwSessions, 5);
            this.lvwSessions.FullRowSelect = true;
            this.lvwSessions.HideSelection = false;
            this.lvwSessions.Location = new System.Drawing.Point(3, 23);
            this.lvwSessions.MultiSelect = false;
            this.lvwSessions.Name = "lvwSessions";
            this.lvwSessions.Size = new System.Drawing.Size(713, 195);
            this.lvwSessions.TabIndex = 1;
            this.lvwSessions.UseCompatibleStateImageBehavior = false;
            this.lvwSessions.View = System.Windows.Forms.View.Details;
            // 
            // btnDelete
            // 
            this.btnDelete.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDelete.Location = new System.Drawing.Point(115, 223);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(109, 26);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "&Delete...";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnStart
            // 
            this.btnStart.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStart.Location = new System.Drawing.Point(495, 223);
            this.btnStart.Margin = new System.Windows.Forms.Padding(2);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(109, 26);
            this.btnStart.TabIndex = 13;
            this.btnStart.Text = "Start &One Time";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStartMirror
            // 
            this.btnStartMirror.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnStartMirror.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStartMirror.Location = new System.Drawing.Point(608, 223);
            this.btnStartMirror.Margin = new System.Windows.Forms.Padding(2);
            this.btnStartMirror.Name = "btnStartMirror";
            this.btnStartMirror.Size = new System.Drawing.Size(109, 26);
            this.btnStartMirror.TabIndex = 14;
            this.btnStartMirror.Text = "Start &Mirror";
            this.btnStartMirror.UseVisualStyleBackColor = true;
            this.btnStartMirror.Click += new System.EventHandler(this.btnStartMirror_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.btnDelete, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblSessionList, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lvwSessions, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnStartMirror, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnStart, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.grpStartType, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnNew, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(719, 299);
            this.tableLayoutPanel1.TabIndex = 19;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AutoSize = true;
            this.tableLayoutPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.chkIncludeCompleted, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.chkRefreshEnabled, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.lvwRunningSessions, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lvwEvents, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.btnStopSession, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.btnGetSessions, 2, 2);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.99999F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 3F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(719, 299);
            this.tableLayoutPanel2.TabIndex = 15;
            // 
            // btnNew
            // 
            this.btnNew.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnNew.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNew.Location = new System.Drawing.Point(2, 223);
            this.btnNew.Margin = new System.Windows.Forms.Padding(2);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(109, 26);
            this.btnNew.TabIndex = 15;
            this.btnNew.Text = "&New...";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // MigrationHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(731, 329);
            this.Controls.Add(this.tabMain);
            this.Name = "MigrationHome";
            this.RightToLeftLayout = true;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Team Foundation Server: TFS to TFS Migration Tool";
            this.Activated += new System.EventHandler(this.MigrationHome_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MigrationHome_FormClosing);
            this.Load += new System.EventHandler(this.MigrationHome_Load);
            this.tabMain.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.grpStartType.ResumeLayout(false);
            this.grpStartType.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblSessionList;
        private System.Windows.Forms.DataGridViewTextBoxColumn vCSessionNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sourceServerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sourceProjectDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destServerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destProjectDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sourceFolderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destFolderDataGridViewTextBoxColumn;
        private System.Windows.Forms.ListView lvwRunningSessions;
        private System.Windows.Forms.ColumnHeader sessionIdentifier;
        private System.Windows.Forms.Button btnGetSessions;
        private System.Windows.Forms.ColumnHeader startTime;
        private System.Windows.Forms.ColumnHeader runningTime;
        private System.Windows.Forms.ColumnHeader startType;
        private System.Windows.Forms.Button btnStopSession;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.GroupBox grpStartType;
        private System.Windows.Forms.RadioButton optTwoWay;
        private System.Windows.Forms.RadioButton optOneWay;
        private System.Windows.Forms.Timer timerRefresh;
        private System.Windows.Forms.ListView lvwEvents;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.CheckBox chkIncludeCompleted;
        private System.Windows.Forms.ColumnHeader status;
        private System.Windows.Forms.CheckBox chkRefreshEnabled;
        private System.Windows.Forms.Button btnStartMirror;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.ListView lvwSessions;
        private System.Windows.Forms.ColumnHeader sessionId;
        private System.Windows.Forms.ColumnHeader sessionType;
        private System.Windows.Forms.ColumnHeader sourceProject;
        private System.Windows.Forms.ColumnHeader destProject;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btnNew;
    }
}
