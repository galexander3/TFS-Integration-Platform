namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Screens
{
    partial class ConfigureVCMapping
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpSource = new System.Windows.Forms.GroupBox();
            this.vcPickerSource = new Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls.VCFolderPicker();
            this.grpDestFolder = new System.Windows.Forms.GroupBox();
            this.vcPickerDest = new Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls.VCFolderPicker();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.grpExclude = new System.Windows.Forms.GroupBox();
            this.chkExclude = new System.Windows.Forms.CheckBox();
            this.grpSource.SuspendLayout();
            this.grpDestFolder.SuspendLayout();
            this.grpExclude.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpSource
            // 
            this.grpSource.Controls.Add(this.vcPickerSource);
            this.grpSource.Location = new System.Drawing.Point(12, 12);
            this.grpSource.Name = "grpSource";
            this.grpSource.Size = new System.Drawing.Size(359, 341);
            this.grpSource.TabIndex = 1;
            this.grpSource.TabStop = false;
            this.grpSource.Text = "1. Select Source Version Control Folder";
            // 
            // vcPickerSource
            // 
            this.vcPickerSource.Location = new System.Drawing.Point(6, 19);
            this.vcPickerSource.Name = "vcPickerSource";
            this.vcPickerSource.Size = new System.Drawing.Size(349, 309);
            this.vcPickerSource.TabIndex = 0;
            this.vcPickerSource.TeamProjectName = null;
            this.vcPickerSource.TfsServerName = null;
            // 
            // grpDestFolder
            // 
            this.grpDestFolder.Controls.Add(this.vcPickerDest);
            this.grpDestFolder.Location = new System.Drawing.Point(373, 12);
            this.grpDestFolder.Name = "grpDestFolder";
            this.grpDestFolder.Size = new System.Drawing.Size(385, 341);
            this.grpDestFolder.TabIndex = 2;
            this.grpDestFolder.TabStop = false;
            this.grpDestFolder.Text = "2. Select Destination Version Control Folder";
            // 
            // vcPickerDest
            // 
            this.vcPickerDest.Location = new System.Drawing.Point(7, 18);
            this.vcPickerDest.Name = "vcPickerDest";
            this.vcPickerDest.Size = new System.Drawing.Size(329, 311);
            this.vcPickerDest.TabIndex = 0;
            this.vcPickerDest.TeamProjectName = null;
            this.vcPickerDest.TfsServerName = null;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(682, 384);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(601, 384);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 4;
            this.btnOK.Text = "&OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 415);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(763, 22);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // grpExclude
            // 
            this.grpExclude.Controls.Add(this.chkExclude);
            this.grpExclude.Location = new System.Drawing.Point(12, 360);
            this.grpExclude.Name = "grpExclude";
            this.grpExclude.Size = new System.Drawing.Size(359, 47);
            this.grpExclude.TabIndex = 6;
            this.grpExclude.TabStop = false;
            this.grpExclude.Text = "(Advanced)  Select to Exclude (Cloak) This Folder";
            // 
            // chkExclude
            // 
            this.chkExclude.AutoSize = true;
            this.chkExclude.Location = new System.Drawing.Point(25, 19);
            this.chkExclude.Name = "chkExclude";
            this.chkExclude.Size = new System.Drawing.Size(64, 17);
            this.chkExclude.TabIndex = 0;
            this.chkExclude.Text = "Exclude";
            this.chkExclude.UseVisualStyleBackColor = true;
            // 
            // ConfigureVCMapping
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(763, 437);
            this.Controls.Add(this.grpExclude);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.grpDestFolder);
            this.Controls.Add(this.grpSource);
            this.Name = "ConfigureVCMapping";
            this.Text = "ConfigureVCMapping";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ConfigureVCMapping_FormClosing);
            this.Load += new System.EventHandler(this.ConfigureVCMapping_Load);
            this.grpSource.ResumeLayout(false);
            this.grpDestFolder.ResumeLayout(false);
            this.grpExclude.ResumeLayout(false);
            this.grpExclude.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls.VCFolderPicker vcPickerSource;
        private System.Windows.Forms.GroupBox grpSource;
        private System.Windows.Forms.GroupBox grpDestFolder;
        private Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls.VCFolderPicker vcPickerDest;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.GroupBox grpExclude;
        private System.Windows.Forms.CheckBox chkExclude;
    }
}