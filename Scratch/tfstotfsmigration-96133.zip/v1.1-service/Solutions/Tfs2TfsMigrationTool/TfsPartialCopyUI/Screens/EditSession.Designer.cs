namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client
{
    partial class EditSession
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabSessionDetails = new System.Windows.Forms.TabControl();
            this.tabVersionControl = new System.Windows.Forms.TabPage();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnAddMapping = new System.Windows.Forms.Button();
            this.lvwMappings = new System.Windows.Forms.ListView();
            this.colSourceFolder = new System.Windows.Forms.ColumnHeader();
            this.colDestFolder = new System.Windows.Forms.ColumnHeader();
            this.colExclude = new System.Windows.Forms.ColumnHeader();
            this.tabWorkItemTracking = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbLinkedVCSession = new System.Windows.Forms.ComboBox();
            this.chkEnableLinking = new System.Windows.Forms.CheckBox();
            this.lblWorkItemFilterDest = new System.Windows.Forms.Label();
            this.txtWorkItemFilterDest = new System.Windows.Forms.TextBox();
            this.txtWorkItemFilterSource = new System.Windows.Forms.TextBox();
            this.lblWorkItemFilterSource = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.grpSessionType = new System.Windows.Forms.GroupBox();
            this.optWorkItems = new System.Windows.Forms.RadioButton();
            this.optVersionControl = new System.Windows.Forms.RadioButton();
            this.teamProjectPickerDest = new Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls.TeamProjectPicker();
            this.teamProjectPickerSource = new Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls.TeamProjectPicker();
            this.tabSessionDetails.SuspendLayout();
            this.tabVersionControl.SuspendLayout();
            this.tabWorkItemTracking.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpSessionType.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabSessionDetails
            // 
            this.tabSessionDetails.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabSessionDetails.Controls.Add(this.tabVersionControl);
            this.tabSessionDetails.Controls.Add(this.tabWorkItemTracking);
            this.tabSessionDetails.Location = new System.Drawing.Point(6, 201);
            this.tabSessionDetails.Name = "tabSessionDetails";
            this.tabSessionDetails.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabSessionDetails.SelectedIndex = 0;
            this.tabSessionDetails.Size = new System.Drawing.Size(601, 187);
            this.tabSessionDetails.TabIndex = 3;
            // 
            // tabVersionControl
            // 
            this.tabVersionControl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabVersionControl.Controls.Add(this.btnRemove);
            this.tabVersionControl.Controls.Add(this.btnAddMapping);
            this.tabVersionControl.Controls.Add(this.lvwMappings);
            this.tabVersionControl.Location = new System.Drawing.Point(4, 25);
            this.tabVersionControl.Name = "tabVersionControl";
            this.tabVersionControl.Padding = new System.Windows.Forms.Padding(3);
            this.tabVersionControl.Size = new System.Drawing.Size(593, 158);
            this.tabVersionControl.TabIndex = 0;
            this.tabVersionControl.Text = "Version Control";
            this.tabVersionControl.UseVisualStyleBackColor = true;
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(524, 43);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(58, 23);
            this.btnRemove.TabIndex = 2;
            this.btnRemove.Text = "&Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnAddMapping
            // 
            this.btnAddMapping.Location = new System.Drawing.Point(524, 13);
            this.btnAddMapping.Name = "btnAddMapping";
            this.btnAddMapping.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnAddMapping.Size = new System.Drawing.Size(57, 23);
            this.btnAddMapping.TabIndex = 1;
            this.btnAddMapping.Text = "&Add...";
            this.btnAddMapping.UseVisualStyleBackColor = true;
            this.btnAddMapping.Click += new System.EventHandler(this.btnAddMapping_Click);
            // 
            // lvwMappings
            // 
            this.lvwMappings.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.lvwMappings.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colSourceFolder,
            this.colDestFolder,
            this.colExclude});
            this.lvwMappings.FullRowSelect = true;
            this.lvwMappings.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvwMappings.HotTracking = true;
            this.lvwMappings.HoverSelection = true;
            this.lvwMappings.Location = new System.Drawing.Point(6, 13);
            this.lvwMappings.Name = "lvwMappings";
            this.lvwMappings.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lvwMappings.Size = new System.Drawing.Size(512, 128);
            this.lvwMappings.TabIndex = 0;
            this.lvwMappings.UseCompatibleStateImageBehavior = false;
            this.lvwMappings.View = System.Windows.Forms.View.Details;
            // 
            // colSourceFolder
            // 
            this.colSourceFolder.Text = "Source Folder";
            this.colSourceFolder.Width = 207;
            // 
            // colDestFolder
            // 
            this.colDestFolder.Text = "Destination Folder";
            this.colDestFolder.Width = 239;
            // 
            // colExclude
            // 
            this.colExclude.Text = "Exclude";
            // 
            // tabWorkItemTracking
            // 
            this.tabWorkItemTracking.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabWorkItemTracking.Controls.Add(this.groupBox1);
            this.tabWorkItemTracking.Controls.Add(this.chkEnableLinking);
            this.tabWorkItemTracking.Controls.Add(this.lblWorkItemFilterDest);
            this.tabWorkItemTracking.Controls.Add(this.txtWorkItemFilterDest);
            this.tabWorkItemTracking.Controls.Add(this.txtWorkItemFilterSource);
            this.tabWorkItemTracking.Controls.Add(this.lblWorkItemFilterSource);
            this.tabWorkItemTracking.Location = new System.Drawing.Point(4, 25);
            this.tabWorkItemTracking.Name = "tabWorkItemTracking";
            this.tabWorkItemTracking.Padding = new System.Windows.Forms.Padding(3);
            this.tabWorkItemTracking.Size = new System.Drawing.Size(593, 158);
            this.tabWorkItemTracking.TabIndex = 1;
            this.tabWorkItemTracking.Text = "Work Items";
            this.tabWorkItemTracking.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbLinkedVCSession);
            this.groupBox1.Location = new System.Drawing.Point(323, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(256, 51);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Linked Version Control Session:";
            // 
            // cmbLinkedVCSession
            // 
            this.cmbLinkedVCSession.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLinkedVCSession.Enabled = false;
            this.cmbLinkedVCSession.FormattingEnabled = true;
            this.cmbLinkedVCSession.ItemHeight = 13;
            this.cmbLinkedVCSession.Location = new System.Drawing.Point(6, 19);
            this.cmbLinkedVCSession.Name = "cmbLinkedVCSession";
            this.cmbLinkedVCSession.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cmbLinkedVCSession.Size = new System.Drawing.Size(235, 21);
            this.cmbLinkedVCSession.TabIndex = 0;
            // 
            // chkEnableLinking
            // 
            this.chkEnableLinking.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkEnableLinking.AutoSize = true;
            this.chkEnableLinking.Location = new System.Drawing.Point(329, 17);
            this.chkEnableLinking.Name = "chkEnableLinking";
            this.chkEnableLinking.Size = new System.Drawing.Size(96, 17);
            this.chkEnableLinking.TabIndex = 5;
            this.chkEnableLinking.Text = "Enable Linking";
            this.chkEnableLinking.UseVisualStyleBackColor = true;
            this.chkEnableLinking.CheckedChanged += new System.EventHandler(this.chkEnableLinking_CheckedChanged);
            // 
            // lblWorkItemFilterDest
            // 
            this.lblWorkItemFilterDest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblWorkItemFilterDest.AutoSize = true;
            this.lblWorkItemFilterDest.Location = new System.Drawing.Point(8, 72);
            this.lblWorkItemFilterDest.Name = "lblWorkItemFilterDest";
            this.lblWorkItemFilterDest.Padding = new System.Windows.Forms.Padding(0, 4, 2, 2);
            this.lblWorkItemFilterDest.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblWorkItemFilterDest.Size = new System.Drawing.Size(219, 19);
            this.lblWorkItemFilterDest.TabIndex = 3;
            this.lblWorkItemFilterDest.Text = "Destination Work Item Filter (blank for none):";
            // 
            // txtWorkItemFilterDest
            // 
            this.txtWorkItemFilterDest.Location = new System.Drawing.Point(11, 94);
            this.txtWorkItemFilterDest.Name = "txtWorkItemFilterDest";
            this.txtWorkItemFilterDest.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtWorkItemFilterDest.Size = new System.Drawing.Size(257, 20);
            this.txtWorkItemFilterDest.TabIndex = 2;
            this.txtWorkItemFilterDest.Text = "[System.WorkItemType]=\'Bug\'";
            // 
            // txtWorkItemFilterSource
            // 
            this.txtWorkItemFilterSource.Location = new System.Drawing.Point(11, 40);
            this.txtWorkItemFilterSource.Name = "txtWorkItemFilterSource";
            this.txtWorkItemFilterSource.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtWorkItemFilterSource.Size = new System.Drawing.Size(259, 20);
            this.txtWorkItemFilterSource.TabIndex = 0;
            this.txtWorkItemFilterSource.Text = "[System.WorkItemType]=\'Bug\'";
            // 
            // lblWorkItemFilterSource
            // 
            this.lblWorkItemFilterSource.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblWorkItemFilterSource.AutoSize = true;
            this.lblWorkItemFilterSource.Location = new System.Drawing.Point(8, 18);
            this.lblWorkItemFilterSource.Name = "lblWorkItemFilterSource";
            this.lblWorkItemFilterSource.Padding = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.lblWorkItemFilterSource.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblWorkItemFilterSource.Size = new System.Drawing.Size(201, 19);
            this.lblWorkItemFilterSource.TabIndex = 1;
            this.lblWorkItemFilterSource.Text = "Source Work Item Filter (blank for none):";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(527, 394);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(442, 394);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // grpSessionType
            // 
            this.grpSessionType.Controls.Add(this.optWorkItems);
            this.grpSessionType.Controls.Add(this.optVersionControl);
            this.grpSessionType.Location = new System.Drawing.Point(6, 3);
            this.grpSessionType.Name = "grpSessionType";
            this.grpSessionType.Size = new System.Drawing.Size(238, 44);
            this.grpSessionType.TabIndex = 6;
            this.grpSessionType.TabStop = false;
            this.grpSessionType.Text = "Session Type";
            // 
            // optWorkItems
            // 
            this.optWorkItems.AutoSize = true;
            this.optWorkItems.Location = new System.Drawing.Point(148, 18);
            this.optWorkItems.Name = "optWorkItems";
            this.optWorkItems.Size = new System.Drawing.Size(79, 17);
            this.optWorkItems.TabIndex = 1;
            this.optWorkItems.TabStop = true;
            this.optWorkItems.Text = "&Work Items";
            this.optWorkItems.UseVisualStyleBackColor = true;
            this.optWorkItems.CheckedChanged += new System.EventHandler(this.optWorkItems_CheckedChanged);
            // 
            // optVersionControl
            // 
            this.optVersionControl.AutoSize = true;
            this.optVersionControl.Checked = true;
            this.optVersionControl.Location = new System.Drawing.Point(12, 18);
            this.optVersionControl.Name = "optVersionControl";
            this.optVersionControl.Size = new System.Drawing.Size(96, 17);
            this.optVersionControl.TabIndex = 0;
            this.optVersionControl.TabStop = true;
            this.optVersionControl.Text = "&Version Control";
            this.optVersionControl.UseVisualStyleBackColor = true;
            this.optVersionControl.CheckedChanged += new System.EventHandler(this.optVersionControl_CheckedChanged_1);
            // 
            // teamProjectPickerDest
            // 
            this.teamProjectPickerDest.GroupBoxTitle = "Destination Team Project";
            this.teamProjectPickerDest.Location = new System.Drawing.Point(248, 49);
            this.teamProjectPickerDest.Name = "teamProjectPickerDest";
            this.teamProjectPickerDest.Size = new System.Drawing.Size(252, 154);
            this.teamProjectPickerDest.TabIndex = 2;
            // 
            // teamProjectPickerSource
            // 
            this.teamProjectPickerSource.GroupBoxTitle = "Source Team Project";
            this.teamProjectPickerSource.Location = new System.Drawing.Point(6, 49);
            this.teamProjectPickerSource.Name = "teamProjectPickerSource";
            this.teamProjectPickerSource.Size = new System.Drawing.Size(238, 154);
            this.teamProjectPickerSource.TabIndex = 1;
            // 
            // EditSession
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 424);
            this.Controls.Add(this.grpSessionType);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.tabSessionDetails);
            this.Controls.Add(this.teamProjectPickerDest);
            this.Controls.Add(this.teamProjectPickerSource);
            this.Name = "EditSession";
            this.Text = "Add/Edit Migration Session";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.EditSession_FormClosing);
            this.Load += new System.EventHandler(this.EditSession_Load);
            this.tabSessionDetails.ResumeLayout(false);
            this.tabVersionControl.ResumeLayout(false);
            this.tabWorkItemTracking.ResumeLayout(false);
            this.tabWorkItemTracking.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.grpSessionType.ResumeLayout(false);
            this.grpSessionType.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls.TeamProjectPicker teamProjectPickerSource;
        private Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls.TeamProjectPicker teamProjectPickerDest;
        private System.Windows.Forms.TabControl tabSessionDetails;
        private System.Windows.Forms.TabPage tabVersionControl;
        private System.Windows.Forms.TabPage tabWorkItemTracking;
        private System.Windows.Forms.ListView lvwMappings;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnAddMapping;
        private System.Windows.Forms.ColumnHeader colSourceFolder;
        private System.Windows.Forms.ColumnHeader colDestFolder;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox grpSessionType;
        private System.Windows.Forms.RadioButton optWorkItems;
        private System.Windows.Forms.RadioButton optVersionControl;
        private System.Windows.Forms.Label lblWorkItemFilterSource;
        private System.Windows.Forms.TextBox txtWorkItemFilterSource;
        private System.Windows.Forms.Label lblWorkItemFilterDest;
        private System.Windows.Forms.TextBox txtWorkItemFilterDest;
        private System.Windows.Forms.ColumnHeader colExclude;
        private System.Windows.Forms.CheckBox chkEnableLinking;
        private System.Windows.Forms.ComboBox cmbLinkedVCSession;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}