using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Screens
{
    public delegate void MappingCompletedEventHandler(object sender, EventArgs e);

    public partial class ConfigureVCMapping : Form
    {
        private bool _sourceFolderSelected = false;
        private bool _destFolderSelected = false;
        private bool _saved = false;

        public event MappingCompletedEventHandler MappingComplete;

        public string SourcePath
        {
            get { return this.vcPickerSource.SelectedPath; }
        }
        public string DestinationPath
        {
            get { return this.vcPickerDest.SelectedPath; }
        }

        public bool Cloak
        {
            get { return this.chkExclude.Checked; }
        }

        public ConfigureVCMapping(string sourceTeamProject, string sourceTfsServer, string destTeamProject, string destTfsServer, bool useStoredCredsSource, bool useStoredCredsDest)
        {
            InitializeComponent();

            this.vcPickerSource.TeamProjectName = sourceTeamProject;
            this.vcPickerSource.TfsServerName = sourceTfsServer;
            this.vcPickerSource.UseStoredCredentials = useStoredCredsSource;
            this.vcPickerSource.InitializeTree();

            this.vcPickerSource.PathChanged += new Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls.PathChangedEventHandler(vcPickerSource_PathChanged);
            this.vcPickerDest.TeamProjectName = destTeamProject;
            this.vcPickerDest.TfsServerName = destTfsServer;
            this.vcPickerDest.UseStoredCredentials = useStoredCredsDest;
            this.vcPickerDest.InitializeTree();

            this.vcPickerDest.PathChanged += new Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls.PathChangedEventHandler(vcPickerDest_PathChanged);
        }

        void vcPickerDest_PathChanged(object sender, EventArgs e)
        {
            _destFolderSelected = true;
            UpdateButtonStatus();
        }

        void vcPickerSource_PathChanged(object sender, EventArgs e)
        {
            _sourceFolderSelected = true;
            UpdateButtonStatus();
        }

        private void ConfigureVCMapping_Load(object sender, EventArgs e)
        {
            btnOK.Enabled = false;
        }

        private void UpdateButtonStatus()
        {
            if (_sourceFolderSelected == true && _destFolderSelected == true)
                btnOK.Enabled = true;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (!_sourceFolderSelected || !_destFolderSelected)
            {
                MessageBox.Show("Please select both a source and a destination path.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (!vcPickerSource.IsValidServerItem(SourcePath))
            {
                MessageBox.Show("Please make sure the source path is a valid path on the source server.", "Invalid Path", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (!vcPickerDest.IsValidServerItem(DestinationPath))
            {
                MessageBox.Show("Please make sure the destination path is a valid path on the destination server.", "Invalid Path", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                _saved = true;
                this.MappingComplete(null, null);
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ConfigureVCMapping_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_saved && MessageBox.Show("Cancel Without Saving?", "Confirm Cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                e.Cancel = true;
        }

    }
}