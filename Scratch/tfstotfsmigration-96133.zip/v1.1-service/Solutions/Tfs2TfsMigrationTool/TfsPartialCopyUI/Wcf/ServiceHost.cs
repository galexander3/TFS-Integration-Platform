using System;
using System.ServiceModel;

// A WCF service consists of a contract (defined below), 
// a class which implements that interface, and configuration 
// entries that specify behaviors and endpoints associated with 
// that implementation (see <system.serviceModel> in your application
// configuration file).

internal class LocalServiceHost
{
    internal static ServiceHost _localServiceHost = null;

    public static bool Running = false;

    internal static void StartService(Type type)
    {
        //Consider putting the baseAddress in the configuration system
        //and getting it here with AppSettings
//        Uri baseAddress = new Uri("net.pipe://localhost/MigrationSessionEditService");

        //Instantiate new ServiceHost 
        _localServiceHost = new ServiceHost(type);
        
        //Open myServiceHost
        _localServiceHost.Open();

        _localServiceHost.Faulted += new EventHandler(_localServiceHost_Faulted);

        Running = true;
    }

    static void _localServiceHost_Faulted(object sender, EventArgs e)
    {

        System.Diagnostics.EventLog.WriteEntry("TFS Sync Tool Service (Self Hosted)", "Service has faulted: " + e.ToString());
    }

    internal static void StopService()
    {
        //Call StopService from your shutdown logic (i.e. dispose method)
        if (_localServiceHost.State != CommunicationState.Closed)
            _localServiceHost.Close();

        Running = false;
    }
}
