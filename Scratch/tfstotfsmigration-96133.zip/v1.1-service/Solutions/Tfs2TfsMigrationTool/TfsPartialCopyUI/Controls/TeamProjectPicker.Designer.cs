namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls
{
    partial class TeamProjectPicker
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpSourceProject = new System.Windows.Forms.GroupBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.lblSourceProjectName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSourceServerName = new System.Windows.Forms.TextBox();
            this.cmbSourceProjectName = new System.Windows.Forms.ComboBox();
            this.chkUseStoredCred = new System.Windows.Forms.CheckBox();
            this.grpSourceProject.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpSourceProject
            // 
            this.grpSourceProject.Controls.Add(this.chkUseStoredCred);
            this.grpSourceProject.Controls.Add(this.btnConnect);
            this.grpSourceProject.Controls.Add(this.lblSourceProjectName);
            this.grpSourceProject.Controls.Add(this.label1);
            this.grpSourceProject.Controls.Add(this.txtSourceServerName);
            this.grpSourceProject.Controls.Add(this.cmbSourceProjectName);
            this.grpSourceProject.Location = new System.Drawing.Point(0, 0);
            this.grpSourceProject.Name = "grpSourceProject";
            this.grpSourceProject.Size = new System.Drawing.Size(235, 145);
            this.grpSourceProject.TabIndex = 4;
            this.grpSourceProject.TabStop = false;
            this.grpSourceProject.Text = "<Group Title>";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(151, 44);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(63, 23);
            this.btnConnect.TabIndex = 5;
            this.btnConnect.Text = "&Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // lblSourceProjectName
            // 
            this.lblSourceProjectName.AutoSize = true;
            this.lblSourceProjectName.Location = new System.Drawing.Point(9, 94);
            this.lblSourceProjectName.Name = "lblSourceProjectName";
            this.lblSourceProjectName.Size = new System.Drawing.Size(73, 13);
            this.lblSourceProjectName.TabIndex = 4;
            this.lblSourceProjectName.Text = "Team Project:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "TFS Server:";
            // 
            // txtSourceServerName
            // 
            this.txtSourceServerName.Location = new System.Drawing.Point(9, 47);
            this.txtSourceServerName.Name = "txtSourceServerName";
            this.txtSourceServerName.Size = new System.Drawing.Size(135, 20);
            this.txtSourceServerName.TabIndex = 2;
            // 
            // cmbSourceProjectName
            // 
            this.cmbSourceProjectName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSourceProjectName.Enabled = false;
            this.cmbSourceProjectName.FormattingEnabled = true;
            this.cmbSourceProjectName.Location = new System.Drawing.Point(9, 113);
            this.cmbSourceProjectName.MaxDropDownItems = 100;
            this.cmbSourceProjectName.Name = "cmbSourceProjectName";
            this.cmbSourceProjectName.Size = new System.Drawing.Size(205, 21);
            this.cmbSourceProjectName.Sorted = true;
            this.cmbSourceProjectName.TabIndex = 1;
            // 
            // chkUseStoredCred
            // 
            this.chkUseStoredCred.AutoSize = true;
            this.chkUseStoredCred.Location = new System.Drawing.Point(9, 73);
            this.chkUseStoredCred.Name = "chkUseStoredCred";
            this.chkUseStoredCred.Size = new System.Drawing.Size(134, 17);
            this.chkUseStoredCred.TabIndex = 6;
            this.chkUseStoredCred.Text = "Use Stored Credentials";
            this.chkUseStoredCred.UseVisualStyleBackColor = true;
            // 
            // TeamProjectPicker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grpSourceProject);
            this.Name = "TeamProjectPicker";
            this.Size = new System.Drawing.Size(244, 153);
            this.grpSourceProject.ResumeLayout(false);
            this.grpSourceProject.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpSourceProject;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label lblSourceProjectName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSourceServerName;
        private System.Windows.Forms.ComboBox cmbSourceProjectName;
        private System.Windows.Forms.CheckBox chkUseStoredCred;
    }
}
