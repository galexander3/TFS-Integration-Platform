using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.TeamFoundation.VersionControl.Common;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls
{
    public delegate void PathChangedEventHandler(object sender, EventArgs e);

    public partial class VCFolderPicker : UserControl
    {
        private const int LEVELS_TO_LOAD = 1;
        private string _serverName;
        private string _teamProject;
        private VersionControlServer _vcs;
        private bool _useStoredCreds;


        public VCFolderPicker()
        {
            InitializeComponent();
        }

        public event PathChangedEventHandler PathChanged;

        public string TfsServerName
        {
            get { return _serverName; }
            set { _serverName = value; }
        }

        public string TeamProjectName
        {
            get { return _teamProject; }
            set { _teamProject = value; }
        }

        public bool UseStoredCredentials
        {
            get { return _useStoredCreds; }
            set{ _useStoredCreds = value; }
        }

        public string SelectedPath
        {
            get { return txtPath.Text; }
        }

        public void InitializeTree()
        {
            TfsHelper helper = new TfsHelper();
            if (helper.TfsConnect(this.TfsServerName, this.UseStoredCredentials))
            {

                ItemSet itemSet = helper.GetVCTree(this.TeamProjectName);

                if (itemSet.Items.Length > 0)
                    _vcs = itemSet.Items[0].VersionControlServer;

                LoadTree(itemSet.Items, null, 0);

                this.stripServerName.Text = this.TfsServerName;
                this.statusMessage.Text = "Connected.";
            }
        }

        /// <summary>
        /// Check to see whether the provided is a valid server path of the current picked server.
        /// </summary>
        /// <param name="path">Server path to be checked</param>
        /// <returns></returns>
        public bool IsValidServerItem(string path)
        {
            if (_vcs == null)
            {
                return false;
            }

            if (path != VersionControlPath.GetFullPath(path))
            {
                return false;
            }

            return (_vcs.TryGetTeamProjectForServerPath(path) != null);
        }

        private void LoadTree(Item[] items, TreeNode parentNode, int levelsLoaded)
        {
            if (items == null)
            {
                ItemSet itemSet = _vcs.GetItems(parentNode.FullPath + "/*", RecursionType.None);

                if (itemSet != null)
                    items = itemSet.Items;
            }

            foreach(Item item in items)
            {
                if (item.ItemType == ItemType.Folder)
                {
                    TreeNode currentNode;


                    if (parentNode == null)
                    {
                        currentNode = tvwFolders.Nodes.Add(item.ServerItem, item.ServerItem, "Folder");

                    }
                    else
                    {
                        string[] fullPath = item.ServerItem.Split("/".ToCharArray());

                        string folderName = fullPath[fullPath.Length - 1];

                        currentNode = parentNode.Nodes.Add(item.ServerItem, folderName, "Folder");
                    }

                    //Add a place holder so a plus sign is shown in the tree, and mark node as load required
                    currentNode.Tag = true;
                    currentNode.Nodes.Add("placeholder");
                }
            }
        }



        private void tvwFolders_AfterSelect(object sender, TreeViewEventArgs e)
        {
            txtPath.Text = e.Node.FullPath;
        }

        void txtPath_TextChanged(object sender, System.EventArgs e)
        {
            PathChanged(sender, e);
        }

        private void tvwFolders_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            if (e.Node.Tag != null)
            {
                //There is a placeholder node, clear it, the go get the children
                e.Node.Tag = null;
                e.Node.Nodes.Clear();

                LoadTree(null, e.Node, 0);
            }
        }


    }
}
