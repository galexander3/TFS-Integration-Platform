namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Controls
{
    partial class VCFolderPicker
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tvwFolders = new System.Windows.Forms.TreeView();
            this.stsMain = new System.Windows.Forms.StatusStrip();
            this.statusMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.stripConnectedTo = new System.Windows.Forms.ToolStripStatusLabel();
            this.stripServerName = new System.Windows.Forms.ToolStripStatusLabel();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.stsMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // tvwFolders
            // 
            this.tvwFolders.FullRowSelect = true;
            this.tvwFolders.HotTracking = true;
            this.tvwFolders.Location = new System.Drawing.Point(0, 3);
            this.tvwFolders.Name = "tvwFolders";
            this.tvwFolders.PathSeparator = "/";
            this.tvwFolders.Size = new System.Drawing.Size(342, 248);
            this.tvwFolders.TabIndex = 0;
            this.tvwFolders.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.tvwFolders_BeforeExpand);
            this.tvwFolders.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvwFolders_AfterSelect);
            // 
            // stsMain
            // 
            this.stsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusMessage,
            this.stripConnectedTo,
            this.stripServerName});
            this.stsMain.Location = new System.Drawing.Point(0, 286);
            this.stsMain.Name = "stsMain";
            this.stsMain.Size = new System.Drawing.Size(352, 22);
            this.stsMain.SizingGrip = false;
            this.stsMain.TabIndex = 1;
            // 
            // statusMessage
            // 
            this.statusMessage.Name = "statusMessage";
            this.statusMessage.Size = new System.Drawing.Size(83, 17);
            this.statusMessage.Text = "Not Initialized.";
            // 
            // stripConnectedTo
            // 
            this.stripConnectedTo.Name = "stripConnectedTo";
            this.stripConnectedTo.Size = new System.Drawing.Size(85, 17);
            this.stripConnectedTo.Text = "Connected To:";
            // 
            // stripServerName
            // 
            this.stripServerName.Name = "stripServerName";
            this.stripServerName.Size = new System.Drawing.Size(93, 17);
            this.stripServerName.Text = "<Server Name.>";
            // 
            // txtPath
            // 
            this.txtPath.Enabled = true;
            this.txtPath.Location = new System.Drawing.Point(0, 258);
            this.txtPath.Name = "txtPath";
            this.txtPath.ReadOnly = false;
            this.txtPath.Size = new System.Drawing.Size(342, 20);
            this.txtPath.TabIndex = 2;
            this.txtPath.TextChanged += new System.EventHandler(txtPath_TextChanged);
            // 
            // VCFolderPicker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtPath);
            this.Controls.Add(this.stsMain);
            this.Controls.Add(this.tvwFolders);
            this.Name = "VCFolderPicker";
            this.Size = new System.Drawing.Size(352, 308);
            this.stsMain.ResumeLayout(false);
            this.stsMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView tvwFolders;
        private System.Windows.Forms.StatusStrip stsMain;
        private System.Windows.Forms.ToolStripStatusLabel statusMessage;
        private System.Windows.Forms.ToolStripStatusLabel stripConnectedTo;
        private System.Windows.Forms.ToolStripStatusLabel stripServerName;
        private System.Windows.Forms.TextBox txtPath;
    }
}
