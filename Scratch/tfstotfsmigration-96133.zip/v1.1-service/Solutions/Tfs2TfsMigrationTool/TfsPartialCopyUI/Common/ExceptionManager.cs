using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.DataContracts;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Common
{
    class ExceptionManager
    {
        public static void DisplayExceptionToUser(Exception ex)
        {
            DisplayExceptionToUser(ex, "Error Occurred", "An error has occurred in the application.");
        }

        public static void DisplayExceptionToUser(FaultException faultException, string userMessage)
        {
            string message = String.Format("{0}  Check Event Log for Details.  Error information: {1}", userMessage, ((FaultException<ServerError>)faultException).Detail.Message);

            //For now just show the error in a message box, possibly add a new form for this in the future
            MessageBox.Show(message, "Unhandled error", MessageBoxButtons.OK, MessageBoxIcon.Error);


            WriteEventLogEntry(message, faultException);
        }

        public static void DisplayExceptionToUser(FaultException<ServerError> ex, string userMessage)
        {
            string message = String.Format("{0}  Check Event Log for Details.  Error information: {1}", userMessage, ex.Detail.Message);

            //For now just show the error in a message box, possibly add a new form for this in the future
            MessageBox.Show(message, "Unhandled error", MessageBoxButtons.OK, MessageBoxIcon.Error);


            WriteEventLogEntry(message, ex);
        }

        public static void DisplayExceptionToUser(Exception ex, string caption, string userMessage)
        {
            string message = String.Format("{0}  Check Event Log for Details.  Error information: {1}", userMessage, ex.Message);

            //For now just show the error in a message box, possibly add a new form for this in the future
            MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);


            WriteEventLogEntry(message, ex);
        }

        private static void WriteEventLogEntry(string message, Exception ex)
        {
            try
            {
                string detailedMessage = String.Format("Message: {0}\n Call Stack: {1}", message, ex.StackTrace);

                if (!EventLog.SourceExists(Application.ProductName))
                    EventLog.CreateEventSource(Application.ProductName, "Application");

                EventLog.WriteEntry(Application.ProductName, detailedMessage, EventLogEntryType.Error);
            }
            catch (Exception innerEx)
            {
                MessageBox.Show(String.Format("Could not log event to Event Log.  Message Follows: {0}", innerEx.Message), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void DisplayExceptionToUser(TimeoutException timeout,  string userMessage)
        {
            string message = String.Format("{0} Check Event Log for Details.  Error information: {1}", userMessage, timeout.ToString());

            //For now just show the error in a message box, possibly add a new form for this in the future
            MessageBox.Show(message, "Unhandled error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            WriteEventLogEntry(message, timeout);
        }

        public static void DisplayExceptionToUser(CommunicationException comm,  string userMessage)
        {
            string message = String.Format("{0} Check Event Log for Details.  Error information: {1}", userMessage, comm.ToString());

            //For now just show the error in a message box, possibly add a new form for this in the future
            MessageBox.Show(message, "Unhandled error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            WriteEventLogEntry(message, comm);
        }

        //public static void DisplayExceptionToUser(FaultException fault,  string userMessage)
        //{
        //    string message = String.Format("{0} Check Event Log for Details.  Error information: {1}", userMessage, fault.ToString());

        //    //For now just show the error in a message box, possibly add a new form for this in the future
        //    MessageBox.Show(message, "Unhandled error", MessageBoxButtons.OK, MessageBoxIcon.Error);

        //    WriteEventLogEntry(message, fault);
        //}
        
    }
}
