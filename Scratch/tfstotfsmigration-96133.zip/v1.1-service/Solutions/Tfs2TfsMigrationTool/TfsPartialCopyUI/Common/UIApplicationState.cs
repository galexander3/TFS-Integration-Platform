using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Vsts.Ranger.Migration.TfsToTfs;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client.Common
{
    class UIApplicationState
    {
        private static SessionFileManager _primarySessionFileManager = new SessionFileManager();


        public static SessionFileManager SessionFileManager
        {
            get { return _primarySessionFileManager; }
        }
    }

}