using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Client
{
    public class MigrationConfig
    {
        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlRootAttribute("Migration", Namespace = "", IsNullable = false)]
        public partial class MigrationElement
        {

            private System.Collections.Generic.List<ProviderElement> providersField;

            private System.Collections.Generic.List<ServerElement> serversField;

            private System.Collections.Generic.List<SettingsElementSetting> settingsField;

            private VCElement vcField;

            private WITElement witField;

            private MigrationElementSql sqlField;

            public MigrationElement()
            {
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Provider", IsNullable = false)]
            public System.Collections.Generic.List<ProviderElement> Providers
            {
                get
                {
                    if ((this.providersField == null))
                    {
                        this.providersField = new System.Collections.Generic.List<ProviderElement>();
                    }
                    return this.providersField;
                }
                set
                {
                    this.providersField = value;
                }
            }
            
            
            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Tfs", IsNullable = false)]
            public System.Collections.Generic.List<ServerElement> Servers
            {
                get
                {
                    if ((this.serversField == null))
                    {
                        this.serversField = new System.Collections.Generic.List<ServerElement>();
                    }
                    return this.serversField;
                }
                set
                {
                    this.serversField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Setting", IsNullable = false)]
            public System.Collections.Generic.List<SettingsElementSetting> Settings
            {
                get
                {
                    if ((this.settingsField == null))
                    {
                        this.settingsField = new System.Collections.Generic.List<SettingsElementSetting>();
                    }
                    return this.settingsField;
                }
                set
                {
                    this.settingsField = value;
                }
            }

            
            /// <remarks/>
            public VCElement VC
            {
                get
                {
                    return this.vcField;
                }
                set
                {
                    this.vcField = value;
                }
            }

            /// <remarks/>
            public WITElement WIT
            {
                get
                {
                    return this.witField;
                }
                set
                {
                    this.witField = value;
                }
            }

            /// <remarks/>
            public MigrationElementSql Sql
            {
                get
                {
                    return this.sqlField;
                }
                set
                {
                    this.sqlField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class ProviderElement : IdElement
        {

            private string assemblyQualifiedNameField;

            
            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute(DataType = "normalizedString")]
            public string AssemblyQualifiedName
            {
                get
                {
                    return this.assemblyQualifiedNameField;
                }
                set
                {
                    this.assemblyQualifiedNameField = value;
                }
            }

        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(WITSessionElement))]
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(VCSessionElement))]
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(ServerElement))]
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(ProviderElement))]
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public abstract partial class IdElement
        {

            private string idField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "NCName")]
            public string id
            {
                get
                {
                    return this.idField;
                }
                set
                {
                    this.idField = value;
                }
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(WitLinkingElement))]
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public abstract partial class LinkSessionBase
        {

            private LinkSessionBaseEngine engineField;

            /// <remarks/>
            public LinkSessionBaseEngine Engine
            {
                get
                {
                    return this.engineField;
                }
                set
                {
                    this.engineField = value;
                }
            }
        }



        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class LinkSessionBaseEngine
        {

            private System.Collections.Generic.List<System.Xml.XmlElement> anyField;

            private string providerField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAnyElementAttribute()]
            public System.Collections.Generic.List<System.Xml.XmlElement> Any
            {
                get
                {
                    if ((this.anyField == null))
                    {
                        this.anyField = new System.Collections.Generic.List<System.Xml.XmlElement>();
                    }
                    return this.anyField;
                }
                set
                {
                    this.anyField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "NCName")]
            public string provider
            {
                get
                {
                    return this.providerField;
                }
                set
                {
                    this.providerField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WitLinkingElement : LinkSessionBase
        {

            private SessionReferenceElement versionControlField;

            /// <remarks/>
            public SessionReferenceElement VersionControl
            {
                get
                {
                    return this.versionControlField;
                }
                set
                {
                    this.versionControlField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class SessionReferenceElement
        {

            private string sessionField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "NCName")]
            public string session
            {
                get
                {
                    return this.sessionField;
                }
                set
                {
                    this.sessionField = value;
                }
            }
        }



        /// <remarks/>
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(WitCollectionsPolicy))]
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(WitFileAttachmentPolicy))]
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(WitFieldConflictPolicy))]
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public abstract partial class WitMasterPolicy
        {

            private WitMasterPolicyMaster masterField;

            public WitMasterPolicy()
            {
                this.masterField = WitMasterPolicyMaster.@default;
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            [System.ComponentModel.DefaultValueAttribute(WitMasterPolicyMaster.@default)]
            public WitMasterPolicyMaster master
            {
                get
                {
                    return this.masterField;
                }
                set
                {
                    this.masterField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public enum WitMasterPolicyMaster
        {

            /// <remarks/>
            @default,

            /// <remarks/>
            tfs,

            /// <remarks/>
            other,
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(WitFileAttachmentPolicy))]
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WitCollectionsPolicy : WitMasterPolicy
        {

            private WitCollectionsPolicyReaction reactionField;

            public WitCollectionsPolicy()
            {
                this.reactionField = WitCollectionsPolicyReaction.master;
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            [System.ComponentModel.DefaultValueAttribute(WitCollectionsPolicyReaction.master)]
            public WitCollectionsPolicyReaction reaction
            {
                get
                {
                    return this.reactionField;
                }
                set
                {
                    this.reactionField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public enum WitCollectionsPolicyReaction
        {

            /// <remarks/>
            @throw,

            /// <remarks/>
            master,

            /// <remarks/>
            union,
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WitFileAttachmentPolicy : WitCollectionsPolicy
        {

            private string tempDirField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string tempDir
            {
                get
                {
                    return this.tempDirField;
                }
                set
                {
                    this.tempDirField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WitFieldConflictPolicy : WitMasterPolicy
        {

            private WitFieldConflictPolicyReaction reactionField;

            public WitFieldConflictPolicy()
            {
                this.reactionField = WitFieldConflictPolicyReaction.master;
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            [System.ComponentModel.DefaultValueAttribute(WitFieldConflictPolicyReaction.master)]
            public WitFieldConflictPolicyReaction reaction
            {
                get
                {
                    return this.reactionField;
                }
                set
                {
                    this.reactionField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public enum WitFieldConflictPolicyReaction
        {

            /// <remarks/>
            @throw,

            /// <remarks/>
            master,
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WitMissingNodePolicy
        {

            private WitMissingNodePolicyReaction reactionField;

            public WitMissingNodePolicy()
            {
                this.reactionField = WitMissingNodePolicyReaction.create;
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            [System.ComponentModel.DefaultValueAttribute(WitMissingNodePolicyReaction.create)]
            public WitMissingNodePolicyReaction reaction
            {
                get
                {
                    return this.reactionField;
                }
                set
                {
                    this.reactionField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public enum WitMissingNodePolicyReaction
        {

            /// <remarks/>
            @throw,

            /// <remarks/>
            create,

            /// <remarks/>
            @default,
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WitMissingUserPolicy
        {

            private WitMissingUserPolicyReaction reactionField;

            private string defaultUserField;

            public WitMissingUserPolicy()
            {
                this.reactionField = WitMissingUserPolicyReaction.@throw;
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            [System.ComponentModel.DefaultValueAttribute(WitMissingUserPolicyReaction.@throw)]
            public WitMissingUserPolicyReaction reaction
            {
                get
                {
                    return this.reactionField;
                }
                set
                {
                    this.reactionField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string defaultUser
            {
                get
                {
                    return this.defaultUserField;
                }
                set
                {
                    this.defaultUserField = value;
                }
            }
        }



        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public enum WitMissingUserPolicyReaction
        {

            /// <remarks/>
            @throw,

            /// <remarks/>
            @default,
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WitPoliciesElement
        {

            private WitMissingUserPolicy missingUserField;

            private WitMissingNodePolicy missingAreaField;

            private WitMissingNodePolicy missingIterationField;

            private WitFieldConflictPolicy fieldConflictField;

            private WitFileAttachmentPolicy attachmentsConflictField;

            private WitCollectionsPolicy linksConflictField;

            private RepositorySystem masterField;

            public WitPoliciesElement()
            {
                this.masterField = RepositorySystem.tfs;
            }

            /// <remarks/>
            public WitMissingUserPolicy MissingUser
            {
                get
                {
                    return this.missingUserField;
                }
                set
                {
                    this.missingUserField = value;
                }
            }

            /// <remarks/>
            public WitMissingNodePolicy MissingArea
            {
                get
                {
                    return this.missingAreaField;
                }
                set
                {
                    this.missingAreaField = value;
                }
            }

            /// <remarks/>
            public WitMissingNodePolicy MissingIteration
            {
                get
                {
                    return this.missingIterationField;
                }
                set
                {
                    this.missingIterationField = value;
                }
            }

            /// <remarks/>
            public WitFieldConflictPolicy FieldConflict
            {
                get
                {
                    return this.fieldConflictField;
                }
                set
                {
                    this.fieldConflictField = value;
                }
            }

            /// <remarks/>
            public WitFileAttachmentPolicy AttachmentsConflict
            {
                get
                {
                    return this.attachmentsConflictField;
                }
                set
                {
                    this.attachmentsConflictField = value;
                }
            }

            /// <remarks/>
            public WitCollectionsPolicy LinksConflict
            {
                get
                {
                    return this.linksConflictField;
                }
                set
                {
                    this.linksConflictField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            [System.ComponentModel.DefaultValueAttribute(RepositorySystem.tfs)]
            public RepositorySystem master
            {
                get
                {
                    return this.masterField;
                }
                set
                {
                    this.masterField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        public enum RepositorySystem
        {

            /// <remarks/>
            tfs,

            /// <remarks/>
            other,
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WITFieldMappingElement
        {

            private string tfsField;

            private string otherField;

            private string fieldMapField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string tfs
            {
                get
                {
                    return this.tfsField;
                }
                set
                {
                    this.tfsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string other
            {
                get
                {
                    return this.otherField;
                }
                set
                {
                    this.otherField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string fieldMap
            {
                get
                {
                    return this.fieldMapField;
                }
                set
                {
                    this.fieldMapField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WITElement
        {

            private System.Collections.Generic.List<SettingsElementSetting> settingsField;

            private System.Collections.Generic.List<WITSessionElement> sessionsField;

            private System.Collections.Generic.List<WITElementFieldMap> fieldMapsField;

            private System.Collections.Generic.List<WITElementValueMap> valueMapsField;

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Setting", IsNullable = false)]
            public System.Collections.Generic.List<SettingsElementSetting> Settings
            {
                get
                {
                    if ((this.settingsField == null))
                    {
                        this.settingsField = new System.Collections.Generic.List<SettingsElementSetting>();
                    }
                    return this.settingsField;
                }
                set
                {
                    this.settingsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Session", IsNullable = false)]
            public System.Collections.Generic.List<WITSessionElement> Sessions
            {
                get
                {
                    if ((this.sessionsField == null))
                    {
                        this.sessionsField = new System.Collections.Generic.List<WITSessionElement>();
                    }
                    return this.sessionsField;
                }
                set
                {
                    this.sessionsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("FieldMap", IsNullable = false)]
            public System.Collections.Generic.List<WITElementFieldMap> FieldMaps
            {
                get
                {
                    if ((this.fieldMapsField == null))
                    {
                        this.fieldMapsField = new System.Collections.Generic.List<WITElementFieldMap>();
                    }
                    return this.fieldMapsField;
                }
                set
                {
                    this.fieldMapsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("ValueMap", IsNullable = false)]
            public System.Collections.Generic.List<WITElementValueMap> ValueMaps
            {
                get
                {
                    if ((this.valueMapsField == null))
                    {
                        this.valueMapsField = new System.Collections.Generic.List<WITElementValueMap>();
                    }
                    return this.valueMapsField;
                }
                set
                {
                    this.valueMapsField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class SettingsElementSetting
        {

            private string nameField;

            private string valueField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "NCName")]
            public string name
            {
                get
                {
                    return this.nameField;
                }
                set
                {
                    this.nameField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WITSessionElement : IdElement
        {

            private System.Collections.Generic.List<SettingsElementSetting> settingsField;

            private WitTfsServer tfsField;

            private WITSessionElementSource sourceField;

            private ReadQueueElement fastQueueField;

            private ReadQueueElement slowQueueField;

            private WITSessionElementWorkItemTypes workItemTypesField;

            private WitPoliciesElement policiesField;

            private System.Collections.Generic.List<EventSinksElementEventSink> eventSinksField;

            private WitLinkingElement linkingField;

            private bool ignoreRevisionsField;

            private string sleepTimeField;

            public WITSessionElement()
            {
                this.ignoreRevisionsField = false;
                this.sleepTimeField = "60";
            }


            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Setting", IsNullable = false)]
            public System.Collections.Generic.List<SettingsElementSetting> Settings
            {
                get
                {
                    if ((this.settingsField == null))
                    {
                        this.settingsField = new System.Collections.Generic.List<SettingsElementSetting>();
                    }
                    return this.settingsField;
                }
                set
                {
                    this.settingsField = value;
                }
            }

            /// <remarks/>
            public WitTfsServer Tfs
            {
                get
                {
                    return this.tfsField;
                }
                set
                {
                    this.tfsField = value;
                }
            }

            /// <remarks/>
            public WITSessionElementSource Source
            {
                get
                {
                    return this.sourceField;
                }
                set
                {
                    this.sourceField = value;
                }
            }

            /// <remarks/>
            public ReadQueueElement FastQueue
            {
                get
                {
                    return this.fastQueueField;
                }
                set
                {
                    this.fastQueueField = value;
                }
            }

            /// <remarks/>
            public ReadQueueElement SlowQueue
            {
                get
                {
                    return this.slowQueueField;
                }
                set
                {
                    this.slowQueueField = value;
                }
            }

            /// <remarks/>
            public WITSessionElementWorkItemTypes WorkItemTypes
            {
                get
                {
                    return this.workItemTypesField;
                }
                set
                {
                    this.workItemTypesField = value;
                }
            }

            /// <remarks/>
            public WitPoliciesElement Policies
            {
                get
                {
                    return this.policiesField;
                }
                set
                {
                    this.policiesField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("EventSink", IsNullable = false)]
            public System.Collections.Generic.List<EventSinksElementEventSink> EventSinks
            {
                get
                {
                    if ((this.eventSinksField == null))
                    {
                        this.eventSinksField = new System.Collections.Generic.List<EventSinksElementEventSink>();
                    }
                    return this.eventSinksField;
                }
                set
                {
                    this.eventSinksField = value;
                }
            }

            /// <remarks/>
            public WitLinkingElement Linking
            {
                get
                {
                    return this.linkingField;
                }
                set
                {
                    this.linkingField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            [System.ComponentModel.DefaultValueAttribute(false)]
            public bool ignoreRevisions
            {
                get
                {
                    return this.ignoreRevisionsField;
                }
                set
                {
                    this.ignoreRevisionsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "nonNegativeInteger")]
            [System.ComponentModel.DefaultValueAttribute("60")]
            public string sleepTime
            {
                get
                {
                    return this.sleepTimeField;
                }
                set
                {
                    this.sleepTimeField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WitTfsServer : TfsServerReference
        {

            private string projectField;

            private string filterField;

            private string defaultAreaField;

            private string defaultIterationField;

            private WriteQueueElement writeQueueField;

            private FileAttachmentElement fileAttachmentsField;

            private LinkElement linksField;

            private MetadataSynchronizationElement metadataSynchronizationField;

            private WitTfsServerFieldForm fieldFormField;

            public WitTfsServer()
            {
                this.fieldFormField = WitTfsServerFieldForm.Friendly;
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute(DataType = "normalizedString")]
            public string Project
            {
                get
                {
                    return this.projectField;
                }
                set
                {
                    this.projectField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute(DataType = "normalizedString", IsNullable=false)]
            public string Filter
            {
                get
                {
                    return this.filterField;
                }
                set
                {
                    this.filterField = value;
                    
                    
                }
            }

            /// <remarks/>
            public string DefaultArea
            {
                get
                {
                    return this.defaultAreaField;
                }
                set
                {
                    this.defaultAreaField = value;
                }
            }

            /// <remarks/>
            public string DefaultIteration
            {
                get
                {
                    return this.defaultIterationField;
                }
                set
                {
                    this.defaultIterationField = value;
                }
            }

            /// <remarks/>
            public WriteQueueElement WriteQueue
            {
                get
                {
                    return this.writeQueueField;
                }
                set
                {
                    this.writeQueueField = value;
                }
            }

            /// <remarks/>
            public FileAttachmentElement FileAttachments
            {
                get
                {
                    return this.fileAttachmentsField;
                }
                set
                {
                    this.fileAttachmentsField = value;
                }
            }

            /// <remarks/>
            public LinkElement Links
            {
                get
                {
                    return this.linksField;
                }
                set
                {
                    this.linksField = value;
                }
            }

            /// <remarks/>
            public MetadataSynchronizationElement MetadataSynchronization
            {
                get
                {
                    return this.metadataSynchronizationField;
                }
                set
                {
                    this.metadataSynchronizationField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            [System.ComponentModel.DefaultValueAttribute(WitTfsServerFieldForm.Friendly)]
            public WitTfsServerFieldForm fieldForm
            {
                get
                {
                    return this.fieldFormField;
                }
                set
                {
                    this.fieldFormField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class WriteQueueElement : ReadQueueElement
        {

            private string batchSize1Field;

            public WriteQueueElement()
            {
                this.batchSize1Field = "64";
            }

        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(WriteQueueElement))]
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class ReadQueueElement
        {

            private string threadCountField;

            private string batchSizeField;

            public ReadQueueElement()
            {
                this.threadCountField = "2";
                this.batchSizeField = "50";
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "nonNegativeInteger")]
            [System.ComponentModel.DefaultValueAttribute("2")]
            public string threadCount
            {
                get
                {
                    return this.threadCountField;
                }
                set
                {
                    this.threadCountField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "positiveInteger")]
            [System.ComponentModel.DefaultValueAttribute("50")]
            public string batchSize
            {
                get
                {
                    return this.batchSizeField;
                }
                set
                {
                    this.batchSizeField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class FileAttachmentElement
        {

            private string filesPerUpdateField;

            public FileAttachmentElement()
            {
                this.filesPerUpdateField = "10";
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "positiveInteger")]
            [System.ComponentModel.DefaultValueAttribute("10")]
            public string filesPerUpdate
            {
                get
                {
                    return this.filesPerUpdateField;
                }
                set
                {
                    this.filesPerUpdateField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class LinkElement
        {

            private string linksPerUpdateField;

            public LinkElement()
            {
                this.linksPerUpdateField = "10";
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "positiveInteger")]
            [System.ComponentModel.DefaultValueAttribute("10")]
            public string linksPerUpdate
            {
                get
                {
                    return this.linksPerUpdateField;
                }
                set
                {
                    this.linksPerUpdateField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class MetadataSynchronizationElement
        {

            private System.Collections.Generic.List<NamesCollectionName> ignoredTypesField;

            private System.Collections.Generic.List<NamesCollectionName> ignoredListsField;

            private MetadataSynchronizationElementTypes typesField;

            public MetadataSynchronizationElement()
            {
                this.typesField = MetadataSynchronizationElementTypes.all;
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Name", IsNullable = false)]
            public System.Collections.Generic.List<NamesCollectionName> IgnoredTypes
            {
                get
                {
                    if ((this.ignoredTypesField == null))
                    {
                        this.ignoredTypesField = new System.Collections.Generic.List<NamesCollectionName>();
                    }
                    return this.ignoredTypesField;
                }
                set
                {
                    this.ignoredTypesField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Name", IsNullable = false)]
            public System.Collections.Generic.List<NamesCollectionName> IgnoredLists
            {
                get
                {
                    if ((this.ignoredListsField == null))
                    {
                        this.ignoredListsField = new System.Collections.Generic.List<NamesCollectionName>();
                    }
                    return this.ignoredListsField;
                }
                set
                {
                    this.ignoredListsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            [System.ComponentModel.DefaultValueAttribute(MetadataSynchronizationElementTypes.all)]
            public MetadataSynchronizationElementTypes types
            {
                get
                {
                    return this.typesField;
                }
                set
                {
                    this.typesField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class NamesCollectionName
        {

            private string valueField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string value
            {
                get
                {
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }
        }

        /// <remarks/>
        [System.FlagsAttribute()]
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public enum MetadataSynchronizationElementTypes
        {

            /// <remarks/>
            accounts = 1,

            /// <remarks/>
            lists = 2,

            /// <remarks/>
            types = 4,

            /// <remarks/>
            all = 8,
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public enum WitTfsServerFieldForm
        {

            /// <remarks/>
            Friendly,

            /// <remarks/>
            Reference,
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIncludeAttribute(typeof(WitTfsServer))]
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public abstract partial class TfsServerReference
        {

            private string serverField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "NCName")]
            public string server
            {
                get
                {
                    return this.serverField;
                }
                set
                {
                    this.serverField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class WITSessionElementSource
        {

            private WitTfsServer tfs;

            /// <remarks/>
           // [System.Xml.Serialization.XmlElementAttribute("Provider", typeof(WITSessionElementSourceProvider))]
            //[System.Xml.Serialization.XmlElementAttribute("Tfs", typeof(WitTfsServer))]
            public WitTfsServer Tfs
            {
                get
                {
                    return this.tfs;
                }
                set
                {
                    this.tfs = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class WITSessionElementSourceProvider : ProviderReference
        {

            private WriteQueueElement writeQueueField;

            private object initializationDataField;

            /// <remarks/>
            public WriteQueueElement WriteQueue
            {
                get
                {
                    return this.writeQueueField;
                }
                set
                {
                    this.writeQueueField = value;
                }
            }

            /// <remarks/>
            public object InitializationData
            {
                get
                {
                    return this.initializationDataField;
                }
                set
                {
                    this.initializationDataField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public abstract partial class ProviderReference
        {

            private string providerField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "NCName")]
            public string provider
            {
                get
                {
                    return this.providerField;
                }
                set
                {
                    this.providerField = value;
                }
            }
        }

        //Added this by hand since the schema doesnt go down to this level
        public class WITSessionSource
        {
            public WitTfsServer Tfs = new WitTfsServer();
        }

        
        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class WITSessionElementWorkItemTypes
        {

            private System.Collections.Generic.List<WITFieldMappingElement> workItemTypeField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute("WorkItemType")]
            public System.Collections.Generic.List<WITFieldMappingElement> WorkItemType
            {
                get
                {
                    if ((this.workItemTypeField == null))
                    {
                        this.workItemTypeField = new System.Collections.Generic.List<WITFieldMappingElement>();
                    }
                    return this.workItemTypeField;
                }
                set
                {
                    this.workItemTypeField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class EventSinksElementEventSink
        {

            private System.Xml.XmlElement anyField;

            private string providerField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAnyElementAttribute()]
            public System.Xml.XmlElement Any
            {
                get
                {
                    return this.anyField;
                }
                set
                {
                    this.anyField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "NCName")]
            public string provider
            {
                get
                {
                    return this.providerField;
                }
                set
                {
                    this.providerField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class WITElementFieldMap
        {

            private System.Collections.Generic.List<object> itemsField;

            private string nameField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute("Exclude", typeof(WITElementFieldMapExclude))]
            [System.Xml.Serialization.XmlElementAttribute("Field", typeof(WITElementFieldMapField))]
            public System.Collections.Generic.List<object> Items
            {
                get
                {
                    if ((this.itemsField == null))
                    {
                        this.itemsField = new System.Collections.Generic.List<object>();
                    }
                    return this.itemsField;
                }
                set
                {
                    this.itemsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "NCName")]
            public string name
            {
                get
                {
                    return this.nameField;
                }
                set
                {
                    this.nameField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class WITElementFieldMapExclude
        {

            private RepositorySystem systemField;

            private string fieldField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public RepositorySystem system
            {
                get
                {
                    return this.systemField;
                }
                set
                {
                    this.systemField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string field
            {
                get
                {
                    return this.fieldField;
                }
                set
                {
                    this.fieldField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class WITElementFieldMapField
        {

            private string tfsNameField;

            private string otherNameField;

            private string valueMapField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string tfsName
            {
                get
                {
                    return this.tfsNameField;
                }
                set
                {
                    this.tfsNameField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string otherName
            {
                get
                {
                    return this.otherNameField;
                }
                set
                {
                    this.otherNameField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string valueMap
            {
                get
                {
                    return this.valueMapField;
                }
                set
                {
                    this.valueMapField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class WITElementValueMap
        {

            private System.Collections.Generic.List<WITElementValueMapValue> valueField;

            private string nameField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute("Value")]
            public System.Collections.Generic.List<WITElementValueMapValue> Value
            {
                get
                {
                    if ((this.valueField == null))
                    {
                        this.valueField = new System.Collections.Generic.List<WITElementValueMapValue>();
                    }
                    return this.valueField;
                }
                set
                {
                    this.valueField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "NCName")]
            public string name
            {
                get
                {
                    return this.nameField;
                }
                set
                {
                    this.nameField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class WITElementValueMapValue
        {

            private string tfsField;

            private string otherField;

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string tfs
            {
                get
                {
                    return this.tfsField;
                }
                set
                {
                    this.tfsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public string other
            {
                get
                {
                    return this.otherField;
                }
                set
                {
                    this.otherField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class VCElement
        {

            private System.Collections.Generic.List<SettingsElementSetting> settingsField;

            private System.Collections.Generic.List<VCSessionElement> sessionsField;

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Setting", IsNullable = false)]
            public System.Collections.Generic.List<SettingsElementSetting> Settings
            {
                get
                {
                    if ((this.settingsField == null))
                    {
                        this.settingsField = new System.Collections.Generic.List<SettingsElementSetting>();
                    }
                    return this.settingsField;
                }
                set
                {
                    this.settingsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Session", IsNullable = false)]
            public System.Collections.Generic.List<VCSessionElement> Sessions
            {
                get
                {
                    if ((this.sessionsField == null))
                    {
                        this.sessionsField = new System.Collections.Generic.List<VCSessionElement>();
                    }
                    return this.sessionsField;
                }
                set
                {
                    this.sessionsField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class VCSessionElement : IdElement
        {

            private System.Collections.Generic.List<SettingsElementSetting> settingsField;

            private System.Collections.Generic.List<VCSessionMappingElement> mappingsField;

            private VCSessionElementTfs tfsField;

            private VCSessionElementSource sourceField;

            private System.Collections.Generic.List<EventSinksElementEventSink> eventSinksField;

            private string providerField;

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Setting", IsNullable = false)]
            public System.Collections.Generic.List<SettingsElementSetting> Settings
            {
                get
                {
                    if ((this.settingsField == null))
                    {
                        this.settingsField = new System.Collections.Generic.List<SettingsElementSetting>();
                    }
                    return this.settingsField;
                }
                set
                {
                    this.settingsField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Mapping", IsNullable = false)]
            public System.Collections.Generic.List<VCSessionMappingElement> Mappings
            {
                get
                {
                    if ((this.mappingsField == null))
                    {
                        this.mappingsField = new System.Collections.Generic.List<VCSessionMappingElement>();
                    }
                    return this.mappingsField;
                }
                set
                {
                    this.mappingsField = value;
                }
            }

            /// <remarks/>
            public VCSessionElementTfs Tfs
            {
                get
                {
                    return this.tfsField;
                }
                set
                {
                    this.tfsField = value;
                }
            }

            /// <remarks/>
            public VCSessionElementSource Source
            {
                get
                {
                    return this.sourceField;
                }
                set
                {
                    this.sourceField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("EventSink", IsNullable = false)]
            public System.Collections.Generic.List<EventSinksElementEventSink> EventSinks
            {
                get
                {
                    if ((this.eventSinksField == null))
                    {
                        this.eventSinksField = new System.Collections.Generic.List<EventSinksElementEventSink>();
                    }
                    return this.eventSinksField;
                }
                set
                {
                    this.eventSinksField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "NCName")]
            public string provider
            {
                get
                {
                    return this.providerField;
                }
                set
                {
                    this.providerField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class VCSessionMappingElement
        {

            private string srcField;

            private string tgtField;

            private bool cloakField;

            public VCSessionMappingElement()
            {
                this.cloakField = false;
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string src
            {
                get
                {
                    return this.srcField;
                }
                set
                {
                    this.srcField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute(DataType = "normalizedString")]
            public string tgt
            {
                get
                {
                    return this.tgtField;
                }
                set
                {
                    this.tgtField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            [System.ComponentModel.DefaultValueAttribute(false)]
            public bool cloak
            {
                get
                {
                    return this.cloakField;
                }
                set
                {
                    this.cloakField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class VCSessionElementTfs : TfsServerReference
        {

            private string workspaceField;

            private string workspaceRootField;

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute(DataType = "normalizedString")]
            public string Workspace
            {
                get
                {
                    return this.workspaceField;
                }
                set
                {
                    this.workspaceField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute(DataType = "normalizedString")]
            public string WorkspaceRoot
            {
                get
                {
                    return this.workspaceRootField;
                }
                set
                {
                    this.workspaceRootField = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class VCSessionElementSource
        {

            private VCSessionElementTfs tfs;

            /// <remarks/>
            // [System.Xml.Serialization.XmlElementAttribute("Provider", typeof(WITSessionElementSourceProvider))]
            //[System.Xml.Serialization.XmlElementAttribute("Tfs", typeof(WitTfsServer))]
            public VCSessionElementTfs Tfs
            {
                get
                {
                    return this.tfs;
                }
                set
                {
                    this.tfs = value;
                }
            }
        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        public partial class ServerElement : IdElement
        {

            private string serverField;
            private string useStoredCredentials = null;

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute(DataType = "normalizedString")]
            public string Server
            {
                get
                {
                    return this.serverField;
                }
                set
                {
                    this.serverField = value;
                }
            }

            [System.Xml.Serialization.XmlElement(ElementName = "UseStoredCredentials", IsNullable = false)]
            public string UseStoredCredentials
            {
                get
                {
                    return useStoredCredentials;
                }
                set
                {
                    useStoredCredentials = value;
                }
            }

        }

        /// <remarks/>
        [System.CodeDom.Compiler.GeneratedCodeAttribute("GXSD", "1.0.0.0")]
        [System.SerializableAttribute()]
        [System.Diagnostics.DebuggerStepThroughAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class MigrationElementSql
        {

            private string connectionStringField;

            private string databaseField;

            private string serverField;

            /// <remarks/>
            public string ConnectionString
            {
                get
                {
                    return this.connectionStringField;
                }
                set
                {
                    this.connectionStringField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute(DataType = "normalizedString")]
            public string Database
            {
                get
                {
                    return this.databaseField;
                }
                set
                {
                    this.databaseField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute(DataType = "normalizedString")]
            public string Server
            {
                get
                {
                    return this.serverField;
                }
                set
                {
                    this.serverField = value;
                }
            }
        }
    }
}
