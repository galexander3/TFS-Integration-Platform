using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;
using Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.Schemas;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.DataContracts
{
    [DataContract]
    public class FileListDataContract
    {
        [DataMember]
        public List<string> fileNames = new List<string>();
    }

}