using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.DataContracts
{
    [DataContract]
    public class ServerError
    {
        private string message;

        [DataMember]
        public string Message
        {
            get { return message; }
            set { message = value; }
        }

        public ServerError()
        {

        }

        public ServerError(string message)
        {
            this.message = message;
        }

        public override string ToString()
        {
            return message;
        }
    }
}
