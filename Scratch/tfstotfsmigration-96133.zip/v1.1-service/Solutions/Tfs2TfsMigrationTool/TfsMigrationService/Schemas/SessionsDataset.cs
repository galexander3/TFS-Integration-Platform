﻿namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.Schemas {


    partial class SessionsDataset
    {
        partial class EventsDataTable
        {
        }
    }
}
