using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.Business
{
    class ExceptionManager
    {

        public static void WriteEventLogEntry(string message, Exception ex)
        {
            try
            {
                string sourceName = "TfsMigrationService";

                string detailedMessage = String.Format("Message: {0}\n Call Stack: {1} {2}", message, ex.Message, ex.StackTrace);

                if (!EventLog.SourceExists(sourceName))
                    EventLog.CreateEventSource(sourceName, "Application");

                EventLog.WriteEntry(sourceName, detailedMessage, EventLogEntryType.Error);
            }
            catch (Exception innerEx)
            {
                //If an error occurs here, then Event Log access is not working.  Nowhere to write it to but a trace file...
                System.Diagnostics.Trace.Write(innerEx.Message);
            }
        }
    }
}
