using System;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.Business
{
    class TfsToTfsSession
    {
        private SessionEventManager _sessionEventManager;
        private IMigrationSession _session;

        public SessionEventManager SessionEventManager
        {
            get{ return _sessionEventManager;}
            set{_sessionEventManager = value;}
        }

        public IMigrationSession Session
        {
            get { return _session; }
            set {_session = value; }
        }
    }
}
