using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.DataContracts;
using Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.Schemas;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.ServiceContracts
{
    [ServiceContract()]
    public interface IMigrationServiceContract
    {

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        string GetConfigFileContents();

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        string GetTemplateFileContents();

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        void SaveConfigFile(string fileContents);

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        void InitializeService();

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        void ShutDownService();

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        void StartSession(string sessionId, bool oneWay);

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        void StopSession(string sessionId, int sessionInstanceId);

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        void StartMirror(string sessionId, bool oneWay);

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        void StopMirror(string sessionId, int sessionInstanceId);

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        SessionsDataset GetSessionInstances(bool includeCompleted);

        [FaultContract(typeof(ServerError))] 
        [OperationContract]
        SessionsDataset GetEventsForSessionInstance(int sessionInstanceId);



    }
}
