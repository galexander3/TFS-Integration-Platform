﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.Common
{
    public class Constants
    {
        /// <summary>
        /// Name of the TfsToTfs Migration Windows Service
        /// </summary>
        public const string CMIGRATIONSERVICENAME = "TfsMigrationWindowsServiceHost";
    }
}
