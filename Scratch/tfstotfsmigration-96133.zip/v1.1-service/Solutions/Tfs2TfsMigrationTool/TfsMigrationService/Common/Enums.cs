using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Vsts.Ranger.Migration.TfsToTfs.Service.Common
{
    public enum SessionInstanceStatuses
    {
        Running,
        Completed
    }


    public enum MigrationEvents
    {
        AnalysisComplete,
        SessionStart,
        SessionError,
        SessionComplete,
        SessionAborted,
        WorkItemMigrationStart,
        WorkItemMigrationFailed,
        WorkItemAnalysisComplete,
        WorkItemMigrationComplete,
        WorkItemFieldConflict,
        WorkItemAttachmentsOutOfSync,
        WorkItemLinksOutOfSync,
        MissingUser,
        MigrationStarting,
        MigrationResumed,
        MigrationPaused,
        MigrationError,
        MigrationComplete,
        MigrationAborted,
        MigratingChangeStarted,
        MigratingChangeComplete,
        MigrateSingleItemError,
        MigrateSingleItemWarning,
        AnalyzingChangeStarted,
        AnalyzingChangeComplete,
        AnalysisStarting,
        AnalysisResumed,
        AnalysisPaused,
        AnalysisError,
        AnalysisAborted
    }

}
