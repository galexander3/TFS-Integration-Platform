﻿/*
This script was created by Visual Studio on 6/27/2007 at 1:55 PM.
Run this script on grahamba-laptop\sqlexpress.TfsSyncTool.dbo to make it the same as grahamba-laptop.TPCopyLogging.dbo.
This script performs its actions in the following order:
1. Disable foreign-key constraints.
2. Perform DELETE commands. 
3. Perform UPDATE commands.
4. Perform INSERT commands.
5. Re-enable foreign-key constraints.
Please back up your target database before running this script.
*/
SET NUMERIC_ROUNDABORT OFF
GO
SET XACT_ABORT, ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
-- Pointer used for text / image updates. This might not be needed, but is declared here just in case
DECLARE @pv binary(16)
BEGIN TRANSACTION
if not exists (select * from [dbo].[SessionInstanceStatuses] where [StatusID] = (N'Completed')) INSERT INTO [dbo].[SessionInstanceStatuses] ([StatusID]) VALUES (N'Completed')
if not exists (select * from [dbo].[SessionInstanceStatuses] where [StatusID] = (N'Running')) INSERT INTO [dbo].[SessionInstanceStatuses] ([StatusID]) VALUES (N'Running')
if not exists (select * from [dbo].[SessionInstanceStatuses] where [StatusID] = (N'Stopped')) INSERT INTO [dbo].[SessionInstanceStatuses] ([StatusID]) VALUES (N'Stopped')

COMMIT TRANSACTION
