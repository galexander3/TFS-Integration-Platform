﻿CREATE PROCEDURE [dbo].[sp_GetEventsForSessionInstance]
@SessionInstanceID int
AS
BEGIN
	SET NOCOUNT ON;


SELECT top 500 [EventID]
      ,[SessionInstanceID]
      ,[EventType]
      ,[Description]
      ,[Exception]
      ,[MigratedItemCount]
      ,[MigratedFailureCount]
      ,[Time]
      ,[SourceID]
      ,[SourceRevisions]
      ,[TargetID]
      ,[TargetRevisions]
      ,[Ids]
      ,[Reaction]
      ,[FieldName]
      ,[Username]
      ,[WorkItemStore]
  FROM [Events]
WHERE [SessionInstanceID] = @SessionInstanceID 
ORDER BY EventID DESC


END


