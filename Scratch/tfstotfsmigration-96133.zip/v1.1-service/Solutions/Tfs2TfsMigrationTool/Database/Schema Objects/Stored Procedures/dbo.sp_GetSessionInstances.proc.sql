﻿CREATE PROCEDURE [dbo].[sp_GetSessionInstances]
@IncludeCompleted bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

if(@IncludeCompleted = 0)
	BEGIN
		SELECT [SessionInstanceID]
			  ,[CurrentStatus]
			  ,[StartTime]
			  ,[CompleteTime]
			  ,[SessionID]
			  ,[OneTimeOnly]
			  ,[OneWayMigration]
		  FROM [SessionInstances]
		WHERE CurrentStatus = 'Running'
		ORDER BY [StartTime] DESC
	END
ELSE
	BEGIN
		SELECT [SessionInstanceID]
			  ,[CurrentStatus]
			  ,[StartTime]
			  ,[CompleteTime]
			  ,[SessionID]
			  ,[OneTimeOnly]
			  ,[OneWayMigration]
		  FROM [SessionInstances]
		ORDER BY [StartTime] DESC
	END

END


