﻿CREATE PROCEDURE [dbo].[sp_UpdateSessionInstance]
@SessionInstanceID int,
@CurrentStatus varchar(50)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


DECLARE @OneTimeOnly bit

SELECT @OneTimeOnly = OneTimeOnly from SessionInstances where sessioninstanceid = @SessionInstanceID

select @OneTimeOnly

--  Stopped Mirrored Session
IF(@CurrentStatus = 'Stopped')
	BEGIN
		UPDATE [SessionInstances]
		   SET [CurrentStatus] = @CurrentStatus
		 WHERE [SessionInstanceID] = @SessionInstanceID
	END
ELSE
	BEGIN
		IF(@CurrentStatus = 'Completed' AND @OneTimeOnly = 1)  
			BEGIN
				-- Ignore 'Completed' updates for Mirrored sessions, they can only be 'Stopped'
				UPDATE [SessionInstances]
				   SET [CurrentStatus] = @CurrentStatus
					  ,[CompleteTime] = GETDATE()
				 WHERE [SessionInstanceID] = @SessionInstanceID
			END
	END
	
	
END


