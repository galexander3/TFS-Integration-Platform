﻿CREATE PROCEDURE [dbo].[sp_InsertSessionInstance]
@CurrentStatus varchar(50),
@StartTime datetime,
@SessionID varchar(250),
@OneTimeOnly bit,
@OneWayMigration bit,
@SessionInstanceID int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

INSERT INTO [SessionInstances]
           ([CurrentStatus]
           ,[StartTime]
           ,[SessionID]
		   ,[OneTimeOnly]
           ,[OneWayMigration])
     VALUES
           (@CurrentStatus,
			@StartTime,
			@SessionID,
            @OneTimeOnly,
            @OneWayMigration)

select @SessionInstanceID = @@IDENTITY

END


