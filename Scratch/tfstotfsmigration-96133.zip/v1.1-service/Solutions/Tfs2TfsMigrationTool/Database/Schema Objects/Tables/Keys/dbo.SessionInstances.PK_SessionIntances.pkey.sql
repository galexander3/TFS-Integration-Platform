﻿ALTER TABLE [dbo].[SessionInstances] ADD CONSTRAINT [PK_SessionIntances] PRIMARY KEY CLUSTERED  ([SessionInstanceID]) ON [PRIMARY]


