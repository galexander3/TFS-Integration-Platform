﻿CREATE TABLE [dbo].[SessionInstanceStatuses]
(
[StatusID] [varchar] (50) NOT NULL
) ON [PRIMARY]


