﻿ALTER TABLE [dbo].[Events] WITH NOCHECK ADD
CONSTRAINT [FK_Events_SessionInstances] FOREIGN KEY ([SessionInstanceID]) REFERENCES [dbo].[SessionInstances] ([SessionInstanceID])


