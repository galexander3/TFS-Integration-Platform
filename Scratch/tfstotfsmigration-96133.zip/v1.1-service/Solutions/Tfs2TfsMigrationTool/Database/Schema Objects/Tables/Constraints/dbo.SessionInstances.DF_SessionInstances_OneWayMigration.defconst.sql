﻿ALTER TABLE [dbo].[SessionInstances] ADD CONSTRAINT [DF_SessionInstances_OneWayMigration] DEFAULT ((1)) FOR [OneWayMigration]


