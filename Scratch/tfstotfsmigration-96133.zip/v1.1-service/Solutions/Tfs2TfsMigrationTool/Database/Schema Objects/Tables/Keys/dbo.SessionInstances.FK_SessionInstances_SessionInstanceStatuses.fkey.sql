﻿ALTER TABLE [dbo].[SessionInstances] ADD
CONSTRAINT [FK_SessionInstances_SessionInstanceStatuses] FOREIGN KEY ([CurrentStatus]) REFERENCES [dbo].[SessionInstanceStatuses] ([StatusID])


