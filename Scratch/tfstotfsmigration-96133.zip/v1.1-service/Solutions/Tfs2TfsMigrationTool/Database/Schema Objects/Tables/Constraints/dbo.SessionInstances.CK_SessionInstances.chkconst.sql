﻿ALTER TABLE [dbo].[SessionInstances] ADD CONSTRAINT [CK_SessionInstances] CHECK (([dbo].[IsSessionActive]([SessionID])<=(1)))


