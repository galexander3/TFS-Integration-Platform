﻿ALTER TABLE [dbo].[SessionInstanceStatuses] ADD CONSTRAINT [PK_SessionInstanceStatuses] PRIMARY KEY CLUSTERED  ([StatusID]) ON [PRIMARY]


