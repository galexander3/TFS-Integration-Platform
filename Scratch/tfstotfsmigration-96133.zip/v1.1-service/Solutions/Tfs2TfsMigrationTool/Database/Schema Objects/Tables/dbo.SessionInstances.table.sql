﻿CREATE TABLE [dbo].[SessionInstances]
(
[SessionInstanceID] [int] NOT NULL IDENTITY(1, 1),
[CurrentStatus] [varchar] (50) NOT NULL,
[StartTime] [datetime] NOT NULL,
[CompleteTime] [datetime] NULL,
[SessionID] [varchar] (250) NOT NULL,
[OneTimeOnly] [bit] NOT NULL,
[OneWayMigration] [bit] NOT NULL
) ON [PRIMARY]


