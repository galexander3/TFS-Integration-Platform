﻿CREATE TABLE [dbo].[Events]
(
[EventID] [bigint] NOT NULL IDENTITY(1, 1),
[SessionInstanceID] [int] NOT NULL,
[EventType] [varchar] (255) NOT NULL,
[Description] [varchar] (500) NULL,
[Exception] [varchar] (max) NULL,
[MigratedItemCount] [bigint] NULL,
[MigratedFailureCount] [bigint] NULL,
[Time] [datetime] NULL,
[SourceID] [varchar] (255) NULL,
[SourceRevisions] [bigint] NULL,
[TargetID] [varchar] (255) NULL,
[TargetRevisions] [bigint] NULL,
[Ids] [varchar] (255) NULL,
[Reaction] [varchar] (255) NULL,
[FieldName] [varchar] (255) NULL,
[Username] [varchar] (255) NULL,
[WorkItemStore] [varchar] (255) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


