﻿ALTER TABLE [dbo].[SessionInstances] ADD CONSTRAINT [DF_SessionInstances_OneTimeOnly] DEFAULT ((1)) FOR [OneTimeOnly]


