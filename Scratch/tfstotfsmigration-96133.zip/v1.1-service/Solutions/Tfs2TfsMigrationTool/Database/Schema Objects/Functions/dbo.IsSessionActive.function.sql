﻿CREATE FUNCTION IsSessionActive(@SessionID varchar(250))
RETURNS int
AS
BEGIN
	--  This function is used by a Check Constraint.  It returns true if there is already an active
	--  session record since there can only be one running instance of a migration session.

	DECLARE @ReturnVal int

	SELECT @ReturnVal = count(*) from SessionInstances
	WHERE SessionID = @SessionID AND CurrentStatus = 'Running'

	RETURN @ReturnVal

END


