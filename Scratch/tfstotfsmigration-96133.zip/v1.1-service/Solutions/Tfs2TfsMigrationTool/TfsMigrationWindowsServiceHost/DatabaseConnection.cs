using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

namespace TfsMigrationWindowsServiceHost
{
    public partial class DatabaseConnection : Form
    {
        private SqlConnectionStringBuilder builder;

        public DatabaseConnection()
        {
            InitializeComponent();
		}

        public string ServerName
        {
            get 
            { 
                return @"localhost\" + 
                    txtServerInstanceName.Text.Substring(1 + txtServerInstanceName.Text.IndexOf(@"\")); 
            }
        }

        public string DatabaseName
        {
            get { return txtDatabase.Text; }
        }

        public bool CreateDatabase
        {
            get { return !chkUseExistingDB.Checked; }   
        }

        public SqlConnectionStringBuilder ConnectionStringBuilder
        {
            set { builder = value; }
            get { return builder; } 
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (!CreateDatabase
                || IsValidServerInstanceName(this.txtServerInstanceName.Text))
            {
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Please input a valid local database instance name.");

                this.txtServerInstanceName.Focus();
                this.txtServerInstanceName.SelectAll();
            }
        }

        private bool IsValidServerInstanceName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                return false;
            }

            if (name.Equals(@"\"))
            {
                return false;
            }

            if (name.IndexOf(@"\") > 0)
            {
                return false;
            }

            return true;
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            System.Data.IDbConnection connection = new SqlConnection();

            builder.DataSource = txtServerInstanceName.Text;
            builder.InitialCatalog = txtDatabase.Text;
            builder.IntegratedSecurity = true;

            connection.ConnectionString = builder.ConnectionString;

            try 
            {
                connection.Open();

                MessageBox.Show("Connection OK.");
            }
            catch
            {
                MessageBox.Show("Could not connect. Check the configuration.");
            }
        }


        private void DatabaseConnection_Load(object sender, EventArgs e)
        {
            string defaultServerStr = builder.DataSource;

            txtServerInstanceName.Text = defaultServerStr.Substring(defaultServerStr.IndexOf(@"\") + 1);
            txtDatabase.Text = builder.InitialCatalog;
            
        }

        private void chkUseExistingDB_CheckedChanged(object sender, EventArgs e)
        {
            txtDatabase.Enabled = chkUseExistingDB.Checked;
        }
    }
}