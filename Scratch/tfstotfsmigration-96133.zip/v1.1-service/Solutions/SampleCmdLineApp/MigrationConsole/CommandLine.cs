// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace MigrationConsole
{
    public delegate void CommandLineArgHandler(string arg);
    public delegate void CommandLineNameValuePair(string key, string value);

    class CommandLine
    {
        public event CommandLineNameValuePair ReceiveNameValuePair;
        public event CommandLineArgHandler UnknownArgument;

        void Default(string arg)
        {
            int equalSplit = arg.IndexOf('=');
            if (equalSplit != -1)
            {
                string key;
                string value;
                if (TryCrackVariable(arg, equalSplit, out key, out value))
                {
                    OnReceiveNameValuePair(key, value);
                    return;
                }
            }

            OnUnknownArgument(arg);
        }

        private void OnUnknownArgument(string arg)
        {
            if (UnknownArgument != null)
            {
                UnknownArgument(arg);
            }
        }

        private void OnReceiveNameValuePair(string key, string value)
        {
            if (ReceiveNameValuePair != null)
            {
                ReceiveNameValuePair(key, value);
            }
        }

        static bool TryCrackVariable(string arg, int equalSplit, out string key, out string value)
        {
            bool cracked = false;
            key = null;
            value = null;

            if (equalSplit > 0)
            {
                key = arg.Substring(0, equalSplit);
                value = arg.Substring(equalSplit + 1);
                cracked = true;
            }

            return cracked;
        }

        public void ProcessArgs(string[] args)
        {
            if (args.Length > 0)
            {
                foreach (string arg in args)
                {
                    ProcessArg(arg);
                }
            }
            else
            {
                Usage();
                Environment.Exit(0);
            }
        }

        CommandLineArgHandler GetDelegate(string arg)
        {
            CommandLineArgHandler eval;

            if (!s_argEval.TryGetValue(arg, out eval))
            {
                eval = Default;
            }

            return eval;
        }

        void ProcessArg(string arg)
        {
            CommandLineArgHandler eval = GetDelegate(arg);
            if (eval != null)
            {
                eval(arg);
            }
        }

        public static void Usage()
        {
            Console.WriteLine("------------");
            Console.WriteLine("Usage :");
            Console.WriteLine("\tMigrationconsole.exe <configuration_file> [Mode=Full Wait=60 <other_setting...>]");
            Console.WriteLine("\n");
            Console.WriteLine("1. Configuration_file(Required): The path to cofiguration file.");
            Console.WriteLine("\n");
            Console.WriteLine("2. Mode(Optional): The session starting mode you want to start. This setting can be one of the following value:");
            Console.WriteLine("\tFull: A one time two way synchronization. This is the default value");
            Console.WriteLine("\tSourceToTfs: A one time one way synchronization from Source to Tfs");
            Console.WriteLine("\tTfsToSource: A one time one way synchronization from Tfs to Source");
            Console.WriteLine("\tService: The synchronization is running as a service. Press 'Ctrl-C' to stop the service.");
            Console.WriteLine("\n");
            Console.WriteLine("3. Wait(Optional): The wait time (in seconds) between each polling of session status. The default value is 60.");
            Console.WriteLine("\n");
            Console.WriteLine("4. Other_settings(Optional): Overwrite config settings in 'key=value' format. All keys are case sensitive.");
            Console.WriteLine("------------");
        }

        Dictionary<string, CommandLineArgHandler> s_argEval =
            new Dictionary<string, CommandLineArgHandler>(StringComparer.InvariantCultureIgnoreCase);
    }
}
