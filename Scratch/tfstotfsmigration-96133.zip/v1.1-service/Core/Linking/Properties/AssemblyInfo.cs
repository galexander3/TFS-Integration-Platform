﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Linking")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("568154f9-5c39-43b8-9f90-485596262441")]

[assembly: InternalsVisibleTo("Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100fbc52802e02f530474e35b25f2a1586195d9df76b731be71eb23de6709bb1f4001e044c767cbf9472b94872459caef27558229420a7b044e80543c0eecf66685faa1d9fc4232653d6666e5aee7096eeeaaa44011bad3de497aae736d05a436a72c600717628dc086cc4a555e137e97b5e4d612b60f81d64f1d9b31417e7183d4")]
