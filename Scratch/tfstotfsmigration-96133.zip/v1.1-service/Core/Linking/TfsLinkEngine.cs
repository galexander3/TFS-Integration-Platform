// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Xml.Serialization;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;

using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;


namespace Microsoft.TeamFoundation.Migration.Linking
{
    [XmlType("TfsLinkEngine")]
    public class TfsLinkEngine : LinkEngineBase
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        public TfsLinkEngine()
        {
            // Register TFS link handlers
            ExtractLinksCallback += new ExtractLinks(GetWorkItemHyperlinkLinks);
            ExtractLinksCallback += new ExtractLinks(GetWorkItemRelatedLinks);
            ExtractLinksCallback += new ExtractLinks(GetWorkItemChangeListLinks);
            ExtractLinksCallback += new ExtractLinks(GetWorkItemLatestFileLinks);
            ExtractLinksCallback += new ExtractLinks(GetWorkItemRevisionFileLinks);
            ExtractLinksCallback += new ExtractLinks(GetWorkItemExternalLinks);

            // Register artifact handlers
            RegisterHandler(new TfsHyperlinkHandler());
            RegisterHandler(new TfsWorkItemHandler(this));
            RegisterHandler(new TfsChangelistHandler(this));
            RegisterHandler(new TfsLatestFileHandler(this));
            RegisterHandler(new TfsRevisionFileHandler(this));
            RegisterHandler(new TfsExternalArtifactHandler());
        }

        /// <summary>
        /// Registers artifact handler for both systems.
        /// </summary>
        /// <param name="handler">Artifact handler</param>
        private void RegisterHandler(
            IArtifactHandler handler)
        {
            TfsHandlers.Add(handler);
            OtherHandlers.Add(handler);
        }
    }
}
