// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.IO;
using System.Xml.Serialization;

using Microsoft.TeamFoundation.Migration.Toolkit.Linking;

namespace Microsoft.TeamFoundation.Migration.Linking
{
    /// <summary>
    /// The creational factory for the TFS Linking engine
    /// </summary>
    public class TfsLinkingEngineFactory : IConfigFactory
    {
        #region IConfigFactory Members

        /// <summary>
        /// Creates and returns a new instance of the configuration factory initialized using the provided input parameters.
        /// </summary>
        /// <param name="type">The type of object the factory is being requested to create (should be ILinkEngine).</param>
        /// <param name="xmlFragment">The initialization XML</param>
        /// <returns>The newly created instance of the ILinkEngine derived instance or null if the provided type parameter is not ILinkEngine.</returns>
        public object CreateInstance(Type type, string xmlFragment)
        {
            if (type == typeof(ILinkEngine))
            {
                return new TfsLinkEngine();
            }

            return null;
        }

        #endregion
    }
}
