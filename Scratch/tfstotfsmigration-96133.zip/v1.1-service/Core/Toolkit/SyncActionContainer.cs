// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// Indicates what action to take with the associated data.
    /// </summary>
    public enum AssociationAction
    {
        Add,        // The association needs to be added
        Remove      // The association needs to be removed
    }

    /// <summary>
    /// Container for synchronization operations.
    /// </summary>
    /// <typeparam name="T">Type of the item in the container</typeparam>
    public class SyncActionContainer<T>
    {
        private AssociationAction m_action;                 // Action on the item
        private T m_item;                                   // Item

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="action">Action on the item</param>
        /// <param name="item">item</param>
        public SyncActionContainer(
            AssociationAction action,
            T item)
        {
            m_action = action;
            m_item = item;
        }

        /// <summary>
        /// Provides access to the action.
        /// </summary>
        public AssociationAction Action { get { return m_action; } set { m_action = value; } }

        /// <summary>
        /// Returns item from the container.
        /// </summary>
        public T Item { get { return m_item; } }
    }

}
