using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Client;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    public class AuthenticationHelper
    {

        public static TeamFoundationServer GetServerInstance(string server)
        {
            TfsServer tfsServer = MigrationConfiguration.TfsServers[server];

            bool useStoredCredentials = false;

            if(tfsServer.UseStoredCredentials != null)
                useStoredCredentials = bool.Parse(tfsServer.UseStoredCredentials.ToLower());

            if (useStoredCredentials)
            {
                TeamFoundationServer tfs;

                try
                {
                    tfs = TeamFoundationServerFactory.GetServer(tfsServer.Server, new StoredCredentialsProvider());
                    tfs.EnsureAuthenticated();
                }
                catch (Exception ex)
                {
                    TraceManager.TraceException(ex);
                    throw;
                }
                return tfs;
            }
            else
            {
                TeamFoundationServer tfs;

                try
                {
                    tfs = TeamFoundationServerFactory.GetServer(tfsServer.Server);
                    tfs.EnsureAuthenticated();
                }
                catch (Exception ex)
                {
                    TraceManager.TraceException(ex);
                    throw;
                }
                
                return tfs;
            }
        }
    }
}
