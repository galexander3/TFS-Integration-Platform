// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using Microsoft.TeamFoundation.Migration.Toolkit;

namespace WITTest
{
    /// <summary>
    /// Summary description for WorkItemTrackingSessionTest
    /// </summary>
    [TestClass]
    public class WorkItemTrackingSessionTest
    {

        private string CongigFileValidParam = "WITTests.ValidParam.xml";
        private string CongigFileNoID = "WITTests.NoID.xml";
        private string CongigFileNoServer = "WITTests.NoSessionID.xml";
        private string CongigFileNoSource = "WITTests.MultiSession.xml";
        private string CongigFileNoProvider = "WITTests.NoProvider.xml";
        private string CongigFileServerNotExists = "WITTests.NoProvider.xml";


        public WorkItemTrackingSessionTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod, Description("Should pass")]
        public void TestValidParameters()
        {
            try
            {
                Load(CongigFileValidParam);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should pass - " + e.Message);
            }

            Assert.IsTrue(MigrationConfiguration.Providers.ContainsKey("provider1"), "should pass");
            Assert.IsTrue(MigrationConfiguration.TfsServers.ContainsKey("server1"), "should pass");
        }

        [TestMethod, Description("It should fail")]
        public void TestEmptyID()
        {
            try
            {
                Load(CongigFileNoID);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should pass - " + e.Message);
            }
        }

        [TestMethod, Description("It should fail")]
        public void TestEmptyProviderID()
        {
            try
            {
                Load(CongigFileNoProvider);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should fail - " + e.Message);
            }
        }

        [TestMethod, Description("It should fail")]
        public void TestServerIsNull()
        {
            try
            {
                Load(CongigFileNoServer);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should fail - " + e.Message);
            }
        }

        [TestMethod, Description("It should fail")]
        public void TestSourceIsNull()
        {
            try
            {
                Load(CongigFileNoSource);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should fail - " + e.Message);
            }
        }

        [TestMethod, Description("It should fail")]
        public void TestInvalidSource()
        {
            try
            {
                Load(CongigFileValidParam);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should fail - " + e.Message);
            }
        }

        [TestMethod, Description("It should fail")]
        public void TestInvalidServer()
        {
            try
            {
                Load(CongigFileServerNotExists);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should fail - " + e.Message);
            }
        }

        public void TestLowerCasedServername()
        {
            try
            {
                Load(CongigFileValidParam);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should pass - " + e.Message);
            }
        }

        public void TestUpperCasedServername()
        {
            try
            {
                Load(CongigFileValidParam);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should pass - " + e.Message);
            }
        }

        /// <summary>
        /// Loads configuration settings from resources with the given name/
        /// </summary>
        /// <param name="name">Resource name</param>
        private void Load(string resName)
        {
            if (string.IsNullOrEmpty(resName))
            {
                throw new ArgumentException("Resource name should not be null or empty");
            }

            using (Stream stream = this.GetType().Assembly.GetManifestResourceStream(resName))
            {
                MigrationConfiguration.Load(stream);
            }
        }
    }
}
