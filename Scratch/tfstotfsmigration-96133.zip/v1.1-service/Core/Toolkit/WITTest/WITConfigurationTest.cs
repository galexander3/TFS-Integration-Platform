// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;

namespace WITTest
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class WITConfigurationTest
    {
        private string CongigFileNoWIT = "WITTests.NoWIT.xml";
        private string CongigFileNoID = "WITTests.NoID.xml";
        private string CongigFileEmpty = "WITTests.EmptyWIT.xml";
        private string CongigFileNoSessionID = "WITTests.NoSessionID.xml";
        private string CongigFileMultiSession = "WITTests.MultiSession.xml";
        private string CongigFileDupSessionID = "WITTests.DupSessionID.xml";
        private string CongigFileNoProvider = "WITTests.NoProvider.xml";
        
        
        public WITConfigurationTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion


        [TestInitialize]
        public void Initialize()
        {
        }

        [TestCleanup]
        public void Cleanup()
        {
        }


        [TestMethod, Description("Should fail")]
        public void TestNoWITNode()
        {
            try
            {
                Load(CongigFileNoWIT);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should pass - " + e.Message);
            }
        }

        [TestMethod, Description("Should fail")]
        public void TestNoID()
        {
            try
            {
                Load(CongigFileNoID);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should pass - " + e.Message);
            }
        }

        [TestMethod, Description("Should fail")]
        public void TestEmptyID()
        {
            try
            {
                Load(CongigFileEmpty);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should pass - " + e.Message);
            }
        }


        [TestMethod, Description("Should fail")]
        public void TestNoSessionID()
        {
            try
            {
                Load(CongigFileNoSessionID);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should pass - " + e.Message);
            }
        }


        [TestMethod, Description("Should pass for mulitple valid session")]
        public void TestMultipleValidSession()
        {
            
            try
            {
                Load(CongigFileMultiSession);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed : Should pass - " + e.Message);
            }
            
        }


        [TestMethod, Description("Should fail for duplicated session id")]
        public void TestDuplicatedSessionID()
        {
            try
            {
                Load(CongigFileDupSessionID);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed as expected - " + e.Message);
            }
        }

        [TestMethod, Description("Should fail for duplicated session id")]
        public void TestNoProvider()
        {
            try
            {
                Load(CongigFileNoProvider);
            }
            catch (InitializationException e)
            {
                Console.WriteLine("Failed as expected - " + e.Message);
            }
        }


        /// <summary>
        /// Loads configuration settings from resources with the given name/
        /// </summary>
        /// <param name="name">Resource name</param>
        private void Load(string resName)
        {
            if (string.IsNullOrEmpty(resName))
            {
                throw new ArgumentException("Resource name should not be null or empty");
            }

            using (Stream stream = this.GetType().Assembly.GetManifestResourceStream(resName))
            {
                MigrationConfiguration.Load(stream);
            }
        }

    }
}
