// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// Identifies system used in synchronization.
    /// </summary>
    public enum SystemType
    {
        Tfs,                            // TFS system
        Other,                          // Non-TFS (ACME) system
    }

    /// <summary>
    /// System-specific pair with a value for TFS and for non-TFS systems.
    /// </summary>
    /// <typeparam name="T">Item type</typeparam>
    public class SystemPair<T>
    {
        private T m_tfs;                                    // TFS item
        private T m_other;                                  // Other item

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="tfs">Value on the TFS side</param>
        /// <param name="other">Value on the other side</param>
        public SystemPair(
            T tfs,
            T other)
        {
            m_tfs = tfs;
            m_other = other;
        }

        /// <summary>
        /// Represents content in the string form.
        /// </summary>
        /// <returns>String representation of the content</returns>
        public override string ToString()
        {
            return String.Format(CultureInfo.InvariantCulture, "Tfs: {0}; Other: {1}", m_tfs, m_other);
        }

        public T Tfs { get { return m_tfs; } set { m_tfs = value; } }
        public T Other { get { return m_other; } set { m_other = value; } }
        public T this[SystemType system]
        {
            get { return system == SystemType.Tfs? m_tfs : m_other; }
            set
            {
                if (system == SystemType.Tfs)
                {
                    m_tfs = value;
                }
                else
                {
                    m_other = value;
                }
            }
        }
    }
}
