-- Copyright (c) Microsoft Corporation. All rights reserved.

IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'UPSDEXEC' AND type = 'R')
    DROP ROLE [UPSDEXEC]
GO

CREATE ROLE UPSDEXEC
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [dbo].[ChangeGroups]    Script Date: 07/10/2006 09:54:46 ******/
CREATE TABLE [dbo].[ChangeGroups](
	[ChangeGroupID] [int] IDENTITY NOT NULL,
	[ExecutionOrder] [bigint] NOT NULL,
	[Owner] [nvarchar](max) NOT NULL,
	[Comment] [nvarchar](2048) NULL,
	[ChangeTime] [datetime] NOT NULL,
	[Status] [int] NOT NULL,
	[SessionId] [nvarchar](max) NULL,
	[Direction] [int] NOT NULL,
	[Name] [nvarchar](max) NULL
 CONSTRAINT [PK_ChangeGroups] PRIMARY KEY CLUSTERED 
(
	[ChangeGroupID] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[ActionData]    Script Date: 07/10/2006 09:54:54 ******/
CREATE TABLE [dbo].[ActionData](
	[ActionId] [int] IDENTITY NOT NULL,
	[ChangeGroupID] [int] NOT NULL,
	[Order]         [int] NOT NULL DEFAULT 0,
	[State]         [int] NOT NULL DEFAULT 0,
	[SourceItem] [xml] NULL,
	[TargetSourceItem] [xml] NULL,
	[TargetTargetItem] [xml] NULL,
	[BasicAction] [int] NOT NULL,
	[Recursivity] [bit] NOT NULL,
	[Label] [nvarchar](max) NULL,
	[Version] [nvarchar](max) NULL,
	[MergeVersionTo] [nvarchar](max) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ActionData]  
	WITH CHECK ADD CONSTRAINT 
	[FK_ActionData_ChangeGroups] FOREIGN KEY([ChangeGroupID])
	REFERENCES [dbo].[ChangeGroups] ([ChangeGroupID])
	ON DELETE CASCADE
GO

ALTER TABLE [dbo].[ActionData] CHECK CONSTRAINT [FK_ActionData_ChangeGroups]
GO

/****** Object:  Index [IXCU_ActionId]    Script Date: 07/24/2008 15:21:52 ******/
CREATE UNIQUE CLUSTERED INDEX [IXCU_ActionId] ON [dbo].[ActionData] 
(
	[ActionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, 
DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

/****** Object:  Index [IX_ChangeGroupID]    Script Date: 07/24/2008 15:15:46 ******/
CREATE NONCLUSTERED INDEX [IX_ChangeGroupID] ON [dbo].[ActionData] 
(
	[ChangeGroupID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, 
DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[ConversionHistory]    Script Date: 07/10/2006 09:55:02 ******/
CREATE TABLE [dbo].[ConversionHistory](
	[SessionId] [nvarchar](max) NULL,
	[SourceChangeId] [nvarchar](max) NOT NULL,
	[TfsChangesetId] [int] NULL,
	[UtcWhen] [datetime] NOT NULL,
	[FromSource] [bit] NOT NULL,
	[Comment] [nvarchar](max) NULL
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[Version]    Script Date: 07/10/2006 09:55:02 ******/
CREATE TABLE [dbo].[Version](
	[Version] nvarchar(256) NOT NULL
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[SessionState]    Script Date: 07/10/2006 09:55:02 ******/
CREATE TABLE [dbo].[SessionState](
	[SessionId] [nvarchar](max) NULL,
	[Variable] [nvarchar](256) NULL,
	[Value] [nvarchar](max) NULL
) ON [PRIMARY]

GO
