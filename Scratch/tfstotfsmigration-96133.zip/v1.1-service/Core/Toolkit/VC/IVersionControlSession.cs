// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// The interface that exposes the common events of a version control session.
    /// </summary>
    public interface IVersionControlSession : IMigrationSession
    {
        /// <summary>
        /// Fired before analysis begins.
        /// </summary>
        event EventHandler<VersionControlEventArgs> AnalysisStarting;

        /// <summary>
        /// Fired when analysis encounters an error.
        /// </summary>
        event EventHandler<VersionControlEventArgs> AnalysisError;

        /// <summary>
        /// Fired when an analysis session is aborted.
        /// </summary>
        event EventHandler<VersionControlEventArgs> AnalysisAborted;

        /// <summary>
        /// Fired when an analysis session is completed.
        /// </summary>
        event EventHandler<VersionControlEventArgs> AnalysisComplete;

        /// <summary>
        /// Fired when an individual change analysis is about to begin.
        /// </summary>
        event EventHandler<VersionControlEventArgs> AnalyzingChangeStarting;

        /// <summary>
        /// Fired when an individual change analysis completes
        /// </summary>
        event EventHandler<VersionControlEventArgs> AnalyzingChangeComplete;

        /// <summary>
        /// Fired when migration is about to begin
        /// </summary>
        event EventHandler<VersionControlEventArgs> MigrationStarting;

        /// <summary>
        /// Fired when a migration session encounters an error
        /// </summary>
        event EventHandler<VersionControlEventArgs> MigrationError;

        /// <summary>
        /// Fired when a migration session is aborted.
        /// </summary>
        event EventHandler<VersionControlEventArgs> MigrationAborted;

        /// <summary>
        /// Fired when a migration session completes.
        /// </summary>
        event EventHandler<VersionControlEventArgs> MigrationComplete;

        /// <summary>
        /// Fired when an individual migration action is about to begin
        /// </summary>
        event EventHandler<VersionControlEventArgs> MigratingChangeStarting;

        /// <summary>
        /// Fired when an individual migration action completes
        /// </summary>
        event EventHandler<VersionControlEventArgs> MigratingChangeComplete;

        /// <summary>
        /// Fired when an item download is about to being.
        /// </summary>
        event EventHandler<VersionControlEventArgs> MigrationDownloadStarted;

        /// <summary>
        /// Fired when an item download has completed.
        /// </summary>
        event EventHandler<VersionControlEventArgs> MigrationDownloadCompleted;

        /// <summary>
        /// Fired when there is a migration warning.
        /// </summary>
        event EventHandler<VersionControlEventArgs> MigrationWarning;
    }
}
