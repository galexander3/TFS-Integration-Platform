// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;
using System.Diagnostics;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    [Serializable]
    public class VersionControlMigrationException : MigrationException
    {
        public VersionControlMigrationException()
            : base(MigrationToolkitVCResources.DefaultUnresolvableConflictExceptionMessage)
        {
        }

        public VersionControlMigrationException(string message)
            : base(message)
        {
        }

        public VersionControlMigrationException(string message, bool canRetry)
            : base(message)
        {
            m_canRetry = canRetry;
        }

        public VersionControlMigrationException(Exception innerException)
            : base(MigrationToolkitVCResources.DefaultUnresolvableConflictExceptionMessage, innerException)
        {
        }

        public VersionControlMigrationException(Exception innerException, bool canRetry)
            : base(MigrationToolkitVCResources.DefaultUnresolvableConflictExceptionMessage, innerException)
        {
            m_canRetry = canRetry;
        }

        public VersionControlMigrationException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        public VersionControlMigrationException(string message, Exception innerException, bool canRetry)
            : base(message, innerException)
        {
            m_canRetry = canRetry;
        }

        protected VersionControlMigrationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public bool CanRetry
        {
            get
            {
                return m_canRetry;
            }
        }
        [NonSerializedAttribute]
        bool m_canRetry;
    }

    [Serializable]
    public class MappingNotFoundException : VersionControlMigrationException
    {
        public MappingNotFoundException()
            : this(MigrationToolkitVCResources.VCMappingMissingUnknownItem)
        {
            Debug.Assert(false, "we should not use this exception ctor");
        }

        public MappingNotFoundException(string message)
            : this(message, null)
        {
        }

        public MappingNotFoundException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected MappingNotFoundException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

    }

    /// <summary>
    /// Exception type for the migration toolkit.  Can be used directly or as
    /// a base type.
    /// </summary>
    [Serializable]
    public class UnresolvableConflictException : VersionControlMigrationException
    {
        public UnresolvableConflictException()
            : base(MigrationToolkitVCResources.DefaultUnresolvableConflictExceptionMessage)
        {
        }

        public UnresolvableConflictException(string message)
            : base(message)
        {
        }

        public UnresolvableConflictException(Exception innerException)
            : base(MigrationToolkitVCResources.DefaultUnresolvableConflictExceptionMessage, innerException)
        {
        }

        public UnresolvableConflictException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected UnresolvableConflictException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }


    [Serializable]
    public class VCInvalidPathException : VersionControlMigrationException
    {
        public VCInvalidPathException()
            : base(MigrationToolkitVCResources.DefaultUnresolvableConflictExceptionMessage)
        {
        }

        public VCInvalidPathException(string message)
            : base(message)
        {
        }

        public VCInvalidPathException(Exception innerException)
            : base(MigrationToolkitVCResources.DefaultUnresolvableConflictExceptionMessage, innerException)
        {
        }

        public VCInvalidPathException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected VCInvalidPathException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }

    [Serializable]
    class MigrationAbortedException : VersionControlMigrationException
    {
        public MigrationAbortedException()
            : base(MigrationToolkitVCResources.MigrationProcessAborted)
        {
        }
    }
}
