// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit.VC
{
    public static class Constants
    {
        public const string SqlConnectionStringVariableName = "SQLConnectionString";

        internal const string MigrationToolkitSwitchName = "MigrationToolkit";
        internal const string MigrationToolkitSwitchDescription = "Migration toolkit verbosity switch";
        internal const string MigrationToolkitSwitchDefault = "2";

        public const string MigrationEngineSwitchName = "VCMigrationEngine";
        public const string MigrationEngineSwitchDescription = "Migration engine verbosity switch";
        public const string MigrationEngineSwitchDefault = "2";

        public const string TfsBatchSizeVariableName = "TFSBatchSize";
    }
}
