// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit.VC
{
    public class SqlChangeGroupingMananger : ChangeGroupingMananger
    {
        public SqlChangeGroupingMananger(
            IMigrationItemSerializer sourceSerializer,
            IMigrationItemSerializer targetSerializer,
            VersionControlSession session,
            MigrationDirection direction)
            : base(sourceSerializer, targetSerializer, session, direction)
        {
            if (session == null)
            {
                throw new ArgumentNullException("session");
            }
        }

        public override ChangeGrouping Next()
        {
            return SqlChangeGrouping.Next(this);
        }

        public override int DemoteInProgressActionsToPending()
        {
            return SqlChangeGrouping.DemoteInProgressActionsToPending(Session.Id, Direction);
        }

        public override int PromoteAnalysisToPending()
        {
            return SqlChangeGrouping.PromoteAnalysisToPending(Session.Id, Direction);
        }

        public override int DemoteInProgressActionsToPending(IMigrationTransaction trx)
        {
            return SqlChangeGrouping.DemoteInProgressActionsToPending(trx, Session.Id, Direction);
        }

        public override int PromoteAnalysisToPending(IMigrationTransaction trx)
        {
            return SqlChangeGrouping.PromoteAnalysisToPending(trx, Session.Id, Direction);
        }

        public override ChangeGrouping Create(string groupName)
        {
            ChangeGrouping group = new SqlChangeGrouping(this);
            group.Name = groupName;

            return group;
        }
    }
}
