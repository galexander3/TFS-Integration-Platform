// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.VersionControl.Client;

namespace Microsoft.TeamFoundation.Migration.Toolkit.VC
{
    /// <summary>
    /// The specific action of the migration item.
    /// </summary>
    public enum ChangeAction
    {
        Unknown,
        Add,
        Edit,
        Rename,
        Delete,
        Undelete,
        Branch,
        Merge,
        Label,
        Encoding,
    }

    /// <summary>
    /// The common interface for all migration actions to implement.  Migration actions represent a single
    /// operation to perform on the migration target.
    /// </summary>
    public interface IMigrationAction
    {
        /// <summary>
        /// The change grouping the action is a part of.
        /// </summary>
        ChangeGrouping ChangeGroup
        {
            get;
        }

        /// <summary>
        /// The source item of the migration action.  This is the source item from the source system.
        /// The primary purpose of this item is for item download information.  If no item is being
        /// downloaded (for example during a delete) then this item may be null.
        /// </summary>
        IMigrationItem SourceItem
        {
            get;
            set;
        }

        /// <summary>
        /// The source item of the migration action in the target system.  This item is used during
        /// migration operations that involve a source and target item such as a rename, merge or branch.
        /// This item may be null if not needed (for example add, edit, delete and Label).
        /// </summary>
        IMigrationItem TargetSourceItem
        {
            get;
            set;
        }

        /// <summary>
        /// the target item of the migration action in the target system.  This is used during
        /// migration actions that involve one or more target system items such as add, edit, delete or rename.
        /// This item should never be null.
        /// </summary>
        IMigrationItem TargetTargetItem
        {
            get;
            set;
        }

        /// <summary>
        /// The action being performed.
        /// </summary>
        ChangeAction Action
        {
            get;
            set;
        }

        /// <summary>
        /// If the action is a Label operation this is the name of the label.
        /// </summary>
        string Label
        {
            get;
            set;
        }

        /// <summary>
        /// If the action is an encoding operation this is the new encoding type.
        /// </summary>
        string Encoding
        {
            get;
            set;
        }

        /// <summary>
        /// If true the action is performed recursively, otherwise not.
        /// </summary>
        bool Recursive
        {
            get;
            set;
        }

        /// <summary>
        /// The order in which this action should be executed relative to other actions in the change grouping.
        /// </summary>
        int Order
        {
            get;
            set;
        }

        /// <summary>
        /// The current state of the action.
        /// </summary>
        ActionState State
        {
            get;
            set;
        }

        /// <summary>
        /// Type of the action item. Any = 0, Folder = 1, File = 2,
        /// </summary>
        ItemType ItemType
        {
            get;
            set;
        }

        /// <summary>
        /// This Property is only used for undelete, branch and merge action. 
        /// For undelete action, this is the version in which the item was deleted.
        /// For branch action, this is the branch from version
        /// For merge action, this is the start version of merge
        /// </summary>
        string Version
        {
            get;
            set;
        }

        /// <summary>
        /// This Property is only used for merge action. 
        /// For merge action, this is the end version of merge
        /// </summary>
        string MergeVersionTo
        {
            get;
            set;
        }
    }
}
