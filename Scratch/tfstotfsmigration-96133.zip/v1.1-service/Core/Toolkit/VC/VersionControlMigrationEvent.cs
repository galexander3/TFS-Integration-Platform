// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    public class VersionControlEventArgs : MigrationEventArgs
    {
        SystemType m_primarySystem;                 // Primary system of the migration
        ChangeGrouping m_changeGroup;
        /// <summary>
        /// Creates a new event args.
        /// </summary>
        public VersionControlEventArgs(SystemType sourceSystem)
            : this(MigrationToolkitVCResources.DefaultVCEventString, sourceSystem)
        {
        }

        /// <summary>
        /// Creates a new event args with the specified changeGrouping.
        /// </summary>
        /// <param name="sessionId">The session this event was fired in.</param>
        public VersionControlEventArgs(ChangeGrouping changeGrouping, SystemType sourceSystem)
            : this(changeGrouping, MigrationToolkitVCResources.DefaultVCEventString, sourceSystem)
        {
        }

        /// <summary>
        /// Creates a new event args with the specified description.
        /// </summary>
        /// <param name="description">The description of the event</param>
        /// <param name="sourceSystem">The primary system of this event</param>
        public VersionControlEventArgs(string description, SystemType sourceSystem)
            : this(description, null, sourceSystem)
        {
        }

        /// <summary>
        /// Creates a new event args with the specified description and exception.
        /// </summary>
        /// <param name="description">The description of the event</param>
        /// <param name="exception">Exception that should be associated with the event</param>
        /// <param name="sourceSystem">The primary system of this event</param>
        public VersionControlEventArgs(string description, Exception exception, SystemType sourceSystem)
            : base(description, exception)
        {
            m_primarySystem = sourceSystem;
        }

        /// <summary>
        /// Creates a new event args with the specified session and description.
        /// </summary>
        /// <param name="sessionId">The session this event was fired in.</param>
        /// <param name="description">The description of the event</param>
        public VersionControlEventArgs(ChangeGrouping changeGrouping, string description, SystemType sourceSystem)
            : this(changeGrouping, description, null, sourceSystem)
        {
        }

        /// <summary>
        /// Creates a new event args with the specified session and description.
        /// </summary>
        /// <param name="changeGrouping"></param>
        /// <param name="description">The description of the event</param>
        public VersionControlEventArgs(ChangeGrouping changeGrouping, string description, Exception exception, SystemType sourceSystem)
            : base(description, exception)
        {
            m_changeGroup = changeGrouping;
            m_primarySystem = sourceSystem;
        }

        /// <summary>
        /// The ChangeGrouping instance that was being operated on at the time the event was fired.
        /// </summary>
        public ChangeGrouping ChangeGroup
        {
            get
            {
                return m_changeGroup;
            }
        }

        /// <summary>
        /// Gets primary system used in the migration.
        /// </summary>
        public SystemType PrimarySystem 
        { 
            get 
            { 
                return m_primarySystem; 
            } 
        }
    }
}
