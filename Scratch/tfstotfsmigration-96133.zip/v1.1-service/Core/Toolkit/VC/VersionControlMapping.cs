// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// A version control mapping object.  Defines the source, target and workspace mapping 
    /// type (active or cloak) for each VC mapping
    /// </summary>
    [XmlType("Mapping")]
    public class VersionControlMapping
    {
        /// <summary>
        /// The source VC system mapping path.
        /// </summary>
        [XmlAttribute("src")]
        public string Source
        {
            get
            {
                return m_source;
            }
            set
            {
                m_source = value;
            }
        }

        /// <summary>
        /// The TFS system mapping path
        /// </summary>
        [XmlAttribute("tgt")]
        public string Target
        {
            get
            {
                return m_target;
            }
            set
            {
                m_target = value;
            }
        }

        /// <summary>
        /// If True the mapping is a Cloak mapping, else if False an Active mapping.  Default is false (Active).
        /// </summary>
        [XmlAttribute("cloak")]
        public bool Cloak;

        private string m_source;
        private string m_target;
    }
}
