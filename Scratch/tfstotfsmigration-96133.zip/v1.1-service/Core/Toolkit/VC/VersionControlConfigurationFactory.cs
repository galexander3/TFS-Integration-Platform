// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// The provider factory for the VersionControlConfiguration object.
    /// </summary>
    public class VersionControlConfigurationFactory : IConfigFactory
    {
        #region IConfigFactory Members

        /// <summary>
        /// Creates and returns a new instance of the VersionControlConfiguration classes.
        /// </summary>
        /// <param name="xmlFragment">The initialization xml.</param>
        /// <returns>A VersionControlConfiguration instance.</returns>
        public object CreateInstance(Type type, string xmlFragment)
        {
            if (type == typeof(IMigrationProvider))
            {
                using (StringReader sr = new StringReader(xmlFragment))
                {
                    XPathDocument xpDoc = new XPathDocument(sr);
                    return VersionControlConfiguration.Load(xpDoc.CreateNavigator());
                }
            }

            return null;
        }

        #endregion
    }
}
