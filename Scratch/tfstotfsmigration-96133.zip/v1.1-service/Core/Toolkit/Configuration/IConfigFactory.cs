// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// The common interface that migration toolkit provider factories implement.
    /// </summary>
    public interface IConfigFactory
    {
        /// <summary>
        /// Returns an instance of the newly created object.
        /// </summary>
        /// <param name="xmlFragment">The XML blob that will be used to initialize the object</param>
        /// <param name="type">The type of the object the factory is creating</param>
        /// <returns>The newly created provider instance.</returns>
        object CreateInstance(Type type, string xmlFragment);
    }
}
