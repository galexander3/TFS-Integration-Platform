// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{

    /// <summary>
    /// The interface that migration sessions will implement.  Provides base functionality for controlling
    /// the session, determing the session running state and subscribing to session events such as 
    /// running state changes and errors
    /// </summary>
    public interface IMigrationSession : IMigrationProvider, IDisposable
    {
        /// <summary>
        /// Returns session's unique id.
        /// </summary>
        string Id { get; }

        /// <summary>
        /// Fired when the session is about to start.  This is a cancelable event.
        /// </summary>
        event EventHandler<MigrationSessionEventArgs> SessionStart;

        /// <summary>
        /// Fired after a session is aborted.  This is a non-cancelable event.
        /// </summary>
        event EventHandler<MigrationSessionEventArgs> SessionAborted;

        /// <summary>
        /// Fired after the session completes.  This is a non-cancelable event.
        /// </summary>
        event EventHandler<MigrationSessionEventArgs> SessionComplete;

        /// <summary>
        /// Fired when an error occurs within a session.  This is a non-cancelable event.
        /// </summary>
        event EventHandler<MigrationSessionEventArgs> SessionError;

        /// <summary>
        /// Event for custom logging messages.
        /// </summary>
        event EventHandler<Eventing.CustomMigrationEventArgs> CustomEvent;

        /// <summary>
        /// Helper class for logging custom events.
        /// </summary>
        Eventing.LogHelper LogHelper { get; }


        /// <summary>
        /// True if Complete() has been called, false otherwise.
        /// </summary>
        bool IsComplete
        {
            get;
        }

        /// <summary>
        /// True is Abort() has been called, false otherwise.  Calling Start resets this value.
        /// </summary>
        bool IsAborted
        {
            get;
        }

        /// <summary>
        /// True if Start or Resume have been successfully called and 
        /// neither Pause, Abort or Complete have been called.
        /// </summary>
        bool IsRunning
        {
            get;
        }

        /// <summary>
        /// Registers an external event sink with the events.
        /// </summary>
        /// <param name="sink">The event sink to register</param>
        void RegisterEventSink(IMigrationSessionEventSink sink);
    }
}
