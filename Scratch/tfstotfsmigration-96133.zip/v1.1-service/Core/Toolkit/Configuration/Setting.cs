// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// A name/value pair that is exposed through toolkit configuration file.
    /// </summary>
    public class Setting
    {
        /// <summary>
        /// Creates an instance with an empty name and value.
        /// </summary>
        public Setting()
            : this(string.Empty, string.Empty)
        {
        }

        /// <summary>
        /// Creates an instance with the provided name and value.
        /// </summary>
        /// <param name="name">The name of the Setting.</param>
        /// <param name="value">The value of the Setting.</param>
        public Setting(string name, string value)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            if (value == null)
            {
                throw new ArgumentNullException("value");
            }

            Name = name;
            Value = value;
        }

        /// <summary>
        /// The name of the Setting.
        /// </summary>
        [XmlAttribute("name")]
        public string Name
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }

        /// <summary>
        /// The value of the setting.
        /// </summary>
        [XmlAttribute("value")]
        public string Value
        {
            get
            {
                return m_value;
            }
            set
            {
                m_value = value;
            }
        }

        string m_name;
        string m_value;
    }


}
