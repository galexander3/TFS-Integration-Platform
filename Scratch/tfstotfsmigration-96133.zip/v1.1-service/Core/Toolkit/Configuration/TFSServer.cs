// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Tfs")]
    [XmlType("Tfs")]
    public class TfsServer
    {
        [XmlAttribute("id")]
        public string Id
        {
            get
            {
                return m_id;
            }
            set
            {
                m_id = value;
            }
        }

        [XmlElement("Server")]
        public string Server
        {
            get
            {
                return m_server;
            }
            set
            {
                m_server = value;
            }
        }

        [XmlElement(ElementName = "UseStoredCredentials", IsNullable = false)]
        public string UseStoredCredentials
        {
            get
            {
                return m_useStoredCredentials;
            }
            set
            {
                m_useStoredCredentials = value;
            }
        }

        private string m_server;                            // Connection string
        private string m_id;                                // Server id
        private string m_useStoredCredentials = null;
    }
}
