// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Xml.XPath;
using System.Security.Permissions;
using System.Security;
using System.Diagnostics;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    internal static class MigrationUtil
    {
        public static object LoadTypedData(string xmlFragment, Type resultType)
        {
            using (StringReader sr = new StringReader(xmlFragment))
            {
                XmlSerializer xs = new XmlSerializer(resultType);
                return xs.Deserialize(sr);
            }
        }

        internal static int GetProcessId()
        {
            // we need full trust to access the Process class.
            SecurityPermission sp = new SecurityPermission(PermissionState.Unrestricted);
            try
            {
                sp.Demand();
            }
            catch (SecurityException)
            {
                // we can either die here or return a bogus value.
                // let's favor returning something bogus (0 is unused) so our customers can
                // continue to run with slightly less robust logging data
                return 0;
            }

            return Process.GetCurrentProcess().Id;
        }
    }
}
