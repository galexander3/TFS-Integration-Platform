// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// A migration session event sink.
    /// </summary>
    public interface IMigrationSessionEventSink : IDisposable
    {
        /// <summary>
        /// Registers a migration session with the event sink.
        /// </summary>
        /// <param name="session">The migration sessions whose events are being subscribed to.</param>
        void RegisterSession(IMigrationSession session);
    }
}
