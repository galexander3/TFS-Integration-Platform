﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Eventing
{
    /// <summary>
    /// Arguments for custom migration events.
    /// </summary>
    public class CustomMigrationEventArgs : MigrationEventArgs
    {
        /// <summary>
        /// Gets/sets severity of the event.
        /// </summary>
        public EventSeverity Severity { get; internal set; }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="severity">Severity of the event</param>
        /// <param name="description">Description of the event</param>
        /// <param name="exception">Associated exception</param>
        internal CustomMigrationEventArgs(EventSeverity severity, string description, Exception exception)
            : base(description, exception)
        {
            Severity = severity;
        }
    }
}
