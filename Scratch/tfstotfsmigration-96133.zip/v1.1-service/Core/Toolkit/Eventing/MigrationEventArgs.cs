// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// Base class for all migration events.
    /// </summary>
    public class MigrationEventArgs : EventArgs
    {
        private string m_description;                       // Description of the event
        private DateTime m_time;                            // Local time of the event
        private Exception m_exception;                      // Exception associated with the event

        /// <summary>
        /// Gets/sets description of the event.
        /// </summary>
        public string Description { get { return m_description; } set { m_description = value; } }

        /// <summary>
        /// Gets/sets time of the event.
        /// </summary>
        public DateTime Time { get { return m_time; } set { m_time = value; } }

        /// <summary>
        /// Gets/sets exception associated with the event.
        /// </summary>
        public Exception Exception { get { return m_exception; } set { m_exception = value; } }

        /// <summary>
        /// Default constructor
        /// </summary>
        public MigrationEventArgs()
            : this(null)
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="description">Event's description</param>
        public MigrationEventArgs(
            string description)
            : this(description, null)
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="description">Event's description</param>
        /// <param name="exception">Exception to be associated with the event</param>
        public MigrationEventArgs(
            string description,
            Exception exception)
        {
            m_description = description;
            m_exception = exception;
            m_time = DateTime.Now;
        }
    }
}
