﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Eventing
{
    /// <summary>
    /// Severity of the event
    /// </summary>
    public enum EventSeverity { Notification, Warning, Error, }

    /// <summary>
    /// Interface for firing events.
    /// </summary>
    interface IEventLogger
    {
        /// <summary>
        /// Fires the event.
        /// </summary>
        /// <param name="args">Arguments</param>
        void FireCustomEvent(CustomMigrationEventArgs args);
    }

    /// <summary>
    /// Helper class for logging custom events.
    /// </summary>
    public sealed class LogHelper
    {
        IEventLogger m_session;                             // Target session

        /// <summary>
        /// Logs an error.
        /// </summary>
        /// <param name="description">Description of the event</param>
        /// <param name="exception">Associated exception</param>
        public void LogError(string description, Exception exception)
        {
            LogEvent(EventSeverity.Error, description, exception);
        }

        /// <summary>
        /// Logs a warning.
        /// </summary>
        /// <param name="description">Description of the event</param>
        /// <param name="exception">Associated exception</param>
        public void LogWarning(string description, Exception exception)
        {
            LogEvent(EventSeverity.Warning, description, exception);
        }

        /// <summary>
        /// Logs a notification.
        /// </summary>
        /// <param name="description">Description of the event</param>
        public void LogNotification(string description)
        {
            LogEvent(EventSeverity.Notification, description, null);
        }

        /// <summary>
        /// Fires an event of the given type.
        /// </summary>
        /// <param name="severity">Severity of the event</param>
        /// <param name="description">Description of the event</param>
        /// <param name="exception">Associated event</param>
        public void LogEvent(EventSeverity severity, string description, Exception exception)
        {
            m_session.FireCustomEvent(
                new CustomMigrationEventArgs(severity, description, exception));
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="session">Target session</param>
        internal LogHelper(IEventLogger session)
        {
            m_session = session;
        }
    }
}
