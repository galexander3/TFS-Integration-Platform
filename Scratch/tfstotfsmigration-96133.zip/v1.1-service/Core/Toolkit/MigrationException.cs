// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// Exception type for the migration toolkit.  Can be used directly or as
    /// a base type.
    /// </summary>
    [Serializable]
    public class MigrationException : Exception
    {
        public MigrationException()
        {
        }

        public MigrationException(string message)
            : base(message)
        {
        }

        public MigrationException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected MigrationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }

    /// <summary>
    /// Exception type for the migration toolkit.  Can be used directly or as
    /// a base type.
    /// </summary>
    [Serializable]
    public class InitializationException : MigrationException
    {
        public InitializationException()
        {
        }

        public InitializationException(string message)
            : base(message)
        {
        }

        public InitializationException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected InitializationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
