// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Master policy; defines a policy with a conflict resolution and a master system.
    /// </summary>
    public class WitMasterPolicy : WitMigrationConflictPolicy
    {
        private SystemType m_master;                        // Master system

        /// Returns the master system.
        /// </summary>
        public SystemType MasterSystem
        {
            get { return m_master; }
            internal set { m_master = value; }
        }


        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="defaultMaster">Default master system</param>
        /// <param name="nav">Navigator positioned to the policy</param>
        /// <param name="defaultReaction">Default reaction</param>
        public WitMasterPolicy(
            SystemType defaultMaster,
            XPathNavigator nav,
            WitConflictReaction defaultReaction)
            : base(nav, defaultReaction)
        {
            if (nav != null)
            {
                string master = nav.GetAttribute("master", string.Empty);

                switch (master)
                {
                    case "tfs": m_master = SystemType.Tfs; break;
                    case "other": m_master = SystemType.Other; break;
                    default:
                        Debug.Assert(master == "default", "Unknown master element!");
                        m_master = defaultMaster;
                        break;
                }
            }
            else
            {
                m_master = defaultMaster;
            }
        }

    }
}
