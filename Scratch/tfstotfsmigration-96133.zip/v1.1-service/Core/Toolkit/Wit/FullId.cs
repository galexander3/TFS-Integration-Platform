// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Full work item id; used to completely identify a work item being synchronized.
    /// </summary>
    public class FullId
    {
        private string m_system;                            // System name
        private string m_store;                             // Store name
        private string m_id;                                // Work item id

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="system">Source system</param>
        /// <param name="store">Source work item store</param>
        /// <param name="id">Source work item id</param>
        public FullId(
            string system,
            string store,
            string id)
        {
            m_system = system;
            m_store = store;
            m_id = id;
        }

        /// <summary>
        /// Returns system name.
        /// </summary>
        public string System { get { return m_system; } internal set { m_system = value; } }

        /// <summary>
        /// Returns store name.
        /// </summary>
        public string Store { get { return m_store; } internal set { m_store = value; } }

        /// <summary>
        /// Returns work item id.
        /// </summary>
        public string Id { get { return m_id; } internal set { m_id = value; } }

        /// <summary>
        /// Converts full id into string.
        /// </summary>
        /// <returns>String representation of the content</returns>
        public override string ToString()
        {
            return string.Format(Resources.Culture, Resources.FullIdString, m_system, m_store, m_id);
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="store">Work item store</param>
        /// <param name="id">Item id</param>
        internal FullId(
            IMigrationWorkItemStore store,
            string id)
        {
            m_system = store.SystemName;
            m_store = store.StoreName;
            m_id = id;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        internal FullId()
        {
        }
    }
}
