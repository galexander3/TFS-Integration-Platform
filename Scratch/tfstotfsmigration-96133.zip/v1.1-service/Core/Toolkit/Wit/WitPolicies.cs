// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Collection of WIT policies.
    /// </summary>
    public sealed class WitPolicies
    {
        private SystemType m_master;                        // Master system
        private WitMissingUserPolicy m_missingUser;         // Missing user policy
        private WitMigrationConflictPolicy m_missingArea;   // Missing area policy
        private WitMigrationConflictPolicy m_missingIteration;    // Missing iteration policy
        private WitMasterPolicy m_field;                    // Field conflict policy
        private WitFileAttachmentPolicy m_attachments;      // Attachments conflict policy
        private WitMasterPolicy m_links;                      // links conflict policy

        /// <summary>
        /// Returns master system.
        /// </summary>
        public SystemType MasterSystem 
        {   
            get { return m_master; }
            internal set { m_master = value; }
        }

        /// <summary>
        /// Returns missing user policy.
        /// </summary>
        public WitMissingUserPolicy MissingUser 
        { 
            get { return m_missingUser; }
            internal set { m_missingUser = value; } 
        }

        /// <summary>
        /// Returns missing area policy.
        /// </summary>
        public WitMigrationConflictPolicy MissingArea 
        { 
            get { return m_missingArea; }
            internal set { m_missingArea = value; } 
        }

        /// <summary>
        /// Returns missing iteration policy.
        /// </summary>
        public WitMigrationConflictPolicy MissingIteration 
        { 
            get { return m_missingIteration; }
            internal set { m_missingIteration = value; } 
        }

        /// <summary>
        /// Returns attachments conflict policy.
        /// </summary>
        public WitFileAttachmentPolicy AttachmentsConflict 
        { 
            get { return m_attachments; }
            internal set { m_attachments = value; } 
        }

        /// <summary>
        /// Returns attachments conflict policy.
        /// </summary>
        public WitMasterPolicy LinksConflict
        {
            get { return m_links; }
            internal set { m_links = value; }
        }

        /// <summary>
        /// Returns field conflict policy.
        /// </summary>
        public WitMasterPolicy FieldConflict 
        { 
            get { return m_field; } 
            internal set { m_field = value; } 
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="nav">XPath navigator positioned to Policies node</param>
        internal WitPolicies(
            XPathNavigator nav)
        {
            XPathNavigator userNav = null;
            XPathNavigator fieldNav = null;
            XPathNavigator attachNav = null;
            XPathNavigator linkNav = null;
            XPathNavigator areaNav = null;
            XPathNavigator iterationNav = null;

            if (nav != null)
            {
                string master = nav.GetAttribute("master", string.Empty);
                if (master == "tfs")
                {
                    m_master = SystemType.Tfs;
                }
                else
                {
                    Debug.Assert(master == "other", "Unsupported system type!");
                    m_master = SystemType.Other;
                }

                userNav = nav.SelectSingleNode("MissingUser");
                areaNav = nav.SelectSingleNode("MissingArea");
                iterationNav = nav.SelectSingleNode("MissingIteration");
                fieldNav = nav.SelectSingleNode("FieldConflict");
                attachNav = nav.SelectSingleNode("AttachmentsConflict");
                linkNav = nav.SelectSingleNode("LinksConflict");
            }
            else
            {
                // Default values
                m_master = SystemType.Tfs;
            }
            m_missingUser = new WitMissingUserPolicy(userNav, WitConflictReaction.Throw);
            m_missingArea = new WitMigrationConflictPolicy(areaNav, WitConflictReaction.Create);
            m_missingIteration = new WitMigrationConflictPolicy(iterationNav, WitConflictReaction.Create);
            m_field = new WitMasterPolicy(m_master, fieldNav, WitConflictReaction.Master);
            m_attachments = new WitFileAttachmentPolicy(m_master, attachNav, WitConflictReaction.Union);
            m_links = new WitMasterPolicy(m_master, linkNav, WitConflictReaction.Union);
        }
    }
}
