// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;

using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Arguments for the "conflict detected" event.
    /// </summary>
    public class FieldConflictEventArgs : WorkItemMigrationEventArgs
    {
        private string m_field;                             // Source field name
        private Pair<FullRevision> m_revisions;             // Source and target revisions
        private Pair<object> m_values;                      // Conflicting values
        private WitConflictReaction m_reaction;             // Reaction to the conflict

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="primarySystem">Primary system</param>
        /// <param name="field">Field name on the source side</param>
        /// <param name="revisions">Conflicting revisions</param>
        /// <param name="values">Conflicting values</param>
        /// <param name="reaction">Engine's reaction to the event</param>
        public FieldConflictEventArgs(
            SystemType primarySystem,
            string field,
            Pair<FullRevision> revisions,
            Pair<object> values,
            WitConflictReaction reaction)
            : base(primarySystem, revisions.Left)
        {
            m_field = field;
            m_revisions = revisions;
            m_values = values;
            m_reaction = reaction;

            Description = string.Format(
                Resources.Culture,
                Resources.MsgFieldConflictDetected,
                revisions.Left, revisions.Right, field, values.Left, values.Right);
        }

        /// <summary>
        /// Returns source field name.
        /// </summary>
        public string FieldName { get { return m_field; } }

        /// <summary>
        /// Returns conflicting revisions.
        /// </summary>
        public Pair<FullRevision> Revisions { get { return m_revisions; } }

        /// <summary>
        /// Gets conflicting values.
        /// </summary>
        public Pair<object> Values { get { return m_values; } }

        /// <summary>
        /// Gets policy-defined reaction.
        /// </summary>
        public WitConflictReaction Reaction { get { return m_reaction; } }
    }
}
