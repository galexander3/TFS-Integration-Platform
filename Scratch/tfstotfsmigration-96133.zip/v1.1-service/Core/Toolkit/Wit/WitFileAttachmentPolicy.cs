// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// File attachment policy.
    /// </summary>
    public class WitFileAttachmentPolicy: WitMasterPolicy
    {
        /// <summary>
        /// Default temporary directory.
        /// </summary>
        public static readonly string DefaultTempDirectory = Path.GetTempPath();  

        private string m_tempDir;                           // Temp directory
        private AttachmentComparisonAttributes m_flags;     // File comparison flags
        
        /// <summary>
        /// Returns the master system.
        /// </summary>
        public string TempDirectory { get { return m_tempDir; } }

        /// <summary>
        /// Returns extra comparison attributes.
        /// </summary>
        public AttachmentComparisonAttributes ExtraComparisonAttributes { get { return m_flags; } }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="defaultMaster">Default master system.</param>
        /// <param name="nav">Policy element</param>
        /// <param name="defaultReaction">Default reaction in case the node is missing</param>
        public WitFileAttachmentPolicy(
            SystemType defaultMaster,
            XPathNavigator nav,
            WitConflictReaction defaultReaction)
            : base (defaultMaster, nav, defaultReaction)
        {
            if (nav != null)
            {
                m_tempDir = nav.GetAttribute("filesPerUpdate", string.Empty);
                m_flags = GetComparisonAttributes(nav.GetAttribute("extraComparisonAttributes", string.Empty));
            }
            else
            {
                m_tempDir = DefaultTempDirectory;
                m_flags = AttachmentComparisonAttributes.All;
            }
        }

        /// <summary>
        /// Translates list of attributes from XML.
        /// </summary>
        /// <param name="s">string list of attributes</param>
        /// <returns>Set of flags</returns>
        private static AttachmentComparisonAttributes GetComparisonAttributes(
            string s)
        {
            AttachmentComparisonAttributes flags = AttachmentComparisonAttributes.None;
            string[] tokens = s.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string t in tokens)
            {
                if (t == "createTime")
                {
                    flags |= AttachmentComparisonAttributes.CreateTime;
                }
                else if (t == "lastWriteTime")
                {
                    flags |= AttachmentComparisonAttributes.LastWriteTime;
                }
                else
                {
                    Debug.Assert(t == "all", "Unsupported comparison attribute!");
                    flags = AttachmentComparisonAttributes.All;
                    break;
                }
            }
            return flags;
        }
    }
}
