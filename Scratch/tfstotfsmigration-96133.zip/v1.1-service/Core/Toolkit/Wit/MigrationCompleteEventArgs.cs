// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;

using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Arguments for the completed work item migration event.
    /// </summary>
    public class MigrationCompleteEventArgs : WorkItemMigrationEventArgs
    {
        private FullId m_targetId;                          // Id of the target work item
        private int m_sourceRevisions;                      // Number of revisions on the source side
        private int m_targetRevisions;                      // Number of revisions on the target side

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="primarySystem">Primary system</param>
        /// <param name="sourceId">Id of the source work item</param>
        /// <param name="targetId">Id of the work item on the other side</param>
        /// <param name="sourceRevisions">Number of revisions migrated from the source side</param>
        /// <param name="targetRevisions">Number of revisions created on the target side</param>
        public MigrationCompleteEventArgs(
            SystemType primarySystem,
            FullId sourceId,
            FullId targetId,
            int sourceRevisions,
            int targetRevisions)
            : base(primarySystem, sourceId)
        {
            m_targetId = targetId;
            m_sourceRevisions = sourceRevisions;
            m_targetRevisions = targetRevisions;

            Description = string.Format(
                Resources.Culture,
                Resources.MsgItemMigrationComplete, 
                sourceId, targetId, sourceRevisions, targetRevisions);
        }

        /// <summary>
        /// Constructor for migration that failed.
        /// </summary>
        /// <param name="primarySystem">Primary system</param>
        /// <param name="sourceId">Id of the source work item</param>
        /// <param name="e">Exception that occurred</param>
        public MigrationCompleteEventArgs(
            SystemType primarySystem,
            FullId sourceId,
            Exception e)
            : base(primarySystem, sourceId)
        {
            Exception = e;
            Description = string.Format(Resources.Culture, Resources.MsgItemMigrationFailed, sourceId);
        }

        /// <summary>
        /// Gets the work item on the other side.
        /// </summary>
        public FullId TargetId { get { return m_targetId; } }

        /// <summary>
        /// Returns number of revisions migrated from the source side.
        /// </summary>
        public int SourceRevisions { get { return m_sourceRevisions; } }

        /// <summary>
        /// Returns number of revisions created on the target side.
        /// </summary>
        public int TargetRevisions { get { return m_targetRevisions; } }
    }

}
