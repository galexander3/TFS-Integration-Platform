// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// TFS-specific attachments configuration.
    /// </summary>
    public class TfsAttachmentConfiguration
    {
        /// <summary>
        /// Default number of attachments to add/remove per batch/revision.
        /// </summary>
        public const int DefaultAttachmentsPerUpdate = 10;  

        private int m_filesPerUpdate;       // Number of attachments to upload per batch/revision


        /// <summary>
        /// Returns the number of attachments to upload per batch/revision.
        /// </summary>
        public int AttachmentsPerUpdate 
        { 
            get { return m_filesPerUpdate; }
            internal set { m_filesPerUpdate = value; }
        }

        /// <summary>
        /// Creates file attachment configuration object and initializes it with data 
        /// from XML, if any.
        /// </summary>
        /// <param name="nav">XML positioned to the queue element. Can be null.</param>
        /// <returns>File attachment configuration object</returns>
        internal static TfsAttachmentConfiguration Create(XPathNavigator nav)
        {
            TfsAttachmentConfiguration c = new TfsAttachmentConfiguration();
            if (nav != null)
            {
                c.m_filesPerUpdate = XmlConvert.ToInt32(nav.GetAttribute("filesPerUpdate", string.Empty));
            }
            return c;
        }

        /// <summary>
        /// Constructor. Initializes class with default settings.
        /// </summary>
        private TfsAttachmentConfiguration() 
        {
            m_filesPerUpdate = DefaultAttachmentsPerUpdate;
        }
    }
}
