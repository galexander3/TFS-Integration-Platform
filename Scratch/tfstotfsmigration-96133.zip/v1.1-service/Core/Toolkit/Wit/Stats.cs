// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Threading;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// WIT synchronization statistics
    /// </summary>
    class Stats
    {
        private long m_revisionsCreated;                    // Number of revisions created on both sides
        private long m_itemsSynchronized;                   // Number of synchronized items
        private long m_itemsFailed;                         // Number of items that failed to synchronize

        // Accessors
        public long RevisionsCreated { get { return m_revisionsCreated; } }
        public long ItemsSynchronized { get { return m_itemsSynchronized; } }
        public long ItemsFailed { get { return m_itemsFailed; } }

        /// <summary>
        /// Increments number of failed items.
        /// </summary>
        public void IncrementFailedItems()
        {
            Interlocked.Increment(ref m_itemsFailed);
        }

        /// <summary>
        /// Increments number of created revisions.
        /// </summary>
        public void IncrementCreatedRevisions()
        {
            Interlocked.Increment(ref m_revisionsCreated);
        }

        /// <summary>
        /// Increments number of successfully synchronizes items
        /// </summary>
        public void IncrementSynchronizedItems()
        {
            Interlocked.Increment(ref m_itemsSynchronized);
        }
    }
}
