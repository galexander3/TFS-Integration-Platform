// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;

using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Field definition class.
    /// </summary>
    class InternalFieldDefinition
    {
        private int m_id;                                   // Field id
        private Pair<string> m_names;                       // Field names
        private ValueMap m_valueMap;                        // Value map for this field
        private bool m_isFlat;                              // Tells whether the field is flat

        /// <summary>
        /// Constructor for a field definition from the config file.
        /// </summary>
        /// <param name="sharedData">Shared data object</param>
        /// <param name="id">Unique id</param>
        /// <param name="isFlat">Tells whether the field is flat</param>
        /// <param name="e">Field mapping entry from the config file</param>
        public InternalFieldDefinition(
            SyncProcess sharedData,
            int id,
            bool isFlat,
            FieldMapEntry e)
        {
            m_id = id;
            m_names = new Pair<string>(e.TfsName, e.OtherName);
            m_isFlat = isFlat;

            MigrationConfiguration.Current.Wit.ValueMaps.TryGetValue(e.ValueMapName, out m_valueMap);
            
            if (sharedData.TfsSide == Side.Right)
            {
                m_names = !m_names;
            }
        }

        /// <summary>
        /// Constructor for unmapped field definition.
        /// </summary>
        /// <param name="sharedData">Shared data object</param>
        /// <param name="id">Field id</param>
        /// <param name="name">Field name (same on both sides)</param>
        /// <param name="isFlat">Tells whether the field is flat</param>
        public InternalFieldDefinition(
            int id,
            string name,
            bool isFlat)
        {
            m_id = id;
            m_names = new Pair<string>(name, name);
            m_isFlat = isFlat;
        }

        /// <summary>
        /// Field definition id, unique within work item type definition.
        /// </summary>
        public int Id { get { return m_id; } }

        /// <summary>
        /// Gets field names.
        /// </summary>
        public Pair<string> Names { get { return m_names; } }

        /// <summary>
        /// Gets the value map for this field.
        /// </summary>
        public ValueMap ValueMap { get { return m_valueMap; } }

        /// <summary>
        /// Gets Boolean value telling whether the field is flat.
        /// </summary>
        public bool IsFlat { get { return m_isFlat; } }

        /// <summary>
        /// Translates value using value mapping information. 
        /// </summary>
        /// <param name="value">Orignial value</param>
        /// <param name="sourceSystem">System the original value belongs to</param>
        /// <returns>Mapped value</returns>
        public object TranslateValue(
            object value,
            SystemType sourceSystem)
        {
            return ValueMap == null? value : ValueMap.GetValue(value, sourceSystem);
        }
    }
}
