// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.XPath;

using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Conflict policy; describes a policy that supports conflict resolution.
    /// </summary>
    public class WitMigrationConflictPolicy
    {
        private WitConflictReaction m_reaction;             // Reaction

        /// <summary>
        /// Returns expected reaction to the conflict.
        /// </summary>
        public WitConflictReaction Reaction
        {
            get { return m_reaction; }
            internal set { m_reaction = value; }
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="nav">Policy element</param>
        /// <param name="defaultReaction">Default reaction in case the node is missing</param>
        internal WitMigrationConflictPolicy(
            XPathNavigator nav,
            WitConflictReaction defaultReaction)
        {
            if (nav == null)
            {
                m_reaction = defaultReaction;
            }
            else
            {
                string reaction = nav.GetAttribute("reaction", string.Empty);

                switch (reaction)
                {
                    case "throw": m_reaction = WitConflictReaction.Throw; break;
                    case "default": m_reaction = WitConflictReaction.Default; break;
                    case "master": m_reaction = WitConflictReaction.Master; break;
                    case "create": m_reaction = WitConflictReaction.Create; break;

                    default:
                        Debug.Assert(reaction == "union", "Unsupported reaction!");
                        m_reaction = WitConflictReaction.Union;
                        break;
                }
            }
        }

        /// <summary>
        /// Constructor for testing purposes.
        /// </summary>
        /// <param name="reaction">Reaction</param>
        internal WitMigrationConflictPolicy(
            WitConflictReaction reaction)
        {
            m_reaction = reaction;
        }
    }

    /// <summary>
    /// Describes expected reaction to the conflict.
    /// </summary>
    public enum WitConflictReaction
    {
        Throw,                          // Throw an exception
        Default,                        // Use default value from the config file
        Master,                         // Use data from the master system
        Union,                          // Build a union
        Create,                         // Create missing item
    }
}
