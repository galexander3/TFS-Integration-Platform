// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Field map exclusion class.
    /// </summary>
    public sealed class FieldMapExclusion
    {
        private SystemType m_system;                        // System from which the field should be excluded
        private string m_fieldName;                         // Field name

        /// <summary>
        /// Specifies system from which the field should be exlcuded.
        /// </summary>
        public SystemType System { get { return m_system; } }

        /// <summary>
        /// Gets excluded field name.
        /// </summary>
        public string FieldName { get { return m_fieldName; } }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="nav">XML element</param>
        internal FieldMapExclusion(
            XPathNavigator nav)
        {
            string system = nav.GetAttribute("system", string.Empty);
            if (system == "tfs")
            {
                m_system = SystemType.Tfs;
            }
            else
            {
                Debug.Assert(system == "other", "Unsupported system type!");
                m_system = SystemType.Other;
            }
            m_fieldName = nav.GetAttribute("field", string.Empty);
        }
    }
}
