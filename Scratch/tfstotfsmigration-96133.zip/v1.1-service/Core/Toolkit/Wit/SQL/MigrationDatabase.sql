-- Copyright (c) Microsoft Corporation. All rights reserved.

/****** Object:  Table [dbo].[Sources]    Script Date: 02/22/2007 18:22:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Sources](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[System] [nvarchar](20) NOT NULL,
	[Source] [nvarchar](128) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[System] ASC,
	[Source] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Sessions]    Script Date: 02/22/2007 18:23:07 ******/
CREATE TABLE [dbo].[Sessions](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[LeftSourceId] [int] NOT NULL,
	[RightSourceId] [int] NOT NULL,
	[LeftWatermark] [nvarchar](128),
	[RightWatermark] [nvarchar](128)
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[LeftSourceId] ASC,
	[RightSourceId] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[Sessions]  WITH CHECK ADD FOREIGN KEY([LeftSourceId])
REFERENCES [dbo].[Sources] ([Id])
GO
ALTER TABLE [dbo].[Sessions]  WITH CHECK ADD FOREIGN KEY([RightSourceId])
REFERENCES [dbo].[Sources] ([Id])
GO
ALTER TABLE [dbo].[Sessions]  WITH CHECK ADD CHECK  (([LeftSourceId]<[RightSourceId]))
GO

/****** Object:  Table [dbo].[WorkItems]    Script Date: 03/09/2007 21:45:00 ******/
CREATE TABLE [dbo].[WorkItems](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[SourceId] [int] NOT NULL,
	[PublicId] [nvarchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[SourceId] ASC,
	[PublicId] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[WorkItems]  WITH CHECK ADD FOREIGN KEY([SourceId])
REFERENCES [dbo].[Sources] ([Id])

/****** Object:  Table [dbo].[ItemPairs]    Script Date: 03/09/2007 21:45:50 ******/
CREATE TABLE [dbo].[ItemPairs](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[SessionId] [int] NOT NULL,
	[SourceId] [int] NOT NULL,
	[TargetId] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[SessionId] ASC,
	[TargetId] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[SessionId] ASC,
	[SourceId] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[ItemPairs]  WITH CHECK ADD FOREIGN KEY([SessionId])
REFERENCES [dbo].[Sessions] ([Id])
GO
ALTER TABLE [dbo].[ItemPairs]  WITH CHECK ADD FOREIGN KEY([SourceId])
REFERENCES [dbo].[WorkItems] ([Id])
GO
ALTER TABLE [dbo].[ItemPairs]  WITH CHECK ADD FOREIGN KEY([TargetId])
REFERENCES [dbo].[WorkItems] ([Id])
GO
ALTER TABLE [dbo].[ItemPairs]  WITH CHECK ADD CHECK  (([SourceId]<>[TargetId]))

/****** Object:  Table [dbo].[SyncedRevisions]    Script Date: 03/09/2007 21:46:23 ******/
CREATE TABLE [dbo].[SyncedRevisions](
	[PairId] [int] NOT NULL,
	[SourceRev] [int] NOT NULL,
	[TargetRev] [int] NOT NULL
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[SyncedRevisions]  WITH CHECK ADD FOREIGN KEY([PairId])
REFERENCES [dbo].[ItemPairs] ([Id])
GO
ALTER TABLE [dbo].[SyncedRevisions]  WITH CHECK ADD CHECK  (([SourceRev]>=(0) AND [TargetRev]>=(0)))
