// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.XPath;
using System.Xml;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// The configuration settings for WIT linking.
    /// </summary>
    public class TfsLinkConfiguration
    {
        private const int s_defaultLinksPerUpdate = 100;
        private int m_linksPerUpdate;

        private TfsLinkConfiguration()
        {
            m_linksPerUpdate = s_defaultLinksPerUpdate;
        }

        /// <summary>
        /// The number of links to submit per batch operation.  Defaults to 100.  Setting this value to high can result
        /// in errors when the batches are submitted to the application tier for processing.
        /// </summary>
        public int LinksPerUpdate
        {
            get
            {
                return m_linksPerUpdate;
            }
        }

        /// <summary>
        /// Creates a new instance of the TfsLinkConfiguration object using the provided configuration.
        /// </summary>
        /// <param name="nav">The XML configuration setting to load the settings from</param>
        /// <returns>The created linking configuration object.</returns>
        internal static TfsLinkConfiguration Create(XPathNavigator nav)
        {
            TfsLinkConfiguration c = new TfsLinkConfiguration();
            
            if (nav != null)
            {
                int per = XmlConvert.ToInt32(nav.GetAttribute("linksPerUpdate", string.Empty));
                
                if (per < 1)
                {
                    per = 1;
                }

                c.m_linksPerUpdate = per;
            }

            return c;
        }
    }
}
