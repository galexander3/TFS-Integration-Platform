// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Full revision identifier; used to describe a single revision being migrated.
    /// </summary>
    public class FullRevision : FullId
    {
        int m_revision;                                     // Revision id

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="id">Work item's id</param>
        /// <param name="revision">Work item's revision</param>
        public FullRevision(
            FullId id,
            int revision)
        {
            if (id == null)
            {
                throw new ArgumentNullException("id");
            }
            Id = id.Id;
            Store = id.Store;
            System = id.System;
            m_revision = revision;
        }

        /// <summary>
        /// Gets the revision number.
        /// </summary>
        public int Revision { get { return m_revision; } }

        /// <summary>
        /// Converts content of the class into string.
        /// </summary>
        /// <returns>String representation of the content</returns>
        public override string ToString()
        {
            if (m_revision == -1)
            {
                return base.ToString();
            }

            return string.Format(Resources.Culture, Resources.FullRevisionString, System, Store, Id, m_revision);
        }
    }
}
