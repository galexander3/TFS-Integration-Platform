// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Missing user event.
    /// </summary>
    public class MissingUserEventArgs: MigrationEventArgs
    {
        private IMigrationWorkItemStore m_store;            // Target work item store
        private string m_userName;                          // Missing user's name

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="store">Target work item store</param>
        /// <param name="userName">User name</param>
        public MissingUserEventArgs(
            string sessionId,
            IMigrationWorkItemStore store,
            string userName)
            : base(sessionId)
        {
            m_store = store;
            m_userName = userName;
        }


        /// <summary>
        /// Returns user name.
        /// </summary>
        public string UserName { get { return m_userName; } }

        /// <summary>
        /// Returns work item store where the user is missing.
        /// </summary>
        public IMigrationWorkItemStore WorkItemStore { get { return m_store; } }

    }
}
