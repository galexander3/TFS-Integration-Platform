// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Missing user policy; describes a policy for cases where revision's author is not valid for
    /// the opposite side.
    /// </summary>
    public class WitMissingUserPolicy : WitMigrationConflictPolicy
    {
        private string m_defaultUser;                       // Default user

        /// <summary>
        /// Returns name of the default user.
        /// </summary>
        public string DefaultUser { get { return m_defaultUser; } }

        /// <summary>
        /// Constructor for missing user policy which is defined in the config file.
        /// </summary>
        /// <param name="nav">Policy node</param>
        /// <param name="defaultReaction">Default reaction</param>
        internal WitMissingUserPolicy(
            XPathNavigator nav,
            WitConflictReaction defaultReaction)
            : base(nav, defaultReaction)
        {
            if (nav != null)
            {
                Debug.Assert(nav.Name == "MissingUser", "Unknown user policy!");
                m_defaultUser = nav.GetAttribute("defaultUser", string.Empty);

                if (Reaction == WitConflictReaction.Default &&  string.IsNullOrEmpty(m_defaultUser))
                {
                    throw new WitMigrationException(
                        Resources.ErrorNoDefaultUserInPolicy);
                }
            }
        }
    }
}
