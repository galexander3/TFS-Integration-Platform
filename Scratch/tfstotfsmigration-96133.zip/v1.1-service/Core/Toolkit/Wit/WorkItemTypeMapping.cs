// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Work item type mapping.
    /// </summary>
    public class WorkItemTypeMapping
    {
        private string m_tfsName;                           // TFS work item type name
        private string m_otherName;                         // ACME work item type name
        private string m_fieldMapName;                      // Optional field mapping name

        /// <summary>
        /// TFS work item type name.
        /// </summary>
        public string TfsName { get { return m_tfsName; } }

        /// <summary>
        /// Non-TFS work item type name.
        /// </summary>
        public string OtherName { get { return m_otherName; } }

        /// <summary>
        /// Optional name of the field map used in the mapping.
        /// </summary>
        public string FieldMapName { get { return m_fieldMapName; } }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="nav"></param>
        internal WorkItemTypeMapping(
            XPathNavigator nav)
        {
            Debug.Assert(nav.Name == "WorkItemType", "Wrong XML node!");
            m_tfsName = nav.GetAttribute("tfs", string.Empty);
            m_otherName = nav.GetAttribute("other", string.Empty);
            m_fieldMapName = nav.GetAttribute("fieldMap", string.Empty);
        }
    }
}
