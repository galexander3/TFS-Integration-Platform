// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// SQL Data class; constants for working with the internal database.
    /// </summary>
    static class SqlData
    {
        public const int SystemNameLength = 20;
        public const int SourceNameLength = 128;
        public const int WorkItemIdLength = 50;
        public const int SessionWatermarkLength = 128;
    }
}
