// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Server date time; used to represent a server default time in TFS update package.
    /// </summary>
    class TfsServerDateTime
    {
        private static TfsServerDateTime s_value = new TfsServerDateTime(); // Static value

        /// <summary>
        /// Gets the value.
        /// </summary>
        public static TfsServerDateTime Value { get { return s_value; } }

        /// <summary>
        /// Constructor.
        /// </summary>
        private TfsServerDateTime()
        {
        }
    }
}
