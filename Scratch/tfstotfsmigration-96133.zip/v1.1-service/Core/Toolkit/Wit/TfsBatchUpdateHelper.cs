// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml;

using Microsoft.TeamFoundation.WorkItemTracking.Proxy;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Batch update helper; used to submit multiple updates in a single batch.
    /// </summary>
    class TfsBatchUpdateHelper
    {
        private TfsCore m_core;                             // TFS core
        private ClientService m_svc;                        // Work item tracking service
        private IWorkItemUpdate[] m_updates;                // Updates to submit
        private UpdateResult[] m_results;                   // Update results

        /// <summary>
        /// Submits updates into the work item store.
        /// </summary>
        /// <param name="core">Target TFS</param>
        /// <param name="svc">Work item tracking service</param>
        /// <param name="updates">Updates to submit</param>
        /// <returns>Results</returns>
        public static UpdateResult[] Submit(
            TfsCore core,
            ClientService svc,
            IWorkItemUpdate[] updates)
        {
            TfsBatchUpdateHelper helper = new TfsBatchUpdateHelper(core, svc, updates);
            helper.Submit(0, updates.Length - 1);
            return helper.m_results;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="core">Target TFS</param>
        /// <param name="svc">Work item tracking service</param>
        /// <param name="updates">Updates to submit</param>
        private TfsBatchUpdateHelper(
            TfsCore core,
            ClientService svc,
            IWorkItemUpdate[] updates)
        {
            m_core = core;
            m_svc = svc;
            m_updates = updates;
            m_results = new UpdateResult[updates.Length];
        }

        /// <summary>
        /// Submits items from the given range.
        /// </summary>
        /// <param name="firstItem">First item in the range</param>
        /// <param name="lastItem">Last item in the range</param>
        private void Submit(
            int firstItem,
            int lastItem)
        {
            Debug.Assert(firstItem <= lastItem, "Invalid range!");
            XmlDocument doc = new XmlDocument();
            XmlElement packageElement = doc.CreateElement("Package");
            packageElement.SetAttribute("Product", m_core.WorkItemTrackingUrl);
            doc.AppendChild(packageElement);

            for (int i = firstItem; i <= lastItem; i++)
            {
                TfsWorkItemUpdate u = (TfsWorkItemUpdate)m_updates[i];
                u.SubmitData(doc);
            }

            // Submit the update package
            XmlElement outElement = null;
            Exception resException = null;

            try
            {
                MetadataTableHaveEntry[] metadataHave = new MetadataTableHaveEntry[0];
                string dbStamp;
                IMetadataRowSets rowsets;

                m_svc.Update(
                    ClientService.NewRequestId(),
                    packageElement,
                    out outElement,
                    metadataHave,
                    out dbStamp,
                    out rowsets);
            }
            catch (Exception e)
            {
                resException = e;
            }

            if (resException != null)
            {
                //$TODO_VNEXT: extract more information from SOAP exceptions
                if (firstItem == lastItem)
                {
                    m_results[firstItem] = new UpdateResult(resException);
                }
                else
                {
                    int mid = firstItem + (lastItem - firstItem) / 2;
                    Submit(firstItem, mid);
                    Submit(mid + 1, lastItem);
                }
            }
            else
            {
                // Process results
                foreach (XmlElement resElement in outElement.ChildNodes)
                {
                    Debug.Assert(
                        resElement.Name == "InsertWorkItem" || resElement.Name == "UpdateWorkItem",
                        "Unsupported result element!");
                    Watermark wm = new Watermark(
                        resElement.GetAttribute("ID"),
                        XmlConvert.ToInt32(resElement.GetAttribute("Revision")));

                    m_results[firstItem++] = new UpdateResult(wm);
                }
            }
        }
    }
}
