// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;

using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Arguments for work item migration events.
    /// </summary>
    public class WorkItemMigrationEventArgs: MigrationEventArgs
    {
        private SystemType m_primarySystem;                 // Primary system of the migration
        private FullId m_sourceId;                          // Id of work item being synchronized

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="primarySystem">Primary system</param>
        /// <param name="sourceId">Id of the work item being migrated</param>
        public WorkItemMigrationEventArgs(
            SystemType primarySystem,
            FullId sourceId)
            : this(primarySystem, sourceId, null)
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="primarySystem">Primary system</param>
        /// <param name="sourceId">Id of the work item being migrated</param>
        /// <param name="description">Description of the event</param>
        public WorkItemMigrationEventArgs(
            SystemType primarySystem,
            FullId sourceId,
            string description)
            : this(primarySystem, sourceId, description, null)
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="primarySystem">Primary system</param>
        /// <param name="sourceId">Id of the source work item</param>
        /// <param name="description">Description of the event</param>
        /// <param name="exception">Exception associated with the event</param>
        public WorkItemMigrationEventArgs(
            SystemType primarySystem,
            FullId sourceId,
            string description,
            Exception exception)
            : base(description, exception)
        {
            m_primarySystem = primarySystem;
            m_sourceId = sourceId;
        }

        /// <summary>
        /// Gets id of the source work item.
        /// </summary>
        public FullId SourceId { get { return m_sourceId; } set { m_sourceId = value; } }

        /// <summary>
        /// Gets primary system used in the migration.
        /// </summary>
        public SystemType PrimarySystem { get { return m_primarySystem; } set { m_primarySystem = value; } }
    }
}
