// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Enumeration for all available queue types.
    /// </summary>
    enum QueueType
    {
        Read,               // Read queue
        Write,              // Write queue
    };

    /// <summary>
    /// Queue configuration class.
    /// </summary>
    public class QueueConfiguration
    {
        public const int DefaultReadThreadCount = 2;    // Default thread count for read queues
        public const int DefaultReadBatchSize = 50;     // Default batch size for read queues
        public const int DefaultWriteThreadCount = 2;   // Default thread count for write queues
        public const int DefaultWriteBatchSize = 64;    // Default batch size for write queues

        private int m_threadCount;                          // Number of threads
        private int m_batchSize;                            // Batch size

        /// <summary>
        /// Returns number of threads listening for the queue.
        /// </summary>
        public int ThreadCount 
        { 
            get { return m_threadCount; }
            internal set { m_threadCount = value; }
        }

        /// <summary>
        /// Returns number of items in the queue which triggers the processing.
        /// </summary>
        public int BatchSize 
        { 
            get { return m_batchSize; }
            internal set { m_batchSize = value; } 
        }

        /// <summary>
        /// Constructor for using with unit tests.
        /// </summary>
        /// <param name="threadCount">Thread count</param>
        /// <param name="batchSize">Batch size</param>
        internal QueueConfiguration(
            int threadCount,
            int batchSize)
        {
            m_threadCount = threadCount;
            m_batchSize = batchSize;
        }

        /// <summary>
        /// Creates queue configuration object and initializes it with data from XML, if any.
        /// </summary>
        /// <param name="type">Queue type</param>
        /// <param name="nav">XML positioned to the queue element. Can be null.</param>
        /// <returns>Queue configuration object</returns>
        internal static QueueConfiguration Create(
            QueueType type,
            XPathNavigator nav)
        {
            QueueConfiguration q = new QueueConfiguration(type);
            if (nav != null)
            {
                q.m_batchSize = XmlConvert.ToInt32(nav.GetAttribute("batchSize", string.Empty));
                q.m_threadCount = XmlConvert.ToInt32(nav.GetAttribute("threadCount", string.Empty));
            }
            return q;
        }

        /// <summary>
        /// Constructor. Initializes class with default settings.
        /// </summary>
        /// <param name="type">Queue type</param>
        private QueueConfiguration(
            QueueType type)
        {
            if (type == QueueType.Read)
            {
                m_threadCount = DefaultReadThreadCount;
                m_batchSize = DefaultReadBatchSize;
            }
            else
            {
                m_threadCount = DefaultWriteThreadCount;
                m_batchSize = DefaultWriteBatchSize;
            }
        }
    }
}
