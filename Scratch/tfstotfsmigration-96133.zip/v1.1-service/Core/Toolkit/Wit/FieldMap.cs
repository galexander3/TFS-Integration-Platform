// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Field map class.
    /// </summary>
    public sealed class FieldMap
    {
        private string m_name;                              // Name of the map
        private ReadOnlyCollection<FieldMapEntry> m_fields;         // Fields in the map
        private ReadOnlyCollection<FieldMapExclusion> m_exclusions; // Exclusions from the map

        /// <summary>
        /// Gets the map name.
        /// </summary>
        public string Name { get { return m_name; } }

        /// <summary>
        /// Gets the list of fields in the map.
        /// </summary>
        public ReadOnlyCollection<FieldMapEntry> Fields { get { return m_fields; } }

        /// <summary>
        /// Gets the list of exclusions specified in the map.
        /// </summary>
        public ReadOnlyCollection<FieldMapExclusion> Exclusions { get { return m_exclusions; } }

        /// <summary>
        /// Initializes field map from XML.
        /// </summary>
        /// <param name="nav">XML node</param>
        internal FieldMap(
            XPathNavigator nav)
        {
            m_name = nav.GetAttribute("name", string.Empty);

            List<FieldMapEntry> fields = new List<FieldMapEntry>();
            List<FieldMapExclusion> exclusions = new List<FieldMapExclusion>();

            XPathNodeIterator set = nav.SelectChildren(XPathNodeType.Element);
            foreach (XPathNavigator item in set)
            {
                if (item.Name == "Field")
                {
                    FieldMapEntry field = new FieldMapEntry(item);
                    fields.Add(field);
                }
                else
                {
                    Debug.Assert(item.Name == "Exclude", "Unknown field map element!");
                    FieldMapExclusion exclusion = new FieldMapExclusion(item);
                    exclusions.Add(exclusion);
                }
            }
            m_fields = fields.AsReadOnly();
            m_exclusions = exclusions.AsReadOnly();
        }

    }
}
