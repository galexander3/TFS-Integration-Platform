// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.XPath;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Field map entry class.
    /// </summary>
    public sealed class FieldMapEntry
    {
        private string m_tfsName;                          // TFS field name
        private string m_otherName;                        // Other field name
        private string m_valueMapName;                     // Name of value mapping, if any

        /// <summary>
        /// Gets TFS field name.
        /// </summary>
        public string TfsName { get { return m_tfsName; } }

        /// <summary>
        /// Gets non-TFS field name.
        /// </summary>
        public string OtherName { get { return m_otherName; } }

        /// <summary>
        /// Gets name of the value mapping.
        /// </summary>
        public string ValueMapName { get { return m_valueMapName; } }
        
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="nav">XML element</param>
        internal FieldMapEntry(
            XPathNavigator nav)
        {
            m_tfsName = nav.GetAttribute("tfsName", string.Empty);
            m_otherName = nav.GetAttribute("otherName", string.Empty);
            m_valueMapName = nav.GetAttribute("valueMap", string.Empty);
        }
    }
}
