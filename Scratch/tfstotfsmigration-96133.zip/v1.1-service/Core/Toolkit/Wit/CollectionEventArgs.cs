// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Arguments describing conflict between two collections (attachments or links)
    /// </summary>
    public class CollectionEventArgs : WorkItemMigrationEventArgs
    {
        private FullId m_targetId;                          // Id of the target work item
        private WitConflictReaction m_reaction;             // Reaction to the conflict

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="primarySystem">Primary system</param>
        /// <param name="ids">Ids of conflicting work items</param>
        /// <param name="reaction">Reaction to the conflict</param>
        /// <param name="description">Event's description</param>
        public CollectionEventArgs(
            SystemType primarySystem,
            Pair<FullId> ids,
            WitConflictReaction reaction,
            string description)
            : base(primarySystem, ids.Left, description)
        {
            m_targetId = ids.Right;
            m_reaction = reaction;
        }

        /// <summary>
        /// Returns id of a target work item.
        /// </summary>
        public FullId TargetId { get { return m_targetId; } }

        /// <summary>
        /// Returns expected reaction to the event.
        /// </summary>
        public WitConflictReaction Reaction { get { return m_reaction; } }
    }
}
