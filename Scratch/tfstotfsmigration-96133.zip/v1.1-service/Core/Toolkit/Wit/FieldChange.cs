// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Field change class; used by the analysis engine to describe a single field change across
    /// revisions.
    /// </summary>
    class FieldChange
    {
        private string m_name;                              // Field name
        private int m_revision;                             // Revision in which the change has happened
        private object m_value;                             // New field value
        private InternalFieldDefinition m_fieldDef;         // Internal field definition

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="name">Field name</param>
        /// <param name="revision">Revision number</param>
        /// <param name="value">Field value</param>
        /// <param name="fldDef">Internal field definition</param>
        public FieldChange(
            string name,
            int revision,
            object value, 
            InternalFieldDefinition fldDef)
        {
            m_name = name;
            m_revision = revision;
            m_value = value;
            m_fieldDef = fldDef;
        }

        /// <summary>
        /// Gets revision.
        /// </summary>
        public int Revision { get { return m_revision; } }

        /// <summary>
        /// Gets value.
        /// </summary>
        public object Value { get { return m_value; } }

        /// <summary>
        /// Gets field name.
        /// </summary>
        public string Name { get { return m_name; } }

        /// <summary>
        /// Gets internal field definition.
        /// </summary>
        public InternalFieldDefinition FieldDefinition { get { return m_fieldDef; } }
    }
}
