// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Wit
{
    /// <summary>
    /// Result of obtaining a certain work item.
    /// </summary>
    public sealed class GetWorkItemResult
    {
        private string m_id;                                // Work item id
        private IMigrationWorkItem m_item;                  // Work item (successful calls only)
        private Exception m_exception;                      // Exceptions (failed calls only)

        /// <summary>
        /// Returns id of the requested work item.
        /// </summary>
        public string Id { get { return m_id; } }

        /// <summary>
        /// Returns requested work item if the call was successful.
        /// </summary>
        public IMigrationWorkItem WorkItem { get { return m_item; } }

        /// <summary>
        /// Gets exception if the work item time could not be retrieved.
        /// </summary>
        public Exception Exception { get { return m_exception; } }

        /// <summary>
        /// Constructor for successful calls.
        /// </summary>
        /// <param name="id">Work item id</param>
        /// <param name="item">Work item</param>
        public GetWorkItemResult(
            string id,
            IMigrationWorkItem item)
        {
            if (string.IsNullOrEmpty(id))
            {
                throw new ArgumentNullException("id");
            }
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            m_id = id;
            m_item = item;
        }

        /// <summary>
        /// Constructor for failed calls.
        /// </summary>
        /// <param name="id">Work item id</param>
        /// <param name="exception">Exception that occurred while getting the work item</param>
        public GetWorkItemResult(
            string id,
            Exception exception)
        {
            if (exception == null)
            {
                throw new ArgumentNullException("exception");
            }
            m_id = id;
            m_exception = exception;
        }
    }
}
