// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /// <summary>
    /// Wrapper for the argument exception.
    /// </summary>
    class ToolkitArgException : ArgumentException
    {
        public ToolkitArgException(string argName)
            : base(string.Format(MigrationToolkitResources.Culture, MigrationToolkitResources.ErrorInvalidArg, argName))
        {
            Debug.Assert(!string.IsNullOrEmpty(argName), "Empty argument name!");
        }
    }
}
