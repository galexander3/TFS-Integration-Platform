using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms;

namespace Microsoft.TeamFoundation.Migration.Controls
{
    // Be sure to see http://msdn2.microsoft.com/en-us/library/system.windows.forms.listview.drawitem.aspx
    // to work around bug
    public partial class ListViewProgress : ListView
    {

        public ListViewProgress()
        {
            InitializeComponent();
            this.View = View.Details;
            this.OwnerDraw = true;
        }


        protected override void OnDrawItem(DrawListViewItemEventArgs e)
        {
            base.OnDrawItem(e);
        }

        protected override void OnDrawSubItem(DrawListViewSubItemEventArgs e)
        {
            ListViewItemProgress item = (ListViewItemProgress) e.Item;

            //Create the brushes
            Color foreColor = item.Selected ? SystemColors.HighlightText : item.ForeColor;
            Brush backBrush;
            Brush progressBrush;

            if (!item.Selected)
            {
                //Since we are using the html table formatting, we want all odd rows to be one color
                //and all even rows to be one color.
                backBrush = SystemBrushes.Window;
            }
            else
            {
                backBrush = SystemBrushes.Highlight;
            }
            progressBrush = SystemBrushes.ControlDark;
            //Draw the background.  Since we are drawing a custom background, we cannot use e.DrawBackground()
            //we instead have to use the FillRectangle method.
            float percent = ((float) item.Percent / 100);
            Rectangle progressRect = new Rectangle(e.Bounds.X, e.Bounds.Y, (int) (e.Bounds.Width * percent), e.Bounds.Height);
            e.Graphics.FillRectangle(backBrush, e.Bounds);
            e.Graphics.FillRectangle(progressBrush, progressRect);
            

            //If this item is focused we want to draw the focus rectangle.  The focus rectangle will need to be
            //different colors depending on whether or no it is selected.
            if (item.Focused)
            {
                ControlPaint.DrawFocusRectangle(e.Graphics, item.Bounds);
            }

            //Draw the text
            TextRenderer.DrawText(e.Graphics, e.SubItem.Text, this.Font, e.Bounds, foreColor,
                                  TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        }

   
        protected override void OnDrawColumnHeader(DrawListViewColumnHeaderEventArgs e)
        {
            e.DrawDefault = true;
            base.OnDrawColumnHeader(e);
        }

    }

    public class ListViewItemProgress : ListViewItem
    {
        private int m_percent = 0;


        public ListViewItemProgress(String text)
            : base(text)
        {
            m_percent = 0;
        }

        public ListViewItemProgress(String text, int percentComplete)
            : base(text)
        {
            Debug.Assert(percentComplete <= 100 && percentComplete >= 0);
            m_percent = percentComplete;
        }

        public int Percent
        {
            get { return m_percent; }
            set { m_percent = value; }
        }

    }

    public class ListViewSubItemProgress : ListViewItem.ListViewSubItem
    {
        private int m_percent = 0;

        public ListViewSubItemProgress(ListViewItem owner, string text, int percent) : base(owner, text)
        {
            m_percent = percent;
        }

        public int Percent
        {
            get { return m_percent; }
            set { m_percent = value; }
        }

    }

}