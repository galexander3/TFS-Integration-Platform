// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tests.Framework;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Tests
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class WITConfigurationTest : ConfigManagerTestCaseBase
    {
        
        public WITConfigurationTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        #region WIT Configuration Test cases 
        [TestMethod, Description("Test there is no ?Migration/WIT?section ")]
        public void TestNoWITNode()
        {


            XmlNode m = doc.SelectSingleNode("/Migration");
            if (m != null)
            {
                XmlNode node = doc.SelectSingleNode("/Migration/WIT");
                m.RemoveChild(node);
            }

            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName, configFile), "The test data is valid");
            Assert.IsNull(MigrationConfiguration.Current.Wit);

        }

        [TestMethod, Description("Test there is an empty ?Migration/WIT?section")]
        public void TestEmptyWITSection()
        {


            XmlNode m = doc.SelectSingleNode("/Migration/WIT");
            if (m != null)
            {
                XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions");
                m.RemoveChild(node);
            }
            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is invalid");
        }

        [TestMethod, Description("Test there is a ?Migration/WIT?section with �Setting?name value pairs")]
        public void TestWITSetingNameValue()
        {


            // set values
            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName, configFile), "the data is invalid");

            // get values
            WorkItemTrackingConfiguration witConfig = MigrationConfiguration.Current.Wit;
            Assert.IsNotNull(witConfig.GetValue("Setting1"));
        }

        [TestMethod, Description("Test there is a ?Migration/WIT?section with �Setting?name and no values")]
        public void TestWITSetingNameNoValue()
        {


            XmlNode m = doc.SelectSingleNode("/Migration/WIT/Settings/Setting");
            Assert.IsNotNull(m);
            XmlNode p = doc.SelectSingleNode("/Migration/WIT/Settings");
            Assert.IsNotNull(p);

            XmlElement newSetting = doc.CreateElement("Setting");
            newSetting.InnerXml = m.InnerXml;
            newSetting.SetAttribute(m.Attributes[0].Name, m.Attributes[0].Value);

            p.ReplaceChild(newSetting, m);

            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName, configFile), "the setting data is invalid");
        }


        [TestMethod, Description("Test there is no ?Migration/WIT/Sessions?section ")]
        public void TestNoWITSession()
        {


            XmlNode m = doc.SelectSingleNode("/Migration/WIT");
            if (m != null)
            {
                XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions");
                m.RemoveChild(node);
            }

            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is invalid");

        }

        [TestMethod, Description("Should pass for mulitple valid session")]
        public void TestMultipleValidSession()
        {
            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");

            Assert.IsTrue(MigrationConfiguration.Current != null, "should not be null!");
            Assert.IsTrue(MigrationConfiguration.Current.Wit != null, "should not be null!");
        }

        [TestMethod, Description("Should fail no session id")]
        public void TestWITNoSessionID()
        {

            XmlNode parent = doc.SelectSingleNode("/Migration/WIT/Sessions");
            Assert.IsNotNull(parent);
            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            Assert.IsNotNull(node);

            Assert.IsNotNull(node.Attributes[0]);

            XmlElement newSession = doc.CreateElement("Session");
            newSession.InnerXml = node.InnerXml;
            newSession.RemoveAttribute("id");

            parent.ReplaceChild(newSession, node);

            node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            Assert.IsTrue(node.Attributes.Count == 0);

            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName, configFile), "The test data is invalid");
        }


        [TestMethod, Description("Should fail for duplicated session id")]
        public void TestDuplicatedSessionID()
        {


            XmlNode m = doc.SelectSingleNode("/Migration/WIT/Sessions");
            Assert.IsTrue(m != null);

            XmlNode first = m.FirstChild;
            Assert.IsTrue(first != null);

            XmlNode next = first.CloneNode(true);

            Assert.IsTrue(next != null);

            Assert.IsTrue(first != next);

            m.AppendChild(next);

            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName, configFile), "The test data is invalid");
        }

        [TestMethod, Description("Should fail for no provider id")]
        public void TestNoProvider()
        {


            XmlNode m = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Source");
            if (m != null)
            {
                int count = m.ChildNodes.Count;

                XmlNode node = m.SelectSingleNode("Provider");
                Assert.IsTrue(node != null);
                m.RemoveChild(node);
                node = m.SelectSingleNode("Provider");
                Assert.IsTrue(m.ChildNodes.Count == count - 1);
            }

            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName, configFile), "The test data is valid");
        }
        #endregion
    }
}
