// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Schema;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

using Tests.Framework;

namespace Tests.ConfigurationManager
{
    /// <summary>
    /// Read tests for WIT policies.
    /// </summary>
    [TestClass]
    public class XmlPolicyReadTests
    {
        #region Internals
        private XmlDocument LoadFile()
        {
            return SettingsHelper.LoadResourceXml("Tests.ConfigurationManager.XmlReadTestsData.ValidSettings.xml");
        }
        #endregion

        /// <summary>
        /// Scenario: loading XML file with no Policies node.
        /// Expected result: all policies are initialized with default values.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Loading XML file with no Policies node")]
        public void Read_DefaultPolicySettings()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/Policies");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);

            WitPolicies p = MigrationConfiguration.Current.Wit.Sessions["Session1"].Policies;
            Assert.IsTrue(p.MasterSystem == SystemType.Tfs, "Invalid default master system");

            Assert.IsTrue(p.MissingUser.Reaction == WitConflictReaction.Throw, "Invalid default reaction!");

            Assert.IsTrue(p.FieldConflict.MasterSystem == SystemType.Tfs, "Invalid master system!");
            Assert.IsTrue(p.FieldConflict.Reaction == WitConflictReaction.Master, "Invalid default reaction!");

            Assert.IsTrue(p.AttachmentsConflict.MasterSystem == SystemType.Tfs, "Invalid master system!");
            Assert.IsTrue(p.AttachmentsConflict.Reaction == WitConflictReaction.Union, "Invalid reaction for file attachments!");
            Assert.IsTrue(p.AttachmentsConflict.ExtraComparisonAttributes == AttachmentComparisonAttributes.All, "Invalid comparison attributes!");
        }

        /// <summary>
        /// Scenario: getting default values for missing attributes inside Policies element.
        /// Expected result: all policies are initialized with default values.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Getting default values for missing attributes inside Policies element")]
        public void Read_DefaultPolicySettingsFromXml()
        {
            XmlDocument doc = LoadFile();
            XmlElement pe = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/Policies");

            pe.SetAttribute("master", "other");
            foreach (XmlElement c in pe.ChildNodes)
            {
                c.RemoveAllAttributes();
            }

            SettingsHelper.LoadSettings(doc);

            WitPolicies p = MigrationConfiguration.Current.Wit.Sessions["Session1"].Policies;
            Assert.IsTrue(p.MasterSystem == SystemType.Other, "Invalid default master system");

            Assert.IsTrue(p.MissingUser.Reaction == WitConflictReaction.Throw, "Invalid default reaction!");

            Assert.IsTrue(p.FieldConflict.MasterSystem == SystemType.Other, "Invalid master system!");
            Assert.IsTrue(p.FieldConflict.Reaction == WitConflictReaction.Master, "Invalid default reaction!");
        }

        /// <summary>
        /// Scenario: getting non-default values for policies.
        /// Expected result: values should be read.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Getting non-default values for policies")]
        public void Read_NonDefaultPolicySettingsFromXml()
        {
            XmlDocument doc = LoadFile();
            XmlElement pe = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/Policies");
            pe.SetAttribute("master", "other");

            XmlElement fe = (XmlElement)pe.SelectSingleNode("FieldConflict");
            fe.SetAttribute("master", "tfs");
            fe.SetAttribute("reaction", "throw");

            SettingsHelper.LoadSettings(doc);

            WitPolicies p = MigrationConfiguration.Current.Wit.Sessions["Session1"].Policies;
            WitMasterPolicy fp = p.FieldConflict;

            Assert.IsTrue(p.MasterSystem == SystemType.Other, "Invalid master system!");
            Assert.IsTrue(fp.MasterSystem == SystemType.Tfs, "Invalid master system!");
            Assert.IsTrue(fp.Reaction == WitConflictReaction.Throw, "Invalid reaction!");
        }

        /// <summary>
        /// Scenario: Extra comparison attributes are explicitly specified in the config file.
        /// Expected result: Flag is set.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Explicitly specifying all possible extra comparison attributes in the config file")]
        public void Read_ExplicitExtraComparisonAttributes()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/Policies/AttachmentsConflict");

            string[] vals = new string[] { "", "all", "createTime", "lastWriteTime", };

            foreach (string val in vals)
            {
                e.SetAttribute("extraComparisonAttributes", val);

                SettingsHelper.LoadSettings(doc);
                WitFileAttachmentPolicy p = MigrationConfiguration.Current.Wit.Sessions["Session1"].Policies.AttachmentsConflict;


                if (string.IsNullOrEmpty(val))
                {
                    Assert.IsTrue(p.ExtraComparisonAttributes == AttachmentComparisonAttributes.None, "Invalid flags!");
                }
                else if (val == "all")
                {
                    Assert.IsTrue(p.ExtraComparisonAttributes == AttachmentComparisonAttributes.All, "Invalid flags!");
                    Assert.IsTrue((p.ExtraComparisonAttributes & AttachmentComparisonAttributes.CreateTime) != 0, "Invalid flags!");
                    Assert.IsTrue((p.ExtraComparisonAttributes & AttachmentComparisonAttributes.LastWriteTime) != 0, "Invalid flags!");
                }
                else if (val == "createTime")
                {
                    Assert.IsTrue(p.ExtraComparisonAttributes == AttachmentComparisonAttributes.CreateTime, "Invalid flags!");
                }
                else if (val == "lastWriteTime")
                {
                    Assert.IsTrue(p.ExtraComparisonAttributes == AttachmentComparisonAttributes.LastWriteTime, "Invalid flags!");
                }
                else
                {
                    Assert.Fail("Wrong option!");
                }
            }
        }

        /// <summary>
        /// Scenario: getting default value for extra comparison attributes defined by the schema.
        /// Expected result: missing attribute is set to the default value.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Getting default value for extra comparison attributes defined by the schema")]
        public void Read_ExtraComparisonAttributesFromSchema()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/Policies/AttachmentsConflict");
            e.RemoveAttribute("extraComparisonAttributes");

            SettingsHelper.LoadSettings(doc);
            WitFileAttachmentPolicy p = MigrationConfiguration.Current.Wit.Sessions["Session1"].Policies.AttachmentsConflict;
            Assert.IsTrue(p.ExtraComparisonAttributes == AttachmentComparisonAttributes.All, "Invalid flags!");
        }

        /// <summary>
        /// Scenario: invalid provider type in the config file.
        /// Expected result: no error on loading; meaningful exception on using.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Invalid provider type specified in the config file")]
        [ExpectedException(typeof(InitializationException))]
        public void Read_InvalidProviderType()
        {
            XmlDocument doc = LoadFile();
            SettingsHelper.LoadSettings(doc);

            // Using should result in an exception
            MigrationProvider p = MigrationConfiguration.Providers["InvalidProvider"];
            Type t = p.ProviderType;
        }
    }
}
