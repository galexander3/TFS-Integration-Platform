// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Xml;
using System.Xml.Schema;
using Tests.Framework;
using System.IO;

namespace Tests
{
    /// <summary>
    /// Summary description for TargetEndPointTest
    /// </summary>
    [TestClass]
    public class TargetEndPointTest : ConfigManagerTestCaseBase
    {

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void MainlineWorkspaceTest()
        {
            XmlNode workspaceNode = doc.SelectSingleNode("/Migration/VC/Sessions/Session/Tfs/Workspace");

            configFile.WriteAndLoad();

            VersionControlSession session = MigrationConfiguration.Current.VC.Sessions["Session0"];
            Assert.AreEqual(workspaceNode.InnerText, session.Target.Workspace);
        }

        [TestMethod]
        public void SpecialXMLCharactersInWorkspaceTest()
        {
            XmlNode workspaceNode = doc.SelectSingleNode("/Migration/VC/Sessions/Session/Tfs/Workspace");
            
            workspaceNode.InnerText = workspaceNode.InnerText + TestUtils.SpecialXMLCharacters;

            configFile.WriteAndLoad();

            VersionControlSession session = MigrationConfiguration.Current.VC.Sessions["Session0"];
            Assert.AreEqual(workspaceNode.InnerText, session.Target.Workspace);
        }

        [TestMethod]
        public void MainlineServerTest()
        {
            XmlNode serverNode = doc.SelectSingleNode("/Migration/Servers/Tfs/Server");

            configFile.WriteAndLoad();

            Assert.AreEqual(serverNode.InnerText, MigrationConfiguration.TfsServers[configFile.initializer.usedTargetIds[0]].Server);
        }

        [TestMethod]
        public void SpecialXMLCharactersInServerTest()
        {
            XmlNode serverNode = doc.SelectSingleNode("/Migration/Servers/Tfs/Server");

            serverNode.InnerText = serverNode.InnerText + TestUtils.SpecialXMLCharacters;

            configFile.WriteAndLoad();

            Assert.AreEqual(serverNode.InnerText, MigrationConfiguration.TfsServers[configFile.initializer.usedTargetIds[0]].Server);
        }

        ///<summary>
        ///Scenario: Two Version control sessions share the same workspace name
        ///Expected Result: XmlSchemaValidationException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Two Version control sessions share the same workspace name")]
        [ExpectedException(typeof(InitializationException))]
        public void DuplicateWorkspaceName()
        {
            VersionControlSessionInfo oldSession = ConfigParameters.VersionControl.Sessions[0];

            TfsInfo tfsInfo = new TfsInfo(ConfigParameters.TfsInfo.ServerId, ConfigParameters.TfsInfo.WorkspaceName, ConfigParameters.TfsInfo.WorkspaceRoot, ConfigParameters.TfsInfo.ServerURI);
            tfsInfo.WorkspaceRoot = Path.Combine(ConfigParameters.TfsInfo.WorkspaceRoot, "ExtraValue");

            // provide a null event sink otherwise we end up trying to write to the same text report file
            // which causes an exception (which is the correct behavior).  That is not the intent of this test.
            VersionControlSessionInfo vcSession = new VersionControlSessionInfo(oldSession.Mappings[0], tfsInfo, ConfigParameters.defaultProviderId, ConfigParameters.WssInfo, null);

            vcSession.SessionId = "SameWorkspaceNameSession";
          
            ConfigParameters.VersionControl.Sessions.Add(vcSession);
            
            ConfigFile.WriteAndLoad(ConfigParameters);
        }

        ///<summary>
        ///Scenario: Two Version control sessions share the same workspace root
        ///Expected Result: XmlSchemaValidationException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Two Version control sessions share the same workspace root")]
        [ExpectedException(typeof(InitializationException))]
        public void DuplicateWorkspaceRoot()
        {
            VersionControlSessionInfo oldSession = ConfigParameters.VersionControl.Sessions[0];

            TfsInfo tfsInfo = new TfsInfo(ConfigParameters.TfsInfo.ServerId, "Unique Name", ConfigParameters.TfsInfo.WorkspaceRoot, ConfigParameters.TfsInfo.ServerURI);

            // provide a null event sink otherwise we end up trying to write to the same text report file
            // which causes an exception (which is the correct behavior).  That is not the intent of this test.
            VersionControlSessionInfo vcSession = new VersionControlSessionInfo(oldSession.Mappings[0], tfsInfo, ConfigParameters.defaultProviderId, ConfigParameters.WssInfo, null);

            vcSession.SessionId = "SameWorkspaceRootSession";

            ConfigParameters.VersionControl.Sessions.Add(vcSession);

            ConfigFile.WriteAndLoad(ConfigParameters);
        }
    }
}
