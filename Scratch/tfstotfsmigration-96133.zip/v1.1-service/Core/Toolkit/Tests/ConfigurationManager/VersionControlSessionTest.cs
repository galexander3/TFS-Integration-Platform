// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Schema;
using Tests.Framework;

namespace Tests
{
    /// <summary>
    /// Summary description for VersionControlSessionTest
    /// </summary>
    [TestClass]
    public class VersionControlSessionTest : ConfigManagerTestCaseBase
    {

        #region  Helper Methods

        #endregion helper methods

        #region Test cases
        /// <summary>
        ///Tests the main line scenario of the Version Control Session
        /// Source Target And Mappings Exist Continues with no errors
        ///</summary>
        [TestMethod()]
        public void MainlineVCSessionTest()
        {

            configFile.WriteAndLoad();

            XmlNodeList sessionNodes = doc.SelectSingleNode("/Migration/VC/Sessions").ChildNodes;

            Assert.AreEqual(sessionNodes.Count, MigrationConfiguration.Current.VC.Sessions.Count, "Incorrect Number of Sessions");

            int loopIndex = 0;
            foreach(VersionControlSession session in MigrationConfiguration.Current.VC.Sessions.Values)
            {
                XmlNode sessionNode = sessionNodes[loopIndex];

                validateSessionAttributes(session, sessionNode);

                XmlNodeList mappings = doc.GetElementsByTagName("Mappings");

                mappings = mappings[loopIndex].ChildNodes;
                Assert.AreEqual(mappings.Count, session.Mappings.Count, String.Format("Incorrect number of Mappings in session {0}", session.Id));
                for (int j = 0; j < mappings.Count; j++)
                {
                    XmlNode mapping = mappings[j];

                    Assert.AreEqual(mapping.Attributes["src"].InnerText, session.Mappings[j].Source);
                    Assert.AreEqual(mapping.Attributes["tgt"].InnerText, session.Mappings[j].Target);
                    Assert.AreEqual(mapping.Attributes["cloak"].InnerText, session.Mappings[j].Cloak.ToString().ToLower());

                }
                //validate that methods can be called
                session.SynchronizeFull();

                loopIndex++;
            }

        }

        [TestMethod()]
        public void EmptyMappingsNodeVCSessionTest()
        {


            XmlNode node = doc.SelectSingleNode("/Migration/VC/Sessions/Session/Mappings");
            node.RemoveAll();

            configFile.WriteAndLoad();
            VersionControlSession session = MigrationConfiguration.Current.VC.Sessions["Session0"];

            //validate Id
            validateSessionAttributes(session, node.ParentNode);

            //validate Mapping is empty
            Assert.AreEqual(0, session.Mappings.Count);

            //validate that methods can be called
            session.SynchronizeFull();
        }

        [TestMethod()]
        public void EmptySourceSystemNodeVCSessionTest()
        {


            XmlNode node = doc.SelectSingleNode("/Migration/VC/Sessions/Session/Source");
            node.RemoveAll();

            expectInitilizationException(Microsoft_TeamFoundation_Migration_Toolkit_MigrationToolkitResourcesAccessor.ErrorCreatingProviderFromXml);
        }

        [TestMethod()]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void MappingsCollectionWithEmptyMappingTest()
        {


            XmlNode node = doc.SelectSingleNode("/Migration/VC/Sessions/Session/Mappings/Mapping");
            node.RemoveAll();

            configFile.WriteAndLoad();
        }


        [TestMethod()]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void NullTargetTest()
        {


            XmlNode node = doc.SelectSingleNode("/Migration/VC/Sessions/Session/Tfs");
            node.RemoveAll();

            configFile.WriteAndLoad();
        }

        #endregion test cases
    }
}
