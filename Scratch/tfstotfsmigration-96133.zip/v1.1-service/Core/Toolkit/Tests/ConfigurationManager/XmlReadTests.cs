// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Schema;

using Tests.Framework;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    /// <summary>
    /// Schema validation tests.
    /// </summary>
    [TestClass]
    public class XmlReadTests
    {
        public XmlReadTests()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// Loads configuration file from resources.
        /// </summary>
        /// <returns></returns>
        private XmlDocument LoadFile()
        {
            return SettingsHelper.LoadResourceXml("Tests.ConfigurationManager.XmlReadTestsData.ValidSettings.xml");
        }

        /// <summary>
        /// Scenario: Reading a valid configuration file.
        /// Expected Result: Opening a valid config file should never fail.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Reading default setting should never fail!")]
        public void Read_ValidSettings()
        {
            XmlDocument doc = LoadFile();
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Missing Providers section in the config file.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Missing Providers section should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_NoProviders()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Providers");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Missing AssemblyQualifiedName element in the config file.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2),Owner("aliakb")]
        [Description("Missing AssemblyQualifiedName should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_NoAssemblyQualifiedName()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Providers/Provider/AssemblyQualifiedName");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Empty AssemblyQualifiedName element in the config file.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Empty AssemblyQualifiedName element should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_EmptyAssemblyQualifiedName()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Providers/Provider/AssemblyQualifiedName");
            e.InnerText = string.Empty;

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Missing VC section in the config file.
        /// Expected Result: Configuration is loaded.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Missing VC section should not result in an exception")]
        public void Read_NoVC()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/VC");
            e.ParentNode.RemoveChild(e);
            e = doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Linking']");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Missing WIT section in the config file.
        /// Expected Result: Configuration is loaded.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Missing WIT section should not result in an exception")]
        public void Read_NoWIT()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/WIT");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Duplicate setting names at the top level.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Duplicate setting names at the top level should result in an exception")] 
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_DuplicateGlobalSettingName()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/Settings/Setting");
            XmlElement p = (XmlElement)e.ParentNode;
            p.AppendChild(e.Clone());

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Using an unknown provider inside VC section.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Referring to an unknown provider inside VC section should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_NoProviderInVC()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Providers/Provider[@id='SDProvider']");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Using an unknown provider inside WIT section.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Referring to an unknown provider inside WIT section should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_NoProviderInWIT()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Providers/Provider[@id='RandProvider']");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Duplicate providers' ids.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Providers with duplicate ids should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_DuplicateProviderId()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Providers/Provider");
            e.ParentNode.AppendChild(e.Clone());

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Duplicate ids of TF servers.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("TF servers with duplicate ids should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_DuplicateServerId()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Servers/Tfs");
            e.ParentNode.AppendChild(e.Clone());

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: VC sessions with duplicate ids in the config file.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("VC sessions with duplicate names should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_DuplicateVCSessionId()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/VC/Sessions/Session");
            e.ParentNode.AppendChild(e.Clone());

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: WIT sessions with duplicate ids in the config file.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("WIT sessions with duplicate names should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_DuplicateWITSessionId()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            e.ParentNode.AppendChild(e.Clone());

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Empty Servers section in the config file.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Empty Servers section should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_EmptyServers()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Servers");
            e.RemoveAll();

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Missing Servers section in the config file.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Missing Servers section should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_NoServers()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Servers");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Empty Providers section.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Empty providers section should result in an exception!")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_EmptyProviders()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Providers");
            e.RemoveAll();

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: No sessions under VC element.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("No VC sessions should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_NoVCSessions()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/VC/Sessions");
            e.RemoveAll();

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Empty Mappings element in VC section.
        /// Expected Result: No exceptions.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Empty Mappings element should not result in an exception")]
        public void Read_EmptyMappingsInVCSession()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/VC/Sessions/Session/Mappings");
            e.RemoveAll();

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Missing Mappings element under VC session.
        /// Expected Result: No exceptions.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Missing Mappings element under VC should not result in an exception")]
        public void Read_NoMappingsInVCSession()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/VC/Sessions/Session/Mappings");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: VC Mappings, different only by the value of cloak attribute.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("VC mappings that differ only by cloak value should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_DuplicateMapping()
        {
            XmlDocument doc = LoadFile();
            XmlElement e1 = (XmlElement)doc.SelectSingleNode("/Migration/VC/Sessions/Session/Mappings/Mapping");
            bool isCloaked = XmlConvert.ToBoolean(e1.GetAttribute("cloak"));

            XmlElement e2 = (XmlElement)e1.Clone();
            e2.SetAttribute("cloak", XmlConvert.ToString(!isCloaked));
            e1.ParentNode.AppendChild(e2);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Missing Server element under Tfs node.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Missing Server element under Tfs node should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_NoServerInTfs()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Servers/Tfs/Server");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Empty Server element under TFS node.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Empty Server element under Tfs node should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_EmptyServerInTfs()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Servers/Tfs/Server");
            e.InnerText = string.Empty;

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Schema validation of valid VC paths.
        /// Expected Result: No exceptions.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Validating valid VC paths")]
        public void Read_ValidVCPaths()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/VC/Sessions/Session/Mappings/Mapping");

            string a = "tgt";
            string[] values = new string[]
            {
                "$/",
                "$/F",
                "$/Foo",
                "$/Foo/",
                "$/Foo/Bar",
                "$/Foo/Bar/",
                "$/Foo Bar/Test",
                "$/Foo$Bar",
            };

            for (int i = 0; i < values.Length; i++)
            {
                e.SetAttribute(a, values[i]);

                SettingsHelper.LoadSettings(doc);
            }
        }

        /// <summary>
        /// Scenario: Schema validation of invalid VC paths.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Invalid VC paths should result in an exception")]
        public void Read_InvalidVCPaths()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/VC/Sessions/Session/Mappings/Mapping");
            string[] values = new string[]
            {
                "$",
                "/",
                "$//",
                "$Foo",
                "$/Foo/$Bar",
                "$/Foo//Bar",
            };

            string a = "tgt";
            foreach (string v in values)
            {
                e.SetAttribute(a, v);

                try
                {
                    SettingsHelper.LoadSettings(doc);
                    Assert.Fail(string.Format("Path '{0}' should've been rejected!", v));
                }
                catch (XmlSchemaValidationException)
                {
                    // This is expected - do nothing.
                }
            }
        }
        /// <summary>
        /// Scenario: Initializing Tfs settings from the config file.
        /// Expected Result: Valid config values.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Loading TFS data from the config file")]
        public void Read_WitSession()
        {
            XmlDocument doc = LoadFile();
            SettingsHelper.LoadSettings(doc);

            WorkItemTrackingSession session = MigrationConfiguration.Current.Wit.Sessions["Session1"];

            Assert.IsTrue(session.TfsMigrationSource.Server == "Dogfood", "Invalid server!");
            Assert.IsTrue(session.TfsMigrationSource.Project == "VSTS Dogfood", "Invalid project!");
            Assert.IsTrue(session.TfsMigrationSource.Filter == "[System.WorkItemType]='Orcas Bug'", "Invalid filter!");
            Assert.IsTrue(session.FastQueueConfig.BatchSize == 50, "Invalid batch size in the fast queue!");
            Assert.IsTrue(session.FastQueueConfig.ThreadCount == 2, "Invalid thread count in the fast queue!");
            Assert.IsTrue(session.SlowQueueConfig.BatchSize == 50, "Invalid batch size in the slow queue!");
            Assert.IsTrue(session.SlowQueueConfig.ThreadCount == 2, "Invalid thread count in the slow queue!");
        }

        /// <summary>
        /// Scenario: Loading WIT session with no filter.
        /// Expected Result: No exceptions, filter is null.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("WIT session with no filter should be loaded with no exceptions")]
        public void Read_WitSessionNoFilter()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/Tfs/Filter");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);

            WorkItemTrackingSession session = MigrationConfiguration.Current.Wit.Sessions["Session1"];

            Assert.IsTrue(string.IsNullOrEmpty(session.TfsMigrationSource.Filter), "Invalid filter!");
        }

        /// <summary>
        /// Scenario: Missing TFS project in WIT session.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Missing TFS project in WIT session should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_WitSessionNoProject()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Tfs/Project");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Empty TFS project in WIT session.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Empty project in WIT session should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_WitSessionEmptyProject()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Tfs/Project");
            e.InnerText = string.Empty;

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Referring an unknown TF server in WIT session.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Referring an unknown TF server in WIT session should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_WitSessionUnknownServer()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Tfs");
            e.SetAttribute("server", "FooBar");

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Missing queue elements.
        /// Expected Result: Default values are used for missing queue elements.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Using default values for missing Queue elements")]
        public void Read_WitNoQueues()
        {
            XmlDocument doc = LoadFile();
            XmlNode n = doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']");

            n.RemoveChild(n.SelectSingleNode("FastQueue"));
            n.RemoveChild(n.SelectSingleNode("SlowQueue"));

            SettingsHelper.LoadSettings(doc);
            WorkItemTrackingSession session = MigrationConfiguration.Current.Wit.Sessions["Session1"];

            Assert.IsTrue(session.FastQueueConfig.BatchSize == QueueConfiguration.DefaultReadBatchSize, "Invalid default batch size in fast queue!");
            Assert.IsTrue(session.FastQueueConfig.ThreadCount == QueueConfiguration.DefaultReadThreadCount, "Invalid default thread count in fast queue!");

            Assert.IsTrue(session.SlowQueueConfig.BatchSize == QueueConfiguration.DefaultReadBatchSize, "Invalid default batch size in slow queue!");
            Assert.IsTrue(session.SlowQueueConfig.ThreadCount == QueueConfiguration.DefaultReadThreadCount, "Invalid default thread count in slow queue!");
        }

        /// <summary>
        /// Scenario: Missing Queue's attributes.
        /// Expected Result: Default values are used.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Using default values for missing attributes of the Queue element")]
        public void Read_WitEmptyQueues()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/FastQueue");

            e.RemoveAttribute("threadCount");
            e.RemoveAttribute("batchSize");

            SettingsHelper.LoadSettings(doc);
            WorkItemTrackingSession session = MigrationConfiguration.Current.Wit.Sessions["Session1"];

            Assert.IsTrue(session.FastQueueConfig.BatchSize == QueueConfiguration.DefaultReadBatchSize, "Invalid default batch size in fast queue!");
            Assert.IsTrue(session.FastQueueConfig.ThreadCount == QueueConfiguration.DefaultReadThreadCount, "Invalid default thread count in fast queue!");
        }

        /// <summary>
        /// Scenario: Negative thread count.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Negative thread count should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_WitQueueNegativeThreadCount()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/FastQueue");

            e.SetAttribute("threadCount", XmlConvert.ToString(-1));
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Zero thread count.
        /// Expected Result: No exceptions; syncing is running in a synchronous mode.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Zero thread count is OK")]
        public void Read_WitQueueZeroThreadCount()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/FastQueue");

            e.SetAttribute("threadCount", XmlConvert.ToString(0));
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Zero batch size.
        /// Expected: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Zero batch size should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_WitQueueZeroBatchSize()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/FastQueue");

            e.SetAttribute("batchSize", XmlConvert.ToString(0));
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Negative batch size.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Negative batch size should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_WitQueueNegativeBatchSize()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/FastQueue");

            e.SetAttribute("batchSize", XmlConvert.ToString(-1));
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Using non-default queue parameters.
        /// Expected Results: Parameters should be read from the file.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Reading queue parameters from the file")]
        public void Read_WitQueueNonDefaultValues()
        {
            XmlDocument doc = LoadFile();
            XmlNode root = doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']");

            // Fast queue...
            XmlElement e = (XmlElement)root.SelectSingleNode("FastQueue");
            e.SetAttribute("batchSize", XmlConvert.ToString(QueueConfiguration.DefaultReadBatchSize + 1));
            e.SetAttribute("threadCount", XmlConvert.ToString(QueueConfiguration.DefaultReadThreadCount + 1));

            SettingsHelper.LoadSettings(doc);
            QueueConfiguration fastQueue = MigrationConfiguration.Current.Wit.Sessions["Session1"].FastQueueConfig;
            Assert.IsTrue(fastQueue.BatchSize == QueueConfiguration.DefaultReadBatchSize + 1, "Invalid batch size in the fast queue!");
            Assert.IsTrue(fastQueue.ThreadCount == QueueConfiguration.DefaultReadThreadCount + 1, "Invalid thread count in the fast queue!");

            // Slow queue...
            e = (XmlElement)root.SelectSingleNode("SlowQueue");
            e.SetAttribute("batchSize", XmlConvert.ToString(QueueConfiguration.DefaultReadBatchSize + 2));
            e.SetAttribute("threadCount", XmlConvert.ToString(QueueConfiguration.DefaultReadThreadCount + 2));

            SettingsHelper.LoadSettings(doc);
            QueueConfiguration slowQueue = MigrationConfiguration.Current.Wit.Sessions["Session1"].SlowQueueConfig;
            Assert.IsTrue(slowQueue.BatchSize == QueueConfiguration.DefaultReadBatchSize + 2, "Invalid batch size in the slow queue!");
            Assert.IsTrue(slowQueue.ThreadCount == QueueConfiguration.DefaultReadThreadCount + 2, "Invalid thread count in the slow queue!");
        }

        /// <summary>
        /// Scenario: Empty or missing field maps.
        /// Expected Result: No exceptions - field maps are optional.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Empty/missing field maps")]
        public void Read_EmptyOrNoFieldMaps()
        {
            XmlDocument doc = LoadFile();

            // Delete all references to field maps
            XmlNodeList list = doc.SelectNodes("/Migration/WIT/Sessions/Session/WorkItemTypes");
            foreach (XmlNode node in list)
            {
                node.ParentNode.RemoveChild(node);
            }

            XmlNode e = doc.SelectSingleNode("/Migration/WIT/FieldMaps");
            
            // Empty field maps section
            e.RemoveAll();
            SettingsHelper.LoadSettings(doc);

            // No field maps
            e.ParentNode.RemoveChild(e);
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: No field map reference in the WIT mapping.
        /// Expected Result: No exceptions - referencing a field map is optional.
        /// Map name in reference is optional.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Missing field map reference should not cause exceptions")]
        public void Read_NoFieldMapNameInReference()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session/WorkItemTypes/WorkItemType[@fieldMap='default']");
            e.RemoveAttribute("fieldMap");
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Empty field map reference in the WIT mapping.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Empty field map reference in the WIT mapping should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_EmptyFieldMapNameInReference()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session/WorkItemTypes/WorkItemType");
            e.SetAttribute("fieldMap", string.Empty);
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Referring to an unknown field map.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Referencing an unknown field map should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_UnknownFieldMapNameInReference()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session/WorkItemTypes/WorkItemType");
            e.SetAttribute("fieldMap", "SomeInvalidName");
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Empty field map name.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Empty field map name should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_EmptyFieldMapName()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/FieldMaps/FieldMap");
            XmlElement p = (XmlElement)e.ParentNode;
            e = (XmlElement)e.Clone();
            e.SetAttribute("name", string.Empty);
            p.AppendChild(e);
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Duplicate field map names.
        /// Expected Result: Schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Field maps with duplicate names should result in an exception")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_DuplicateFieldMapName()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/WIT/FieldMaps/FieldMap");
            e.ParentNode.AppendChild(e.Clone());
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: No queue attributes in the TFS write queue configuration.
        /// Expected Result: Default values should be used.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Using default values for TFS write queue in case of missing attributes")]
        public void Read_WriteQueueDefaultParamsInTfs()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/Tfs/WriteQueue");
            e.RemoveAttribute("threadCount");
            e.RemoveAttribute("batchSize");

            SettingsHelper.LoadSettings(doc);
            QueueConfiguration config = MigrationConfiguration.Current.Wit.Sessions["Session1"].TfsMigrationSource.WriteQueueConfig;
            Assert.IsTrue(config.ThreadCount == QueueConfiguration.DefaultWriteThreadCount, "Invalid default thread count!");
            Assert.IsTrue(config.BatchSize == QueueConfiguration.DefaultWriteBatchSize, "Invalid default batch size!");
        }

        /// <summary>
        /// Scenario: using non-default values in the write queue configuration under TFS node.
        /// Expected Result: Specified values were loaded.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Using non-default write queue configuration parameters under TFS node")]
        public void Read_WriteQueueNonDefaultParamsInTfs()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/Tfs/WriteQueue");

            e.SetAttribute("threadCount", XmlConvert.ToString(QueueConfiguration.DefaultWriteThreadCount + 1));
            e.SetAttribute("batchSize", XmlConvert.ToString(QueueConfiguration.DefaultWriteBatchSize + 1));

            SettingsHelper.LoadSettings(doc);
            QueueConfiguration config = MigrationConfiguration.Current.Wit.Sessions["Session1"].TfsMigrationSource.WriteQueueConfig;
            Assert.IsTrue(config.ThreadCount == QueueConfiguration.DefaultWriteThreadCount + 1, "Invalid default thread count!");
            Assert.IsTrue(config.BatchSize == QueueConfiguration.DefaultWriteBatchSize + 1, "Invalid default batch size!");
        }


        /// <summary>
        /// Scenario: no write queue configuration element under TFS node.
        /// Expected Result: No exceptions; using default values.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Missing write queue configuration element in TFS")]
        public void Read_WriteQueueNoElementInTfs()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/Tfs/WriteQueue");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
            QueueConfiguration config = MigrationConfiguration.Current.Wit.Sessions["Session1"].TfsMigrationSource.WriteQueueConfig;
            Assert.IsTrue(config.ThreadCount == QueueConfiguration.DefaultWriteThreadCount, "Invalid default thread count!");
            Assert.IsTrue(config.BatchSize == QueueConfiguration.DefaultWriteBatchSize, "Invalid default batch size!");
        }

        /// <summary>
        /// Scenario: non-default write queue config parameters under the Provider node.
        /// Expected Result: Correct values should be read.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Using non-default write queue configuration parameters under Tfs node")]
        public void Read_WriteQueueNonDefaultParamsInTfsProvider()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session2']/Source/Tfs/WriteQueue");
            e.SetAttribute("threadCount", XmlConvert.ToString(QueueConfiguration.DefaultWriteThreadCount + 1));
            e.SetAttribute("batchSize", XmlConvert.ToString(QueueConfiguration.DefaultWriteBatchSize + 1));

            SettingsHelper.LoadSettings(doc);
            QueueConfiguration config = MigrationConfiguration.Current.Wit.Sessions["Session2"].OtherMigrationSource.Endpoint.WriteQueueConfig;
            Assert.IsTrue(config.ThreadCount == QueueConfiguration.DefaultWriteThreadCount + 1, "Invalid default thread count!");
            Assert.IsTrue(config.BatchSize == QueueConfiguration.DefaultWriteBatchSize + 1, "Invalid default batch size!");
        }

        /// <summary>
        /// Scenario: No WriteQueue element under Provider node.
        /// Expected Result: Default values should be used.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Missing WriteQueue element under TFS Provider node")]
        public void Read_WriteQueueNoElementInTfsProvider()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session2']/Source/Tfs/WriteQueue");
            e.ParentNode.RemoveChild(e);

            SettingsHelper.LoadSettings(doc);
            QueueConfiguration config = MigrationConfiguration.Current.Wit.Sessions["Session2"].OtherMigrationSource.Endpoint.WriteQueueConfig;
            Assert.IsTrue(config.ThreadCount == QueueConfiguration.DefaultWriteThreadCount, "Invalid default thread count!");
            Assert.IsTrue(config.BatchSize == QueueConfiguration.DefaultWriteBatchSize, "Invalid default batch size!");
        }

        /// <summary>
        /// Scenario: Setting non-default write queue parameters for non-TFS provider.
        /// Expected Result: Parameters must be set.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Setting write queue's parameters for non-TFS provider")]
        public void Read_WriteQueueNonDefaultParamsInNotTfsProvider()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/Source/Provider/WriteQueue");

            e.SetAttribute("threadCount", XmlConvert.ToString(QueueConfiguration.DefaultWriteThreadCount + 1));
            e.SetAttribute("batchSize", XmlConvert.ToString(QueueConfiguration.DefaultWriteBatchSize + 1));

            SettingsHelper.LoadSettings(doc);

            QueueConfiguration config = MigrationConfiguration.Current.Wit.Sessions["Session1"].OtherMigrationSource.Endpoint.WriteQueueConfig;
            Assert.IsTrue(config.ThreadCount == QueueConfiguration.DefaultWriteThreadCount + 1, "Invalid default thread count!");
            Assert.IsTrue(config.BatchSize == QueueConfiguration.DefaultWriteBatchSize + 1, "Invalid default batch size!");
        }

        /// <summary>
        /// Scenario: ConnectionString is the only child element of the Sql node.
        /// Expected Result: No exceptions.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("ConnectionString as the only child element of Sql node")]
        public void Read_OnlyConnectionStringInSqlNode()
        {
            XmlDocument doc = LoadFile();
            XmlNode e = doc.SelectSingleNode("/Migration/Sql");

            int i = 0;
            while (i < e.ChildNodes.Count)
            {
                XmlNode child = e.ChildNodes[i];
                if (child.Name != "ConnectionString")
                {
                    e.RemoveChild(child);
                }
                else
                {
                    i++;
                }
            }

            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Reading VC-specific TFS node.
        /// Expected Result: The node must be initialized.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Reading VC-specific Tfs node")]
        public void Read_TfsNodeInVc()
        {
            XmlDocument doc = LoadFile();
            SettingsHelper.LoadSettings(doc);

            VersionControlSession s = MigrationConfiguration.Current.VC.Sessions["Session1"];
            Assert.IsTrue(s.Target != null, "Empty TFS target!");
            Assert.IsTrue(s.Target.Server == "DevTFS", "Invalid server name!");
            Assert.IsTrue(s.Target.Workspace == "DemoTFS1", "Invalid workspace!");
            Assert.IsTrue(s.Target.WorkspaceRoot == @"%TEMP%\MigrationTests1", "Invalid workspace root!");
        }

        /// <summary>
        /// Scenario: TFS provider is used as a source.
        /// Expected Result: TFS data must be available.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("TFS provider used as a source")]
        public void Read_TfsProviderInSource()
        {
            XmlDocument doc = LoadFile();
            SettingsHelper.LoadSettings(doc);

            WorkItemTrackingSession s = MigrationConfiguration.Current.Wit.Sessions["Session2"];
            Assert.IsTrue(s.OtherMigrationSource.SourceType == SystemType.Tfs, "Wrong source type!");
            Assert.IsTrue(s.OtherMigrationSource.TfsSource.Server == "DevTFS", "Wrong server!");
            Assert.IsTrue(s.OtherMigrationSource.TfsSource.Project == "Foo", "Wrong project!");
            Assert.IsTrue(string.IsNullOrEmpty(s.OtherMigrationSource.TfsSource.Filter), "Filter is not null!");
            Assert.IsTrue(s.OtherMigrationSource.OtherSource == null, "Other source is not empty!");
        }

        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Non-TFS provider used as a source")]
        public void Read_OtherProviderInSource()
        {
            XmlDocument doc = LoadFile();
            SettingsHelper.LoadSettings(doc);

            WorkItemTrackingSession s = MigrationConfiguration.Current.Wit.Sessions["Session1"];
            Assert.IsTrue(s.OtherMigrationSource.SourceType == SystemType.Other, "Wrong source type!");
            Assert.IsTrue(s.OtherMigrationSource.TfsSource == null, "TFS source is not null!");
            Assert.IsTrue(s.OtherMigrationSource.OtherSource.WriteQueueConfig != null, "No write queue configuration!");
        }

        /// <summary>
        /// Scenario: invalid provider in the Linking element
        /// Expected result: schema validation exception
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Invalid provider in the linking engine")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_InvalidLinkingProvider()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Linking']/Linking/Engine");
            e.SetAttribute("provider", Guid.NewGuid().ToString());
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: invalid VC session in the Linking element.
        /// Expected result: schema validation exception
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Invalid VC session under the Linking element")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_InvalidLinkingVCSession()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Linking']/Linking/VersionControl");
            e.SetAttribute("session", Guid.NewGuid().ToString());
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: using non-unique TFS field name in mapping.
        /// Expected result: schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Using non-unique TFS field name in the mapping")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_UniqueTfsFieldNameInMapping()
        {
            XmlDocument doc = LoadFile();
            XmlNode map = doc.SelectSingleNode("/Migration/WIT/FieldMaps/FieldMap[@name='default']");
            XmlElement e = doc.CreateElement("Field");
            e.SetAttribute("tfsName", "My.Unique.Field");
            e.SetAttribute("otherName", "Unique Field 1");
            map.AppendChild(e);
            e = doc.CreateElement("Field");
            e.SetAttribute("tfsName", "My.Unique.Field");
            e.SetAttribute("otherName", "Unique Field 2");
            map.AppendChild(e);
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: using non-unique non-TFS field name in mapping.
        /// Expected result: schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Using non-unique non-TFS field name in the mapping")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_UniqueOtherFieldNameInMapping()
        {
            XmlDocument doc = LoadFile();
            XmlNode map = doc.SelectSingleNode("/Migration/WIT/FieldMaps/FieldMap[@name='default']");
            XmlElement e = doc.CreateElement("Field");
            e.SetAttribute("otherName", "My Unique Field");
            e.SetAttribute("tfsName", "My.Unique.Field.1");
            map.AppendChild(e);
            e = doc.CreateElement("Field");
            e.SetAttribute("otherName", "My Unique Field");
            e.SetAttribute("tfsName", "My.Unique.Field.2");
            map.AppendChild(e);
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: pointing to a missing provider in the value transformer section.
        /// Expected result: schema validation exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Missing provider for the value transformer")]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void Read_MissingProviderForValueTransformer()
        {
            XmlDocument doc = LoadFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session[@id='Session1']/FieldValueTransformer");
            e.SetAttribute("provider", "MissingProvider");
            SettingsHelper.LoadSettings(doc);
        }
    }
}
