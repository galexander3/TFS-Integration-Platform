// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Schema;
using Tests.Framework;

namespace Tests
{
    /// <summary>
    /// Summary description for WorkItemTrackingSessionTest
    /// </summary>
    [TestClass]
    public class WorkItemTrackingSessionTest : ConfigManagerTestCaseBase
    {

        private string ValidConfigFile = "ValidWITTest.xml";

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        #region Tests on Work item tracking Session
        [TestMethod, Description("Should pass, Valid ID, ProviderID, TfsSource, and OtherSource")]
        [Ignore]
        //$TODO: I disabled that test because Start method is not implemented, and testing it
        // doesn't make much sense at this moment.
        public void TestValidWITSession()
        {


            Assert.IsTrue(WITTestHelper.CanBeLoaded(ValidConfigFile,configFile), "The test data is valid");

            foreach(KeyValuePair<string, WorkItemTrackingSession> kvp in MigrationConfiguration.Current.Wit.Sessions )
            {
                string sessionID = kvp.Key;
                WorkItemTrackingSession session = kvp.Value;

                Assert.IsNotNull(sessionID);
                Assert.IsNotNull(session);
                Assert.IsTrue(sessionID == session.Id, "session id should be the same");

                session.Start();
            }
        }

        [TestMethod, Description("ID is missing")]
        public void TestIDMissing()
        {


            XmlNode parent = doc.SelectSingleNode("/Migration/WIT/Sessions");
            Assert.IsNotNull(parent);
            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            Assert.IsNotNull(node);

            Assert.IsNotNull(node.Attributes[0]);

            XmlElement newSession = doc.CreateElement("Session");
            newSession.InnerXml = node.InnerXml;
            newSession.RemoveAllAttributes();

            parent.ReplaceChild(newSession, node);

            node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");

            Assert.IsTrue(node.Attributes.Count == 0);

            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is invalid");
        }

        [TestMethod, Description("ProviderID is missing")]
        public void TestProviderIDIsMissing()
        {


            XmlNode parent = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Source");
            Assert.IsNotNull(parent);
            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Source/Provider");
            Assert.IsNotNull(node);

            Assert.IsNotNull(node.Attributes[0]);

            XmlElement newSession = doc.CreateElement("Provider");
            newSession.InnerXml = node.InnerXml;
            newSession.RemoveAllAttributes();

            parent.ReplaceChild(newSession, node);

            node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Source/Provider");
            Assert.IsTrue(node.Attributes.Count == 0);
            Assert.IsTrue(node.Attributes["provider"] == null);

            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is invalid");
        }

        [TestMethod, Description("ID is empty")]
        public void TestEmptyID()
        {


            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            if (node != null)
            {
                XmlAttribute attribute = node.Attributes[0];
                Assert.IsNotNull(attribute);
                attribute.RemoveAll();

                Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is invalid");
            }
        }

        [TestMethod, Description("ProviderID is empty")]
        public void TestEmptyProviderID()
        {


            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Source/Provider");
            if (node != null)
            {
                XmlAttribute attribute = node.Attributes[0];
                Assert.IsNotNull(attribute);
                attribute.RemoveAll();

                Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is invalid");
            }
        }


        [TestMethod, Description("ID is invalid")]
        public void TestInvalidID()
        {


            XmlNode parent = doc.SelectSingleNode("/Migration/WIT/Sessions");
            Assert.IsNotNull(parent);
            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            Assert.IsNotNull(node);

            Assert.IsNotNull(node.Attributes[0]);

            XmlElement newSession = doc.CreateElement("Session");
            newSession.InnerXml = node.InnerXml;
            newSession.SetAttribute(node.Attributes[0].Name, "    ");

            parent.ReplaceChild(newSession, node);

            node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
 
            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is invalid");
        }

        [TestMethod, Description("ID is lower cases")]
        public void TestLowercaseID()
        {


            XmlNode parent = doc.SelectSingleNode("/Migration/WIT/Sessions");
            Assert.IsNotNull(parent);
            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            Assert.IsNotNull(node);

            Assert.IsNotNull(node.Attributes[0]);

            XmlElement newSession = doc.CreateElement("Session");
            newSession.InnerXml = node.InnerXml;
            newSession.SetAttribute(node.Attributes[0].Name, "sessionid");

            parent.ReplaceChild(newSession, node);

            node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");

            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
        }

        [TestMethod, Description("ID is upper cases")]
        public void TestUppercaseID()
        {


            XmlNode parent = doc.SelectSingleNode("/Migration/WIT/Sessions");
            Assert.IsNotNull(parent);
            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            Assert.IsNotNull(node);

            Assert.IsNotNull(node.Attributes[0]);

            XmlElement newSession = doc.CreateElement("Session");
            newSession.InnerXml = node.InnerXml;
            newSession.SetAttribute(node.Attributes[0].Name, "MYSESSIONID");

            parent.ReplaceChild(newSession, node);

            node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");

            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
        }

        [TestMethod, Description("ID is the combination of upper/lower cases")]
        public void TestMixedCaseID()
        {


            XmlNode parent = doc.SelectSingleNode("/Migration/WIT/Sessions");
            Assert.IsNotNull(parent);
            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            Assert.IsNotNull(node);

            Assert.IsNotNull(node.Attributes[0]);

            XmlElement newSession = doc.CreateElement("Session");
            newSession.InnerXml = node.InnerXml;
            newSession.SetAttribute(node.Attributes[0].Name, "MYSissIOniD");

            parent.ReplaceChild(newSession, node);

            node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");

            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
        }

        [TestMethod, Description("ProviderID is lower case")]
        public void TestLowercaseProviderID()
        {

            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Source/Provider");
            Assert.IsTrue(node != null);
            string id = node.Attributes[0].Value = node.Attributes[0].Value.ToLower();


            XmlNodeList nodelist = doc.SelectNodes("/Migration/Providers/Provider");
            Assert.IsTrue(nodelist != null);

            XmlNode newNode = null;

            foreach (XmlNode n in nodelist)
            {
                if (n.Attributes["id"].Value.ToLower() == id)
                {
                    newNode = n.CloneNode(true);
                    newNode.Attributes["id"].Value = id;
                    break;
                }
            }

            if (newNode != null)
            {
                XmlNode p = doc.SelectSingleNode("/Migration/Providers");
                Assert.IsTrue(p != null);
                p.AppendChild(newNode);

            }

            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
        }

        [TestMethod, Description("ProviderID is upper cases")]
        public void TestUppercaseProviderID()
        {

            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Source/Provider");
            Assert.IsTrue(node != null);
            string id = node.Attributes[0].Value = node.Attributes[0].Value.ToUpper();


            XmlNodeList nodelist = doc.SelectNodes("/Migration/Providers/Provider");
            Assert.IsTrue(nodelist != null);

            XmlNode newNode = null;

            foreach (XmlNode n in nodelist)
            {
                if (n.Attributes["id"].Value.ToUpper() == id)
                {
                    newNode = n.CloneNode(true);
                    newNode.Attributes["id"].Value = id;
                    break;
                }
            }

            if (newNode != null)
            {
                XmlNode p = doc.SelectSingleNode("/Migration/Providers");
                Assert.IsTrue(p != null);
                p.AppendChild(newNode);

            }

            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
        }

        [TestMethod, Description("ProviderID is the combination of upper/lower cases")]
        public void TestMixedcaseProviderID()
        {


            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Source/Provider");

            string lower = node.Attributes["provider"].Value.ToLower();
            string upper = node.Attributes["provider"].Value.ToUpper();

            Assert.AreNotEqual(lower, node.Attributes["provider"].Value);
            Assert.AreNotEqual(upper, node.Attributes["provider"].Value);
                        
            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
        }

        [TestMethod, Description("ProviderID is un-defined ")]
        public void TestProviderIDUndefined()
        {


            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Source/Provider");
            Assert.AreNotEqual(node.Attributes["provider"].Value,"Random");
            node.Attributes["provider"].Value = "Random";

            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
        }

        [TestMethod, Description("It should pass")]
        public void TestIDAndProviderIDTheSame()
        {


            XmlNode parent = doc.SelectSingleNode("/Migration/WIT/Sessions");
            Assert.IsNotNull(parent);
            XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            Assert.IsNotNull(node);

            XmlNode provider = doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Source/Provider");

            Assert.IsNotNull(node.Attributes[0]);

            XmlElement newSession = doc.CreateElement("Session");
            newSession.InnerXml = node.InnerXml;
            newSession.SetAttribute(node.Attributes[0].Name, provider.Attributes[0].Value);

            parent.ReplaceChild(newSession, node);

            node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
        }


        [TestMethod, Description("It should fail")]
        public void TestEmptyServer()
        {


            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Tfs");
            e.SetAttribute("server", string.Empty);

            Assert.IsFalse(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is invalid");
        }


        [TestMethod, Description("Should pass for s valid session")]
        [Ignore]
        //$TODO: I disabled this test because Start method is not implemented yet and testing it
        // doesn't make sense.
        public void TestSingleValidSession()
        {


            XmlNode m = doc.SelectSingleNode("/Migration/WIT/Sessions");
            if (m != null)
            {
                XmlNode node = doc.SelectSingleNode("/Migration/WIT/Sessions/Session");
                m.RemoveChild(node);
            }

            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
            Assert.IsTrue(MigrationConfiguration.Current.Wit != null, "WIT session");
            Assert.IsTrue(MigrationConfiguration.Current.Wit.Sessions.Keys.Count == 1, "There is one WIT session");

            foreach (KeyValuePair<string, WorkItemTrackingSession> kvp in MigrationConfiguration.Current.Wit.Sessions)
            {
                string sessionID = kvp.Key;
                WorkItemTrackingSession session = kvp.Value;

                session.Start();
            }
        }


        [TestMethod, Description("It should pass")]
        public void TestLowerCasedServername()
        {
            //XmlDocument doc = TestUtils.PrepareTheXMLFile();
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Tfs");
            Assert.IsTrue(e != null);

            string server = e.GetAttribute("server").ToLower();
            e.SetAttribute("server", server);

            XmlNodeList nodelist = doc.SelectNodes("/Migration/Servers/Tfs");
            Assert.IsTrue(nodelist != null);

            XmlNode newNode = null;

            foreach (XmlNode n in nodelist)
            {
                if (n.Attributes["id"].Value.ToLower() == server)
                {
                    newNode = n.CloneNode(true);
                    newNode.Attributes["id"].Value = server;
                    break;
                }
            }

            if (newNode != null)
            {
                XmlNode p = doc.SelectSingleNode("/Migration/Servers");
                Assert.IsTrue(p != null);
                p.AppendChild(newNode);

            }

            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
        }

        [TestMethod, Description("It should pass")]
        public void TestUpperCasedServername()
        {
            XmlElement e = (XmlElement)doc.SelectSingleNode("/Migration/WIT/Sessions/Session/Tfs");
            Assert.IsTrue(e != null);

            string server = e.GetAttribute("server").ToUpper();
            e.SetAttribute("server", server);

            XmlNodeList nodelist = doc.SelectNodes("/Migration/Servers/Tfs");
            Assert.IsTrue(nodelist != null);

            XmlNode newNode = null;

            foreach (XmlNode n in nodelist)
            {
                if (n.Attributes["id"].Value.ToUpper() == server)
                {
                    newNode = n.CloneNode(true);
                    newNode.Attributes["id"].Value = server;
                    break;
                }
            }

            if (newNode != null)
            {
                XmlNode p = doc.SelectSingleNode("/Migration/Servers");
                Assert.IsTrue(p != null);
                p.AppendChild(newNode);

            }

            Assert.IsTrue(WITTestHelper.CanBeLoaded(configFileName,configFile), "The test data is valid");
        }

        #endregion

    }
}
