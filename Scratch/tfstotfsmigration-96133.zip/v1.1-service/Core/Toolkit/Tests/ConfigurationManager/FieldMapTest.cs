// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Xml;

using Tests.Framework;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    /// <summary>
    /// Tests field map functionality in the configuration manager.
    /// </summary>
    [TestClass]
    public class FieldMapTest
    {
        /// <summary>
        /// Initializes all tests in the class.
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            XmlDocument doc = SettingsHelper.LoadResourceXml("Tests.ConfigurationManager.XmlReadTestsData.ValidSettings.xml");
            SettingsHelper.LoadSettings(doc);
        }

        /// <summary>
        /// Scenario: Loading field maps from the config file.
        /// Expected Result: All values are loaded correctly.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Loading valid field maps from the file")]
        public void FieldMapping_Read()
        {
            Dictionary<string, FieldMap> maps = MigrationConfiguration.Current.Wit.FieldMaps;
            FieldMap map = maps["ReadTest_Empty"];
            Assert.IsTrue(map.Fields.Count == 0, "Wrong number of fields in the empty map!");
            Assert.IsTrue(map.Exclusions.Count == 0, "Wrong number of exclusions in the empty map!");

            map = maps["ReadTest"];
            Assert.IsTrue(map.Fields.Count == 2, "Wrong number of fields in the ReadTest map!");
            Assert.IsTrue(map.Exclusions.Count == 2, "Wrong number of exclusions in the ReadTest map!");

            FieldMapExclusion e = map.Exclusions[0];
            Assert.IsTrue(e.System == SystemType.Other, "Invalid system type!");
            Assert.IsTrue(e.FieldName == "Foo", "Invalid field name!");

            e = map.Exclusions[1];
            Assert.IsTrue(e.System == SystemType.Tfs, "Invalid system type!");
            Assert.IsTrue(e.FieldName == "Some.Dummy.Field", "Invalid field name!");

            FieldMapEntry f = map.Fields[0];
            Assert.IsTrue(f.TfsName == "System.State", "Invalid TFS field name!");
            Assert.IsTrue(f.OtherName == "Status", "Invalid ACME field name!");

            f = map.Fields[1];
            Assert.IsTrue(f.TfsName == "Custom.Field", "Invalid TFS field name!");
            Assert.IsTrue(f.OtherName == "Custom Field", "Invalid ACME field name!");
        }

        /// <summary>
        /// Scenario: loading valid work item type mappings
        /// Expected Result: 
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Loading valid work item type mappings")]
        public void FieldMapping_WorkItemTypes()
        {
            WorkItemTrackingSession s = MigrationConfiguration.Current.Wit.Sessions["Session1"];
            Assert.IsTrue(s.WorkItemTypeMappings.Count == 2, "Wrong number of work item type mappings!");

            WorkItemTypeMapping map = s.WorkItemTypeMappings[0];
            Assert.IsTrue(map.TfsName == "Bug", "Wrong TFS name in mapping!");
            Assert.IsTrue(map.OtherName == "psBug", "Wrong ACME name in mapping!");
            Assert.IsTrue(map.FieldMapName == "default", "Wrong field map name!");

            map = s.WorkItemTypeMappings[1];
            Assert.IsTrue(map.TfsName == "Test Case", "Wrong TFS name in mapping!");
            Assert.IsTrue(map.OtherName == "psTestCase", "Wrong ACME name in mapping!");
            Assert.IsTrue(string.IsNullOrEmpty(map.FieldMapName), "Non-empty field map name!");
        }
    }
}
