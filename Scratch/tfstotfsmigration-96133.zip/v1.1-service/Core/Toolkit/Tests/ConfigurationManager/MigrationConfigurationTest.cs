﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Text;
using System.IO;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using System.Xml;
using System.Collections.Specialized;
using System.Xml.Schema;
using Tests.Framework;

namespace Tests
{
    /// <summary>
    ///This is a test class for Microsoft.TeamFoundation.Migration.Toolkit.MigrationConfiguration and is intended
    ///to contain all Microsoft.TeamFoundation.Migration.Toolkit.MigrationConfiguration Unit Tests
    ///</summary>
    [TestClass()]
    public class MigrationConfigurationTest : ConfigManagerTestCaseBase
    {
        #region Additional test attributes
        private int TurkishCultureInfo = 1055;
        /// <summary>
        /// Loads configuration settings from resources with the given name/
        /// </summary>
        /// <param name="name">Resource name</param>
        private void Load(string name)
        {
            using (Stream stream = this.GetType().Assembly.GetManifestResourceStream(name))
            {
                MigrationConfiguration.Load(stream);
            }
        }
        #endregion


        /// <summary>
        ///A test for Load (Stream)
        ///</summary>
        [TestMethod()]
        public void MigrationConfiguration_Load()
        {
            configFile.WriteAndLoad();
            Assert.IsTrue(MigrationConfiguration.Current != null, "Configuration was not loaded!");
        }

        /// <summary>
        /// A test for WIT-specific settings
        /// </summary>
        [TestMethod]
        public void MigrationConfiguration_WITSettings()
        {
            Load("Tests.ConfigurationManager.Test1.xml");
            WorkItemTrackingConfiguration witConfig = MigrationConfiguration.Current.Wit;

            Assert.IsTrue(witConfig.GetValue("WITSetting1") == "WIT Value 1");
            Assert.IsTrue(witConfig.GetValue("WITSetting2") == "WIT Value 2");
            Assert.IsTrue(witConfig.Settings.Length == 2, "Wrong number of settings at the WIT level!");

            WorkItemTrackingSession session = witConfig.Sessions["PsDevDivBugs"];
            Assert.IsTrue(session.GetValue("SessionSetting") == "SessionValue");
            Assert.IsTrue(session.Settings.Length == 1, "Wrong number of settings in 'PS DevDiv Bugs' session!");

            session = witConfig.Sessions["OtherBugs"];
            Assert.IsTrue(session.Settings.Length == 0, "Wrong number of settings in 'Other bugs' session!");
        }

        //Common Configuration Section Missing
        [TestMethod]
        public void CommonConfigurationMissingTest()
        {


            doc.SelectSingleNode("//Migration/Settings").RemoveAll();

            configFile.WriteAndLoad();

            //Check that the top level settings are 0 length array 
            Assert.IsTrue(0 == MigrationConfiguration.Current.Settings.Length, "There should be no global settings ");

            //Check that the sessions still have settings
            foreach (VersionControlSession session in MigrationConfiguration.Current.VC.Sessions.Values)
            {
                Assert.IsFalse(0 == session.Settings.Length, "The sessions should still have settings");
            }

        }

        //GB18030 Encoding
        [TestMethod]
        public void GBEncodingTest()
        {
            configFile.WriteXMLFile(Encoding.GetEncoding("GB18030"));

            MigrationConfiguration.Load(new FileStream(configFileName, FileMode.Open));

            Assert.IsNotNull(MigrationConfiguration.Current.VC.Sessions);
            Assert.IsNotNull(MigrationConfiguration.Providers);
            Assert.IsNotNull(MigrationConfiguration.TfsServers);
            Assert.IsNotNull(MigrationConfiguration.Current.Settings);
            Assert.IsNotNull(MigrationConfiguration.Current.Wit);
        }

        //Stream with all data commented out
        [TestMethod]
        [ExpectedException(typeof(InitializationException))]
        public void EmptyFileTest()
        {

            String value = doc.InnerXml;
            doc.RemoveAll();
            doc.AppendChild(doc.CreateComment(value));
            
            configFile.WriteAndLoad();
        }

        //Turkish ID
        [TestMethod]
        public void TurkishIDTest()
        {
            //Some Randomly generated Turkish Strings to create ID's from
            String[] TurkishStrings = new string[] { "zıiiİsürIcüİistemidir.iicr", "tİİiidestıkler", "ışekiliefiiIwalıde", "büıükİça" };

            StringCollection TurkishIds = new StringCollection();

            foreach (String turkishString in TurkishStrings)
            {
                TurkishIds.Add(turkishString.ToLower(System.Globalization.CultureInfo.GetCultureInfo(TurkishCultureInfo)));
                TurkishIds.Add(turkishString.ToUpper(System.Globalization.CultureInfo.GetCultureInfo(TurkishCultureInfo)));

            }



            XmlNodeList sessions= doc.GetElementsByTagName("Session");

            for (int i = 0; i < sessions.Count; i++)
            {
                sessions[i].Attributes["id"].InnerText = TurkishIds[i];
                
            }

            //Te XML Schema should let this thorugh
            configFile.WriteAndLoad();
            
        }

        [TestMethod()]
        [ExpectedException(typeof(XmlSchemaValidationException))]
        public void NullSessionIdTest()
        {


            XmlNode node = doc.SelectSingleNode("/Migration/VC/Sessions/Session");
            node.Attributes.Remove(node.Attributes["id"]);

            configFile.WriteAndLoad();
        }

    }
}
