// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Reflection;

namespace Tests
{
    /// <summary>
    /// Loads and returns a config stream replacing any environment variables (%key%) with the expanded value.
    /// If the value does not exist in the environment the origional string (%key%) is left intact.
    /// </summary>
    internal static class ConfigLoader
    {
        static Random s_rng = new Random();

        internal static Stream LoadNamedStream(Assembly assembly, string streamName)
        {
            if (string.IsNullOrEmpty(streamName))
            {
                throw new Exception("Configuration stream name cannot be null or empty");
            }

            using (Stream configFile = assembly.GetManifestResourceStream(streamName))
            {
                if (configFile == null)
                {
                    throw new Exception(string.Format("Unable to load configuration stream {0}", streamName));
                }

                MemoryStream resultStream = new MemoryStream();

                using (StreamReader sr = new StreamReader(configFile))
                {
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        if (line == null)
                        {
                            break;
                        }

                        string newLine = System.Environment.ExpandEnvironmentVariables(line);
                        newLine = newLine.Replace("%RANDOM%", s_rng.Next().ToString());
                        byte[] bytes = UTF8Encoding.UTF8.GetBytes(newLine);
                        resultStream.Write(bytes, 0, bytes.Length);
                    }
                }

                Debug.Assert(resultStream.Length > 0);

                resultStream.Seek(0, SeekOrigin.Begin);
                return resultStream;
            }
        }
    }
}
