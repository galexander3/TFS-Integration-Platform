// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;
using Tests.Framework;
using Microsoft.TeamFoundation.VersionControl.Client;
using System.IO;
using System.Data.SqlClient;
using System.Data;

namespace Tests
{
    [TestClass]
    public class IMigrationActionTest : MigrationTestCaseBase
    {
        ChangeGroupingMananger manager;
        ChangeGrouping group;
        BatchingContext context;
        TestVCEventListeners eventListener;
        TestVCMigrationEngine engine;

        #region Helper Methods

        private SqlMigrationAction CreateConflict(ChangeGroupingMananger manager)
        {
            MigrationItemStrings file1 = new MigrationItemStrings("source\\file1.txt", "target\\file1.txt", TestContext.TestName, ConfigParameters);
            AddTFSFile(file1.LocalPath);
            BranchTFSItem(ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target + "/source", ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target + "/target");

            EditTFSFile(file1.NewLocalPath);
            EditTFSFile(file1.LocalPath);

            string scourceServerPath = ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target + "/source";
            TfsMigrationItem targetSourceItem = new TfsMigrationItem(MasterTfsClient, scourceServerPath, CreateVcWssSession);

            string targetServerPath = ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target + "/target";
            TfsMigrationItem targetTargetItem = new TfsMigrationItem(MasterTfsClient, targetServerPath, CreateVcWssSession);

            SqlMigrationAction action = new SqlMigrationAction(group);
            action.TargetSourceItem = targetSourceItem;
            action.TargetTargetItem = targetTargetItem;
            action.SourceItem = targetSourceItem;
            action.Recursive = true;
            action.Version = "0";
            action.MergeVersionTo = "0";
            group.AddAction(action);
            return action;
        }

        private SqlMigrationAction setupEdit()
        {
            MigrationItemStrings file = new MigrationItemStrings("file1.txt", "new/file1.txt", TestContext.TestName, ConfigParameters);
            AddTFSFile(file.LocalPath);
            AddTFSFile(file.NewLocalPath);

            string root = ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target;

            //The toolkit is going to try to use the sessions workspace root combined with the mapping target to download the content for the file; 
            //if we leave this unedited it will download to the wrong location and the test wont be able to find it
            ConfigParameters.VersionControl.Sessions[0].Tfs.WorkspaceRoot = MasterWorkspace.Folders[0].LocalItem;
            engine = new TestVCMigrationEngine(CreateVcWssSession, manager);

            string serverPath = root + "/new/file1.txt";
            TfsMigrationItem targetTargetItem = new TfsMigrationItem(null, serverPath, CreateVcWssSession);

            TfsMigrationItem sourceItem = new TfsMigrationItem(MasterTfsClient, root + "/file1.txt", CreateVcWssSession);

            SqlMigrationAction action = new SqlMigrationAction(group);
            action.TargetTargetItem = targetTargetItem;
            action.SourceItem = sourceItem;
            return action;
        }

        [TestInitialize]
        public override void Initialize()
        {
            base.Initialize();

            manager = new SqlChangeGroupingMananger(null, null, CreateVcWssSession, MigrationDirection.SourceToTfs);
            group = CreateChangeGroup(manager);
            context = new BatchingContext(MasterWorkspace);
            eventListener = new TestVCEventListeners();

            context.BatchedItemError += eventListener.BatchedItemError;
            context.MergeError += eventListener.MergeItemError;
            DataAccessManager.Current.CreateSchema(false);
            engine = new TestVCMigrationEngine(CreateVcWssSession, manager);

            using (SqlConnection conn = DataAccessManager.Current.GetSqlConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand())
                {

                    cmd.CommandText = "prc_AddConversionHistory";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = conn;

                    cmd.Parameters.Add("@SessionId", SqlDbType.NVarChar).Value = CreateVcWssSession.Id;
                    cmd.Parameters.Add("@SourceChangeId", SqlDbType.NVarChar).Value = "0";
                    cmd.Parameters.Add("@TfsChangesetId", SqlDbType.Int).Value = "0";
                    cmd.Parameters.Add("@UtcWhen", SqlDbType.DateTime).Value = DateTime.Now;
                    cmd.Parameters.Add("@FromSource", SqlDbType.Bit).Value = "True";
                    cmd.Parameters.Add("@Comment", SqlDbType.NVarChar).Value = "Comment";

                    cmd.ExecuteNonQuery();
                }
            }
        }
        #endregion

        ///<summary>
        ///Scenario: Specify a SourceItem object on an Action that is deleted
        ///Expected Result: SourceItem is ignored
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Specify a SourceItem object on an Action that is deleted")]
        public void DeleteWithSourceItemTest()
        {
            MigrationItemStrings deleted = new MigrationItemStrings("file1.txt", null, TestContext.TestName, ConfigParameters);
            MigrationItemStrings other = new MigrationItemStrings("file2.txt", null, TestContext.TestName, ConfigParameters);

            AddTFSFile(deleted.LocalPath);
            AddTFSFile(other.LocalPath);

            TfsMigrationItem targetTargetItem = new TfsMigrationItem(null, deleted.LocalPath, CreateVcWssSession);

            TfsMigrationItem sourceItem = new TfsMigrationItem(null, other.LocalPath, CreateVcWssSession);

            SqlMigrationAction action = new SqlMigrationAction(group);
            action.SourceItem = sourceItem;
            action.TargetTargetItem = targetTargetItem;
            group.AddAction(action);

            engine.CallDelete(action, context);
            context.Flush();
            MasterWorkspace.CheckIn(MasterWorkspace.GetPendingChanges(), DeleteComment);

            Assert.IsNotNull(MasterTfsClient.GetItem(other.LocalPath));
            Assert.IsFalse(eventListener.batchedItemError);
            //Don't use ExpectedException because too many of the calls could cause that.
            try
            {
                Assert.IsNull(MasterTfsClient.GetItem(deleted.LocalPath));
            }
            catch (VersionControlException e)
            {
                Assert.AreEqual(string.Format("Item {0} was not found in source control at version T.", deleted.LocalPath), e.Message, "The wrong exception was thrown");
            }
        }

        ///<summary>
        ///Scenario: Make SourceItem null for an action that requires one 
        ///Expected Result: NullRefrenceException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Make SourceItem null for an action that requires one")]
        [ExpectedException(typeof(NullReferenceException))]
        public void MissingSourceItemTest()
        {
            string serverPath = ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target + "/file1.txt";
            TfsMigrationItem targetTargetItem = new TfsMigrationItem(null, serverPath, CreateVcWssSession);

            SqlMigrationAction action = new SqlMigrationAction(group);
            action.TargetTargetItem = targetTargetItem;
            action.SourceItem = null;

            group.AddAction(action);

            engine.CallAdd(action, context);
        }

        ///<summary>
        ///Scenario: Create TargetSourceItem on an Action that does not use one
        ///Expected Result: TargetSourceItem is ignored
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Create TargetSourceItem on an Action that does not use one")]
        public void UnusedTargetSourceItemTest()
        {
            SqlMigrationAction action = setupEdit();

            string serverPath = ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target + "/file2.txt";
            TfsMigrationItem targetSourceItem = new TfsMigrationItem(null, serverPath, CreateVcWssSession);

            action.TargetSourceItem=targetSourceItem;

            group.AddAction(action);

            engine.CallEdit(action, context);

            context.Flush();

            PendingChange[] changes = MasterWorkspace.GetPendingChanges();

            Assert.AreEqual(1, changes.Length);
            foreach (PendingChange change in changes)
            {
                Assert.IsTrue(change.IsEdit, "A non edit change was pended");
            }
            Assert.IsFalse(eventListener.batchedItemError);
        }

        ///<summary>
        ///Scenario: Attempt a rename without specifying TargetSourceItem
        ///Expected Result: NullRefrenceException
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Attempt a rename without specifying TargetSourceItem")]
        [ExpectedException(typeof(NullReferenceException))]
        public void RenameMissingTargetSourceItemTest()
        {
            string serverPath = ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target + "/file2.txt";
            TfsMigrationItem targetTargetItem = new TfsMigrationItem(null, serverPath, CreateVcWssSession);

            SqlMigrationAction action = new SqlMigrationAction(group);
            action.TargetTargetItem = targetTargetItem;
            action.TargetSourceItem = null;

            group.AddAction(action);

            engine.CallRename(action, context);
        }

        ///<summary>
        ///Scenario: Attempt a merge without specifying TargetSourceItem
        ///Expected Result: NullRefrenceException
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Attempt a merge without specifying TargetSourceItem")]
        [ExpectedException(typeof(NullReferenceException))]
        public void MergeMissingTargetSourceItemTest()
        {
            MigrationItemStrings target = new MigrationItemStrings("target", null, TestContext.TestName, ConfigParameters);
            AddTFSFolder(target.LocalPath);

            TfsMigrationItem targetTargetItem = new TfsMigrationItem(MasterTfsClient, target.ServerPath, CreateVcWssSession);

            SqlMigrationAction action = new SqlMigrationAction(group);
            action.Recursive = true;
            action.SourceItem = targetTargetItem;
            action.TargetSourceItem = null;
            action.TargetTargetItem = targetTargetItem;
            action.Version = "0";
            action.MergeVersionTo = "0";
            group.AddAction(action);

            engine.CallMerge(action, context);
        }

        ///<summary>
        ///Scenario: Action with Null TargetTargetItem
        ///Expected Result: NullRefrenceException
        ///</summary>
        [TestMethod(), Priority(1), Owner("curtisp")]
        [Description("Action with Null TargetTargetItem")]
        [ExpectedException(typeof(NullReferenceException))]
        public void MissingTargetTargetItemTest()
        {
            string serverPath = ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target + "/target";
            TfsMigrationItem targetSourceItem = new TfsMigrationItem(null, serverPath, CreateVcWssSession);

            SqlMigrationAction action = new SqlMigrationAction(group);
            action.Version = "0";
            action.MergeVersionTo = "0";
            action.Recursive = true;
            action.TargetSourceItem = targetSourceItem;
            action.TargetTargetItem = null;
            group.AddAction(action);

            engine.CallMerge(action, context);
        }

        ///<summary>
        ///Scenario: Set Recursive to true on an action that is not recursive
        ///Expected Result: Recursive is ignored
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Set Recursive to true on an action that is not recursive")]
        public void UnusedRecursiveTest()
        {
            SqlMigrationAction action = setupEdit();

            action.Recursive = true;

            group.AddAction(action);

            engine.CallEdit(action, context);

            context.Flush();

            PendingChange[] changes = MasterWorkspace.GetPendingChanges();

            Assert.AreEqual(1, changes.Length);
            foreach (PendingChange change in changes)
            {
                Assert.IsTrue(change.IsEdit, "A non edit change was pended");
            }
            Assert.IsFalse(eventListener.batchedItemError);
        }
    }
}
