using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Tests.Framework;
using System.Data.SqlClient;

namespace Tests
{

    [TestClass]
    public class ConnectionManagerTest : MigrationTestCaseBase
    {
        ///<summary>
        ///Scenario: Call ExecuteNonQuery with a null command
        ///Expected Result: ArgumentNullException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Call ExecuteNonQuery with a null command")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullExecuteNonQueryTest()
        {
            DataAccessManager.ExecuteNonQuery(null);
        }

        ///<summary>
        ///Scenario: Call TryExecuteScalar with a null command
        ///Expected Result: ArgumentNullException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Call TryExecuteScalar with a null command")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullTryExecuteScalarTest()
        {
            int result;
            DataAccessManager.TryExecuteScalar<int>(null, out result);
        }

        ///<summary>
        ///Scenario: Call TryExecuteScalar with a command that will not return anything
        ///Expected Result: Returns false; result is null
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Call TryExecuteScalar with a command that will not return anything")]
        public void UnsuccessfulTryExecuteScalarTest()
        {
            ConfigFile.WriteAndLoad(ConfigParameters);
            string result;

            using (SqlConnection connection = new SqlConnection(string.Format("server={0}; database=master;Integrated Security=SSPI", TestEnvironment.SqlServer)))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(" ", connection);

                Assert.IsFalse(DataAccessManager.TryExecuteScalar<string>(command, out result));
            }
            Assert.IsNull(result);
        }

        ///<summary>
        ///Scenario: Call ExecuteReader with a null command
        ///Expected Result: ArgumentNullException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Call ExecuteReader with a null command")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullCommandExecuteReaderTest()
        {
            DataReaderRealizer<int> reader = DataReaderRealizer<int>;
            DataAccessManager.ExecuteReader<int>(null, reader);
        }

        public int DataReaderRealizer<T>(SqlDataReader reader)
        {
            return 0;
        }
    }
}
