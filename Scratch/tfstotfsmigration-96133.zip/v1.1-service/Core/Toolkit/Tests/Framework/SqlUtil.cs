// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data.SqlClient;
using System.Data;

namespace Tests
{
    public static class SqlUtil
    {

        public static void DropDB(string serverName, string db)
        {
            /* connection pooling will leave connections open even after the SqlCommand has been Dispose()'d.
             * this is by design and generally very good for performance.  However for testing we need to
             * always make sure we clear the pool otherwise we may end up not being able to drop a DB
             * because a pooled connection is still open on it.
             */
            SqlConnection.ClearAllPools();

            using (SqlConnection conn = new SqlConnection(string.Format("server={0};Integrated Security=SSPI", serverName)))
            {
                conn.Open();

                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = string.Format("IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'{0}') DROP DATABASE [{0}]", db);
                    cmd.CommandType = CommandType.Text;

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static int ExecSqlCmd(string strcmd, string connectionString)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = strcmd;
                cmd.CommandType = CommandType.Text;
                
                conn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        public static Object ExecSqlQuery(string query, string connectionString)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;

                conn.Open();
                return cmd.ExecuteScalar();
            }
        }

    }
}
