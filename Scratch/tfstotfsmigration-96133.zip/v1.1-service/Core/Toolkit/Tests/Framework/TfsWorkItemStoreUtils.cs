﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.Framework
{
    class TfsWorkItemStoreUtils
    {
        #region Constructors

		/// <summary>
		/// Constructor to use when you have a specific project to work with.
		/// </summary>
        /// <param name="wiStore">WorkItemStore object that you are working against.</param>
        /// <param name="projectUtils">ProjectUtils object to bind to.</param>
        public TfsWorkItemStoreUtils(WorkItemStore wiStore, TfsProjectUtils projectUtils)
		{
            if (wiStore == null)
                throw new ArgumentException("Invalid WorkItemStore", "wiStore");

            if (projectUtils == null)
                throw new ArgumentException("Invalid ProjectUtils", "projectUtils");

            this.m_workItemStore = wiStore;
			this.m_projectUtils = projectUtils;
        }

		/// <summary>
		/// Constructor to use when there is no project to work with.
		/// </summary>
        /// <param name="wiStoreToBindTo">WorkItemStore object that you are working against.</param>
        public TfsWorkItemStoreUtils(WorkItemStore wiStore)
		{
            if (wiStore == null)
                throw new ArgumentException("Invalid WorkItemStore", "wiStore");

            this.m_workItemStore = wiStore;
		}
		
		
		#endregion
		
		#region private properties

        private WorkItemStore m_workItemStore;
		private TfsProjectUtils m_projectUtils;
        private int m_batchSize = 60; 
                
        #endregion 
        
        #region public properties
        /// <summary>
        /// Property used to hold the WorkItemStore that the Utils is working against.  This value is set when creating
        /// the WorkItemUtils property.
        /// </summary>
        public WorkItemStore workItemStore
        {
            get
            {
                return m_workItemStore;
            }
    
        }

		/// <summary>
		/// Gets the ProjectUtils object this instance of the WorkItemStoreUtils is bound to.
		/// </summary>
		/// <value>Project object</value>
		public TfsProjectUtils projectUtils
		{
			get
			{
				return m_projectUtils;
			}
		}

        #endregion
		
		#region public methods
				
		/// <summary>
		/// Creates New WorkItem item using the WorkItemType and Title, and saving it to the database.
		/// </summary>
		/// <param name="wiType">The type of workitem to create.</param>
		/// <param name="title">specific title for the object being created.</param>
		/// <returns>returns the newly created workitem object.</returns>
        public WorkItem CreateNewWorkItem(WorkItemType wiType, string title)
		{
            if (m_projectUtils == null)
                throw new ApplicationException("projectUtils is null");

            if (wiType == null)
                throw new ArgumentException("WorkItemType is null!", "wiType");

            if (title == null)
                throw new ArgumentException("title is null!", "title");

            WorkItem wi = new WorkItem(wiType);

            if (wi == null)
                throw new ApplicationException("Unable to create workitem.  WorkItem(WorkItemStore, WorkItemType) constructor failed!");

            TfsWorkItemUtils wiUtils = new TfsWorkItemUtils(wi, m_projectUtils);

			//Set valid values to the fields.
			wiUtils.MakeWorkItemFieldsValid(title);

            //Save the WorkItem
            wi.Save();
            return wi;
        }

        /// <summary>
        /// Creates New WorkItem item using the WorkItemType and saving it to the database.
        /// </summary>
        /// <param name="wiType">The type of workitem to create.</param>
        /// <returns>returns the newly created workitem object.</returns>
        public WorkItem CreateNewWorkItem(WorkItemType wiType)
        {
            return CreateNewWorkItem(wiType, "WorkItemTrackingMigrationTesting");
        }

		
		/// <summary>
        /// Creates numberOfWorkItems specified with all possible field values including states.
        /// </summary>
        /// <remarks>
        /// Will create up to 12 revisions of a workitem.  Use the overloaded version to specifiy a different max number of revisions to create.
		/// Does not log to the console the state of the revision of the workitem nor the count of workitems.  Use the overloaded version to specify to logToConsole.
        /// </remarks>
		/// <param name="numWorkItems">The number of workitems to create</param>
		/// <param name="wiType">The type of workitem to create.</param>
		/// <param name="wiIDs">An arrayList of workitemIDs that were created by this method.  It helps in keeping track of workitems to use for a suite of tests.</param>
		public void CreateVariableWorkItems(int numWorkItems, WorkItemType wiType, out ArrayList wiIDs)
        {
            // 0 - is for maximum value
            CreateVariableWorkItems(numWorkItems, 0, 12, wiType, false, out wiIDs);
        }
        
        /// <summary>
        /// Modify an existing work items, and update it a few times 
        /// </summary>
        /// <param name="wi">Work Item to be modified</param>
        /// <param name="revision">the highest number of revision</param>
        public void ModifyWorkItems(WorkItem wi, int revision)
        {
            Debug.Assert(wi != null, "the work item is null");

            int oldRev = wi.Revisions.Count;

            if ( oldRev >= revision)
            {
                return;
            }

            for (int i = oldRev - 1; i < revision; i++)
            {
                wi.Description = "Revision " + i;
                wi.Save();
            }
        }
        
		/// <summary>
		/// Creates numberOfWorkItems specified with all possible field values including states.
		/// </summary>
		/// <remarks>
		/// Does not log to the console the state of the revision of the workitem nor the count of workitems.  Use the overloaded version to specify to logToConsole.
        /// </remarks>
		/// <param name="numWorkItems">The number of workitems to create</param>
        /// <param name="maxNumWorkItemsPerProject">Max number of work items to be created per project</param>
		/// <param name="maxNumberOfRevisions">The max number of revisions that can be created for each workitem.  The number of revisions will be random between 1 and this number.</param>
		/// <param name="wiType">The type of workitem to create.</param>
		/// <param name="wiIDs">An arrayList of workitemIDs that were created by this method.  It helps in keeping track of workitems to use for a suite of tests.</param>
        public void CreateVariableWorkItems(int numWorkItems, int maxNumWorkItemsPerProject, int maxNumberOfRevisions, WorkItemType wiType, out ArrayList wiIDs)
		{
            while (true)
            {
                int size = m_batchSize; 

                wiIDs = null;
                if (numWorkItems < m_batchSize)
                {
                    size = numWorkItems; 
                }

                CreateVariableWorkItemsBatch(size, maxNumWorkItemsPerProject, maxNumberOfRevisions, wiType, false, out wiIDs);

                numWorkItems -= m_batchSize;
                if (numWorkItems <= 0)
                {
                    break; 
                }
            }
		}


        /// <summary>
        /// Creates numberOfWorkItems specified with all possible field values including states.
        /// </summary>
        /// <remarks>
        /// Allows full control over logToConsole, maxNumberOfRevisions, etc. unlike the other overloaded versions.
        /// </remarks>
        /// <param name="numWorkItems">The number of workitems to create</param>
        /// <param name="maxNumberOfRevisions">The max number of revisions that can be created for each workitem.  The number of revisions will be random between 1 and this number.</param>
        /// <param name="wiType">The type of workitem to create.</param>
        /// <param name="logToConsole">Tells whether to log to the console or not.</param>
        /// <param name="wiIDs">An arrayList of workitemIDs that were created by this method.  It helps in keeping track of workitems to use for a suite of tests.</param>
        public void CreateVariableWorkItems(int numWorkItems, int maxNumWorkItemsPerProject, int maxNumberOfRevisions, WorkItemType wiType, bool logToConsole, out ArrayList wiIDs)
        {
            Random random = new Random();
            wiIDs = new ArrayList();

            if (m_projectUtils == null)
                throw new ApplicationException("You must have a project to work with.  Use the WorkItemStoreUtils(WorkItemStore, ProjectUtils) constructor.");

            if (wiType == null)
                throw new ArgumentException("Invalid WorkItemType!", "wiType");

            if (numWorkItems <= 0)
                throw new ArgumentException("Invalid number of Workitems!", "numWorkItems");

            if (wiIDs.Capacity < numWorkItems)
                wiIDs.Capacity = numWorkItems;

            //Create specified number of workitems.
            for (int i = 0; i < numWorkItems; i++)
            {
                //Get the existing total number of workitems for that project
                WorkItemCollection wiCollection = this.workItemStore.Query("SELECT [System.Title] "
                    + "FROM WorkItems WHERE [System.TeamProject] = \'" + projectUtils.project.Name + "\'");
                int existingWorkItemCount = wiCollection.Count;

                //Move out as we have added as many work items
                //as specified by the max value for this project
                if (existingWorkItemCount >= maxNumWorkItemsPerProject)
                {
                    break;
                }

                //Create blank object in memory.
                WorkItem wi = new WorkItem(wiType);

                if (wi == null)
                    throw new ApplicationException("Unable to create workitem.  WorkItem(WorkItemStore, WorkItemType) constructor failed!");

                TfsWorkItemUtils wiUtils = new TfsWorkItemUtils(wi, m_projectUtils);

                //Set field values.
                wiUtils.SetFieldValues(logToConsole);

                //Save the result again.
                //TODO: Figure out a better solution here, but for now just ignore any save failures and keep going with workitem creations.
                try
                {
                    wi.Save();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                //Add to the arraylist.  Use these IDs during testing.  Less prone to failure when others are running tests on the back end as well.
                wiIDs.Add(wi.Id);

                int count = random.Next(1, 3);
                int revisions = 1;
                while (revisions % count == 0 && revisions < maxNumberOfRevisions)
                {
                    if (!wi.IsOpen)
                        wi.Open();

                    //Set field values.
                    wiUtils.SetFieldValues(logToConsole);

                    wi.Fields["Description"].Value = "Set to " + wi.Fields["State"].Value.ToString() + " by OMTestFramework tool...";

                    //TODO: Figure out a better solution here, but for now just ignore any save failures and keep going with workitem creations.
                    try
                    {
                        wi.Save();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    revisions++;
                    count = random.Next(1, 3);
                }
            }
            if (logToConsole)
                Console.WriteLine("Created {0} {1}s", wiIDs.Count, wiType.Name.ToString());
        }

        /// <summary>
        /// Creates numberOfWorkItems specified with all possible field values including states.
        /// </summary>
        /// <remarks>
        /// Allows full control over logToConsole, maxNumberOfRevisions, etc. unlike the other overloaded versions.
        /// </remarks>
        /// <param name="numWorkItems">The number of workitems to create</param>
        /// <param name="maxNumberOfRevisions">The max number of revisions that can be created for each workitem.  The number of revisions will be random between 1 and this number.</param>
        /// <param name="wiType">The type of workitem to create.</param>
        /// <param name="logToConsole">Tells whether to log to the console or not.</param>
        /// <param name="wiIDs">An arrayList of workitemIDs that were created by this method.  It helps in keeping track of workitems to use for a suite of tests.</param>
        public void CreateVariableWorkItemsBatch(int numWorkItems, int maxNumWorkItemsPerProject, int maxNumberOfRevisions, WorkItemType wiType, bool logToConsole, out ArrayList wiIDs)
        {
            Random random = new Random();
            wiIDs = new ArrayList();

            if (m_projectUtils == null)
                throw new ApplicationException("You must have a project to work with.  Use the WorkItemStoreUtils(WorkItemStore, ProjectUtils) constructor.");

            if (wiType == null)
                throw new ArgumentException("Invalid WorkItemType!", "wiType");

            if (numWorkItems <= 0)
                throw new ArgumentException("Invalid number of Workitems!", "numWorkItems");

            if (wiIDs.Capacity < numWorkItems)
                wiIDs.Capacity = numWorkItems;

            //Get the existing total number of workitems for that project
            int existingWorkItemCount = this.workItemStore.QueryCount("SELECT [System.Title] "
                + "FROM WorkItems WHERE [System.TeamProject] = \'" + projectUtils.project.Name + "\'");

            //Move out as we have added as many work items
            //as specified by the max value for this project
            int nToAdd = maxNumWorkItemsPerProject - existingWorkItemCount;
            if (nToAdd <= 0)
            {
                return;
            }
            else if (numWorkItems > nToAdd)
            {
                numWorkItems = nToAdd;  //only add enough WI. 
            }

            //create an array of work items 
            WorkItem[] wisBatch = new WorkItem[numWorkItems];

            //Create specified number of workitems.
            for (int i = 0; i < numWorkItems; i++)
            {
                //Create blank object in memory.
                WorkItem wi = new WorkItem(wiType);

                wi.Title = "batch " + i;

                if (wi == null)
                    throw new ApplicationException("Unable to create workitem.  WorkItem(WorkItemStore, WorkItemType) constructor failed!");

                TfsWorkItemUtils wiUtils = new TfsWorkItemUtils(wi, m_projectUtils);

                //Set field values.
                wiUtils.SetFieldValues(logToConsole);
                wisBatch[i] = wi;

            }
            try
            {
                m_workItemStore.BatchSave(wisBatch);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // now update the WIs multiple times [0 .. maxNumberOfRevisions)
            int count = random.Next(maxNumberOfRevisions);

            for (int j = 0; j < count; j++)
            {
                for (int k = 0; k < numWorkItems; k++)
                {
                    TfsWorkItemUtils wiUtils = new TfsWorkItemUtils(wisBatch[k], m_projectUtils);

                    //Set field values.
                    wiUtils.SetFieldValues(logToConsole);
                }

                try
                {
                    m_workItemStore.BatchSave(wisBatch);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }                
            }
        }

		/// <summary>
		/// Used to determin whether a project exists within the current workitemstore or not
		/// </summary>
		/// <param name="projectName"> string of the project name to match against</param>
		/// <returns> GetProjectExist boolean - true if the project exists, false if not, or if there was an error</returns>
		public bool ProjectExist(string projectName)
		{
			//Error handling
			if (m_workItemStore == null || projectName.Length == 0)
			{
				return false;
			}

            //Main
            foreach (Project localProject in m_workItemStore.Projects)
            {
                if (localProject.Name == projectName)
                {
                    return true;
                }
            }

            return false;
        }

		/// <summary>
		/// Returns a single workitem using the WorkItemStore query method.
		/// </summary>
		/// <param name="itemID">ID of workitem to retrieve</param>
		/// <returns></returns>
        public WorkItem GetWorkItemFromQuery(int itemID)
		{
			
			string wiqlQueryString = "select ID from WorkItems where ID = " + itemID;
			WorkItemCollection wiCollection = m_workItemStore.Query(wiqlQueryString);
			return wiCollection[0];
		}
		#endregion
    }
}
