// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.IO;
using System.Reflection;
using System.Xml;

using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Tests.Framework
{
    /// <summary>
    /// Settings helper class.
    /// </summary>
    class SettingsHelper
    {
        /// <summary>
        /// Loads XML file from resources.
        /// </summary>
        /// <param name="resourceName">Resource name</param>
        /// <returns>Xml file</returns>
        public static XmlDocument LoadResourceXml(
            string resourceName)
        {
            using (Stream stream = typeof(SettingsHelper).Assembly.GetManifestResourceStream(resourceName))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(stream);
                return doc;
            }
        }

        /// <summary>
        /// Loads settings from the given XML file.
        /// </summary>
        /// <param name="doc">XML config file</param>
        public static void LoadSettings(
            XmlDocument doc)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                doc.Save(stream);
                stream.Position = 0;
                MigrationConfiguration.Load(stream);
            }
        }
    }
}
