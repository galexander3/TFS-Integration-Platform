// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Specialized;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.IO;


namespace Tests.Framework
{
    public class MigrationInitializers
    {
        private static Random generator = new Random();

        public StringSet usedProviderIds;
        public StringSet usedTargetIds;
        public StringSet usedSinkFileNames;

        public MigrationInitializers()
        {
            usedProviderIds = new StringSet();
            usedTargetIds = new StringSet();
            usedSinkFileNames = new StringSet();
        }



        private string sinkFileName = "MigrationToolKitGeneratedTextReport.txt";

        public string SinkFileName
        {
            get
            {
                String filename;
                do
                {
                    filename = generator.Next() + sinkFileName;

                }
                while (usedSinkFileNames.Contains(filename));

                usedSinkFileNames.Add(filename);

                return TestUtils.TextReportRoot + filename;
            }
        }



        //TODO pick more interesting strings
        public string[] validSettingName = new string[] {
        "Setting0",
        "Setting1",
        "Setting2",
        "Setting3",
        "Setting4",
        "Setting5"};


        public string validWorkSpace()
        {
            //TODO Add Better random string generation here
            return "AWorkSpace" + generator.Next().ToString(); ;
        }

        public string validWorkSpaceRoot()
        {
            string workspaceRoot;

            while (true)
            {
                workspaceRoot = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
                if (!Directory.Exists(workspaceRoot))
                {
                    break;
                }
            }

            return workspaceRoot;
        }


        public string validSessionID()
        {
            //TODO Add Better random string generation here
            return "Session1" + generator.Next().ToString();
        }

        public string validSessionID(int sessionId)
        {
            //TODO Add Better random string generation here
            return string.Format("Session{0}", sessionId);
        }

        public string validProviderID()
        {
            //TODO pick more interesting strings
            String[] providerIds = new String[] { "Provider1", "Provider2", "Provider3", "Provider4", "Provider5" };

            String providerId = providerIds[generator.Next(0, providerIds.Length - 1)];
            usedProviderIds.Add(providerId);

            return providerId;
        }

        public string validMapCloak()
        {
            return validBoolean().ToString().ToLower();
        }

        public string validMapTgt()
        {
            //TODO add better random string genereation here
            return "$/Target1" + generator.Next().ToString();
        }

        public string validMapSrc()
        {
            //TODO add better random string genereation here
            return "$/Source1" + generator.Next().ToString();
        }

        public String validTargetId()
        {
            //TODO pick more interesting strings
            String[] targetIds = new String[] { "DevTfs", "TestTFS", "DogFood", "MyTFS", "YetAnotherTFS" };

            String targetId = targetIds[generator.Next(0, targetIds.Length - 1)];
            usedTargetIds.Add(targetId);

            return targetId;
        }

        public String validTargetServer()
        {
            return "http://aFakeServer:8080/";
        }

        public string validSourceName()
        {
            return "SD";
        }

        public bool validBoolean()
        {
            if (generator.Next(1) == 1)
            {
                return false;
            }
            else return true;

        }

        internal Exception ValidException()
        {
            return new MigrationException("Here is a migration exception");
        }

        internal long validLong()
        {
            return generator.Next();
        }

        internal string validDescription()
        {
            //TODO : Add better random string genereation
            return "Here is a description of an Event" + generator.Next();
        }

        internal string validAssemblyQualifiedName()
        {
            return "FC1_Loader.SDProviderFactory, FC1_Loader, Version=1.0.0.0, Culture=neutral";
        }

        public string validSettingValue()
        {
            //TODO pick more interesting strings
            String[] settingsValues = new String[] { "true", "False", generator.Next().ToString(), generator.NextDouble().ToString(), "ValueType" };

            return settingsValues[generator.Next(0, settingsValues.Length - 1)];
        }

        public string ValidWITQuery()
        {
            String[] srcs = new String[] { "SELECT System.ID FROM WorkItems.Team Project='Orcas' AND SystemWorkItemType='Bug'", "" };
            String src = srcs[generator.Next(0, srcs.Length - 1)];

            return src;
        }


        public string ValidWITSourceName()
        {
            String[] srcs = new String[] { "Source", "Foo" };
            String src = srcs[generator.Next(0, srcs.Length - 1)];

            return src;
        }

        public string ValidWITDestination()
        {
            String[] dests = new String[] { "Destination", "Bar" };
            String dest = dests[generator.Next(0, dests.Length - 1)];

            return dest;
        }

        public string ValidWITProject()
        {
            String[] projs = new String[] { "Oracs", "" };
            String proj = projs[generator.Next(0, projs.Length - 1)];

            return proj;
        }
    }
}
