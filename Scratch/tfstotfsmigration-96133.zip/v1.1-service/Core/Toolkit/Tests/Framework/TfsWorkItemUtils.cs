﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.Framework
{
    class TfsWorkItemUtils
    {
        #region Constuctors
        /// <summary>
		/// Constructor
		/// </summary>
		/// <remarks>
		/// You will have to create a new instance of the WorkItemUtils for every
		/// WorkItem object you want to take action on.
		/// </remarks>
		/// <param name="wi">WorkItem object that this instance of the WorkItemUtils will bind to.</param>
		public TfsWorkItemUtils(WorkItem wi, TfsProjectUtils projectUtils)
		{
            if (wi == null)
                throw new ArgumentException("WorkItem is null", "wi");

            if (projectUtils == null)
                throw new ArgumentException("ProjectUtils is null", "projectUtils");

            m_workItem = wi;
			m_projectUtils = projectUtils;
		}

		#endregion
		
		#region private members

		private WorkItem m_workItem;

        private TfsProjectUtils m_projectUtils;
                
		private static Hashtable m_fieldHT = new Hashtable();
		private static Hashtable m_valueHT = new Hashtable();

		private static Random valueRandom = new Random();

		#endregion

		#region public properties

		/// <summary>
		/// Gets the WorkItem object this instance of the WorkItemUtils is bound to.
		/// </summary>
		/// <value>WorkItem object</value>
		public WorkItem workItem
		{
			get
			{
				return m_workItem;
			}
		}

		/// <summary>
		/// Gets the Project object this instance of the WorkItemUtils is bound to.
		/// </summary>
		/// <value>Project object</value>
		public TfsProjectUtils projectUtils
		{
			get
			{
				return m_projectUtils;
			}
		}
		
		#endregion

		#region Public Methods

        /// <summary>
        /// Sets the appropriate field values based upon the current possible values picked up from the field AllowedValues collection.
        /// </summary>
        /// <param name="consoleLogFlag">Used to tell the method to log to the console for testing.</param>
        public void SetFieldValues(bool consoleLogFlag)
        {
            //First we need to set the State.  This dictates valid values for all other fields.
            SetFieldValue(m_workItem.Fields["System.State"]);

            if (consoleLogFlag)
                Console.WriteLine("State = " + m_workItem.Fields["System.State"].Value);

            foreach (Field field in m_workItem.Fields)
            {
                SetFieldValue(field);
            }
        }

        /// <summary>
		///		Sets each Field in a Fields collection (from any WorkItem object)
		///		to a valid value.
		/// </summary>
		/// <remarks>
		///		Does not touch valid fields. Sets the field to the 
		///		first valid value it can, so it's not very picky.
		/// </remarks>
		/// <returns>
		///		True - if all fields are valid
		///		False - if there is a field that is invalid (won't be able to save the work item.
		/// </returns>
		public bool MakeWorkItemFieldsValid(string title)
		{
			bool m_InvalidField = false;
			AllowedValuesCollection m_allowedValues = null;

			//Find each required field
			foreach (Field field in m_workItem.Fields)
			{
			
				//set the Area and Iteration node IDs.
				if (field.Name.ToString() == "AreaID")
					//Randomly set the TreeID to a valid node.
					field.Value = m_projectUtils.GetRandomTreeID(TfsProjectUtils.NodeType.Area);
				if (field.Name.ToString() == "IterationID")
					//Randomly set the TreeID to a valid node.
					field.Value = m_projectUtils.GetRandomTreeID(TfsProjectUtils.NodeType.Iteration);

				//If Field is required, find the right value
				if (!field.IsValid)
				{
					//If we can get the value from the 
					//AllowedValues collection, that is
					//the quickest way to do it.
					if (field.AllowedValues.Count > 0)
					{
						//Use the first value and get on with it
						m_allowedValues = field.AllowedValues;
						field.Value = m_allowedValues[0];
					}
					else
					{
						if (field.Name.ToString() == "Title")
							field.Value = title;
						else
							SetValidFieldValue(field, 5);
					}
				}//if

				//Check the validity of the field.
				if (!field.IsValid)
				{
					m_InvalidField = true;
					Console.WriteLine("Invalid Field " + field.Name + ": " + field.IsValid);
					Console.WriteLine("Current Value: " + field.Value + "\r\n");
				}

			}//foreach


			return !m_InvalidField;

		}//MakeWorkItemFieldsValid()
		#endregion
		
		#region Files

		/// <summary>
		/// Attaches a file to the workItem object.
		/// </summary>
		/// <param name="fullFilePath">string: Full path to a file or url.  Must include the name of the file.</param>
		public void AddAttachment(string fullFilePath)
		{
            Attachment addAttachment = new Attachment(fullFilePath, "WorkItemUtils created file... " + DateTime.Now);
            m_workItem.Attachments.Add(addAttachment);

            AppendDescription("Attached file " + fullFilePath + " by WorkItemUtils Class " + DateTime.Now);
 
		}

		/// <summary>
		/// Removes a file from the workItem.
		/// </summary>
		/// <remarks>
		/// Pass in only the name and not the full path to the file.
		/// For URLs pass in the full URL.
		/// </remarks>
		/// <param name="fileName">string: fileName/url to be removed.</param>
		public void RemoveAttachment(string fileName)
		{
            //Remove appropriate attachment object based upon the name.
            for (int i = 1; i <= m_workItem.Attachments.Count; i++)
            {
                if (m_workItem.Attachments[i].Name == fileName)
                {
                    m_workItem.Attachments.Remove(m_workItem.Attachments[i]);
                    break;
                }
            }

            AppendDescription("Removed attachment " + fileName + " by WorkItemUtils Class " + DateTime.Now);
		}
		#endregion

		#region private methods

        private void AppendDescription(string description)
        {
            //Append to the description that this file has been removed.
            string descriptionToAppend;
            descriptionToAppend = m_workItem.Fields["Description"].Value.ToString();
            descriptionToAppend += Environment.NewLine;
            descriptionToAppend += description;
            descriptionToAppend += Environment.NewLine;
            m_workItem.Fields["Description"].Value = descriptionToAppend;
        }

        private void SetFieldValue(Field field)
        {
            int maxChars = 12;

            //If field is not editable get out of here.  TODO: Remove checks to workaround bugs#9172, 10039 when fixed.
            if (!field.IsEditable || field.Name == "Work Item Type" || field.Name == "Work Item FormID" || field.Name == "Created By")
                return;

            //Check to see if field has values.
            if (field.AllowedValues.Count > 0)
            {
                string fieldValue = GetValidValue(field);

                if (fieldValue != null)
                    field.Value = fieldValue;
                else
                    //There are no validValues for this state, so don't set one.
                    return;
            }
            else
            {
                //Set a random value based upon the type and maxchars.
                SetValidFieldValue(field, maxChars);
            }

        }
        
        private string GetValidValue(Field field)
		{
			if (field.AllowedValues.Count == 0)
				return null;

			int index = valueRandom.Next(field.AllowedValues.Count);
			int count = 0;
			foreach(string allowedValue in field.AllowedValues)
			{
				if(index == count)
					return allowedValue;
				count++;
			}

			return null;
		}

		private void SetValidFieldValue(Field field, int maxChar)
		{
            Random random = new Random();

			//We can only set fields that are not readonly and are not of type TreePath.
			if (field.IsEditable && field.FieldDefinition.FieldType != FieldType.TreePath)
			{

				//TODO: Localize all field names.
                if (field.Name.ToString() == "AreaID")
                    field.Value = m_projectUtils.GetRandomTreeID(TfsProjectUtils.NodeType.Area);
                else if (field.Name == "IterationID")
                    field.Value = m_projectUtils.GetRandomTreeID(TfsProjectUtils.NodeType.Iteration);
                else if (field.Name == "Title")
                    field.Value = "Created by OMFramework (" + System.Environment.ExpandEnvironmentVariables("%USERNAME%") + ")..." + DateTime.Now.Ticks.ToString();  //TODO: Localize this string.
                else if (field.Name.Contains("Work"))  //Keep work values more realistic.
                    field.Value = random.Next(100);
                else if (field.Name.ToLower().IndexOf("build") >= 0 && field.FieldDefinition.FieldType == FieldType.String)
                    field.Value = GetBuild();
                else
                {
                    switch (field.FieldDefinition.FieldType)
                    {
                        case FieldType.Integer:
                            field.Value = random.Next(Int32.MaxValue);
                            break;
                        case FieldType.Html:
                            field.Value = "http://www.msn.com";         //TODO: Localize this string.
                            break;
                        case FieldType.DateTime:
                            field.Value = DateTime.Now.AddMilliseconds(300).ToString();
                            break;
                        default:
                            field.Value = GetRandomText(maxChar);   //TODO: update this to use Maui.Core localized string builder methods.
                            break;
                    }

                }
			}
		}

        /*
		private bool IsValueValid(Field field, XmlNode xmlNode)
		{
			foreach (string validValue in field.AllowedValues)
			{
				if (validValue == xmlNode.InnerText)
					return true;
			}

			return false;
		} */

		private string GetBuild()
		{
			Random random = new Random();
			StringBuilder build = new StringBuilder("Lab");
			build.Append(random.Next(20, 29));
			build.Append(".");
			build.Append(random.Next(11111, 99999));
			build.Append(".");
			build.Append(random.Next(0, 99));

			return build.ToString();
		}

        // todo: truncate the lenght. 
        public static string GetRandomText(int length)
        {
            Guid testGuid = Guid.NewGuid();

            StringBuilder sb = new StringBuilder(length);
            while (sb.Length < length)
            {
                sb.Append(Guid.NewGuid()); 
            }

            if (sb.Length > length)
            {
                sb.Remove(length, sb.Length - length);
            }

            return sb.ToString(); 
        }

		#endregion

    }
}
