using System;
using System.Collections.Generic;
using System.Text;

namespace Tests.Framework
{
    public class CommonStrings
    {
        private static string urlCombine = "{0}/{1}";
        private static string wSSFileUrl = "http://{0}/sites/testSite/{1}/{2}";//	The format string for the URL of a file in WSS

        public static string UrlCombine
        {
            get { return CommonStrings.urlCombine; }
        }

        public static string WSSFileUrl
        {
            get { return CommonStrings.wSSFileUrl; }
        }
    }
}
