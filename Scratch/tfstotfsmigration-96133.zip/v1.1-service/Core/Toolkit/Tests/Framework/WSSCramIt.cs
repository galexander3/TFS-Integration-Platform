// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Xml;
using System.IO;
using System.Diagnostics;

namespace Tests.Framework
{
    public class WSSCramIt
    {
        static String CramItLocation = Path.Combine(Directory.GetDirectoryRoot(Environment.SystemDirectory), @"Program Files\MOTIF\12\Bin");

        /// <summary>
        /// Start WSSCramIt with the given file name. 
        /// </summary>
        /// <param name="cramItFileName">The xml file with which to start CramIt</param>
        public static void Populate(string cramItFileName)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(cramItFileName);
            //Add the remote machine to the xml file
            ((XmlElement)doc.SelectSingleNode("RunRemotely")).SetAttribute("machine", TestEnvironment.WssMachine);
            doc.Save(cramItFileName);

            System.Diagnostics.Process populationProcess = new System.Diagnostics.Process();
            populationProcess.StartInfo.FileName = Path.Combine(CramItLocation, "osgcramit.exe");
            populationProcess.StartInfo.Arguments = cramItFileName;

            populationProcess.Start();

            populationProcess.WaitForExit();

            populationProcess.Dispose();
        }
    }
}
