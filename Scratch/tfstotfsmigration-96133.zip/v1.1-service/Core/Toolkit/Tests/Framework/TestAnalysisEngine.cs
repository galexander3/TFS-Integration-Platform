using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.VersionControl.Wss;

namespace Tests.Framework
{
    public class TestAnalysisEngine : TfsToSourceAnalysisEngine
    {
        VersionControlSession session;

        public TestAnalysisEngine(VersionControlSession session, ChangeGroupingMananger manager)
            : base(session, manager)
        {
            this.session = session;
        }

        public void CallExecute(TfsAnalysisAlgorithm algorithm, Change change, ChangeGrouping group)
        {
            Execute(algorithm, change, group);
        }

        protected override TfsAnalysisAlgorithms LoadAnalysisAlgorithms()
        {
            return new TestAnalysisAlgorithims(session);
        }

        protected override ChangeGrouping CreateChangeGrouping(Changeset changeSet)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        protected override Microsoft.TeamFoundation.Migration.Toolkit.VersionControlMapping FindChangeMapping(Change change)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public TfsAnalysisAlgorithm CallGetHandler(ChangeType changeType)
        {
            return GetHandler(changeType);
        }
    }

    public class TestAnalysisAlgorithims : TfsAnalysisAlgorithms
    {
        VersionControlSession session;

        public TestAnalysisAlgorithims(VersionControlSession session)
        {
            this.session = session;
        }

        protected override bool IsItemMapped(Item tfsItem)
        {
            return true;
        }

        protected override VersionControlSession Session
        {
            get { return session; }
        }

        protected override IMigrationItem CreateMigrationItem(Item tfsItem)
        {
            return new TfsMigrationItem(tfsItem, session);
        }
    }
}
