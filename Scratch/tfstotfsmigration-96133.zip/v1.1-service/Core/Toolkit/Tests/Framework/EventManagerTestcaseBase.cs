// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tests.Framework;
namespace Tests
{
    public class EventManagerTestcaseBase : MigrationTestCaseBase
    {
        #region Additional test attributes
        protected VersionControlSession target;
        protected VersionControlEventArgs eventArgs;
        protected TestEventSink sink;
        protected MigrationInitializers initializer;

        [TestInitialize()]
        public override void Initialize()
        {
            base.Initialize();

            configFileName = TestContext.TestName + ".xml";
            configFile = new ConfigFile(configFileName);

            doc = configFile.Doc;

            target = new VersionControlSession();

            initializer = new MigrationInitializers();

            eventArgs = new VersionControlEventArgs(
                initializer.validDescription(),
                initializer.ValidException(), SystemType.Other);
            sink = new TestEventSink(eventArgs);
            target.RegisterEventSink(sink);
        }

        [TestCleanup()]
        public override void Cleanup()
        {
            target.Stop();
            target.Dispose();
            target = null;
            eventArgs = null;

            sink.Dispose();
            sink = null;
            base.Cleanup();
        }

        protected void OnlyEventFired(TestEventSink sink, int index)
        {
            for (int i = 0; i < sink.counter.Length; i++)
            {
                if (i == index)
                {   //Checks that the event in question was fired only once
                    Assert.AreEqual(1, sink.counter[i], String.Format("Event {0} fired the wrong number of times",i));

                }
                else
                {  //Checks that no other events were fired
                    Assert.AreEqual(0, sink.counter[i], String.Format("Event {0} Should not have fired",i));
                }

            }

        }

        protected void NoEventsFired(TestEventSink sink)
        {
            for (int i = 0; i < sink.counter.Length; i++)
            {
                //Checks that the event in question was fired only once
                Assert.AreEqual(0, sink.counter[i], String.Format("Event {0} Should not have fired",i));
            }

        }

        protected void EventsFired(TestEventSink sink, List<int> indexs)
        {
            indexs.Sort();
            for (int i = 0; i < sink.counter.Length; i++)
            {
                if (indexs.Contains(i))
                {   //Checks that the event in question was fired only once
                    Assert.AreEqual((indexs.LastIndexOf(i)-indexs.IndexOf(i)+1), sink.counter[i],
                        "Event Fired The wrong number of times");

                }
                else
                {  //Checks that no other events were fired
                    Assert.AreEqual(0, sink.counter[i], "Wrong Event was Fired.  Event " + i);
                }

            }

        }


        #endregion

    }
}
