// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.IO;
using System.Collections.Specialized;

namespace Tests.Framework
{
    public class ConfigFile
    {
        private Random generator;
        private string fileName;
        public MigrationInitializers initializer;
        private XmlDocument doc;

        //The filename the Config file will use when it is written
        public string FileName
        {
            get { return fileName; }
            set { fileName = value; }
        }

        //The XML doument of the config file.  Only use if the XML needs to be manipulated directly.
        public XmlDocument Doc
        {
            get { return doc; }
            set { doc = value; }
        }

        //Writes this configFile with default encoding and loads it into the current MigrationConfiguration.Current
        public void WriteAndLoad()
        {
            WriteXMLFile(null);
            using (FileStream fs = new FileStream(fileName, FileMode.Open))
            {
                MigrationConfiguration.Load(fs);
            }
        }

        //Writes this configFile with the encoding specified
        public void WriteXMLFile(Encoding encoding)
        {
            using (XmlTextWriter migrationConfigWritter = new XmlTextWriter(fileName, encoding))
            {
                doc.WriteTo(migrationConfigWritter);
            }
        }

        //Creates a valid configFile pased on configParameters and loads it into the current MigrationConfiguration.Current 
        public static void WriteAndLoad(ConfigParameters configParameters)
        {
            ConfigFile file = new ConfigFile(configParameters);
            file.WriteAndLoad();
        }

        #region Parameter Based XML File

        //Create a valid Config file based on configParameters by using the Create%NodeName%(%Node%Info) methods
        //Each method knows how to assemble the proper XML for its node and returns an element that is appended to the parent node.
        public ConfigFile(ConfigParameters configParameters)
        {
            fileName = configParameters.TestcaseName + ".xml";
            doc = new XmlDocument();
            XmlElement configFile = doc.CreateElement("Migration");
            configFile.AppendChild(CreateSettings(configParameters.Settings));

            if (configParameters.VersionControl != null)
            {
                configFile.AppendChild(CreateVCNode(configParameters.VersionControl));
            }

            if (configParameters.WorkItemTracking != null)
            {
                configFile.AppendChild(CreateWITNode(configParameters.WorkItemTracking));
            }

            XmlElement serversNode= doc.CreateElement("Servers");
            configFile.AppendChild(serversNode);
            foreach (ServerInfo server in configParameters.Servers)
            {
                XmlElement tfsNode = Doc.CreateElement("Tfs");
                XmlElement serverNode=doc.CreateElement("Server");
                tfsNode.SetAttribute("id", server.ServerId);
                serverNode.InnerText = server.ServerURI;

                tfsNode.AppendChild(serverNode);
                serversNode.AppendChild(tfsNode);
            }

            XmlElement providersNode = doc.CreateElement("Providers");
            configFile.AppendChild(providersNode);
            foreach (ProviderInfo provider in configParameters.Providers)
            {
                XmlElement providerNode = doc.CreateElement("Provider");
                providerNode.SetAttribute("id", provider.ProviderId);

                XmlElement assemblyQName = doc.CreateElement("AssemblyQualifiedName");
                assemblyQName.InnerText = provider.AssemblyQualifiedName;
                providerNode.AppendChild(assemblyQName);

                providersNode.AppendChild(providerNode);
            }

            configFile.AppendChild(CreateSqlNode(configParameters.SqlInfo));

            doc.AppendChild(configFile);
        }

        private XmlNode CreateWITNode(WorkItemTrackingInfo workItemTrackingInfo)
        {
            XmlElement witNode = doc.CreateElement("WIT");

            XmlElement sessionsNode = doc.CreateElement("Sessions");
            witNode.AppendChild(sessionsNode);

            foreach (WorkItemTrackingSessionInfo session in workItemTrackingInfo.WitSessions)
            {
                sessionsNode.AppendChild(CreateWitSession(session));
            }
            
            witNode.AppendChild(CreateFieldMaps(workItemTrackingInfo));

            return witNode;
        }

        private XmlElement CreateVCNode(VersionControlInfo configParameters)
        {
            XmlElement vcNode = doc.CreateElement("VC");

            vcNode.AppendChild(CreateSettings(configParameters.Settings));

            XmlElement sessionsNode = doc.CreateElement("Sessions");
            vcNode.AppendChild(sessionsNode);

            foreach (VersionControlSessionInfo session in configParameters.Sessions)
            {
                sessionsNode.AppendChild(CreateVCSession(session));
            }

            return vcNode;
        }

        private XmlElement CreateSqlNode(SqlInfo sqlInfo)
        {
            XmlElement sqlNode = doc.CreateElement("Sql");

            XmlElement connectionString = Doc.CreateElement("ConnectionString");
            XmlElement database = Doc.CreateElement("Database");
            XmlElement server = Doc.CreateElement("Server");

            connectionString.InnerText = sqlInfo.ConnectionString;
            database.InnerText = sqlInfo.Database;
            server.InnerText = sqlInfo.Server;

            sqlNode.AppendChild(connectionString);
            sqlNode.AppendChild(database);
            sqlNode.AppendChild(server);

            return sqlNode;
        }

        private XmlNode CreateSettings(Dictionary<string, string> settingsInfo)
        {
            XmlElement settingsNode = doc.CreateElement("Settings");
            if (settingsInfo != null && settingsInfo.Count != 0)
            {
                foreach (KeyValuePair<string,string> setting in settingsInfo)
                {
                    XmlElement settingNode = doc.CreateElement("Setting");
                    settingNode.SetAttribute("name", setting.Key);
                    settingNode.SetAttribute("value", setting.Value);
                    settingsNode.AppendChild(settingNode);
                }
            }

            return settingsNode;
        }

        private XmlElement CreateVCSession(VersionControlSessionInfo session)
        {
            XmlElement sessionNode = doc.CreateElement("Session");
            XmlElement mappingsNode = doc.CreateElement("Mappings");
            XmlElement sourceNode = doc.CreateElement("Source");
            XmlElement eventSinksNode = doc.CreateElement("EventSinks");
           
            sessionNode.SetAttribute("id", session.SessionId);
            sessionNode.SetAttribute("provider", session.ProviderId);

            sourceNode.AppendChild(session.Source.generateXml(Doc));      


            foreach (EventSinkInfo eventSink in session.EventSinks)
            {
                if (eventSink != null)
                {
                    eventSinksNode.AppendChild(eventSink.generateXml(Doc));
                }
            }
            
            foreach (MappingsInfo mappingInfo in session.Mappings)
            {
                mappingsNode.AppendChild(CreateVCMapping(mappingInfo));
            }            

            sessionNode.AppendChild(mappingsNode);
            sessionNode.AppendChild(CreateTfsNode(session.Tfs));
            sessionNode.AppendChild(CreateSettings(session.Settings));
            
            sessionNode.AppendChild(sourceNode);
            sessionNode.AppendChild(eventSinksNode);

            return sessionNode;
        }

        private XmlElement CreateTfsNode(TfsInfo tfs)
        {
            XmlElement tfsNode = doc.CreateElement("Tfs");
            XmlElement workspaceNode = doc.CreateElement("Workspace");
            XmlElement workspaceRootNode = doc.CreateElement("WorkspaceRoot");

            workspaceNode.InnerText = tfs.WorkspaceName;
            workspaceRootNode.InnerText = tfs.WorkspaceRoot;

            tfsNode.SetAttribute("server", tfs.ServerId);
            tfsNode.AppendChild(workspaceNode);
            tfsNode.AppendChild(workspaceRootNode);

            return tfsNode;
        }

        private XmlElement CreateVCMapping(MappingsInfo mappingInfo)
        {
            XmlElement mappingNode = doc.CreateElement("Mapping");
            mappingNode.SetAttribute("src", mappingInfo.Source);
            mappingNode.SetAttribute("tgt", mappingInfo.Target);
            mappingNode.SetAttribute("cloak", mappingInfo.Cloak.ToString().ToLower());
            return mappingNode;
        }

        private XmlElement CreateFieldMaps(WorkItemTrackingInfo wit)
        {
            XmlElement mapsNode = doc.CreateElement("FieldMaps");

            foreach (FieldMapInfo fm in wit.FieldMaps)
            {
                XmlElement mapNode = doc.CreateElement("FieldMap");
                mapNode.SetAttribute("name", fm.Name);

                foreach (FieldExcludionEntry fe in fm.FieldExclusionList)
                {
                    XmlElement fieldNode = doc.CreateElement("Field");
                    fieldNode.SetAttribute("tfsName", fe.FieldPair.TfsName);
                    fieldNode.SetAttribute("otherName", fe.FieldPair.OtherName);
                    mapNode.AppendChild(fieldNode);

                    if (fe.Exclusion.Sys != null && fe.Exclusion.Sys != string.Empty)
                    {
                        XmlElement excludeNode = doc.CreateElement("Exclude");
                        excludeNode.SetAttribute("system", fe.Exclusion.Sys);
                        excludeNode.SetAttribute("field", fe.Exclusion.Field);
                        mapNode.AppendChild(excludeNode);
                    }
                }
                mapsNode.AppendChild(mapNode);

            }

            return mapsNode;
        }
        private XmlElement CreateFieldMapping(FieldMappingInfo fieldMapping)
        {
            List<WorkItemTypeDef> wiTypes = fieldMapping.WiTypes;

            XmlElement mappingNode = doc.CreateElement("WorkItemTypes");

            foreach(WorkItemTypeDef wit in wiTypes)
            {
                XmlElement wtNode = doc.CreateElement("WorkItemType");
                wtNode.SetAttribute("tfs", wit.Tfs);
                wtNode.SetAttribute("other", wit.Other);
                if (wit.FieldMap != string.Empty)
                {
                    wtNode.SetAttribute("fieldMap", wit.FieldMap);
                }
                mappingNode.AppendChild(wtNode);
            }
    
            return mappingNode;
        }

        private XmlNode CreateWitSession(WorkItemTrackingSessionInfo session)
        {
            XmlElement sessionNode = doc.CreateElement("Session");
            XmlElement tfsNode = doc.CreateElement("Tfs");
            XmlElement fastQueueNode = doc.CreateElement("FastQueue");
            XmlElement slowQueueNode = doc.CreateElement("SlowQueue");
 
            sessionNode.SetAttribute("id", session.SessionId);

            tfsNode.SetAttribute("server", session.TFS.ServerName);
            tfsNode.SetAttribute("fieldForm", "Reference");

            XmlElement projNode = doc.CreateElement("Project");
            projNode.InnerText = session.TFS.Project;
            tfsNode.AppendChild(projNode);

            if (session.TFS.Filter != null)
            {
                XmlElement filterNode = doc.CreateElement("Filter");
                filterNode.InnerText = session.TFS.Filter;
                tfsNode.AppendChild(filterNode);
            }
            sessionNode.AppendChild(tfsNode);

            if (session.SourceTFS != null)
            {
                sessionNode.AppendChild(CreateWITSourceTfs(session.SourceTFS));
            }

            fastQueueNode.SetAttribute("threadCount", session.FastQueue.ThreadCount.ToString());
            fastQueueNode.SetAttribute("batchSize", session.FastQueue.BatchSize.ToString());
            sessionNode.AppendChild(fastQueueNode);

            slowQueueNode.SetAttribute("threadCount", session.FastQueue.ThreadCount.ToString());
            slowQueueNode.SetAttribute("batchSize", session.SlowQueue.BatchSize.ToString());
            sessionNode.AppendChild(slowQueueNode);
            if (session.FMapping != null)
            {
                sessionNode.AppendChild(CreateFieldMapping(session.FMapping));
            }
            return sessionNode;
        }

        private XmlNode CreateWITProvider(WitProviderInfo witProviderInfo)
        {
            XmlElement srcNode = doc.CreateElement("Source");

            XmlElement provNode = doc.CreateElement("Provider");
            provNode.SetAttribute("provider", witProviderInfo.Id);

            srcNode.AppendChild(provNode);

            return srcNode;
        }


        private XmlNode CreateWITSourceTfs(TFSWitInfo wit)
        {
            XmlElement srcNode = doc.CreateElement("Source");

            XmlElement tfsNode = doc.CreateElement("Tfs");
            tfsNode.SetAttribute("server", wit.ServerName);
        
            XmlElement projNode = doc.CreateElement("Project");
            projNode.InnerText = wit.Project;
            
            tfsNode.AppendChild(projNode);

            XmlElement queueNode = doc.CreateElement("WriteQueue");
            queueNode.SetAttribute("threadCount", "2");
            queueNode.SetAttribute("threadCount", "2");
            tfsNode.AppendChild(queueNode);

            srcNode.AppendChild(tfsNode);

            return srcNode;
        }


        #endregion Parameter Based XML File

        #region Random XML File

        public ConfigFile(string fileName)
        {
            this.fileName = fileName;
            generator = new Random();
            initializer = new MigrationInitializers();
            doc = new XmlDocument();

            XmlElement configFile = doc.CreateElement("Migration");

            configFile.AppendChild(CreateSettings());
            configFile.AppendChild(CreateVCType());
            
            configFile.AppendChild(CreateWITType());
            
            configFile.AppendChild(CreateProviders());

            configFile.AppendChild(CreateServer());

            configFile.AppendChild(CreateSqlNode());

            doc.AppendChild(configFile);
        }

        private XmlElement CreateServer()
        {
            XmlElement serversNode = doc.CreateElement("Servers");

            foreach (string targetId in initializer.usedTargetIds)
            {
                XmlElement tfsNode = doc.CreateElement("Tfs");
                tfsNode.SetAttribute("id", targetId);
                serversNode.AppendChild(tfsNode);

                XmlElement serverNode = doc.CreateElement("Server");
                serverNode.InnerText = initializer.validTargetServer();
                tfsNode.AppendChild(serverNode);
            }
            return serversNode;

        }

        private XmlElement CreateProviders()
        {
            XmlElement providersNode = doc.CreateElement("Providers");
            foreach (string providerId in initializer.usedProviderIds)
            {
                providersNode.AppendChild(CreateProvider(providerId));
            }

            providersNode.AppendChild(CreateProvider("WITProvider", "Tests.WIT.Rand.RandProviderFactory, Tests, Version=1.0.0.0, Culture=neutral"));
            providersNode.AppendChild(CreateProvider("TextReport", "Microsoft.TeamFoundation.Migration.Toolkit.TextReportFactory, Microsoft.TeamFoundation.Migration.Toolkit, Version=1.0.0.0, Culture=neutral"));
            
            providersNode.AppendChild(CreateProvider("SQLReport", "Microsoft.TeamFoundation.Migration.Toolkit.SqlReportFactory, Microsoft.TeamFoundation.Migration.Toolkit, Version=1.0.0.0, Culture=neutral"));

            return providersNode;
        }

        private XmlElement CreateProvider(string providerId)
        {
            XmlElement providerNode = doc.CreateElement("Provider");
            providerNode.SetAttribute("id", providerId);
            XmlElement assemblyNode = doc.CreateElement("AssemblyQualifiedName");
            assemblyNode.InnerText = initializer.validAssemblyQualifiedName();
            providerNode.AppendChild(assemblyNode);
            return providerNode;
        }

        private XmlElement CreateVCType()
        {
            XmlElement migrationType = doc.CreateElement("VC");

            migrationType.AppendChild(CreateSettings());

            XmlElement sessions = doc.CreateElement("Sessions");

            int numberOfSessions = generator.Next(1, 5);
            for (int i = 0; i < numberOfSessions; i++)
            {
                sessions.AppendChild(CreateSession(i));
            }
            migrationType.AppendChild(sessions);

            return migrationType;
        }

        private XmlNode CreateSqlNode()
        {
            XmlElement sqlNode = doc.CreateElement("Sql");

            XmlElement server = doc.CreateElement("Server");
            server.InnerText = "sql-server";
            sqlNode.AppendChild(server);

            XmlElement database = doc.CreateElement("Database");
            database.InnerText = "MigrationToolkitTest2";
            sqlNode.AppendChild(database);

            return sqlNode;
        }

        private XmlElement CreateSettings()
        {
            XmlElement settingsNode = doc.CreateElement("Settings");


            int numberOfSettings = generator.Next(2, 5);
            for (int i = 0; i < numberOfSettings; i++)
            {
                XmlElement settingNode = doc.CreateElement("Setting");
                settingNode.SetAttribute("name", initializer.validSettingName[i]);
                settingNode.SetAttribute("value", initializer.validSettingValue());
                settingsNode.AppendChild(settingNode);
            }

            return settingsNode;

        }

        private XmlElement CreateSession(int sessionId)
        {
            XmlElement session = doc.CreateElement("Session");

            session.SetAttribute("id", initializer.validSessionID(sessionId));
            session.SetAttribute("provider", initializer.validProviderID());

            session.AppendChild(CreateMappings());

            session.AppendChild(CreateTarget());

            session.AppendChild(CreateSource());

            session.AppendChild(CreateEventSink());

            session.AppendChild(CreateSettings());

            return session;

        }

        private XmlElement CreateTarget()
        {
            XmlElement targetNode = doc.CreateElement("Tfs");

            targetNode.SetAttribute("server",initializer.validTargetId());

            XmlElement workspaceNode = doc.CreateElement("Workspace");
            workspaceNode.InnerText = initializer.validWorkSpace();
            targetNode.AppendChild(workspaceNode);


            XmlElement workspaceRootNode = doc.CreateElement("WorkspaceRoot");
            workspaceRootNode.InnerText = initializer.validWorkSpaceRoot();
            targetNode.AppendChild(workspaceRootNode);

            return targetNode;
        }


        private XmlElement CreateSource()
        {
            XmlElement sourceNode = doc.CreateElement("Source");
            XmlElement source = doc.CreateElement(initializer.validSourceName());

            XmlElement port = doc.CreateElement("SdPort");
            port.InnerText = "DDRTSD:4000";
            source.AppendChild(port);

            XmlElement proxy = doc.CreateElement("SdProxy");
            proxy.InnerText = "VSNCSDPROXY:4040";
            source.AppendChild(proxy);

            XmlElement client = doc.CreateElement("SdClient");
            client.InnerText = "client";
            source.AppendChild(client);

            sourceNode.AppendChild(source);
            return sourceNode;
        }

        private XmlElement CreateMappings()
        {
            XmlElement mappingsNode = doc.CreateElement("Mappings");

            int numberOfSettings = generator.Next(2, 5);
            for (int i = 0; i < numberOfSettings; i++)
            {
                mappingsNode.AppendChild(CreateMap());
            }


            return mappingsNode;
        }

        private XmlElement CreateMap()
        {

            XmlElement mapNode = doc.CreateElement("Mapping");

            mapNode.SetAttribute("src", initializer.validMapSrc());
            mapNode.SetAttribute("tgt", initializer.validMapTgt());
            mapNode.SetAttribute("cloak", initializer.validMapCloak());
            return mapNode;

        }

        private XmlElement CreateEventSink()
        {
            XmlElement eventSinks = doc.CreateElement("EventSinks");
            XmlElement eventSink = doc.CreateElement("EventSink");
            eventSink.SetAttribute("provider", "TextReport");

            XmlElement report = doc.CreateElement("TextReport");

            XmlElement file = doc.CreateElement("File");
            file.InnerText = initializer.SinkFileName;
            report.AppendChild(file);

            XmlElement append = doc.CreateElement("Append");
            append.InnerText = "false";
            report.AppendChild(append);

            eventSinks.AppendChild(eventSink);
            eventSink.AppendChild(report);
            return eventSinks;
        }

        private XmlElement CreateProvider(string id, string assemblyName)
        {
            XmlElement providerNode = doc.CreateElement("Provider");
            providerNode.SetAttribute("id", id);
            XmlElement assemblyNode = doc.CreateElement("AssemblyQualifiedName");
            assemblyNode.InnerText = assemblyName;
            providerNode.AppendChild(assemblyNode);
            return providerNode;
        }

        private XmlElement CreateWITType()
        {
            XmlElement migrationType = doc.CreateElement("WIT");

            migrationType.AppendChild(CreateSettings());

            XmlElement sessions = doc.CreateElement("Sessions");

            int numberOfSessions = 2; //generator.Next(1, 2);
            for (int i = 0; i < numberOfSessions; i++)
            {
                sessions.AppendChild(CreateWITSession());
            }
            migrationType.AppendChild(sessions);

            return migrationType;
        }

        private XmlElement CreateWITSession()
        {

            XmlElement session = doc.CreateElement("Session");

            session.SetAttribute("id", initializer.validSessionID());

            session.AppendChild(CreateWITTarget());
            session.AppendChild(CreateWITProvider());
            session.AppendChild(CreateSettings());

            return session;
        }

        private XmlElement CreateWITTarget()
        {
            XmlElement targetNode = doc.CreateElement("Tfs");

            targetNode.SetAttribute("server", initializer.validTargetId());

            string query = initializer.ValidWITQuery();
            if (query != string.Empty)
            {
                XmlElement sourceNode = doc.CreateElement("Filter");
                sourceNode.InnerText = query;
                targetNode.AppendChild(sourceNode);
            }

            string proj = initializer.ValidWITProject();
            if (proj != string.Empty)
            {

                //XmlElement destNode = doc.CreateElement("Destination");
                XmlElement projectNode = doc.CreateElement("Project");
                projectNode.InnerText = proj;
                targetNode.AppendChild(projectNode);
            }

            return targetNode;
        }

        private XmlElement CreateWITProvider()
        {
            XmlElement srcNode = doc.CreateElement("Source");
            XmlElement provNode = doc.CreateElement("Provider");
            XmlElement dataNode = doc.CreateElement("InitializationData");

            provNode.SetAttribute("provider", "WITProvider");

            srcNode.AppendChild(provNode);
            provNode.AppendChild(dataNode);

            return srcNode;
        }
        #endregion Random XML File
    }

}
