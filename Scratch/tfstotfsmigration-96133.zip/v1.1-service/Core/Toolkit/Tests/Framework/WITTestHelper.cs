// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Schema;
using Tests.Framework;

namespace Tests
{
    /// <summary>
    ///     This is a helper class for WIT testing. It will provide some static functions
    /// </summary>
    internal class WITTestHelper
    {
        /// <summary>
        /// private constructor, forbid creating objects
        /// </summary>
        private WITTestHelper()
        {


        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="resName">Resource name</param>
        /// <returns>if it can be loaded successfully, return true; 
        ///     else if it is throw XmlSchemaValidationException, return false.
        /// </returns>
        static internal bool CanBeLoaded(string resName, ConfigFile configFileGenerator)
        {
            try
            {
                configFileGenerator.FileName = resName;
                configFileGenerator.WriteAndLoad();
            }
            catch (XmlSchemaValidationException)
            {
                return false;
            }
            catch (Exception)
            {
                throw;
            }

            return true;
        }

        /// <summary>
        /// Loads configuration settings from resources with the given name/
        /// </summary>
        /// <param name="name">Resource name</param>
        private void Load(string resName)
        {
            if (string.IsNullOrEmpty(resName))
            {
                throw new ArgumentException("Resource name should not be null or empty");
            }

            using (Stream stream = this.GetType().Assembly.GetManifestResourceStream(resName))
            {
                MigrationConfiguration.Load(stream);
            }
        }
    }
}
