// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml;
using System.IO;

namespace Tests.Framework
{

    /**   Directions: Preparing an Evironment File to Run tests
     * 1. Specifying all the variables in the "Edit this region..." region. 
     * 2. Find this test in the Test View.  View its properties; change Test Enabled to True.
     * 3. Run this test. 
     * 4. (Optional)Change the Test Enabled property back to false so this test is not picked up in future runs.
     * 5. Undo pending changes on this test.
     */

    [TestClass]
    public class CreateEnvironmentFile
    {
        #region Test Context
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #endregion Test context

        #region Edit this region to your enviroment information
        //The URI for your TFS server Samples:  "http://curtisp-test:8080" , "http://tkbgitvstfat01:8080" 
        string masterServer = "curtisp-orcas";
        string dependentServer = "curtisp-whidbey";
      
        //The team project you want to use for testing. The team project must already exist. Samples: "ConvTest", "Orcas", "vstsDogFood"
        string masterProject = "MigrationTest";
        string dependentProject = "MigrationTest";
        
        //The name of the workspace to use for migration.  Samples: "migrationTestWorkspace", "curtisp"
        string workspaceName = "migrationTestWorkSpace";
        //The root directory of the workspace used for migration Samples: "D:\VisualStudio\migrationWorkspace", "D:\dd\tsadt"
        string workspaceRoot = @"C:\workspaces\migrationTestWorkspace";

        //The name of the computer that has the SQL server for migration Smaples: "curtisp-test", "tkbgitvstfdt01"
        string sqlServer = "curtisp-orcas";

        //The URL of the WSS site to migrate Samples: "http://curtisp-test", "http://dev-div"
        string wssUrl = "http://curitsp-orcas";
        //The document library of the WSS site to migrate Samples: "testLib", "Shared Documents"
        string wssDocumentLibrary = "testlib";
        //The timezone of the WSS site to migrate Samples: "GMT -5:00", "GMT -8:00"
        string wssTimeZone = "GMT -5:00";
        //The machine which is running WSS, and TagRunner -Listen Sample "curtisp-test"
        string wssMachine = "curtisp-orcas";
        // the valid Wss user name (display name), not alias
        string wssUser = "Curtis Pettit";
        #endregion


        /** Editing this file for a new schema
         * 1. Add variables for the inforation you want to specify in the above region with comments
         *  Sample: //The server of other
         *          string otherServer = "";
         * 2. If your adding a node to the schema add it under the declaration of WSS node
         *  Sample: XmlElement otherNode = doc.CreateElement("Other");
         * 
         * 3. Wrap the setting of the attributes in if (!String.IsNullOrEmpty(tfsServer)) so if the variable wasn't set; it wont be added to the environment file
         *  Sample:  if (!String.IsNullOrEmpty(tfsServer))
         *           {
         *              otherNode.SetAttribute("server", tfsServer);
         *           }
         * 4. Append the new node to the enviromentNode before the document is written
         *  Sample: environmentNode.AppendChild(otherNode);
         * 
         * 5. Send a mail to migtool when you checkin stating that new information has been added to the environment file and they need to edit the file or regenerate it.
         */
        [TestMethod]
        public void RunCreateEnvironmentFile()
        {
            XmlDocument doc = new XmlDocument();

            XmlElement environmentNode = doc.CreateElement("Environment");
            XmlElement tfsNode = doc.CreateElement("TFS");
            XmlElement sqlNode = doc.CreateElement("SQL");
            XmlElement wssNode = doc.CreateElement("WSS");

            //New nodes go here
            XmlElement node = doc.CreateElement("Master");

            if (!String.IsNullOrEmpty(masterServer))
            {
                node.SetAttribute("server", masterServer);
            }
            if (!String.IsNullOrEmpty(masterProject))
            {
                node.SetAttribute("teamProject", masterProject);
            }
            if (!String.IsNullOrEmpty(workspaceName))
            {
                node.SetAttribute("workspace", workspaceName);
            }
            if (!String.IsNullOrEmpty(workspaceRoot))
            {
                node.SetAttribute("workspaceRoot", workspaceRoot);
            }

            tfsNode.AppendChild(node);

            node = doc.CreateElement("Dependent");

            if (!String.IsNullOrEmpty(dependentServer))
            {
                node.SetAttribute("server", dependentServer);
            }
            if (!String.IsNullOrEmpty(dependentProject))
            {
                node.SetAttribute("teamProject", dependentProject);
            }
            if (!String.IsNullOrEmpty(workspaceName))
            {
                node.SetAttribute("workspace", workspaceName);
            }
            if (!String.IsNullOrEmpty(workspaceRoot))
            {
                node.SetAttribute("workspaceRoot", workspaceRoot);
            }

            tfsNode.AppendChild(node);

            node = doc.CreateElement("WssAdaptor");

            if (!String.IsNullOrEmpty(wssUser))
            {
                node.SetAttribute("wssUser", wssUser);
            }
            tfsNode.AppendChild(node);

            if (!String.IsNullOrEmpty(sqlServer))
            {
                sqlNode.SetAttribute("server", sqlServer);
            }

            if (!String.IsNullOrEmpty(wssUrl))
            {
                wssNode.SetAttribute("url", wssUrl);
            }
            if (!String.IsNullOrEmpty(wssDocumentLibrary))
            {
                wssNode.SetAttribute("library", wssDocumentLibrary);
            }
            if (!String.IsNullOrEmpty(wssTimeZone))
            {
                wssNode.SetAttribute("gmt", wssTimeZone);
            }
            if (!String.IsNullOrEmpty(wssTimeZone))
            {
                wssNode.SetAttribute("machine", wssMachine);
            }

            //new nodes attributes go here

            doc.AppendChild(environmentNode);
            environmentNode.AppendChild(tfsNode);
            environmentNode.AppendChild(sqlNode);
            environmentNode.AppendChild(wssNode);
            //append the new node to environment node here

            //Navigate from the working directory up to the solution diretory; which will always be the same.
            string fileName = Directory.GetParent(TestContext.TestDeploymentDir).Parent.Parent.FullName + "\\MigrationTestEnvironment.xml";
            using (XmlTextWriter writer = new XmlTextWriter(fileName, null))
            {
                writer.Formatting = Formatting.Indented;
                doc.WriteTo(writer);
            }
        }
    }
}
