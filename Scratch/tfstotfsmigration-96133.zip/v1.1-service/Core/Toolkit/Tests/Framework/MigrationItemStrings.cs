using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Tests.Framework;

namespace Tests.Framework
{
    public class MigrationItemStrings
    {
        private string name;
        private string localPath;
        private string uri;
        private string serverPath;
        private string newName;
        private string newLocalPath;
        private string newUri;
        private string newServerPath;

        public string Name
        {
            get { return name; }
        }

        public string LocalPath
        {
            get { return localPath; }
        }

        public string Uri
        {
            get { return uri; }
        }

        public string ServerPath
        {
            get { return serverPath; }
        }

        public string NewName
        {
            get { return newName; }
        }

        public string NewLocalPath
        {
            get { return newLocalPath; }
        }

        public string NewUri
        {
            get { return newUri; }
        }

        public string NewServerPath
        {
            get { return newServerPath; }
        }

        /// <summary>
        /// Encapsulates all the paths for one item (file or folder) in a migration 
        /// </summary>
        /// <param name="itemName">The Desired itemName</param>
        /// <param name="newItemName">Item name after a namespace change (rename, branch)</param>
        /// <param name="TestcaseName">The name of the testcase this item is migrated in</param>
        /// <param name="ConfigParameters">Wrapper for the MigrationConfiguration file</param>
        /// <param name="useSource">Determines if the paths should be based on the source of the mapping(tfs2tfs) or the target(wss2tfs)</param>
        public MigrationItemStrings(string itemName, string newItemName, string TestcaseName, ConfigParameters ConfigParameters, bool useSource)
        {
            if (useSource)
            {
                setStrings(itemName, newItemName, TestcaseName, ConfigParameters.VersionControl.Sessions[0].Mappings[0].Source, Path.Combine(TestUtils.TextReportRoot, "dependent/"));
            }
            else
            {
                setStrings(itemName, newItemName, TestcaseName, ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target, Path.Combine(TestUtils.TextReportRoot, "master/"));
            }
        }

        /// <summary>
        /// Sets the private strings for this migration Item
        /// </summary>
        /// <param name="itemName">The Desired itemName</param>
        /// <param name="newItemName">Item name after a namespace change (rename, branch)</param>
        /// <param name="TestcaseName">The name of the testcase this item is migrated in</param>
        /// <param name="serverRoot">The path on the server where this item will be added</param>
        /// <param name="localRoot">The path on the hardrive where this item will be added</param>
        private void setStrings(string itemName, string newItemName, string testcaseName, string serverRoot, string localRoot)
        {
            name = itemName;
            localPath = Path.Combine(localRoot, itemName).Replace('/', '\\');
            uri = string.Format(CommonStrings.WSSFileUrl, TestEnvironment.WssMachine, testcaseName, itemName).Replace('\\', '/');
            serverPath = string.Format(CommonStrings.UrlCombine, serverRoot, itemName);

            if (newItemName != null)
            {
                newName = newItemName;
                newLocalPath = Path.Combine(localRoot, NewName).Replace('/', '\\');
                newUri = string.Format(CommonStrings.WSSFileUrl, TestEnvironment.WssMachine, testcaseName, NewName).Replace('\\', '/');
                newServerPath = string.Format(CommonStrings.UrlCombine, serverRoot, NewName);
            }
        }


        /// <summary>
        /// Encapsulates all the paths for one item (file or folder) in a (WSS2TFS) migration 
        /// </summary>
        /// <param name="itemName">The Desired itemName</param>
        /// <param name="newItemName">Item name after a namespace change (rename, branch)</param>
        /// <param name="TestcaseName">The name of the testcase this item is migrated in</param>
        /// <param name="ConfigParameters">Wrapper for the MigrationConfiguration file</param>
        /// <param name="useSource">Determines if the paths should be based on the source of the mapping(tfs2tfs) or that target(wss2tfs)</param>
        public MigrationItemStrings(string itemName, string newItemName, string testcaseName, ConfigParameters configParameters)
            : this(itemName, newItemName, testcaseName, configParameters, false)
        {
        }
    }
}
