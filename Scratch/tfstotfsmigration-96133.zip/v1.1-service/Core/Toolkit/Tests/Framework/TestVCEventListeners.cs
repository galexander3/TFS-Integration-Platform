using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;
using System.Diagnostics;
using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Tests.Framework
{
    public class TestVCEventListeners
    {
        public bool batchedItemError;
        public bool mergeItemError;
        public bool beforeUpdate;
        public string shevlesetName;

        public TestVCEventListeners()
        {
            Reset();
        }

        public virtual void BatchedItemError(object sender, BatchedItemEventArgs e)
        {
            batchedItemError = true;
            Trace.TraceError(e.ToString());
        }

        public virtual void MergeItemError(object sender, BatchedMergeErrorEventArgs e)
        {
            mergeItemError = true;
            Trace.TraceError(e.ToString());
        }

        public virtual void OnBeforeUpdate(object sender, HighWaterMarkUpdatedEventArgs<string> e)
        {
            beforeUpdate = true;
            Trace.TraceInformation(e.ToString());
        }

        public virtual void GetConflictShevleSet(object sender, MigrationEventArgs e)
        {
            shevlesetName = e.Description.Replace("Conflicts shelved in ",string.Empty);
        }


        internal void Reset()
        {
            batchedItemError = false;
            mergeItemError = false;
            beforeUpdate = false;
            shevlesetName = null;
        }
    }
}
