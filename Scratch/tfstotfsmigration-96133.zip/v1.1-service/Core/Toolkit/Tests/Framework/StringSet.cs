// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace System.Collections.Specialized
{
    public class StringSet : StringCollection
    {

        new public int Add(String toAdd)
        {
            if (!this.Contains(toAdd))
            {
                return base.Add(toAdd);
            }
            else
            {
                return 0;
            }
        }
    }
}
