// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    
    public class TestEventSink : IMigrationSessionEventSink
    { 
        IMigrationSession session;

        public void Dispose()
        {

        }

        public int[] counter;
        private MigrationEventArgs expected;

        public enum VersionControlEvents { 
            SessionAborted, SessionComplete, SessionPaused, SessionResumed,
            SessionStart,SessionError,AnalysisAborted,AnalysisComplete,AnalysisError,
            AnalysisPaused, AnalysisResumed,AnalyzingChangeComplete, 
            AnalyzingChangeStarting,BeforeAnalysis,BeforeMigration,
            MigratingChangeComplete, MigratingChangeStarting, MigrationAborted,
            MigrationComplete, MigrationError, MigrationPaused, MigrationResumed
        };

        public TestEventSink(MigrationEventArgs expected)
        {
            this.expected = expected;
        }

        public void verifyEventArgs(MigrationEventArgs actual)
        {
            Assert.IsTrue(object.ReferenceEquals(actual.GetType(), expected.GetType()), "Different event types!");

            Assert.AreEqual(expected.Description, actual.Description, "Description Does not match");
            Assert.AreEqual(expected.Exception, actual.Exception, "Exception Does not match");

            if (actual is MigrationSessionEventArgs)
            {
                MigrationSessionEventArgs a = (MigrationSessionEventArgs)actual;
                MigrationSessionEventArgs e = (MigrationSessionEventArgs)expected;

                Assert.AreEqual(e.MigratedItemCount, a.MigratedItemCount, "MigratedItemCount Does not match");
                Assert.AreEqual(e.FailedItemCount, a.FailedItemCount, "FailedItemCount Does not match");
            }
            else if (actual is VersionControlEventArgs)
            {
                VersionControlEventArgs a = (VersionControlEventArgs)actual;
                VersionControlEventArgs e = (VersionControlEventArgs)expected;

                //$TODO: implement
            }
            else
            {
                Assert.Fail("Unsupported event type!");
            }
        }

        public virtual void RegisterSession(IMigrationSession session)
        {
            counter = new int [22];
            if (session == null)
            {
                throw new ArgumentNullException("session");
            }
            //0
            session.SessionAborted += new EventHandler<MigrationSessionEventArgs>(SessionAbort);
            //1
            session.SessionComplete += new EventHandler<MigrationSessionEventArgs>(SessionCompleted);
            //2
            session.SessionStart += new EventHandler<MigrationSessionEventArgs>(SessionStart);
            //3
            session.SessionError += new EventHandler<MigrationSessionEventArgs>(SessionError);

            VersionControlSession vcSession = session as VersionControlSession;
            if (vcSession != null)
            {
                registerVCSession(vcSession);
            }
        }

        public void registerVCSession(IVersionControlSession vcSession)
        {
            this.session = vcSession;
            //6
            vcSession.AnalysisAborted += new EventHandler<VersionControlEventArgs>(AnalysisAborted);
            //7
            vcSession.AnalysisComplete += new EventHandler<VersionControlEventArgs>(AnalysisComplete);
            //8
            vcSession.AnalysisError += new EventHandler<VersionControlEventArgs>(AnalysisError);
            //9
            vcSession.AnalyzingChangeComplete += new EventHandler<VersionControlEventArgs>(AnalyzingChangeComplete);
            //12
            vcSession.AnalyzingChangeStarting += new EventHandler<VersionControlEventArgs>(AnalyzingChangeStarting);
            //13
            vcSession.AnalysisStarting += new EventHandler<VersionControlEventArgs>(beforeAnalysis);
            //14
            vcSession.MigrationStarting += new EventHandler<VersionControlEventArgs>(BeforeMigration);
            //15
            vcSession.MigratingChangeComplete += new EventHandler<VersionControlEventArgs>(MigratingChangeComplete);
            //16
            vcSession.MigratingChangeStarting += new EventHandler<VersionControlEventArgs>(MigratingChangeStarting);
            //17
            vcSession.MigrationAborted += new EventHandler<VersionControlEventArgs>(MigrationAborted);
            //18
            vcSession.MigrationComplete += new EventHandler<VersionControlEventArgs>(MigrationComplete);
            //19
            vcSession.MigrationError += new EventHandler<VersionControlEventArgs>(MigrationError);
        }

        #region event handelers
        private void MigrationPaused(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.MigrationPaused]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void MigrationResumed(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.MigrationResumed]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void MigratingChangeComplete(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.MigratingChangeComplete]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void MigratingChangeStarting(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.MigratingChangeStarting]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void MigrationAborted(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.MigrationAborted]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void MigrationComplete(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.MigrationComplete]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void MigrationError(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.MigrationError]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void AnalyzingChangeComplete(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.AnalyzingChangeComplete]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void AnalyzingChangeStarting(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.AnalyzingChangeStarting]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }
                
        private void AnalysisResumed (object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.AnalysisResumed]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void BeforeMigration (object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.BeforeMigration]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void AnalysisPaused(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.AnalysisPaused]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void AnalysisError(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.AnalysisError]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void AnalysisComplete(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.AnalysisComplete]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void beforeAnalysis(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.BeforeAnalysis]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void AnalysisAborted(object sender, MigrationEventArgs e)
        {
            counter[(int)VersionControlEvents.AnalysisAborted]++;
            verifyEventArgs((VersionControlEventArgs)e);
        }

        private void SessionStart(object sender, MigrationSessionEventArgs e)
        {
            counter[(int)VersionControlEvents.SessionStart]++;
        }

        private void SessionPaused(object sender, MigrationSessionEventArgs e)
        {
            counter[(int)VersionControlEvents.SessionPaused]++;
        }

        private void SessionAbort(object sender, MigrationSessionEventArgs e)
        {
            counter[(int)VersionControlEvents.SessionAborted]++;
        }

        private void SessionError(object sender, MigrationSessionEventArgs e)
        {
            counter[(int)VersionControlEvents.SessionError]++;
        }

        private void SessionResumed(object sender, MigrationSessionEventArgs e)
        {
            counter[(int)VersionControlEvents.SessionResumed]++;
        }

        private void SessionCompleted(object sender, MigrationSessionEventArgs e)
        {
            counter[(int)VersionControlEvents.SessionComplete]++;
        }

        private void SessionEvent(object sender, MigrationSessionEventArgs e)
        {
            throw new Exception("Unrecongized Event fired");
        }
        #endregion
    }
    
}
