// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Xml;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tests.Framework;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.VersionControl.Client;
using System.Diagnostics;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;

namespace Tests.Framework
{
    /**
     * This is the class from which all tests should ultimatly inherit.
     * it contains the TestContext The Team test object which gives information about the test cases
     * 
     * The Initialize method which creates the default configParameters and uses it to generate a defualt configFile
     * The Cleanup() method disposes the MigrationConfiguration and deletes any reports left in the text report root. 
     * 
     * Both are virtual so that the testcase can override them with addtional behavior. But the overriding methods hsould always call the base method
     */
    public abstract class MigrationTestCaseBase
    {
        protected const string AddComment = "Migration Test add"; //The comment for Add checkins
        protected const string BranchComment = "Migration test Branch"; //The comment for branch checkins
        protected const string CleanUpComment = "Migration Test Cleanup"; //The comment for clean up check ins 
        protected const string DeleteComment = "Migration Test delete"; //The comment for delete checkins
        protected const string EditComment = "Migration test Edit"; //The comment for edit checkins
        protected const string UndeleteComment = "Migration Test undelete"; //The comment for undelete checkins
        protected const string MergeComment = "Migration test Merge"; //The comment for merge checkins
        protected const string MultiActionComment = "Migration Test multi action"; //The comment for checkins with multiple pending changes.
        protected const string RenameComment = "Migration Test rename"; //The comment for rename checkins; that are not used in WSS

        protected const string testWorkspace = "testWorkspace";
        private TeamFoundationServer tfsServer;
        private VersionControlServer tfsClient;
        protected string configFileName;
        protected XmlDocument doc;
        protected ConfigFile configFile;
        private ConfigParameters configParameters;
        private TestContext testContextInstance;
        private Workspace masterWorkspace;

        protected virtual Workspace Workspace
        {
            get { return MasterWorkspace; }
        }

        protected Workspace MasterWorkspace
        {
            get
            {
                if (masterWorkspace == null)
                {
                    try
                    {
                        //This call should throw an excepetion; because the cleanup should have gotten rid of this
                        masterWorkspace = MasterTfsClient.GetWorkspace(testWorkspace, Environment.UserName);
                        //If it doesnt run the clean up now; before the rest of the testcase.
                        CleanUpWorkspace(tfsClient, masterWorkspace);
                    }
                    catch (WorkspaceNotFoundException) {/*were good*/ }
                    //because we checked before, now were practically guaranteed this call will be successful
                    masterWorkspace = MasterTfsClient.CreateWorkspace(testWorkspace, Environment.UserName);

                    masterWorkspace.Map(ConfigParameters.VersionControl.Sessions[0].Mappings[0].Target, Path.Combine(TestUtils.TextReportRoot, "master/"));
                }
                return masterWorkspace;
            }
        }

        public VersionControlSession CreateVcWssSession
        {
            get
            {
                ConfigFile.WriteAndLoad(ConfigParameters);
                return MigrationConfiguration.Current.VC.Sessions["VCSession1"];
            }
        }

        protected TeamFoundationServer MasterTfsServer
        {
            get
            {
                if (tfsServer == null)
                {
                    tfsServer = TeamFoundationServerFactory.GetServer(TestEnvironment.MasterServer);
                }
                return tfsServer;
            }
        }

        protected VersionControlServer MasterTfsClient
        {
            get
            {
                if (tfsClient == null)
                {
                    tfsClient = (VersionControlServer)MasterTfsServer.GetService(typeof(VersionControlServer));
                }
                return tfsClient;
            }
        }

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        protected ConfigParameters ConfigParameters
        {
            get
            {
                if (configParameters == null)
                {
                    configParameters = new ConfigParameters(TestContext.TestName);
                }
                return configParameters;
            }
        }

        [TestInitialize]
        public virtual void Initialize()
        {

            TestEnvironment.Load();
        }

        [TestCleanup]
        public virtual void Cleanup()
        {
            CleanUpTfs(ConfigParameters.MasterTfsPath.Remove(ConfigParameters.MasterTfsPath.LastIndexOf('/')), masterWorkspace);
            CleanUpWorkspace(tfsClient, MasterWorkspace);

            configParameters = null;

            disposeMigrationConfiguration();

            if (Directory.Exists(TestUtils.TextReportRoot))
            {
                TestUtils.DeleteDirectory(TestUtils.TextReportRoot);
            }

            SqlUtil.DropDB(TestEnvironment.SqlServer, TestContext.TestName);
        }

        protected static void disposeMigrationConfiguration()
        {
            if (MigrationConfiguration.Current != null)
            {
                if (MigrationConfiguration.Current.VC != null)
                {

                    foreach (VersionControlSession session in MigrationConfiguration.Current.VC.Sessions.Values)
                    {
                        session.Stop();
                        session.Dispose();
                    }
                    MigrationConfiguration.Current.VC.Dispose();
                }

                if (MigrationConfiguration.Current.Wit != null)
                {
                    foreach (WorkItemTrackingSession session in MigrationConfiguration.Current.Wit.Sessions.Values)
                    {
                        session.Dispose();
                    }
                    MigrationConfiguration.Current.Wit.Dispose();
                }

                MigrationConfiguration.Current.Dispose();
            }
        }

        protected void CleanUpWorkspace(VersionControlServer server, Workspace workspace)
        {
            if (server != null)
            {
                try
                {
                    server.GetWorkspace(workspace.Name, Environment.UserName);
                    server.DeleteWorkspace(workspace.Name, Environment.UserName);
                }
                catch (WorkspaceNotFoundException)
                {
                    Trace.TraceInformation("Cleanup could not find the test workspace {0}.", workspace.Name);
                }
            }
        }

        protected void CleanUpTfs(string path, Workspace workspace)
        {
            //Theres no point in trying to cleanup after a test that did not try to add anything
            if (workspace != null)
            {
                try
                {
                    PendingChange[] changes = workspace.GetPendingChanges();
                    if (changes.Length > 0)
                    {
                        workspace.Undo(changes);
                    }
                    //This will only work as long as we only need one mapping. 
                    workspace.PendDelete(path);
                    changes = workspace.GetPendingChanges();
                    if (changes.Length > 0)
                    {
                        workspace.CheckIn(changes, CleanUpComment);
                    }
                    else
                    {
                        Trace.TraceInformation("There was nothing to cleanup in TFS.");
                    }
                }
                catch (Exception e)
                {
                    Trace.TraceError("There was an Exception when trying to cleanup in TFS.  {0}", e.ToString());
                }
            }
        }

        #region Population Helper methods
        protected int AddTFSFile(string localPath)
        {
            TestUtils.CreateRandomFile(localPath, 10);

            Workspace.PendAdd(localPath);
            return Workspace.CheckIn(Workspace.GetPendingChanges(), AddComment);
        }

        protected int AddTFSFolder(string localPath)
        {
            Directory.CreateDirectory(localPath);

            Workspace.PendAdd(localPath);
            return Workspace.CheckIn(Workspace.GetPendingChanges(), AddComment);
        }

        protected int EditTFSFile(string localPath)
        {
            Workspace.Get(VersionSpec.Latest, GetOptions.Overwrite);
            TestUtils.EditRandomFile(localPath);
            Workspace.PendEdit(localPath);
            return Workspace.CheckIn(Workspace.GetPendingChanges(), EditComment);
        }

        protected int RenameTFSItem(string oldServerPath, string newServerPath, string comment)
        {
            Workspace.Get(VersionSpec.Latest, GetOptions.Overwrite);
            Workspace.PendRename(oldServerPath, newServerPath);
            return Workspace.CheckIn(Workspace.GetPendingChanges(), comment);
        }

        protected int BranchTFSItem(string source, string target)
        {
            Workspace.Get(VersionSpec.Latest, GetOptions.Overwrite);
            Workspace.PendBranch(source, target, VersionSpec.Latest);
            return Workspace.CheckIn(Workspace.GetPendingChanges(), BranchComment);
        }

        protected void UndeleteTFSFile(string serverPath, int changesetId)
        {
            Item item = MasterTfsClient.GetChangeset(changesetId).Changes[0].Item;
            Workspace.Get();
            Workspace.PendUndelete(serverPath, item.DeletionId);
            Workspace.CheckIn(Workspace.GetPendingChanges(), UndeleteComment);
        }

        protected int DeleteTFSItem(string serverPath)
        {
            Workspace.PendDelete(serverPath);
            return Workspace.CheckIn(Workspace.GetPendingChanges(), DeleteComment);
        }

        protected int MergeTFSItem(MigrationItemStrings mergeItem, int mergeFromChangeset)
        {
            Workspace.Merge(mergeItem.ServerPath, mergeItem.NewServerPath, VersionSpec.ParseSingleSpec(mergeFromChangeset.ToString(), Environment.UserName), VersionSpec.Latest, LockLevel.None, RecursionType.Full, MergeOptions.None);
            return Workspace.CheckIn(Workspace.GetPendingChanges(), MergeComment);
        }

        #endregion

        protected ChangeGrouping CreateChangeGroup(ChangeGroupingMananger manager)
        {
            return CreateChangeGroup(manager, string.Empty);
        }

        protected ChangeGrouping CreateChangeGroup(ChangeGroupingMananger manager, string name)
        {
            ChangeGrouping group = manager.Create(name);
            group.SessionId = manager.Session.Id;
            group.Owner = "testuser";
            group.Status = ChangeStatus.Analysis;
            group.ChangeTimeUtc = DateTime.Now;
            group.Comment = string.Empty;
            return group;
        }
    }
}