// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Xml;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Framework
{
    public class ConfigManagerTestCaseBase :MigrationTestCaseBase
    {
        [TestInitialize]
        public override void Initialize()
        {
            configFileName = TestContext.TestName + ".xml";
            configFile = new ConfigFile(configFileName);

            doc = configFile.Doc;
        }

        protected void validateSessionAttributes(VersionControlSession session, XmlNode sessionNode)
        {
            //validate Id
            Assert.AreEqual(sessionNode.Attributes["id"].InnerText, session.Id, "Session ID's dont match");
            Assert.AreEqual(sessionNode.Attributes["provider"].InnerText, session.ProviderId, String.Format("Incorrect provider used in session {0}", session.Id));
        }

        protected void expectInitilizationException(string message)
        {
            try
            {
                configFile.WriteAndLoad();
                Assert.Fail("Migration Exception was not thrown");
            }
            catch (InitializationException e)
            {
                //This exception is expected.
                Assert.IsTrue(e.StackTrace.Contains("at Microsoft.TeamFoundation.Migration.Toolkit.VersionControlConfiguration.LoadVCSession(XPathNavigator xml)"), "Exception Did not come from the right place");
                Assert.AreEqual(message, e.Message);
            }
        }
    }
}
