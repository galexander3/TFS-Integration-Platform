// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Migration.VersionControl.Wss;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;
using Microsoft.TeamFoundation;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Teamfoundation.Migration.VersionControl.SharePoint.Lists;
using System.IO;
using Microsoft.Teamfoundation.Migration.VersionControl.SharePoint.Versions;
using System.Security.Cryptography;
using System.Diagnostics;

namespace Tests.Framework
{
    public class WSS2TFSVerification
    {
        #region Helper Methods
        /// <summary>
        /// Exposes the Versions WSDL to the test cases
        /// </summary>
        /// <param name="session">The session the version was migrated in</param>
        /// <param name="canonicalUrl">the URL for the file to ge the versions of</param>
        /// <returns>The webservice object for the URL passed in</returns>
        public static Versions GetVersions(VersionControlSession session, string canonicalUrl)
        {
            return Util.GetVersionsServiceForUrl(canonicalUrl, session);
        }

        /// <summary>
        /// Encapsulates the webservice calls to WSS to get a list of Items for a document libarary
        /// </summary>
        /// <param name="session">The session the Document library was migrated in</param>
        /// <returns>A list of files in the WSS document library</returns>
        public static List<ListItemInfo> GetWSSItems(VersionControlSession session)
        {
            List<ListItemInfo> items = new List<ListItemInfo>();
            Lists l = new Lists(((WssProvider)session.Source).BaseUrl);
            l.UseDefaultCredentials = true;
            WSSListEnumerator enumerator = new WSSListEnumerator(((WssProvider)session.Source).DocumentLibrary);

            //Load the "tip" revision of everything in WSS  as a XML Tree
            XmlNode node = l.GetListItems(((WssProvider)session.Source).DocumentLibrary, null, null, WSSListEnumerator.getViewFields(), null, WSSListEnumerator.getQueryOptions(null));

            //Create a list of the items so that we can query the history of each item.
            XmlSerializer xs = new XmlSerializer(typeof(listitems));
            listitems li = (listitems)xs.Deserialize(new StringReader(node.OuterXml));

            if (li.Items[0].row != null)
            {
                foreach (row row in li.Items[0].row)
                {
                    items.Add(new ListItemInfo(row, ((Session)session).Culture));
                }
            }
            return items;
        }

        /// <summary>
        /// Reduce the server path the the imporantant part, from the documentlibrary on
        /// </summary>
        /// <param name="path">Server path to normalize</param>
        /// <param name="session">The VersionControlSession which the item was migrated by.</param>
        /// <returns>Important part of the file path</returns>
        public static string Normalize(string path, VersionControlSession session)
        {
            return path.Substring(path.IndexOf(((WssProvider)session.Source).DocumentLibrary));
        }
        #endregion

        #region Diff the servers
        /// <summary>
        /// Compares the history in TFS to that in Wss and removes all entries that are matching or not migration candidates.
        /// Such that after this method is run the contents of tfsHistory is the versions that failed to migrate to WSS
        /// and the contents of wssHistory is the versions that fialed to migrate to TFS
        /// </summary>
        /// <param name="tfsHistory">Tfs migration history</param>
        /// <param name="wssHistory">Wss migraiton history</param>
        /// <param name="session">The session the history was migrated in</param>
        public static void RemoveSimilarMigrationHistory(Dictionary<string, List<HistoryVersion>> tfsHistory, Dictionary<string, List<HistoryVersion>> wssHistory, VersionControlSession session)
        {
            Trace.TraceInformation(String.Format("Started with {0} TFS Files and {1} WSS files", tfsHistory.Count, wssHistory.Count));

            //Iterate over each entry in the TFS history
            string[] keyCollection = new string[tfsHistory.Count];
            tfsHistory.Keys.CopyTo(keyCollection, 0);
            foreach (string key in keyCollection)
            {
                List<HistoryVersion> tfsItemHistory = tfsHistory[key];
                List<HistoryVersion> wssItemHistory = null;

                if (!wssHistory.TryGetValue(key, out wssItemHistory))
                {
                    Trace.TraceWarning(String.Format("Did not find a WSS item that matched {0}", key));
                    //The most common reason there wouldn't be a matching file in WSS is the case where its not a migration candidate
                    tfsItemHistory.RemoveAll(IsNotMigrationCandidate);
                    RemoveEmptyEntries(key, tfsHistory, wssHistory, tfsItemHistory, wssItemHistory);
                    continue;
                }

                RemoveSimilarTfsVersions(session, tfsItemHistory, wssItemHistory);

                RemoveEmptyEntries(key, tfsHistory, wssHistory, tfsItemHistory, wssItemHistory);

                // This is called after RemoveSimilarTfsVersions so we know that any versions that match should have been removed by that
                // Therefore we will only remove versions that were not migration candidates
                wssItemHistory.RemoveAll(IsNotMigrationCandidate);

                RemoveEmptyEntries(key, tfsHistory, wssHistory, tfsItemHistory, wssItemHistory);
            }

            TraceRemaining(tfsHistory, wssHistory);
        }

        /// <summary>
        /// Checks if all the history versions have been removed for a particular entry.
        /// If thats the case then the history entry is taken out of the dictionary.
        /// </summary>
        /// <param name="key">The file record to remove</param>
        /// <param name="tfsHistory">The TFS history dictionary</param>
        /// <param name="wssHistory">The WSS history dictionary</param>
        /// <param name="tfsItemHistory">The TFS file record </param>
        /// <param name="wssItemHistory">the WSS file record</param>
        private static void RemoveEmptyEntries(string key, Dictionary<string, List<HistoryVersion>> tfsHistory, Dictionary<string, List<HistoryVersion>> wssHistory, List<HistoryVersion> tfsItemHistory, List<HistoryVersion> wssItemHistory)
        {
            //If we emptied all the versions of a file we can remove it from the dictionary
            if (tfsItemHistory.Count == 0)
            {
                //It may be the case that the item was already removed; dont want to log the message twice.
                if (tfsHistory.Remove(key))
                {
                    Trace.TraceInformation(String.Format("The TFS item {0} has no more versions in the history. Removing it from the dictionary.", key));
                }
            }

            if (wssItemHistory != null)
            {
                if (wssItemHistory.Count == 0)
                {
                    //It may be the case that the item was already removed; dont want to log the message twice.
                    if (wssHistory.Remove(key))
                    {
                        Trace.TraceInformation(String.Format("The WSS item {0} has no more versions in the history. Removing it from the dictionary.", key));
                    }
                }
            }
        }

        /// <summary>
        /// Outputs some information on any file history left in the collections after RemoveSimilarMigraitonHistory has finished.
        /// </summary>
        /// <param name="tfsHistory">The TFS history dictionary</param>
        /// <param name="wssHistory">The WSS history dictionary</param>
        private static void TraceRemaining(Dictionary<string, List<HistoryVersion>> tfsHistory, Dictionary<string, List<HistoryVersion>> wssHistory)
        {
            Trace.TraceInformation(String.Format("TfsHistroy has {0} items left and wssHistory has {1} items left", tfsHistory.Count, wssHistory.Count));
            foreach (KeyValuePair<string, List<HistoryVersion>> tfsHistoryEntry in tfsHistory)
            {
                Trace.TraceInformation(String.Format("tfsHistroy has a record for {0}", tfsHistoryEntry.Key));
                foreach (HistoryVersion tfsVersion in tfsHistoryEntry.Value)
                {
                    Trace.TraceInformation(tfsVersion.ToString());
                }
            }

            foreach (KeyValuePair<string, List<HistoryVersion>> wssHistoryEntry in wssHistory)
            {
                Trace.TraceInformation(String.Format("wssHistroy has a record for {0}", wssHistoryEntry.Key));
                foreach (HistoryVersion wssVersion in wssHistoryEntry.Value)
                {
                    Trace.TraceInformation(wssVersion.ToString());
                }
            }
        }

        /// <summary>
        /// Looks at the list of versions in tfs, if they should have been migrated it tires to match it up to a version in WSS if it finds a match it that match from both lists. 
        /// If it should not have been migrated, it removes it from tfs.
        /// </summary>
        /// <param name="session">The session the history was migrated in</param>
        /// <param name="tfsItemHistory">A list of versions for an item in TFS</param>
        /// <param name="wssItemHistory">A list of versions for an item in WSS</param>
        private static void RemoveSimilarTfsVersions(VersionControlSession session, List<HistoryVersion> tfsItemHistory, List<HistoryVersion> wssItemHistory)
        {
            tfsItemHistory.RemoveAll(IsNotMigrationCandidate);

            for (int i = tfsItemHistory.Count - 1; i >= 0; i--)
            {
                HistoryVersion tfsVersion = tfsItemHistory[i];
                //this is a migration canidate we must search for its match in wssHistory
                foreach (HistoryVersion wssVersion in wssItemHistory)
                {

                    //Compare the rest of the data to ensure that this version was migrated properly
                    //TODO: Add UsersMatch, when its ready
                    //Cannot match names because a Rename changes the name of all the previous versions in WSS. So they will never match
                    if (CommentsMatch(tfsVersion, wssVersion) && ContentMatches(tfsVersion.Md5Sum, wssVersion.Md5Sum))
                    {
                        //if it was migrated properly remove the versions from both lists
                        Trace.TraceInformation(String.Format("TFS item: {0} and WSS item {1} match.  Removing them.", tfsVersion, wssVersion));
                        tfsItemHistory.Remove(tfsVersion);
                        wssItemHistory.Remove(wssVersion);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Compares the hash values for a file in tfs to a file in wss
        /// </summary>
        /// <param name="tfsMd5Sum">tfs hash</param>
        /// <param name="wssMd5Sum">wss hash</param>
        /// <returns>true if the files contents are the same</returns>
        public static bool ContentMatches(byte[] tfsMd5Sum, byte[] wssMd5Sum)
        {
            if (tfsMd5Sum.Length != wssMd5Sum.Length)
            {
                return false;
            }

            for (int i = 0; i < tfsMd5Sum.Length; i++)
            {
                if (tfsMd5Sum[i] != wssMd5Sum[i])
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Compares the user names used in migration
        /// </summary>
        /// <param name="tfsUser">user who made the checkin in tfs</param>
        /// <param name="wssUser">user who made the checkin in tfs</param>
        /// <param name="session">The session the history was migrated in</param>
        /// <returns>true if tfsUser maps to wssUser, false otherwise</returns>
        private static bool UsersMatch(string tfsUser, string wssUser, VersionControlSession session)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        /// <summary>
        /// Determines if the comment in tfsVersion matches the comment in the wssVersion, taking into account the changes to that the migration engine made
        /// </summary>
        /// <param name="tfsVersion">Version in tfs to check the comment of</param>
        /// <param name="wssVersion">Version in wss to check the comment of</param>
        /// <returns>true if the comments match; false otherwise</returns>
        public static bool CommentsMatch(HistoryVersion tfsVersion, HistoryVersion wssVersion)
        {
            //TODO: Add date matching when its ready
            string format = "{0} (Migrated by TFS Migration Toolkit)";

            string migratedToTFS = String.Format(format, wssVersion.Comment);
            string migratedFromTFS = String.Format(format, tfsVersion.Comment);

            if ((tfsVersion.Comment.StartsWith(migratedToTFS)) || (migratedFromTFS.StartsWith(wssVersion.Comment)))
            {
                return true;
            }
            return false;
        }
        #endregion Diff the servers

        #region Build the history objects

        /// <summary>
        /// Generate the migration history in tfs
        /// </summary>
        /// <param name="session">The session that the migration was done in</param>
        /// <returns>A Dictionary (string, List(HistoryVersion)) representation of the file history in Tfs</returns>
        public static Dictionary<string, List<HistoryVersion>> CreateTfsHistory(VersionControlSession session)
        {
            TeamFoundationServer tfsServer = TeamFoundationServerFactory.GetServer(MigrationConfiguration.TfsServers[session.Target.Server].Server);
            VersionControlServer tfsClient = (VersionControlServer)tfsServer.GetService(typeof(VersionControlServer));

            //Load the "tip" revision of everything in TFS as a list (pages)
            List<Item> items = new List<Item>();
            foreach (VersionControlMapping mapping in session.Mappings)
            {
                items.AddRange(RemoveCloaked(tfsClient.GetItems(mapping.Target, VersionSpec.Latest, RecursionType.Full, DeletedState.NonDeleted, ItemType.File).Items, session));
            }

            Dictionary<string, List<HistoryVersion>> tfsHistory = new Dictionary<string, List<HistoryVersion>>();

            //for each file in the team project add it to tfsHistory  
            foreach (Item item in items)
            {
                List<HistoryVersion> versions = new List<HistoryVersion>();

                //Get all the changesets
                //TODO:  This query seems to be returning changesets that are not associated with item. Investigate.
                System.Collections.IEnumerable changesets = tfsClient.QueryHistory(item.ServerItem, VersionSpec.Latest, 0, RecursionType.None, null, null, null, Int32.MaxValue, true, false);

                //Add all changesets to versions
                foreach (Changeset changeset in changesets)
                {
                    //TODO: Should this be wrapped with isMapped?
                    versions.Add(new HistoryVersion(changeset, item.ItemId, session));
                }

                tfsHistory.Add(Normalize(item.ServerItem, session), versions);
            }

            return tfsHistory;
        }

        /// <summary>
        /// Generate the migration history in wss
        /// </summary>
        /// <param name="session">The session that the migration was done in</param>
        /// <returns>A Dictionary (string, List(HistoryVersion)) representation of the file history in Wss</returns>
        public static Dictionary<string, List<HistoryVersion>> CreateWssHistory(VersionControlSession session)
        {
            Dictionary<string, List<HistoryVersion>> wssHistory = new Dictionary<string, List<HistoryVersion>>();

            List<ListItemInfo> items = GetWSSItems(session);

            //for each item load metadata about revision. 
            foreach (ListItemInfo item in items)
            {
                if ((IsMapped(item.FilePath, session)) && (item.FSObjType == 0)) //Only file history can be queried
                {
                    List<HistoryVersion> historyVersions = new List<HistoryVersion>();

                    string canonicalUrl = string.Format("{0}/{1}", ((WssProvider)session.Source).BaseUrl, Normalize(item.FilePath, session));

                    //Get all the changes 
                    Versions vers = GetVersions(session, canonicalUrl);
                    XmlNode versions = vers.GetVersions(canonicalUrl);

                    Document document = new Document(versions, CultureInfo.CurrentCulture);

                    foreach (DocumentVersion documentVersion in document.Versions)
                    {
                        historyVersions.Add(new HistoryVersion(documentVersion, session));
                    }

                    wssHistory.Add(Normalize(item.FilePath, session), historyVersions);
                }
            }
            return wssHistory;
        }

        /// <summary>
        /// Determines if this version should have been migrated.
        /// </summary>
        /// <param name="historyItem">The version to check</param>
        /// <returns>false if this version should have been migrated; true otherwise</returns>
        private static bool IsNotMigrationCandidate(HistoryVersion historyItem)
        {
            //check for wss forbidden file name
            //NOTE  '/'  is not allowed either; but that would be converterd into a folder, which is valid
            char[] forbiddenWssCharacters = { '~', '#', '%', '&', '*', '{', '}', '|', '\\', ':', '"', '<', '>', '?' };
            if (historyItem.Name.IndexOfAny(forbiddenWssCharacters) != -1)
            {
                Trace.TraceInformation(String.Format("{0} contains illegal WSS characters", historyItem.Name));
                return true;
            }

            //check if "thicket" file
            string[] thicketExtensions = new string[] { ".files", "_files", "-Dateien", "_fichiers", "_bestanden", "_file", "_archivos",
                "-filer", "_tiedostot", "_pliki", "_soubory", "_elemei", "_ficheiros", "_arquivos", "_dosyalar", "_datoteke", "_fitxers",
                "_failid", "_fails", "_bylos", "_fajlovi", "_fitxategiak" };

            foreach (string extension in thicketExtensions)
            {
                if (historyItem.Name.Contains(extension))
                {
                    Trace.TraceInformation(String.Format("{0} contains thicket extension {1}", historyItem.Name, extension));
                    return true;
                }
            }

            //check for ignore change comment
            if (historyItem.Comment.Contains("SkipChangeComment"))
            {
                Trace.TraceInformation(String.Format("The item {0} has the skip change comment", historyItem.Name));
                return true;
            }

            //check for path segment too long
            string[] folderArray = historyItem.Name.Split('/');
            foreach (string folder in folderArray)
            {
                if (folder.Length >= 128)
                {
                    return true;
                }
            }

            //Dot restriction
            int dotLocation = historyItem.Name.LastIndexOf('.');
            //want to ignore files that dont have a dot, and dont want to index before 0
            if (dotLocation > 1)
            {
                if (historyItem.Name[dotLocation - 1].Equals('.'))
                {
                    Trace.TraceInformation(String.Format("The item {0} has a dot preceding the extension", historyItem.Name));
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Determines if the path was mapped in the session
        /// </summary>
        /// <param name="serverPath">server path to check if it is mapped</param>
        /// <param name="session">session to look for mappings in</param>
        /// <returns>true if the server path was mapped in the session; false otherwise.</returns>
        public static bool IsMapped(string serverPath, VersionControlSession session)
        {
            serverPath = Normalize(serverPath, session);
            foreach (VersionControlMapping m in session.Mappings)
            {
                if ((TFStringComparer.VersionControlPath.StartsWith(serverPath, Normalize(m.Target, session))) || (serverPath.StartsWith(Normalize(m.Source, session))))
                {
                    if (!IsCloaked(serverPath, session))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Take a list of Versioned Items and remove the ones that are cloaked
        /// </summary>
        /// <param name="items">Array of Versioned Items</param>
        /// <param name="session">Session the items were migrated in</param>
        /// <returns>A list of Versioned Items that are not cloaked</returns>
        public static List<Item> RemoveCloaked(Item[] items, VersionControlSession session)
        {
            List<Item> returnList = new List<Item>();

            foreach (Item item in items)
            {
                if (!IsCloaked(item.ServerItem, session))
                {
                    returnList.Add(item);
                }
            }
            return returnList;
        }

        /// <summary>
        /// Determine if a server path is cloaked in a session
        /// </summary>
        /// <param name="serverPath">The path to check if it is cloaked</param>
        /// <param name="session">THe session the path may be cloaked for</param>
        /// <returns>True if the path is cloaked; false otherwise.</returns>
        private static bool IsCloaked(string serverPath, VersionControlSession session)
        {
            serverPath = Normalize(serverPath, session);
           

            foreach (VersionControlMapping mapping in session.Mappings)
            {
                //Make sure that these paths end with a slash so that ab/ is not the same as ab.txt
                string source = TestUtils.EnsureEndsWithSlash(Normalize(mapping.Source, session));
                string target = TestUtils.EnsureEndsWithSlash(Normalize(mapping.Target, session));
                if (mapping.Cloak)
                {
                    if (serverPath.StartsWith(source) || serverPath.StartsWith(target))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        #endregion Build history objects

    }

    /// <summary>
    /// This class represents a single version of a file in Tfs or Wss, containing all the information to determine if that version was migrated properly 
    /// </summary>
    public class HistoryVersion
    {

        private string user;
        private string comment;
        private string name;
        private byte[] md5Sum;
        private DateTime checkinTime;

        public string User
        {
            get { return user; }
        }

        public string Comment
        {
            get { return comment; }
        }

        public string Name
        {
            get { return name; }
        }

        public byte[] Md5Sum
        {
            get { return md5Sum; }
        }

        public DateTime CheckinTime
        {
            get { return checkinTime; }
        }

        public override string ToString()
        {
            return String.Format("Item name: {0}  Checked in by: {1} at time: {2} with the comment: {3}", Name, User, CheckinTime, Comment);
        }

        /// <summary>
        /// HistoryVersion Constructor for tfs
        /// </summary>
        /// <param name="changeset">The changeset that created this version</param>
        /// <param name="itemId">The id of the item this version is for</param>
        /// <param name="session">The session this version was migrated in</param>
        public HistoryVersion(Changeset changeset, int itemId, VersionControlSession session)
        {
            user = changeset.Owner;
            comment = changeset.Comment;
            checkinTime = changeset.CreationDate;

            Item item = FindCorrectItem(itemId, changeset.Changes);
            //Take only the important part of the name, from the documentLibrary on
            name = WSS2TFSVerification.Normalize(item.ServerItem, session);

            md5Sum = item.HashValue;
        }

        /// <summary>
        /// HistoryVersion consutrctor for Wss
        /// </summary>
        /// <param name="documentVersion">the DoucmentVersion for this version</param>
        /// <param name="session">The session this version was migrated in</param>
        public HistoryVersion(DocumentVersion documentVersion, VersionControlSession session)
        {
            user = documentVersion.CreatedBy;
            comment = documentVersion.Comment;
            checkinTime = documentVersion.Created;

            name = WSS2TFSVerification.Normalize(documentVersion.Url, session);

            //Download the item from WSS to calculate the md5Sum
            String localPath = Path.GetTempPath() + "wssHashFile";
            WssMigrationItem item = new WssMigrationItem(documentVersion.Url, documentVersion.Version);
            item.Session = session;
            item.DownloadUrl = documentVersion.Url;
            item.Download(localPath);

            using (FileStream fs = new FileStream(localPath, FileMode.Open))
            {
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
                md5Sum = md5.ComputeHash(fs);
            }
            File.Delete(localPath);
        }

        /// <summary>
        /// Finds the item that matches according to the itemId
        /// </summary>
        /// <param name="itemId">The item id to match</param>
        /// <param name="changes">the array of changes to look for the tiem</param>
        /// <returns>the item with itemId from changes</returns>
        private Item FindCorrectItem(int itemId, Change[] changes)
        {
            foreach (Change change in changes)
            {
                if (change.Item.ItemId == itemId)
                {
                    return change.Item;
                }
            }
            throw new Exception (String.Format("Could not find the item {0} in the changes given", itemId));
        }
    }
}