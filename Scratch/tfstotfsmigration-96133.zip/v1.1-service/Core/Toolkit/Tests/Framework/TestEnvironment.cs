// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;

namespace Tests.Framework
{
    /** Adding new information to the test environment
     * 
     * 1. Create the private variables  Sample: private static String otherServer;
     * 2. Use Refactor-> Encapulate field on the new private variables
     * 3. Add and if statement that will Assert.inconclusive if the value was not set 
     *      Sample:
     *              if (String.IsNullOrEmpty(otherServer))
                    {
                        Assert.Inconclusive(String.Format(assertMessage, "otherServer"));
                    }
     * 
     * 
     * 4. Move the field declarations to the Properties Region
     * 5. Set the new fields in Load() form the environment file  
     *   Sample: 
     *          node=environment.SelectSingleNode("Environment/OtherServer");
     *          OtherServer= node.GetAttribute("server");
     * 
     * 6. Make sure to update RunCreateEnvironment() in CreateEnvironment
     * 7. If the new variables will be used in the migration configuration file, update the ConfigParameters consturctor to use it
     * 
     */
    public class TestEnvironment
    {
        private static string assertMessage = "The variable {0} was expected in your environment file and not found";

        static bool assertInconclusive = true;

        private static string sqlServer;

        private static string masterServer;
        private static string dependentServer;

        private static string masterWorkspace;
        private static string dependentWorkspace;

        private static string masterWorkspaceRoot;
        private static string dependentWorkspaceRoot;

        private static string masterProject;
        private static string dependentProject;

        private static string tfsToTfsVCAdaptor;

        private static string wssUrl;
        private static string wssDocumentLibrary;
        private static string wssTimeZone;
        private static string wssMachine;
        private static string wssUser;

        private static string linkingWitSessionName;
        private static string linkingVcSessionName;

        //add new private variables here

        #region Properties

        //Move field declarations to here


        public static string SqlServer
        {
            get
            {
                if (String.IsNullOrEmpty(sqlServer))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "sqlServer"));
                }
                return TestEnvironment.sqlServer;
            }
        }


        public static string MasterServer
        {
            get
            {
                if (String.IsNullOrEmpty(masterServer))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "masterServer"));
                }
                return TestEnvironment.masterServer;
            }
        }

        public static string DependentServer
        {
            get
            {
                if (String.IsNullOrEmpty(dependentServer))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "dependentServer"));
                }
                return TestEnvironment.dependentServer;
            }
        }

        public static string MasterWorkspace
        {
            get
            {
                if (String.IsNullOrEmpty(masterWorkspace))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "masterWorkspace"));
                }
                return TestEnvironment.masterWorkspace;
            }
        }

        public static string DependentWorkspace
        {
            get
            {
                if (String.IsNullOrEmpty(dependentWorkspace))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "dependentWorkspace"));
                }
                return TestEnvironment.dependentWorkspace;
            }
        }

        public static string MasterWorkspaceRoot
        {
            get
            {
                if (String.IsNullOrEmpty(masterWorkspaceRoot))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "masterWorkspaceRoot"));
                }
                return TestEnvironment.masterWorkspaceRoot;
            }
        }

        public static string DependentWorkspaceRoot
        {
            get
            {
                if (String.IsNullOrEmpty(dependentWorkspaceRoot))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "dependentWorkspaceRoot"));
                }
                return TestEnvironment.dependentWorkspaceRoot;
            }
        }

        public static string MasterProject
        {
            get
            {
                if (String.IsNullOrEmpty(masterProject))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "masterProject"));
                }
                return TestEnvironment.masterProject;
            }
        }

        public static string DependentProject
        {
            get
            {
                if (String.IsNullOrEmpty(dependentProject))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "dependentProject"));
                }
                return TestEnvironment.dependentProject;
            }
        }

        public static string TfsToTfsVCAdaptor
        {
            get
            {
                if (String.IsNullOrEmpty(tfsToTfsVCAdaptor))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "tfsToTfsVCAdaptor"));
                }

                if (!File.Exists(tfsToTfsVCAdaptor))
                {
                    Assert.Inconclusive("The Tfs VC adaptor file was not found at {0}, please use specify the correct locaiton in you environmentfile", tfsToTfsVCAdaptor);
                }
                return TestEnvironment.tfsToTfsVCAdaptor;
            }
        }
        
        public static string WssUser
        {
            get
            {
                if (String.IsNullOrEmpty(wssUser))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "wssUser"));
                }
                return TestEnvironment.wssUser;
            }
        }


        public static string WssUrl
        {
            get
            {
                if (String.IsNullOrEmpty(wssUrl))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "wssUrl"));
                }
                return TestEnvironment.wssUrl;
            }
        }

        public static string WssDocumentLibrary
        {
            get
            {
                if (String.IsNullOrEmpty(wssDocumentLibrary))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "wssDocumentLibrary"));
                }
                return TestEnvironment.wssDocumentLibrary;
            }
        }

        public static string WssTimeZone
        {
            get
            {
                if (String.IsNullOrEmpty(wssTimeZone))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "wssTimeZone"));
                }
                return TestEnvironment.wssTimeZone;
            }
        }


        public static string WssMachine
        {
            get
            {
                if (String.IsNullOrEmpty(wssMachine))
                {
                    Assert.Inconclusive(String.Format(assertMessage, "wssMachine"));
                }
                return TestEnvironment.wssMachine;
            }
        }

        public static string LinkingWitSessionName
        {
            get
            {
                return TestEnvironment.linkingWitSessionName;
            }
        }

        public static string LinkingVcSessionName
        {
            get
            {
                return TestEnvironment.linkingVcSessionName;
            }
        }

        #endregion Properties

        /**
         * This is the method that loads enviroment data from the enviroment file
         * if the environment file could not be found it will assert.Inconclusive.
         * After this is mehtod is sucessfully called all the enviroment information is available to the test cases through the public static fields
         */
        public static void Load()
        {
            XmlDocument environment = new XmlDocument();

            string fileLocation = Environment.GetEnvironmentVariable("MigrationEnvironment");
            if (!String.IsNullOrEmpty(fileLocation))
            {
                environment.Load(fileLocation);
            }
            else
            {
                try
                {
                    environment.Load("MigrationTestEnvironment.xml");
                }
                catch (FileNotFoundException)
                {
                    Assert.Inconclusive("The envrionment file was not found. Create an envrionment file in your solution directory, or point envrioment variable MigrationEnvrionment to it.  See the directions at the top of CreateEnvrionmentFile.cs for help.");
                }
            }

            XmlElement node = (XmlElement)environment.SelectSingleNode("Environment/SQL");
            sqlServer = node.GetAttribute("server");

            node = (XmlElement)environment.SelectSingleNode("Environment/TFS/Master");
            masterServer = node.GetAttribute("server");
            masterWorkspace = node.GetAttribute("workspace");
            masterWorkspaceRoot = node.GetAttribute("workspaceRoot");
            masterProject = node.GetAttribute("teamProject");

            node = (XmlElement)environment.SelectSingleNode("Environment/TFS/Dependent");
            dependentServer = node.GetAttribute("server");
            dependentWorkspace = node.GetAttribute("workspace");
            dependentWorkspaceRoot = node.GetAttribute("workspaceRoot");
            dependentProject = node.GetAttribute("teamProject");

            node = (XmlElement)environment.SelectSingleNode("Environment/TFS/WssAdaptor");
            wssUser = node.GetAttribute("wssUser");

            node = (XmlElement)environment.SelectSingleNode("Environment/TFS/TfsToTfsVCAdaptor");
            if (node != null)
            {
                tfsToTfsVCAdaptor = node.GetAttribute("location");
            }

            node = (XmlElement)environment.SelectSingleNode("Environment/WSS");
            wssUrl = node.GetAttribute("url");
            wssDocumentLibrary = node.GetAttribute("library");
            wssTimeZone = node.GetAttribute("gmt");
            wssMachine = node.GetAttribute("machine");

            node = (XmlElement)environment.SelectSingleNode("Environment/Linking");
            if (node != null)
            {
                linkingWitSessionName = node.GetAttribute("witSessionName");
                linkingVcSessionName = node.GetAttribute("vcSessionName");
            }
        }
    }
}
