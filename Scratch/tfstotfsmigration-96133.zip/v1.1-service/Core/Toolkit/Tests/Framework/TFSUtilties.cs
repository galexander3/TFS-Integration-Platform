// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.TeamFoundation;
using Microsoft.TeamFoundation.Server;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

using Microsoft.TeamFoundation.WorkItemTracking.Proxy;

namespace Tests.Framework
{
    class TFSUtilties
    {
        #region Private Members
        
        private WorkItemStore m_workItemStore;
        private TeamFoundationServer m_server;
        private string m_projectName;
        private static ClientService witCls = null;        
        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets the WorkItemStore object
        /// </summary>
        public WorkItemStore Store
        {
            get
            {
                if (this.m_workItemStore == null)
                {
                    this.m_workItemStore = new WorkItemStore(this.m_server);
                }

                return this.m_workItemStore;
            }
            set
            {
                if (value == null)
                {
                    throw new InvalidOperationException("Work item store cannot be set to null");
                }

                this.m_workItemStore = value;
            }
        }

        public TeamFoundationServer TFServer
        {
            get { return m_server;  }

        }
        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="server">Team Foundation Server</param>
        public TFSUtilties(TeamFoundationServer server)
        {
            if (server == null)
            {
                throw new ArgumentNullException("server");
            }

            this.m_server = server;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="server">Team Foundation Server</param>
        public TFSUtilties(string server)
        {
            if (server == null)
            {
                throw new ArgumentNullException("server");
            }

            this.m_server = new TeamFoundationServer(server);

            if (this.m_server == null)
            {
                throw new ArgumentNullException("Team Foundation Server");
            }
        }

        #endregion


        #region Public Methods

        public WorkItem CreateWorkItem(string workItemType)
        {
            // Retrieve the WorkItemType
            WorkItemType wiType = null;
            try
            {
                wiType = m_workItemStore.Projects[m_projectName].WorkItemTypes[workItemType];
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Work item type specified does exist", ex);
            }

            WorkItem workItem = new WorkItem(wiType);

            if (workItem == null)
            {
                throw new Exception("Unable to create the work item");
            }

            return workItem;
        }

        public void CreateLink(int sourceWorkItemId, int targetWorkItemId, string linkTypeRefName, string comment, bool saveSourceWorkItem)
        {
            WorkItem source = Store.GetWorkItem(sourceWorkItemId);
            WorkItem target = Store.GetWorkItem(targetWorkItemId);

            if (source == null || target == null)
            {
                throw new Exception(String.Format("Unable the retrieve the work item with the specified id: {0}", source == null ? sourceWorkItemId : targetWorkItemId));
            }

            if (String.IsNullOrEmpty(linkTypeRefName))
            {
                throw new ArgumentException("Argument cannot be null or empty", "linkTypeRefName");
            }

            // Get the link type
            WorkItemLinkType linkType = Store.WorkItemLinkTypes[linkTypeRefName];

            // Create the link
            WorkItemLink link = new WorkItemLink(linkType);
            link.SourceId = source.Id;
            link.TargetId = target.Id;
            link.Comment = comment;

            // Add the link to the source work item
            source.WorkItemLinks.Add(link);

            // Save
            if (saveSourceWorkItem)
            {
                source.Save();
            }
        }

        public void DeleteLink(WorkItem source, WorkItem target, string linkTypeRefName, bool saveSourceWorkItem)
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }

            if (target == null)
            {
                throw new ArgumentNullException("target");
            }

            if (String.IsNullOrEmpty(linkTypeRefName))
            {
                throw new ArgumentException("Argument cannot be null or empty", "linkTypeRefName");
            }

            // Verify the link type
            if (!Store.WorkItemLinkTypes.Contains(linkTypeRefName))
            {
                throw new ArgumentException(String.Format("The link type specified '{0}' is not valid", linkTypeRefName));
            }

            // Get the link type
            WorkItemLinkType linkType = Store.WorkItemLinkTypes[linkTypeRefName];

            // Find the link to be removed
            for (int i = 0; i < source.WorkItemLinks.Count; i++)
            {
                WorkItemLink link = source.WorkItemLinks[i];
                if ((link.TargetId == target.Id) && (link.LinkType == linkType))
                {
                    source.WorkItemLinks.Remove(link);
                    break;
                }
            }

            // Save
            if (saveSourceWorkItem)
            {
                source.Save();
            }
        }

        public TeamFoundationServer GetTeamFoundationServer(string server)
        {
            if (server == null)
            {
                throw new ArgumentNullException("TFS server name");
            }

            return new TeamFoundationServer(server);
        }


        public void InitClientService(TeamFoundationServer tfs)
        {
            if (tfs == null)
            {
                throw new ArgumentNullException("Team Foundation Server");
            }

           IRegistration reg = (IRegistration)tfs.GetService(typeof(IRegistration));
           if (reg == null)
           {
               throw new ArgumentNullException("IRegistration Interface");
           }

           RegistrationEntry[] registrationEntries = reg.GetRegistrationEntries("WorkItemTracking");

           if (registrationEntries.Length < 1)
           {
               throw new InvalidOperationException(String.Format("Registration does not have an entry for tool with ID '{0}'.", "WorkItemTracking"));
           }
           if (registrationEntries.Length > 1)
           {
               throw new InvalidOperationException(String.Format("Registration has more than one entry for tool with ID '{0}'.", "WorkItemTracking"));
           }
           string serviceInterfaceName = "WorkitemService";

           ServiceInterface[] serviceInterfaces = registrationEntries[0].ServiceInterfaces;
           ServiceInterface serviceInterface = null;
           foreach (ServiceInterface s in serviceInterfaces)
           {
               if (s.Name.Equals(serviceInterfaceName, StringComparison.OrdinalIgnoreCase))
               {
                   serviceInterface = s;
                   break;
               }
           }

           if (serviceInterface == null)
           {
               throw new ArgumentNullException("Service Interface");
           }

           witCls = new ClientService();

           if (serviceInterface.Url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
               serviceInterface.Url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
           {
               witCls.Url = serviceInterface.Url;
           }
           else
           {
               witCls.Url = String.Format("{0}{1}", m_server.Uri.AbsoluteUri, serviceInterface.Url);
           }
        }
        #endregion
    }
}
