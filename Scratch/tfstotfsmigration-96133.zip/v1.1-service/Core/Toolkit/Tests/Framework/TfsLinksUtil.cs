﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Threading;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
namespace Tests.Framework
{
    class TfsLinksUtil
    {
        public TfsLinksUtil(WorkItemStore wiStore)
        {
            this.wiStore = wiStore;
        }


        public void CreateWorkItemLinks(string projectName)
        {
            WorkItemCollection workItemCollection = wiStore.Query("SELECT [System.Title] "
                + "FROM WorkItems WHERE [System.TeamProject] = \'" + projectName + "\' ");

            if (workItemCollection.Count < 2)
            {
                //create work items
                
            }

            WorkItemLinkType wiLinkType = wiStore.WorkItemLinkTypes["System.LinkTypes.Related"];

            WorkItem srcWorkItem = workItemCollection[0];
            WorkItem targetWorkItem = workItemCollection[1];

            WorkItemLink wiLink = new WorkItemLink(wiLinkType, srcWorkItem.Id, targetWorkItem.Id);
            srcWorkItem.Save();

        }


        private WorkItemStore wiStore;

    }
}
