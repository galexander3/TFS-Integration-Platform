﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Threading;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.Framework
{
    class TfsProjectUtils
    {
        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="project">Project object to bind this ProjectUtils to.</param>
        public TfsProjectUtils(Project project)
        {
            m_project = project;
        }

        #endregion


        #region private members

        private Project m_project;
        private ArrayList m_cachedAreaNodeTable = new ArrayList();
        private ArrayList m_cachedIterationNodeTable = new ArrayList();
        private int areaNodeCount = 0;
        private int iterationNodeCount = 0;

        private const string cAreaPathField = "Area Path";
        private const string cAreaIdField = "AreaID";
        private const string cAreaDisplayField = "Project Structure";
        private const string cIterationPathField = "Iteration Path";
        private const string cIterationIdField = "IterationID";
        private const string cIterationDisplayField = "Project Iteration";
      
        private int m_readerLockCount = 0;
        private bool m_isWriting = false;
        private object m_locker = new object();

        #endregion

        #region Enums

        public enum NodeType
        {
            Area,
            Iteration,
        }

        #endregion

        #region public properties

        /// <summary>
        /// Gets the WorkItem object this instance of the WorkItemUtils is bound to.
        /// </summary>
        /// <value>WorkItem object</value>
        public Project project
        {
            get
            {
                return m_project;
            }
        }

        public ArrayList CachedAreaNodeTable
        {
            get
            {
                return m_cachedAreaNodeTable;
            }
        }

        public ArrayList CachedIterationNodeTable
        {
            get
            {
                return m_cachedIterationNodeTable;
            }
        }

        #endregion

        #region public methods

        /// <summary>
        /// Adds node ids to the Cached node tables.
        /// </summary>
        /// <remarks>Primarily used by GetRandomTreeIDs</remarks>
        /// <param name="nodeType">This specifies which node table to update - Area, Iteration</param>
        public void UpdateCachedNodeTables(NodeType nodeType)
        {

            lock (m_locker)
            {
                while (m_readerLockCount > 0)
                    Thread.Sleep(10);

                m_isWriting = true;

                //Get the top level node.
                switch (nodeType)
                {
                    case NodeType.Area:
                        areaNodeCount = 0;
                        m_cachedAreaNodeTable.Clear();
                        //add the project node id.
                        m_cachedAreaNodeTable.Add(m_project.Id);
                        //Walk through the AreaRootNodes collection adding the Area node ids.
                        for (int i = 0; i < m_project.AreaRootNodes.Count; i++)
                        {
                            AddRows(m_project.AreaRootNodes[i], nodeType);
                        }
                        break;
                    case NodeType.Iteration:
                        iterationNodeCount = 0;
                        m_cachedIterationNodeTable.Clear();
                        //add the project node id.
                        m_cachedIterationNodeTable.Add(m_project.Id);
                        //Walk through the IterationRootNodes collection adding the Iteration node ids.
                        for (int i = 0; i < m_project.IterationRootNodes.Count; i++)
                        {
                            AddRows(m_project.IterationRootNodes[i], nodeType);
                        }
                        break;
                }

                m_isWriting = false;
            }

        }

        /// <summary>
        /// Gets a random node ID from the structure under the node passed in.
        /// </summary>
        /// <param name="nodeType">The NodeType of Path you want to get a node from either Iteration or Area.</param>
        /// <returns>node ID</returns>
        public int GetRandomTreeID(NodeType nodeType)
        {
            int previousReaderLockCount = m_readerLockCount;
            try
            {
                if (m_isWriting)
                {
                    //Empty lock to wait for writes to complete.
                    lock (m_locker)
                    {
                    }
                }

                int nodeID = 0;

                Random random = new Random();

                switch (nodeType)
                {
                    case NodeType.Area:
                        if (m_cachedAreaNodeTable.Count == 0)
                            UpdateCachedNodeTables(NodeType.Area);
                        //increment reader lock count.
                        m_readerLockCount++;
                        nodeID = (int)m_cachedAreaNodeTable[random.Next(m_cachedAreaNodeTable.Count)];
                        m_readerLockCount--;
                        break;
                    case NodeType.Iteration:
                        if (m_cachedIterationNodeTable.Count == 0)
                            UpdateCachedNodeTables(NodeType.Iteration);
                        //increment reader lock count.
                        m_readerLockCount++;
                        nodeID = (int)m_cachedIterationNodeTable[random.Next(m_cachedIterationNodeTable.Count)];
                        m_readerLockCount--;
                        break;
                }

                return nodeID;
            }
            catch (Exception ex)
            {
                throw new ApplicationException("GetRandomTreeID failed!\r\n" + ex);
            }
            finally
            {
                //decrement reader lock count.
                if (m_readerLockCount > previousReaderLockCount)
                    m_readerLockCount--;
            }
        }

        #endregion

        #region private methods

        private void AddRows(Node rootNode, NodeType nodeType)
        {
            //Add key and Id to table.
            switch (nodeType)
            {
                case NodeType.Area:
                    m_cachedAreaNodeTable.Add(rootNode.Id);
                    areaNodeCount++;
                    break;
                case NodeType.Iteration:
                    m_cachedIterationNodeTable.Add(rootNode.Id);
                    iterationNodeCount++;
                    break;
            }

            //Console.WriteLine(rootNode.Id + " - " + rootNode.LocalPath);

            //Walk the child nodes.
            for (int i = 0; i < rootNode.ChildNodes.Count; i++)
            {
                Node newRootNode = rootNode.ChildNodes[i];
                AddRows(newRootNode, nodeType);
            }

            return;
        }

        #endregion

    }
}
