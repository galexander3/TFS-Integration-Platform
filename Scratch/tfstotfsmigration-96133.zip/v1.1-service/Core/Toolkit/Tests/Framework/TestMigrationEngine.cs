using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;
using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Tests.Framework
{
    public class TestVCMigrationEngine : SourceToTfsMigrationEngine
    {
        public TestVCMigrationEngine(VersionControlSession session, ChangeGroupingMananger manager)
            : base(session, manager)
        { }

        public void CallProcessChangeGroup(ChangeGrouping group)
        {
            ProcessChangeGroup(group);
        }

        public void CallMerge(MigrationAction action, BatchingContext context)
        {
            Merge(action, context);
        }

        internal void CallBranch(SqlMigrationAction action, BatchingContext context)
        {
            Branch(action, context);
        }

        internal void CallAdd(SqlMigrationAction action, BatchingContext context)
        {
            Add(action, context);
        }

        internal void CallDelete(SqlMigrationAction action, BatchingContext context)
        {
            Delete(action, context);
        }

        internal void CallEdit(SqlMigrationAction action, BatchingContext context)
        {
            Edit(action, context);
        }

        internal void CallRename(SqlMigrationAction action, BatchingContext context)
        {
            Rename(action, context);
        }

        protected override bool IsOurTfsChanges(int changesetId)
        {
            throw new NotImplementedException();
        }
    }
}
