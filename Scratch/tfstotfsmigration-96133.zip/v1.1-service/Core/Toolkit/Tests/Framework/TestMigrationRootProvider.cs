// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Diagnostics;

namespace Tests
{
    public class TestMigrationRootProviderFactory : IConfigFactory
    {
        #region IConfigFactory Members

        public object CreateInstance(Type type, string xmlString)
        {
            if (type == typeof(TestMigrationRootProvider))
            {
                return new TestMigrationRootProvider(xmlString);
            }
            else
            {
                throw new InvalidOperationException();
            }
        }


        #endregion
    }

    public class TestMigrationRootProvider : IMigrationProvider
    {
        public TestMigrationRootProvider(string initString)
        {
            InitializerString = initString;
        }

        public string InitializerString;

        #region IMigrationProvider Members

        public void Abort()
        {
            Trace.WriteLine("Abort called");
        }

        public void Pause()
        {
            Trace.WriteLine("Pause called");            
        }

        public void Resume()
        {
            Trace.WriteLine("Resume called");
        }

        public void Start()
        {
            Trace.WriteLine("Start called");
        }

        public void Stop()
        {
            Trace.WriteLine("Stop called");
        }

        public void Complete()
        {
            Trace.WriteLine("Complete called");
        }

        public void Synchronize(SystemType primarySystem)
        {
            Trace.WriteLine("synchronize called");
        }

        public void SynchronizeFull()
        {
            Trace.WriteLine("SynchronizeFull called");
        }

        #endregion

        #region ISettingsCollection Members

        public T GetValue<T>(string name, T defaultValue)
            where T : IConvertible
        {
            return defaultValue;
        }

        public bool TryGetValue<T>(string settingName, out T settingValue)
            where T : IConvertible
        {
            settingValue = default(T);
            return false;
        }

        public string GetValue(string name)
        {
            return null;
        }

        public Setting[] Settings
        {
            get
            {
                return null;
            }
        }

        public bool TryGetValue(string name, out string value)
        {
            value = null;
            return false;
        }

        public void RegisterParent(ISettingsSection parent)
        {
            // do nothing
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            // no-op
        }

        #endregion
    }
}
