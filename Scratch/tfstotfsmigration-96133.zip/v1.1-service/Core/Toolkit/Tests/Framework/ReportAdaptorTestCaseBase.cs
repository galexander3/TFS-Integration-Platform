// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Tests.Framework
{
    public class ReportAdaptorTestCaseBase : MigrationTestCaseBase
    {
        protected MigrationInitializers initializer;

        [TestInitialize()]
        public override void Initialize()
        {
            base.Initialize();
            
            configFileName = TestContext.TestName + ".xml";
            configFile = new ConfigFile(configFileName);

            doc = configFile.Doc;

            initializer = new MigrationInitializers();

        }

        [TestCleanup()]
        public override void Cleanup()
        {
            initializer = null;
            base.Cleanup();
        }

        internal static void SimulateVCSession(MigrationConfiguration config, string sessionId)
        {
            using (VersionControlSession session = config.VC.Sessions[sessionId])
            {

                Assert.IsFalse(session.IsComplete);
                Assert.IsFalse(session.IsRunning);
                Assert.IsFalse(session.IsAborted);

                for (int i = 0; i < 500; i++)
                {
                    session.Start();

                    Assert.IsTrue(session.IsRunning);
                    Assert.IsFalse(session.IsComplete);
                    Assert.IsFalse(session.IsAborted);

                    session.OnBeforeAnalysis(new VersionControlEventArgs("Analyzing SVN", SystemType.Other));

                    session.OnAnalyzingChangeStarting(new VersionControlEventArgs("Analyzing SVN change 3871", SystemType.Other));
                    session.OnAnalysisError(new
                        VersionControlEventArgs(
                        "Change 3871 performs an edit on missing item $/TeamProject/Application/Program.cs",
                        new Exception(
                            "Error message within an exception",
                            new Exception(
                                "Inner exception 1",
                                new Exception(
                                    "Inner exception 2"))
                                )
                            , SystemType.Other)
                        );

                    session.OnAnalysisAborted(new VersionControlEventArgs("Change 3871 requires manual intervention", SystemType.Other));

                    session.Abort();

                    Assert.IsFalse(session.IsRunning);
                    Assert.IsFalse(session.IsComplete);
                    Assert.IsTrue(session.IsAborted);

                    session.Start();

                    Assert.IsTrue(session.IsRunning);
                    Assert.IsFalse(session.IsComplete);
                    Assert.IsFalse(session.IsAborted);

                    session.OnBeforeAnalysis(new VersionControlEventArgs("Analyzing SVN", SystemType.Other));
                    session.OnAnalyzingChangeStarting(new VersionControlEventArgs("Analyzing SVN change 3871", SystemType.Other));
                    session.OnAnalyzingChangeComplete(new VersionControlEventArgs("Analyzing SVN change 3871 Complete", SystemType.Other));


                    Assert.IsTrue(session.IsRunning);
                    Assert.IsFalse(session.IsComplete);
                    Assert.IsFalse(session.IsAborted);

                    session.OnAnalyzingChangeStarting(new VersionControlEventArgs("Analyzing SVN change 3872", SystemType.Other));
                    session.OnAnalyzingChangeComplete(new VersionControlEventArgs("Analyzing SVN change 3872 Complete", SystemType.Other));

                    session.OnAnalysisComplete(new VersionControlEventArgs("Completed analyzing SVN", SystemType.Other));

                    session.Stop();

                    Assert.IsFalse(session.IsRunning);
                    Assert.IsTrue(session.IsComplete);
                    Assert.IsFalse(session.IsAborted);
                }
            }
        }

    }
}
