// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Framework
{
    /**
     * This class represents all the information required to specify the migration configuration file. 
     * It is the layer of absraction between the test cases and the migration XML
     */

    /** Updating this Class
     * 1. Create the new ___Info class your adding in the appropriate region
     * 2. Add a refrence to the new Info class in the appropriate parent class
     * 3. Use refactor -> Encapsulate field to  create a public field for the refrence
     * 4. Update the constructor of the parent class to populate the new Info field.
     * 5. Update the ConfigFile class to output the XML for your new class.
     * 
     */
    public class ConfigParameters
    {

        //Defaults for config file
        public static string defaultServerId = "testServer";
        public static string defaultProviderId = "testProvider";
        private string PSProviderId = "TestProvider";
        private string defaultFilter = "[System.WorkItemType]='Bug'";
        public static string defaultTextReportProviderId = "TextReportProvider";
        private string textReportAssemblyQualifiedName = "Microsoft.TeamFoundation.Migration.Toolkit.TextReportFactory, Microsoft.TeamFoundation.Migration.Toolkit, Version=1.0.0.0, Culture=neutral";
        private string wssAssemblyQualifiedName = "Microsoft.TeamFoundation.Migration.VersionControl.WSS.WssProviderFactory, WSS2TFS_Adaptor, Version=1.0.0.0, Culture=neutral";

        private const int defaultThreadCount = 2;
        private const int defaultBatchSize = 50;
        /**
         * This method should be called before every test case.
         * 
         * It loads the environment information and uses it and a set of defualts to create a migration configuration that is ready to migrate
         * The config file can be customized to the test case by using the public fields (arranged in the same fasion as the config file)
         * 
         * by defualt you will have
         * 1 VCSession named "VCSession1" with source environment WSS site; a mapping from root to root. And a Text report adaptor in temp\textReports\%testcaseName%Report.txt
         * 2 Providers The text report provider and the WSS provider
         * 1 Server From the Envrionment file
         * 
         */
        public ConfigParameters(string testcaseName)
        {
            this.testcaseName = testcaseName;

            SqlInfo = new SqlInfo(TestEnvironment.SqlServer, testcaseName);

            TfsInfo = new TfsInfo(defaultServerId, TestEnvironment.MasterWorkspace, TestEnvironment.MasterWorkspaceRoot, TestEnvironment.MasterServer);

            WssInfo = new WSSInfo(TestEnvironment.WssUrl, TestEnvironment.WssDocumentLibrary, TestEnvironment.WssTimeZone);

            //Start populating the information for a Config file
            string random = TestUtils.GetRandomAsciiString(10);
            masterTfsPath = String.Format("$/{0}/{1}/{2}", TestEnvironment.MasterProject, "test" + random, testcaseName);
            dependentTfsPath = String.Format("$/{0}/{1}/{2}", TestEnvironment.DependentProject, "test" + random, testcaseName);

            MappingsInfo mapping = new MappingsInfo(TestEnvironment.WssUrl, MasterTfsPath, false);

            TextReportInfo textReportInfo = new TextReportInfo(Path.Combine(TestUtils.TextReportRoot, String.Format("{0}Report.txt", testcaseName)), false, defaultTextReportProviderId);

            VersionControlSessionInfo vcSession = new VersionControlSessionInfo(mapping, TfsInfo, defaultProviderId, WssInfo, textReportInfo);
            versionControl = new VersionControlInfo(SqlInfo, vcSession);

            providers = new List<ProviderInfo>();
            Providers.Add(new ProviderInfo(defaultTextReportProviderId, textReportAssemblyQualifiedName));
            Providers.Add(new ProviderInfo(defaultProviderId, wssAssemblyQualifiedName));

            Providers.Add(new ProviderInfo(PSProviderId, textReportAssemblyQualifiedName));

            servers = new List<ServerInfo>();
            Servers.Add(new ServerInfo(defaultServerId, TfsInfo.ServerURI));


            //WIT info
            TFSWitInfo tfs = new TFSWitInfo(defaultServerId, TestEnvironment.MasterServer,
                                 TestEnvironment.MasterProject, defaultFilter);


            QueueInfo fastQueue = new QueueInfo(defaultThreadCount, defaultBatchSize);
            QueueInfo slowQueue = new QueueInfo(defaultThreadCount, defaultBatchSize);

            TFSWitInfo sourceTfs = new TFSWitInfo(defaultServerId, TestEnvironment.DependentServer, TestEnvironment.DependentProject, string.Empty);

            witSession = new WorkItemTrackingSessionInfo(tfs, fastQueue, slowQueue, sourceTfs);

            WorkItemTracking = new WorkItemTrackingInfo(witSession);

            settings = new Dictionary<string, string>();
        }

        private string testcaseName;
        public string TestcaseName
        {
            get { return testcaseName; }
            set { testcaseName = value; }
        }

        private string masterTfsPath;
        public string MasterTfsPath
        {
            get { return masterTfsPath; }
        }

        private string dependentTfsPath;
        public string DependentTfsPath
        {
            get { return dependentTfsPath; }
        }

        SqlInfo sqlInfo;
        public SqlInfo SqlInfo
        {
            get { return sqlInfo; }
            set { sqlInfo = value; }
        }

        TfsInfo tfsInfo;
        public TfsInfo TfsInfo
        {
            get { return tfsInfo; }
            set { tfsInfo = value; }
        }

        WSSInfo wssInfo;
        public WSSInfo WssInfo
        {
            get { return wssInfo; }
            set { wssInfo = value; }
        }

        VersionControlInfo versionControl;
        public VersionControlInfo VersionControl
        {
            get { return versionControl; }
            set { versionControl = value; }
        }

        List<ProviderInfo> providers;
        public List<ProviderInfo> Providers
        {
            get { return providers; }
        }

        List<ServerInfo> servers;
        public List<ServerInfo> Servers
        {
            get { return servers; }
        }

        Dictionary<string, string> settings;
        public Dictionary<string, string> Settings
        {
            get { return settings; }
        }

        //WIT related
        private WorkItemTrackingInfo workItemTracking;
        public WorkItemTrackingInfo WorkItemTracking
        {
            get { return workItemTracking; }
            set { workItemTracking = value; }
        }

        private WorkItemTrackingSessionInfo witSession;

    }

    #region Common


    public class SqlInfo
    {

        public SqlInfo(string server, string database)
        {
            Database = database;
            Server = server;
        }

        string connectionString;
        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        string database;
        public string Database
        {
            get { return database; }
            set { database = value; }
        }

        string server;
        public string Server
        {
            get { return server; }
            set { server = value; }
        }

    }

    public abstract class EventSinkInfo
    {
        public abstract XmlElement generateXml(XmlDocument doc);
    }

    public class TextReportInfo : EventSinkInfo
    {
        public TextReportInfo(string filePath, bool append, string providerId)
        {
            FilePath = filePath;
            Append = append;
            ProviderId = providerId;
        }

        string filePath;
        public string FilePath
        {
            get { return filePath; }
            set { filePath = value; }
        }

        bool append;
        public bool Append
        {
            get { return append; }
            set { append = value; }
        }

        string providerId;
        public string ProviderId
        {
            get { return providerId; }
            set { providerId = value; }
        }

        public override XmlElement generateXml(XmlDocument doc)
        {
            XmlElement eventSinkNode = doc.CreateElement("EventSink");
            XmlElement textReportNode = doc.CreateElement("TextReport");
            XmlElement filePathNode = doc.CreateElement("File");
            XmlElement appendNode = doc.CreateElement("Append");

            filePathNode.InnerText = FilePath;
            appendNode.InnerText = Append.ToString().ToLower();

            eventSinkNode.SetAttribute("provider", ProviderId);
            eventSinkNode.AppendChild(textReportNode);
            textReportNode.AppendChild(filePathNode);
            textReportNode.AppendChild(appendNode);

            return eventSinkNode;
        }

    }

    /// <summary>
    /// This is a dual use class. It is used to populate the Tfs section of the configuration file;
    /// since the information is the same it can also because to populate the source node, in the case of TFS to TFS migration
    /// </summary>
    public class TfsInfo : SourceInfo
    {
        public TfsInfo(string serverId, string workspace, string workspaceRoot, string serverURI)
        {
            ServerId = serverId;
            WorkspaceName = workspace;
            WorkspaceRoot = workspaceRoot;
            ServerURI = serverURI;
        }

        string serverId;
        public string ServerId
        {
            get { return serverId; }
            set { serverId = value; }
        }

        string workspaceName;
        public string WorkspaceName
        {
            get { return workspaceName; }
            set { workspaceName = value; }
        }

        string workspaceRoot;
        public string WorkspaceRoot
        {
            get { return workspaceRoot; }
            set { workspaceRoot = value; }
        }

        string serverURI;
        public string ServerURI
        {
            get { return serverURI; }
            set { serverURI = value; }
        }

        public XmlElement generateXml(XmlDocument doc)
        {
            XmlElement tfsNode = doc.CreateElement("Tfs");
            XmlElement workspaceNode = doc.CreateElement("Workspace");
            XmlElement workspaceRootNode = doc.CreateElement("WorkspaceRoot");

            tfsNode.SetAttribute("server", serverId);

            workspaceNode.InnerText = WorkspaceName;
            workspaceRootNode.InnerText = WorkspaceRoot;

            tfsNode.AppendChild(workspaceNode);
            tfsNode.AppendChild(workspaceRootNode);

            return tfsNode;
        }

    }

    public class ProviderInfo
    {
        public ProviderInfo(string providerId, string assemblyQualifiedName)
        {
            ProviderId = providerId;
            AssemblyQualifiedName = assemblyQualifiedName;
        }

        string providerId;
        public string ProviderId
        {
            get { return providerId; }
            set { providerId = value; }
        }

        string assemblyQualifiedName;
        public string AssemblyQualifiedName
        {
            get { return assemblyQualifiedName; }
            set { assemblyQualifiedName = value; }
        }
    }

    public class ServerInfo
    {
        public ServerInfo(string serverId, string serverURI)
        {
            ServerId = serverId;
            ServerURI = serverURI;
        }

        string serverId;
        public string ServerId
        {
            get { return serverId; }
            set { serverId = value; }
        }

        string serverURI;
        public string ServerURI
        {
            get { return serverURI; }
            set { serverURI = value; }
        }
    }

    public interface SourceInfo
    {
        XmlElement generateXml(XmlDocument doc);
    }

    #endregion Common

    #region Version Control

    public class WSSInfo : SourceInfo
    {

        public WSSInfo(string serverURL, string documentLibrary, string gmtOffset)
        {
            ServerURL = serverURL;
            GMTOffset = gmtOffset;
            DocumentLibrary = documentLibrary;
        }

        public XmlElement generateXml(XmlDocument doc)
        {
            XmlElement wssNode = doc.CreateElement("WSS");
            XmlElement serverNode = doc.CreateElement("BaseUrl");
            XmlElement offsetNode = doc.CreateElement("GMTOffset");
            XmlElement documentLibNode = doc.CreateElement("DocumentLibrary");

            serverNode.InnerText = ServerURL;
            offsetNode.InnerText = GMTOffset;
            documentLibNode.InnerText = DocumentLibrary;

            wssNode.AppendChild(serverNode);
            wssNode.AppendChild(documentLibNode);
            wssNode.AppendChild(offsetNode);

            return wssNode;
        }

        string serverURL;
        public string ServerURL
        {
            get { return serverURL; }
            set { serverURL = value; }
        }

        string gmtOffset;
        public string GMTOffset
        {
            get { return gmtOffset; }
            set { gmtOffset = value; }
        }

        string documentLibrary;
        public string DocumentLibrary
        {
            get { return documentLibrary; }
            set { documentLibrary = value; }
        }


    }

    public class VersionControlInfo
    {
        public VersionControlInfo(SqlInfo sqlInfo, VersionControlSessionInfo session)
        {
            Sql = sqlInfo;
            sessions = new List<VersionControlSessionInfo>();
            Sessions.Add(session);
        }

        List<VersionControlSessionInfo> sessions;
        public List<VersionControlSessionInfo> Sessions
        {
            get { return sessions; }
        }

        Dictionary<string, string> settings;
        public Dictionary<string, string> Settings
        {
            get { return settings; }
        }

        SqlInfo sql;
        public SqlInfo Sql
        {
            get { return sql; }
            set { sql = value; }
        }
    }

    public class VersionControlSessionInfo
    {
        public VersionControlSessionInfo(MappingsInfo mapping, TfsInfo tfs, string providerId, SourceInfo source, EventSinkInfo eventSink)
        {
            SessionId = "VCSession1";
            mappings = new List<MappingsInfo>();
            settings = new Dictionary<string, string>();

            mappings.Add(mapping);

            Tfs = tfs;
            ProviderId = providerId;
            Source = source;

            eventSinks = new List<EventSinkInfo>();
            EventSinks.Add(eventSink);
        }

        string sessionId;
        public string SessionId
        {
            get { return sessionId; }
            set { sessionId = value; }
        }

        List<MappingsInfo> mappings;
        public List<MappingsInfo> Mappings
        {
            get { return mappings; }
        }

        Dictionary<string, string> settings;
        public Dictionary<string, string> Settings
        {
            get { return settings; }
        }

        TfsInfo tfs;
        public TfsInfo Tfs
        {
            get { return tfs; }
            set { tfs = value; }
        }

        string providerId;
        public string ProviderId
        {
            get { return providerId; }
            set { providerId = value; }
        }

        SourceInfo source;
        public SourceInfo Source
        {
            get { return source; }
            set { source = value; }
        }

        List<EventSinkInfo> eventSinks;
        public List<EventSinkInfo> EventSinks
        {
            get { return eventSinks; }
        }
    }

    public class MappingsInfo
    {
        public MappingsInfo(string source, string target, bool cloak)
        {
            Source = source;
            Target = target;
            Cloak = cloak;
        }


        string source;
        public string Source
        {
            get { return source; }
            set { source = value; }
        }

        string target;
        public string Target
        {
            get { return target; }
            set { target = value; }
        }

        bool cloak;
        public bool Cloak
        {
            get { return cloak; }
            set { cloak = value; }
        }
    }

    #endregion

    #region Work Item Tracking

    public class WorkItemTrackingInfo
    {
        public WorkItemTrackingInfo(WorkItemTrackingSessionInfo session)
        {
            Debug.Assert(session != null, "WorkItemTrackingSessionInfo object shouldn't be null");

            witSessions = new List<WorkItemTrackingSessionInfo>();
            fieldMaps = new List<FieldMapInfo>();
            witSessions.Add(session);
            CreateFieldMaps();
        }

        public void Add(WorkItemTrackingSessionInfo session)
        {
            Debug.Assert(session != null, "WorkItemTrackingSessionInfo should not be null");
            witSessions.Add(session);
        }

        private List<WorkItemTrackingSessionInfo> witSessions;
        private Dictionary<string, string> settings;

        public List<WorkItemTrackingSessionInfo> WitSessions
        {
            get { return witSessions; }
        }

        public Dictionary<string, string> Settings
        {
            get { return settings; }
        }

        internal List<FieldMapInfo> fieldMaps;

        public List<FieldMapInfo> FieldMaps
        {
            get { return fieldMaps; }
        }

        private void CreateFieldMaps()
        {
            ExclusionField[] exfield = new ExclusionField[] { 
                            new ExclusionField(string.Empty, string.Empty),
                            new ExclusionField("tfs", "Some.Dummy.Field"),
                            };
            FieldPairEntry[] fieldPair = new FieldPairEntry[] { 
                            new FieldPairEntry("System.State", "Status"),
                            new FieldPairEntry("Tfs.Field", "Custom Field")
                            };
            List<FieldExcludionEntry> entryList = new List<FieldExcludionEntry>();
            for (int i = 0; i < exfield.Length; i++)
            {
                FieldExcludionEntry fe = new FieldExcludionEntry(fieldPair[i], exfield[i]);
                entryList.Add(fe);
            }

            FieldMapInfo fm = new FieldMapInfo(entryList, "default");
            fieldMaps.Add(fm);
        }

    }

    public class TFSWitInfo
    {
        public TFSWitInfo(string server, string url, string project, string filter)
        {
            Debug.Assert(server != null);
            Debug.Assert(url != null);
            Debug.Assert(project != null);

            this.serverName = server;
            this.url = url;
            this.project = project;
            this.filter = filter;
        }

        private string serverName;

        public string ServerName
        {
            get { return serverName; }
        }

        private string url;
        public string Url
        {
            get { return url; }
        }
        private string project;
        public string Project
        {
            get { return project; }
        }

        private string filter;
        public string Filter
        {
            get { return filter; }
        }
    }

    public class WitSource
    {
        public WitSource(string server, string project, int threadCount, int batchSize)
        {
            this.server = server;
            this.project = project;
            this.threadCount = threadCount;
            this.batchSize = batchSize;
        }

        private string server = string.Empty;

        private string project = string.Empty;

        private int threadCount;

        private int batchSize;

        internal string Server
        {
            get { return server; }
        }

        internal  string Project
        {
            get { return project; }
        }

        internal int ThreadCount
        {
            get { return threadCount; }
        }

        internal int BatchSize
        {
            get { return batchSize; }
        }


    }    


    public class QueueInfo
    {
        public QueueInfo(int threadCount, int batchSize)
        {
            Debug.Assert(threadCount > 0, "Thread count should be positive");
            Debug.Assert(batchSize > 0, "batch size should be positive");
            this.threadCount = threadCount;
            this.batchSize = batchSize;
        }

        private int threadCount;
        internal int ThreadCount
        {
            get { return threadCount; }
        }

        private int batchSize;
        internal int BatchSize
        {
            get { return batchSize; }
        }
    }

    public class WitProviderInfo
    {
        public WitProviderInfo(string source, string dest, string init, string id)
        {
            this.source = source;
            this.destination = dest;
            this.init = init;
            this.id = id;
        }

        private string id;

        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        private string source;
        internal string Source
        {
            get { return source; }
        }


        private string destination;
        internal string Destination
        {
            get { return destination; }
        }

        private string init;
        internal string Init
        {
            get { return init; }
        }
    }

    public class ExclusionField
    {
        private string sys;
        private string field;

        public string Sys
        {
            get { return sys; }
        }

        public string Field
        {
            get { return field; }
        }

        public ExclusionField(string sys, string field)
        {
            this.sys = sys;
            this.field = field;
        }
    }

    public class FieldPairEntry
    {
        public FieldPairEntry(string tfs, string other)
        {
            this.tfsName = tfs;
            this.otherName = other;

        }
        private string tfsName = string.Empty;
        private string otherName = string.Empty;

        public string TfsName
        {
            get { return tfsName; }
        }
        public string OtherName
        {
            get { return otherName; }
        }
    }

    public class FieldExcludionEntry
    {
        private FieldPairEntry fieldPair;
        private ExclusionField exclusion;

        public FieldPairEntry FieldPair
        {
            get { return fieldPair; }
        }

        public ExclusionField Exclusion
        {
            get { return exclusion; }
        }
    

        
        public FieldExcludionEntry(FieldPairEntry fieldPair, ExclusionField exclusion)
        {
            this.fieldPair = fieldPair;
            this.exclusion = exclusion;
        }
    }


    public class FieldMapInfo
    {
        private string name;

        public string Name
        {
            get { return name; }
        }

        private List<FieldExcludionEntry> fieldExclusionList;

        public List<FieldExcludionEntry> FieldExclusionList
        {
            get { return fieldExclusionList; }
        }

        public FieldMapInfo(List<FieldExcludionEntry> fieldExclusionList, string name)
        {
            this.name = name;
            this.fieldExclusionList = fieldExclusionList;
        }
    }

    public class WorkItemTypeDef
    {
        public WorkItemTypeDef(string tfs, string other, string fieldMap)
        {
            this.tfs = tfs;
            this.other = other;
            this.fieldMap = fieldMap;
        }

        public WorkItemTypeDef(string tfs, string other)
        {
            this.tfs = tfs;
            this.other = other;
        }

        private string tfs = string.Empty;
        internal string Tfs
        {
            get { return tfs; }
        }

        private string other = string.Empty;
        internal string Other
        {
            get { return other; }
        }

        private string fieldMap = string.Empty;
        internal string FieldMap
        {
            get { return fieldMap; }
        }
    }

    public class FieldMappingInfo
    {
        public FieldMappingInfo()
        {
            this.wiTypes = new List<WorkItemTypeDef>();
        }

        public FieldMappingInfo(List<WorkItemTypeDef> wiTypes)
        {
            Debug.Assert(wiTypes != null);
            this.wiTypes = wiTypes;
        }

        public void Add(WorkItemTypeDef wType)
        {
            Debug.Assert(wType != null);

            wiTypes.Add(wType);
        }

        private List<WorkItemTypeDef> wiTypes;

        internal List<WorkItemTypeDef> WiTypes
        {
            get { return wiTypes; }
        }
    }


    public class WorkItemTrackingSessionInfo
    {
        public WorkItemTrackingSessionInfo(
                TFSWitInfo tfs,
                QueueInfo fastQueue,
                QueueInfo slowQueue,
                WitProviderInfo provider
            )
        {
            Debug.Assert(tfs != null, "TFSWitInfo should be null");

            this.tfs = tfs;
            this.fastQueue = fastQueue;
            this.slowQueue = slowQueue;
            this.provider = provider;

            sessionId = "WitSession1";
            providerId = "TestProvider";
            fieldMapping = new FieldMappingInfo();

            CreateFieldMapping();
        }

        public WorkItemTrackingSessionInfo(
                TFSWitInfo tfs,
                QueueInfo fastQueue,
                QueueInfo slowQueue,
                TFSWitInfo sourceTfs
            )
        {
            Debug.Assert(tfs != null, "TFSWitInfo should be null");

            this.tfs = tfs;
            this.fastQueue = fastQueue;
            this.slowQueue = slowQueue;
            this.sourceTfs = sourceTfs;

            sessionId = "TfsSession1";
            fieldMapping = new FieldMappingInfo();

            CreateFieldMapping();
        }



        string sessionId;

        public string SessionId
        {
            get { return sessionId; }
            set { sessionId = value; }
        }

        string providerId;

        public string ProviderId
        {
            get { return providerId; }
            set { providerId = value; }
        }
        Dictionary<string, string> settings;

        private TFSWitInfo tfs;
        public TFSWitInfo TFS
        {
            get { return tfs; }
        }

        private TFSWitInfo sourceTfs;
        public TFSWitInfo SourceTFS
        {
            get { return sourceTfs; }
        }


        private QueueInfo fastQueue;

        public QueueInfo FastQueue
        {
            get { return fastQueue; }
        }

        private QueueInfo slowQueue;
        public QueueInfo SlowQueue
        {
            get { return slowQueue; }
        }

        private WitProviderInfo provider;
        public WitProviderInfo Provider
        {
            get { return provider; }
        }

        internal Dictionary<string, string> Settings
        {
            get { return settings; }
        }
        private FieldMappingInfo fieldMapping;

        internal FieldMappingInfo FMapping
        {
            get { return fieldMapping; }
        }

        private void CreateFieldMapping()
        {
            WorkItemTypeDef wit = new WorkItemTypeDef("Tfs Bug", "PsBug", "default");
            fieldMapping.Add(wit);

            wit = new WorkItemTypeDef("Test Case", "PsTest Case");
            fieldMapping.Add(wit);
        }
    }

    #endregion

}
