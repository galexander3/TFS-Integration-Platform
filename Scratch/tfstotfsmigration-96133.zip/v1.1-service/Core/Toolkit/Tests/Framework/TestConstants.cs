using System;
using System.Collections.Generic;
using System.Text;

namespace Tests.Framework
{
    public static class TestConstants
    {
        public struct ProviderQualifiedName
        {
            public const string TestWITProvider = "Tests.WIT.Rand.RandProviderFactory, Tests, Version=1.0.0.0, Culture=neutral";
            public const string TextReport = "Microsoft.TeamFoundation.Migration.Toolkit.TextReportFactory, Microsoft.TeamFoundation.Migration.Toolkit, Version=1.1.31205.01, Culture=neutral";
            public const string SQLReport = "Microsoft.TeamFoundation.Migration.Toolkit.SqlReportFactory, Microsoft.TeamFoundation.Migration.Toolkit, Version=1.1.31205.01, Culture=neutral";
            public const string WSS2TFSAdaptor = "Microsoft.TeamFoundation.Migration.VersionControl.WSS.WssProviderFactory, WSS2TFS_Adaptor, Version=1.1.31205.01, Culture=neutral";
            public const string TfsProvider = "Microsoft.Vsts.Rangers.Migration.TfsToTfs.TfsProviderFactory, TfsToTfsAdaptor, Version=1.1.31205.01, Culture=neutral";
        }
    }
}