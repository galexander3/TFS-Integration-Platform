//****************************************************************************
// MigrationLinkToChangeset.cs
// Owner: nickkirc
//
// Encapsulates a WIT-to-Changeset link used in migration tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Class to encapsulate a WIT-to-Changeset link used in migration
    /// </summary>
    public class MigrationLinkToChangeset : MigrationLink
    {
        protected const string c_registeredChangesetLinkTypeName = "Fixed in Changeset";
        protected MigrationChangeset m_tgtChangeset;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="parentMigrationWorkItem">The migration work item that is the source of the link</param>
        /// <param name="srcWorkItemSide">Side that the source of the link is on</param>
        /// <param name="tgtChangeset">The changeset to link to</param>
        /// <param name="vcWorkspace">The workspace of the changeset</param>
        /// <param name="expectedResult">The link's expected migration result</param>
        public MigrationLinkToChangeset(MigrationWorkItem parentMigrationWorkItem, Side srcWorkItemSide,
                MigrationChangeset tgtChangeset, MigrationLinkResult expectedResult)
            : base(new ExternalLink(
                parentMigrationWorkItem[srcWorkItemSide].Store.RegisteredLinkTypes[c_registeredChangesetLinkTypeName], 
                tgtChangeset.SourceChangeset.ArtifactUri.ToString()), 
                c_defaultWITLinkComment, parentMigrationWorkItem, srcWorkItemSide, expectedResult)
        {
            m_tgtChangeset = tgtChangeset;
        }

        /// <summary>
        /// Compare this link with another and return true if they are equivalent
        /// </summary>
        /// <param name="srcSideLink">Link1</param>
        /// <param name="sideOfLink1">Side of Link1</param>
        /// <returns>True if the same, otherwise false</returns>
        protected override bool IsLinkEquivalent(Link link1, Side sideOfLink1)
        {
            // Make sure the links are of the same type
            if (link1.BaseType.CompareTo(BaseLinkType.ExternalLink) == 0)
            {
                string link1Uri = ((ExternalLink)link1).LinkedArtifactUri;

                if (sideOfLink1 == m_srcWorkItemSide)
                {
                    // Compare if on source side
                    return link1Uri.CompareTo(m_tgtChangeset.SourceChangeset.ArtifactUri.ToString()) == 0;
                }
                else
                {
                    // Compare if on destination side
                    foreach (Changeset dstSideChangeset in m_tgtChangeset.DestinationChangesets)
                    {
                        if (link1Uri.CompareTo(dstSideChangeset.ArtifactUri.ToString()) == 0)
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Compare the link with the given target URI and return true if they are the same
        /// </summary>
        /// <param name="targetUri">Target URI of the link</param>
        /// <returns>True if the same, otherwise false</returns>
        public override bool IsLinkEquivalent(string targetUri)
        {
            return targetUri.CompareTo(m_tgtChangeset.SourceChangeset.ArtifactUri.ToString()) == 0;
        }

        /// <summary>
        /// ToString
        /// </summary>
        /// <returns>Description of migration link</returns>
        public override string ToString()
        {
            return "Link from workitem " + SourceWorkItem.Id.ToString() + " (on " +
                m_srcWorkItemSide.ToString() + " side) to changeset " + m_tgtChangeset.ToString();
        }
    }
}
