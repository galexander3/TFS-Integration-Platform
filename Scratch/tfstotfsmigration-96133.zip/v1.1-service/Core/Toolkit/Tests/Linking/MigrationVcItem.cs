//****************************************************************************
// MigrationVcItem.cs
// Owner: nickkirc
//
// Encapsulates a version controlled item used in migration tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Class to encapsulate a version controlled item used in migration
    /// </summary>
    public class MigrationVcItem
    {
        Side m_srcSide = Side.Left;
        Item m_srcItem = null;
        Item m_dstItem = null;
        MigrationVcWorkspace m_vcWorkspace = null;
        bool m_usingLatestVersion = false;

        /// <summary>
        /// Source-side item
        /// </summary>
        public Item SourceItem { get { return m_srcItem; } }

        /// <summary>
        /// Side of source item
        /// </summary>
        public Side SourceSide { get { return m_srcSide; } }

        /// <summary>
        /// Destination-side item
        /// </summary>
        public Item DestinationItem
        {
            get
            {
                if (m_dstItem == null)
                {
                    m_dstItem = GetReflectedItem();
                }
                return m_dstItem;
            }
        }

        /// <summary>
        /// Source item's artifact URI string
        /// </summary>
        public string SourceArtifactUri 
        { 
            get 
            { 
                return m_usingLatestVersion ? m_srcItem.ArtifactUriLatestItemVersion.ToString() : 
                    m_srcItem.ArtifactUri.ToString(); 
            }
        }

        /// <summary>
        /// Destination item's artifact URI string
        /// </summary>
        public string DestinationArtifactUri
        {
            get
            {
                if (DestinationItem == null)
                {
                    return null;
                }
                return m_usingLatestVersion ? DestinationItem.ArtifactUriLatestItemVersion.ToString() :
                    DestinationItem.ArtifactUri.ToString();
            }
        }

        /// <summary>
        /// True if this item is the latest version (otherwise specific based on a changeset)
        /// </summary>
        public bool UsingLatestVersion { get { return m_usingLatestVersion; } }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="srcVcItem">VC Item</param>
        /// <param name="vcWorkspace">VC Workspace</param>
        /// <param name="srcSide">Side of changeset</param>
        /// <param name="useLatestVersion">True to use the latest version - otherwise specific</param>
        public MigrationVcItem(Item srcVcItem, MigrationVcWorkspace vcWorkspace, Side srcSide, bool useLatestVersion)
        {
            m_srcItem = srcVcItem;
            m_vcWorkspace = vcWorkspace;
            m_srcSide = srcSide;
            m_usingLatestVersion = useLatestVersion;
        }

        /// <summary>
        /// Gets the reflected (destination) VC item of the source item
        /// </summary>
        /// <returns>Reflected changeset</returns>
        protected Item GetReflectedItem()
        {
            // Get the reflected item based on path
            string srcPath = m_srcItem.ServerItem;

            // Left side = Target project side
            string srcServerRoot = m_vcWorkspace.TeamProjects[m_srcSide].ServerItem;
            string tgtServerRoot = m_vcWorkspace.TeamProjects[!m_srcSide].ServerItem;

            // Replace the project portion with the other-side's project
            Assert.IsTrue(srcPath.StartsWith(srcServerRoot), 
                "VCItem's server path {0} does not begin with project root {1}",
                srcPath, srcServerRoot);
            string tgtPath = srcPath.Replace(srcServerRoot, tgtServerRoot);

            // Get the item (latest version)
            try
            {
                VersionControlServer tgtServer = m_vcWorkspace.VCServers[!m_srcSide];
                Item vcItem = tgtServer.GetItem(tgtPath);
                if (m_usingLatestVersion)
                {
                    return vcItem;
                }
                else
                {
                    int itemId = vcItem.ItemId;
                    vcItem = null;

                    // If we need a specific version, look for it
                    foreach (int reflectedChangesetId in m_vcWorkspace.GetReflectedChangesetIds(m_srcItem.ChangesetId, m_srcSide))
                    {
                        try
                        {
                            vcItem = tgtServer.GetItem(itemId, reflectedChangesetId);
                            return vcItem;
                        }
                        catch
                        {
                            // Item may not exist for this changeset - that's okay, just catch error
                            // and look at next changeset.
                        }
                    }
                }
            }
            catch 
            {
                // Item has not been migrated - no reflection
            }

            return null;
        }

        /// <summary>
        /// Migration VcItem description
        /// </summary>
        /// <returns>Description</returns>
        public override string ToString()
        {
            string description = String.Format(
                "Migration vcItem: Source[Id={0} ServerPath={1} Changeset={2}]",
                m_srcItem.ItemId, m_srcItem.ServerItem, m_usingLatestVersion ? "Latest" : m_srcItem.ChangesetId.ToString());

            if (m_dstItem != null)
            {
                description += String.Format(" Destination[Id={0} ServerPath={1} Changeset={2}]",
                m_dstItem.ItemId, m_dstItem.ServerItem, m_usingLatestVersion ? "Latest" : m_dstItem.ChangesetId.ToString());
            }
            return description;
        }
    }
}
