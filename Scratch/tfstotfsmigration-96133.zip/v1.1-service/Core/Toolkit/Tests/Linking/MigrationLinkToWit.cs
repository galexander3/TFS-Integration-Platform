//****************************************************************************
// MigrationLinkToWit.cs
// Owner: nickkirc
//
// Encapsulates a WIT-to-WIT link used in migration tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Class to encapsulate a WIT-to-WIT link used in migration
    /// </summary>
    public class MigrationLinkToWit : MigrationLink
    {
        protected MigrationWorkItem m_tgtWorkItem;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="parentMigrationWorkItem">The migration work item that is the source of the link</param>
        /// <param name="srcWorkItemSide">Side that the source of the link is on</param>
        /// <param name="tgtWorkItem">The work item to link to</param>
        /// <param name="expectedResult">The link's expected migration result</param>
        public MigrationLinkToWit(MigrationWorkItem parentMigrationWorkItem, Side srcWorkItemSide, 
                MigrationWorkItem tgtWorkItem, MigrationLinkResult expectedResult)
            : base(new RelatedLink(tgtWorkItem[srcWorkItemSide].Id), c_defaultWITLinkComment, 
                parentMigrationWorkItem, srcWorkItemSide, expectedResult)
        {
            m_tgtWorkItem = tgtWorkItem;
        }

        /// <summary>
        /// Compare this link with another and return true if they are equivalent
        /// </summary>
        /// <param name="srcSideLink">Link1</param>
        /// <param name="sideOfLink1">Side of Link1</param>
        /// <returns>True if the same, otherwise false</returns>
        protected override bool IsLinkEquivalent(Link link1, Side sideOfLink1)
        {
            // Make sure the links are of the same type
            if (link1.BaseType.CompareTo(BaseLinkType.RelatedLink) == 0)
            {
                // May have to convert this link's work item id if not on the same side
                if (sideOfLink1 != m_tgtWorkItem.SourceSide && !m_tgtWorkItem.HasMigrated)
                {
                    return false;
                }
                return ((RelatedLink)link1).RelatedWorkItemId.CompareTo(m_tgtWorkItem[sideOfLink1].Id) == 0;
            }
            return false;
        }

        /// <summary>
        /// Compare the link with the given target URI and return true if they are the same
        /// </summary>
        /// <param name="targetUri">Target URI of the link</param>
        /// <returns>True if the same, otherwise false</returns>
        public override bool IsLinkEquivalent(string targetUri)
        {
            return targetUri.CompareTo(m_tgtWorkItem[m_srcWorkItemSide].Uri.ToString()) == 0;
        }

        /// <summary>
        /// ToString
        /// </summary>
        /// <returns>Description of migration link</returns>
        public override string ToString()
        {
            return "Link from workitem " + SourceWorkItem.Id.ToString() + " (on " + 
                m_srcWorkItemSide.ToString() + " side) to workitem " + m_tgtWorkItem[m_srcWorkItemSide].Id.ToString();
        }

        /// <summary>
        /// The expected migration result
        /// </summary>
        public override MigrationLinkResult ExpectedResult
        {
            get
            {
                return m_expectedResult;
            }
            set
            {
                m_expectedResult = value;
                foreach (MigrationLink migLink in m_tgtWorkItem.MigrationLinks)
                {
                    if (migLink.ExpectedResult != value &&
                        migLink.IsLinkEquivalent(SourceWorkItem.Uri.ToString()))
                    {
                        migLink.ExpectedResult = value;
                    }
                }
            }
        }
    }
}
