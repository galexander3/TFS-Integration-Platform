//****************************************************************************
// LinkMigrationSettings.cs
// Owner: nickkirc
//
// Container for the migration session settings.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml;

using Tests.Framework;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Container for TFS migration settings
    /// </summary>
    public class LinkMigrationSettings
    {
        protected const string c_DefaultConfigFilename = "Tests.Linking.Data.LinkingConfig.xml";
        protected const string c_TestWitTypeConfigFilename = "Tests.WIT.Data.testwit.xml";
        protected const string c_TestWitTypeName = "WitSyncTest";
        protected const string c_LinkingVcWorkspaceName = "VCLinkingTests";
        protected const string c_DefaultWitSessionName = "LinkingWitSession";
        protected const string c_DefaultVcSessionName = "LinkingVcSession";
        protected const string c_DefaultSourceServerName = "SourceTestServer";
        protected const string c_DefaultTargetServerName = "TargetTestServer";
        protected const string c_LocalWorkspaceSubfolderSrc = "LinkMigrationSource";
        protected const string c_LocalWorkspaceSubfolderTgt = "LinkMigrationTarget";
        protected const string c_SqlConnectionFormat = "server={0};Integrated Security=SSPI";

        // Migration configuration schema mappings
        protected const string c_XMLPathWitSession = "/Migration/WIT/Sessions/Session[@id='{0}']";
        protected const string c_XMLPathWitSrcProject = "/Migration/WIT/Sessions/Session[@id='{0}']/Source/Tfs/Project";
        protected const string c_XMLPathWitTgtProject = "/Migration/WIT/Sessions/Session[@id='{0}']/Tfs/Project";
        protected const string c_XMLPathVcSession = "/Migration/VC/Sessions/Session[@id='{0}']";
        protected const string c_XMLPathVcMapping = "/Migration/VC/Sessions/Session[@id='{0}']/Mappings/Mapping";
        protected const string c_XMLPathSrcWorkspace = "/Migration/VC/Sessions/Session[@id='{0}']/Source/Tfs/WorkspaceRoot";
        protected const string c_XMLPathTgtWorkspace = "/Migration/VC/Sessions/Session[@id='{0}']/Tfs/WorkspaceRoot";
        protected const string c_XMLPathLinkingVC = "/Migration/WIT/Sessions/Session[@id='{0}']/Linking/VersionControl";
        protected const string c_XMLPathTestServer = "/Migration/Servers/Tfs[@id='{0}']/Server";
        protected const string c_XMLPathSqlServerName = "/Migration/Sql/Server";
        protected const string c_XMLPathSqlConnection = "/Migration/Sql/ConnectionString";
        protected const string c_XMLPathSrcLinks = "/Migration/WIT/Sessions/Session/Source/Tfs/Links";
        protected const string c_XMLPathTgtLinks = "/Migration/WIT/Sessions/Session/Tfs/Links";
        protected const string c_AttributeId = "id";
        protected const string c_AttributeSession = "session";
        protected const string c_AttributeLinksPerUpdate = "linksPerUpdate";
        protected const string c_AttributeSrc = "src";
        protected const string c_AttributeTgt = "tgt";

        protected Pair<string> m_serverNames;                 // Name of TFS(Left) and Other(Right) servers
        protected Pair<string> m_projectNames;                // Project names
        protected XmlDocument m_defaultConfig;                // Default configuration
        protected string m_witSessionName;                    // Name of the session used for WIT migration
        protected string m_vcSessionName;                     // Name of the session used for VC migration
        protected string m_sqlServerName;                     // Name of SQL server machine

        protected Pair<WorkItemStore> m_stores;               // Test work item stores
        protected Pair<Project> m_projects;                   // Projects on both sides

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tfsServerName">Target/Left/Master/Tfs server name</param>
        /// <param name="otherServerName">Source/Right/Dependent/Other server name</param>
        /// <param name="tfsProjectName">Target/Left/Master/Tfs project name</param>
        /// <param name="otherProjectName">Source/Right/Dependent/Other project name</param>
        /// <param name="sqlServerName">SQL server name</param>
        /// <param name="witSessionName">WIT Session name</param>
        /// <param name="vcSessionName">VC Session name</param>
        protected LinkMigrationSettings(string tfsServerName, string otherServerName, string tfsProjectName, 
            string otherProjectName, string sqlServerName, string witSessionName, string vcSessionName)
        {
            m_witSessionName = witSessionName;
            m_vcSessionName = vcSessionName;
            m_sqlServerName = sqlServerName;

            m_serverNames = new Pair<string>(tfsServerName, otherServerName);
            m_projectNames = new Pair<string>(tfsProjectName, otherProjectName);
            m_stores = new Pair<WorkItemStore>(new WorkItemStore(m_serverNames.Left), new WorkItemStore(m_serverNames.Right));
            m_projects = new Pair<Project>(m_stores.Left.Projects[m_projectNames.Left], m_stores.Right.Projects[m_projectNames.Right]);
            
            // Load/modify the confiruation file
            m_defaultConfig = LoadConfigXml(c_DefaultConfigFilename);

            // Create the test work item type
            XmlDocument sharedType = LoadXml(c_TestWitTypeConfigFilename);
            m_projects.Left.WorkItemTypes.Import(sharedType.DocumentElement);
            m_projects.Right.WorkItemTypes.Import(sharedType.DocumentElement);

            // Load the session settings
            SettingsHelper.LoadSettings(m_defaultConfig);
            DataAccessManager.Current.CreateSchema(false);
        }

        /// <summary>
        /// Create a LinkMigrationSettings object for linking migration tests
        /// </summary>
        /// <param name="tfsServerName">Target/Left/Master/Tfs server name</param>
        /// <param name="otherServerName">Source/Right/Dependent/Other server name</param>
        /// <param name="tfsProjectName">Target/Left/Master/Tfs project name</param>
        /// <param name="otherProjectName">Source/Right/Dependent/Other project name</param>
        /// <param name="sqlServerName">SQL server name</param>
        /// <param name="witSessionName">WIT Session name</param>
        /// <param name="vcSessionName">VC Session name</param>
        /// <returns>New LinkMigrationSettings</returns>
        public static LinkMigrationSettings GetInstance(string tfsServerName, string otherServerName,
            string tfsProjectName, string otherProjectName, string sqlServerName, string witSessionName, 
            string vcSessionName)
        {
            if (String.IsNullOrEmpty(witSessionName))
            {
                witSessionName = c_DefaultWitSessionName;
            }
            if (String.IsNullOrEmpty(vcSessionName))
            {
                vcSessionName = c_DefaultVcSessionName;
            }
            return new LinkMigrationSettings(tfsServerName, otherServerName, tfsProjectName,
                otherProjectName, sqlServerName, witSessionName, vcSessionName);
        }

        /// <summary>
        /// Returns TFS work item store used for testing.
        /// </summary>
        public Pair<WorkItemStore> Stores { get { return m_stores; } }

        /// <summary>
        /// Returns projects.
        /// </summary>
        public Pair<Project> Projects { get { return m_projects; } }

        /// <summary>
        /// Returns the WIT session
        /// </summary>
        public string WITSessionName
        {
            get { return m_witSessionName; }
        }

        /// <summary>
        /// Returns the VC session
        /// </summary>
        public string VCSessionName
        {
            get { return m_vcSessionName; }
        }

        /// <summary>
        /// The name of the test work item type
        /// </summary>
        public string TestWorkItemTypeName { get { return c_TestWitTypeName; } }

        /// <summary>
        /// The name of the VC workspace for the linking tests
        /// </summary>
        public string LinkingWorkspaceName { get { return c_LinkingVcWorkspaceName; } }

        /// <summary>
        /// Loads document from resources.
        /// </summary>
        /// <param name="name">Resource name</param>
        /// <returns>XML document</returns>
        protected static XmlDocument LoadXml(string name)
        {
            using (Stream stream = typeof(LinkMigrationSettings).Assembly.GetManifestResourceStream(name))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(stream);
                return doc;
            }
        }

        /// <summary>
        /// Loads configuration XML from resources and replaces configurable values.
        /// </summary>
        /// <param name="name">Resource name</param>
        /// <returns>Configuration document</returns>
        protected XmlDocument LoadConfigXml(string name)
        {
            XmlDocument doc = LoadXml(name);

            // Change session names if desired
            if (m_witSessionName != c_DefaultWitSessionName)
            {
                SetAttributeValue(doc, String.Format(c_XMLPathWitSession, c_DefaultWitSessionName), c_AttributeId, m_witSessionName);
            }
            if (m_vcSessionName != c_DefaultVcSessionName)
            {
                SetAttributeValue(doc, String.Format(c_XMLPathVcSession, c_DefaultVcSessionName), c_AttributeId, m_vcSessionName);
                SetAttributeValue(doc, String.Format(c_XMLPathLinkingVC, m_witSessionName), c_AttributeSession, m_vcSessionName);
            }

            // Modify server name
            SetElementValue(doc, String.Format(c_XMLPathTestServer, c_DefaultTargetServerName), m_serverNames.Left);
            SetElementValue(doc, String.Format(c_XMLPathTestServer, c_DefaultSourceServerName), m_serverNames.Right);

            // WIT Substitutions
            SetElementValue(doc, String.Format(c_XMLPathWitTgtProject, m_witSessionName), m_projectNames.Left);
            SetElementValue(doc, String.Format(c_XMLPathWitSrcProject, m_witSessionName), m_projectNames.Right);
            
            // VC Substitutions
            string srcProjectServerRoot = GetProjectServerRootPath(m_serverNames.Right, m_projectNames.Right);
            string tgtProjectServerRoot = GetProjectServerRootPath(m_serverNames.Left, m_projectNames.Left);
            SetVCMapping(doc, srcProjectServerRoot, tgtProjectServerRoot);

            // Set up test SQL server
            m_sqlServerName = SetElementValue(doc, c_XMLPathSqlServerName, m_sqlServerName);
            SetElementValue(doc, c_XMLPathSqlConnection, String.Format(c_SqlConnectionFormat, m_sqlServerName));

            return doc;
        }

        /// <summary>
        /// Gets the server root path for the given project (e.g. $/ProjectA)
        /// </summary>
        /// <param name="serverName">Name of server on which the project resides</param>
        /// <param name="projectName">Name of project</param>
        /// <returns>Server root path</returns>
        protected string GetProjectServerRootPath(string serverName, string projectName)
        {
            TeamFoundationServer tfsServer = TeamFoundationServerFactory.GetServer(serverName);
            VersionControlServer vcServer = (VersionControlServer)tfsServer.GetService(typeof(VersionControlServer));
            return vcServer.GetTeamProject(projectName).ServerItem;
        }

        /// <summary>
        /// Sets value of all nodes returned by the query.
        /// </summary>
        /// <param name="doc">XML document</param>
        /// <param name="xpath">XPath query</param>
        /// <param name="value">Value</param>
        /// <returns>Node's value</returns>
        private static string SetElementValue(XmlDocument doc, string xpath, string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                XmlNode node = doc.SelectSingleNode(xpath);
                value = node.InnerText;
            }
            XmlNodeList nodes = doc.SelectNodes(xpath);

            foreach (XmlNode node in nodes)
            {
                node.InnerText = value;
            }
            return value;
        }

        /// <summary>
        /// Sets value of the attribute of all nodes returned by the query.
        /// </summary>
        /// <param name="doc">XML document</param>
        /// <param name="xpath">XPath query</param>
        /// <param name="attributeName">Name of attribute</param>
        /// <param name="value">Value</param>
        private static void SetAttributeValue(XmlDocument doc, string xpath, string attributeName, string value)
        {
            XmlNodeList nodes = doc.SelectNodes(xpath);
            foreach (XmlNode node in nodes)
            {
                node.Attributes[attributeName].Value = value;
            }
        }

        /// <summary>
        /// Set the Version Control migration mapping to the specified src/tgt folders
        /// </summary>
        /// <param name="doc">XML document</param>
        /// <param name="newSourceServerPath">Source server path to map</param>
        /// <param name="newTargetServerPath">Target server path to map</param>
        protected void SetVCMapping(XmlDocument doc, string newSourceServerPath, string newTargetServerPath)
        {
            SetAttributeValue(doc, String.Format(c_XMLPathVcMapping, m_vcSessionName), c_AttributeSrc, newSourceServerPath);
            SetAttributeValue(doc, String.Format(c_XMLPathVcMapping, m_vcSessionName), c_AttributeTgt, newTargetServerPath);

            // Clear existing temp folders and map them
            string srcLocalPath = Path.Combine(Path.GetTempPath(), c_LocalWorkspaceSubfolderSrc);
            string tgtLocalPath = Path.Combine(Path.GetTempPath(), c_LocalWorkspaceSubfolderTgt);
            TestUtils.DeleteDirectory(srcLocalPath);
            TestUtils.DeleteDirectory(tgtLocalPath);
            SetElementValue(doc, String.Format(c_XMLPathTgtWorkspace, m_vcSessionName), tgtLocalPath);
            SetElementValue(doc, String.Format(c_XMLPathSrcWorkspace, m_vcSessionName), srcLocalPath);
        }

        /// <summary>
        /// Change the Version Control migration mapping to the specified src/tgt folders
        /// </summary>
        /// <param name="newSourceServerPath">Source server path to map</param>
        /// <param name="newTargetServerPath">Target server path to map</param>
        public void ChangeVCMapping(string newSourceServerPath, string newTargetServerPath)
        {
            SetVCMapping(m_defaultConfig, newSourceServerPath, newTargetServerPath);
            SettingsHelper.LoadSettings(m_defaultConfig);
        }

        /// <summary>
        /// Change the linksPerUpdate value for the source and target servers (reloads the sessions)
        /// </summary>
        /// <param name="srcLinksPerUpdate">Number of links per update on source (0 = no change)</param>
        /// <param name="tgtLinksPerUpdate">Number of links per update on target (0 = no change)</param>
        public void ChangeLinksPerUpdate(int srcLinksPerUpdate, int tgtLinksPerUpdate)
        {
            if (srcLinksPerUpdate > 0)
            {
                SetAttributeValue(m_defaultConfig, c_XMLPathSrcLinks, c_AttributeLinksPerUpdate, srcLinksPerUpdate.ToString());
            }
            if (tgtLinksPerUpdate > 0)
            {
                SetAttributeValue(m_defaultConfig, c_XMLPathTgtLinks, c_AttributeLinksPerUpdate, tgtLinksPerUpdate.ToString());
            }

            // Load the session settings
            SettingsHelper.LoadSettings(m_defaultConfig);
        }
    }
}