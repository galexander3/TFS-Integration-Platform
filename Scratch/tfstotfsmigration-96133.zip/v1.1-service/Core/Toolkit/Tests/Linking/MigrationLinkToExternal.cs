//****************************************************************************
// MigrationLinkToExternal.cs
// Owner: nickkirc
//
// Encapsulates a link to an external item used in migration tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Class to encapsulate an external link used in migration
    /// </summary>
    public class MigrationLinkToExternal : MigrationLink
    {
        protected string m_externalUri = string.Empty;
        protected const string c_registeredTestResultLinkTypeName = "Test Result";

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="parentMigrationWorkItem">The migration work item that is the source of the link</param>
        /// <param name="srcWorkItemSide">Side that the source of the link is on</param>
        /// <param name="externalUri">The external Uri of the link</param>
        /// <param name="expectedResult">The link's expected migration result</param>
        public MigrationLinkToExternal(MigrationWorkItem parentMigrationWorkItem, Side srcWorkItemSide,
                string externalUri, MigrationLinkResult expectedResult)
            : base(new ExternalLink(
                parentMigrationWorkItem[srcWorkItemSide].Store.RegisteredLinkTypes[c_registeredTestResultLinkTypeName],
                externalUri), 
                c_defaultExternalLinkComment, parentMigrationWorkItem, srcWorkItemSide, expectedResult)
        {
            m_externalUri = externalUri;
        }

        /// <summary>
        /// Compare this link with another and return true if they are equivalent
        /// </summary>
        /// <param name="srcSideLink">Link1</param>
        /// <param name="sideOfLink1">Side of Link1</param>
        /// <returns>True if the same, otherwise false</returns>
        protected override bool IsLinkEquivalent(Link link1, Side sideOfLink1)
        {
            // Make sure the links are of the same type
            if (link1.BaseType.CompareTo(BaseLinkType.ExternalLink) == 0)
            {
                // Just check the URL/Location
                return ((ExternalLink)link1).LinkedArtifactUri.CompareTo(m_externalUri) == 0;
            }
            return false;
        }

        /// <summary>
        /// Compare the link with the given target URI and return true if they are the same
        /// </summary>
        /// <param name="targetUri">Target URI of the link</param>
        /// <returns>True if the same, otherwise false</returns>
        public override bool IsLinkEquivalent(string targetUri)
        {
            return targetUri.CompareTo(m_externalUri) == 0;
        }

        /// <summary>
        /// ToString
        /// </summary>
        /// <returns>Description of migration link</returns>
        public override string ToString()
        {
            return "Link from workitem " + SourceWorkItem.Id.ToString() +
                " (on " + m_srcWorkItemSide.ToString() + " side) to External uri:" + m_externalUri;
        }
    }
}
