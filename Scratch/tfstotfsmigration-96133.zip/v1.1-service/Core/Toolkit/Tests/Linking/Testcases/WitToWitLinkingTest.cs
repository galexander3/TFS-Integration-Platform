//****************************************************************************
// WitToWitLinkingTest.cs
// Owner: nickkirc
//
// Tests for Migrating WorkItems with links to other WorkItems.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.Linking
{
    /// <summary>
    /// Tests for WIT-to-WIT linkings
    /// </summary>
    [TestClass]
    public class WitToWitLinkingTest : LinkingTestcaseBase
    {
        /// <summary>
        /// Scenario1: Migrate a link to a completely-migrated work item left-to-right
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a completely-migrated work item left-to-right")]
        public void Linking_WIT_CompletelyMigratedItemLtoR()
        {
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            MigrationWorkItem workItem2 = CreateMigrationWorkItem(false, Side.Left);
            workItem2.LinkSourceWorkItemTo(workItem1);
            workItem2.Migrate(true);
        }

        /// <summary>
        /// Scenario2: Migrate a link to a completely-migrated work item right-to-left
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a completely-migrated work item right-to-left")]
        public void Linking_WIT_CompletelyMigratedItemRtoL()
        {
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            MigrationWorkItem workItem2 = CreateMigrationWorkItem(false, Side.Right);
            workItem2.LinkSourceWorkItemTo(workItem1);
            workItem2.Migrate(true);
        }

        /// <summary>
        /// Scenario3: Migrate a link to a work item that is being migrated at the same time
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a work item that is being migrated at the same time")]
        public void Linking_WIT_ItemsMigratedAtSameTime()
        {
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(true);
            MigrationWorkItem workItem2 = CreateMigrationWorkItem(false);
            MigrationLink srcLink = workItem2.LinkSourceWorkItemTo(workItem1);
            MigrationWorkItem.Migrate(false, workItem1, workItem2);

            // Link may have been deferred - that's okay
            Assert.IsTrue(srcLink.ReflectedLinks.Count > 0 || srcLink.HasDeferredLink,
                "The link was not migrated at all. We expected either deferred or successful migration");
        }

        /// <summary>
        /// Scenario4: Link to a work item post-migration and migrate again (Left-to-right)
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Link to a work item post-migration and migrate again (Left-to-right)")]
        public void Linking_WIT_PostMigrationLtoR()
        {
            DefaultSourceSide = Side.Left;
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            MigrationWorkItem workItem2 = CreateAndMigrateWorkItem(true);
            workItem2.LinkSourceWorkItemTo(workItem1);
            workItem2.Migrate(true);
        }

        /// <summary>
        /// Scenario5: Link to a work item post-migration and migrate again (Left-to-right)
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Link to a work item post-migration and migrate again (Right-to-left)")]
        public void Linking_WIT_PostMigrationRtoL()
        {
            DefaultSourceSide = Side.Right;
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            MigrationWorkItem workItem2 = CreateAndMigrateWorkItem(true);
            workItem2.LinkSourceWorkItemTo(workItem1);
            workItem2.Migrate(true);
        }

        /// <summary>
        /// Scenario6: Migrate a link to a work item that has not yet been migrated
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a work item that has not yet been migrated")]
        public void Linking_WIT_NotYetMigratedItem()
        {
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(true);
            MigrationWorkItem workItem2 = CreateMigrationWorkItem(false);
            workItem2.LinkSourceWorkItemTo(workItem1, MigrationLinkResult.Deferred);
            workItem2.Migrate(true);
        }

        /// <summary>
        /// Scenario7: Migrate a work item that was a deferred link
        /// Expected result: Link is migrated and deferred entry removed
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a work item that was a deferred link")]
        public void Linking_WIT_MigrateDeferredItem()
        {
            // Link to workItem1 which is not migrated
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(true);
            MigrationWorkItem workItem2 = CreateMigrationWorkItem(false);
            MigrationLink srcLink = workItem2.LinkSourceWorkItemTo(workItem1, MigrationLinkResult.Deferred);
            workItem2.Migrate(true);

            // Now migrate workItem1
            srcLink.ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            workItem1.Migrate(true);

            // Verify work item 2 - link should now be migrated
            workItem2.VerifyLinkMigration();

            // Verify that the deferred entry was removed
            workItem2.ProcessDeferredLinks(false);
            Assert.IsFalse(srcLink.HasDeferredLink,
                "The deferred link entry was not removed after the link was fully migrated");
        }

        /// <summary>
        /// Scenario8: Migrate a link to a skipped work item that had a conflict
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a skipped work item that had a conflict")]
        public void Linking_WIT_LinkToSkippedWorkItem()
        {
            // Create a link to a migrated work item
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            MigrationWorkItem workItem2 = CreateMigrationWorkItem(true);
            workItem2.LinkSourceWorkItemTo(workItem1);

            // Create a field conflict on the linked work item
            workItem1.SourceWorkItem[CoreField.Title] = "ChangedTitleSource";
            workItem1.DestinationWorkItem[CoreField.Title] = "ChangedTitleDest";

            // Migrate the work items
            MigrationWorkItem.Migrate(false, workItem1, workItem2);
            workItem2.VerifyLinkMigration();
        }

        /// <summary>
        /// Scenario9: Update link comment on a deferred link
        /// Expected result: No-op
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Update link comment on a deferred link")]
        public void Linking_WIT_UpdateCommentOnDeferredLink()
        {
            // Link to workItem1 which is not migrated
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(true);
            MigrationWorkItem workItem2 = CreateMigrationWorkItem(false);
            MigrationLink srcLink = workItem2.LinkSourceWorkItemTo(workItem1, MigrationLinkResult.Deferred);
            workItem2.Migrate(true);

            // Update comment on the link
            srcLink.Link.Comment = "Changed comment - source";

            // Now migrate workItem1
            srcLink.ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            workItem1.Migrate(true);

            // Verify work item 2 - link should now be migrated
            workItem2.VerifyLinkMigration();

            // Verify that the deferred entry was removed after another sync
            workItem2.ProcessDeferredLinks(false);
            Assert.IsFalse(srcLink.HasDeferredLink,
                "The deferred link entry was not removed after the link was fully migrated");
        }

        /// <summary>
        /// Scenario10: Link added to both source and target with different comment
        /// Expected result: No-op
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Link added to both source and target with different comment")]
        public void Linking_WIT_LinksAddedWithDifferentComments()
        {
            // Link to workItem1 which is migrated
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            MigrationWorkItem workItem2 = CreateAndMigrateWorkItem(true);

            // Add equivalent links
            MigrationLink srcLink = workItem2.LinkSourceWorkItemTo(workItem1);
            srcLink.Link.Comment = "Source comment";
            MigrationLink dstLink = workItem2.LinkDestinationWorkItemTo(workItem1);
            dstLink.Link.Comment = "Destination comment";

            // Migrate: Should be a no-op
            workItem2.Migrate(true);
        }

        /// <summary>
        /// Scenario11: Link deleted from both sides
        /// Expected result: No-op
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Link deleted from both sides")]
        public void Linking_WIT_LinkDeletedFromBothSides()
        {
            // Link to workItem1 which is migrated
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            MigrationWorkItem workItem2 = CreateMigrationWorkItem(false);
            MigrationLink srcLink = workItem2.LinkSourceWorkItemTo(workItem1);
            workItem2.Migrate(true);
            
            // Delete link from both sides
            srcLink.DeleteLink();
            srcLink.DeleteReflectedLinks();

            // Migrate: should be no-op
            Assert.IsFalse(workItem2.Migrate(true), "A no-op was expected, but the work items were rev'ed");
        }

        /// <summary>
        /// Scenario12: Change links conflict reaction to Master and delete a migrated link from the source and target sides
        /// Expected result: Default policy is Union; Link remains on both sides when deleted from source; Link deleted from both when deleted from target
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Change links conflict reaction to Master and delete a migrated link from the source and target sides")]
        public void Linking_WIT_LinkConflictReactionPolicy()
        {
            // Default link conflict reaction policy should be: Union
            Assert.IsTrue(MigrationWorkItem.LinksConflictReaction == WitConflictReaction.Union,
                "The default links conflict reaction policy is not 'Union'");

            // Start with an already migrated work item with a link (Source side = Left/Tfs/Target)
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, Side.Left);
            MigrationWorkItem targetWorkItem = CreateAndMigrateWorkItem(true);
            MigrationLink migLink = workItem1.LinkSourceWorkItemTo(targetWorkItem);
            workItem1.Migrate(true);

            // Change the policy to: Master
            MigrationWorkItem.LinksConflictReaction = WitConflictReaction.Master;

            // Delete link from right-side: Should remain on both sides
            migLink.DeleteReflectedLinks();
            migLink.ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            workItem1.Migrate(true);

            // Delete link from left-side: Should be deleted from both sides
            migLink.DeleteLink();
            workItem1.Migrate(true);
        }
    }
}
