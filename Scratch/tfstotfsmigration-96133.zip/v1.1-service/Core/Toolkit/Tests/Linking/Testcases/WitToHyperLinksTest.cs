//****************************************************************************
// WitToHyperLinksTest.cs
// Owner: nickkirc
//
// Tests for Migrating WorkItems with Hyperlinks.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.Linking
{
    /// <summary>
    /// Tests for WIT-to-Hyperlink linkings
    /// </summary>
    [TestClass]
    public class WitToHyperLinksTest : LinkingTestcaseBase
    {
        /// <summary>
        /// Scenario1: Add a hyperlink and migrate left-to-right
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Add a hyperlink and migrate left-to-right")]
        public void Linking_Hyperlink_BasicLeftToRight()
        {
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, Side.Left);
            workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario2: Add a hyperlink and migrate right-to-left
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Add a hyperlink and migrate right-to-left")]
        public void Linking_Hyperlink_BasicRightToLeft()
        {
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, Side.Right);
            workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario3: Add a hyperlink to the source side of an already migrated work item
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Add a hyperlink to the source side of an already migrated work item")]
        public void Linking_Hyperlink_PostMigrationSourceSide()
        {
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, Side.Right);
            workItem1.Migrate(true);
            workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);
            Assert.IsTrue(workItem1.LinksOutOfSyncEventReceived, "We did not get a links out-of-sync event");
        }

        /// <summary>
        /// Scenario4: Add a hyperlink to the target side of an already migrated work item
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Add a hyperlink to the target side of an already migrated work item")]
        public void Linking_Hyperlink_PostMigrationTargetSide()
        {
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, Side.Right);
            workItem1.Migrate(true);
            workItem1.LinkDestinationWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);
            Assert.IsTrue(workItem1.LinksOutOfSyncEventReceived, "We did not get a links out-of-sync event");
        }

        /// <summary>
        /// Scenario5: Add a hyperlink as well as make other changes in the same revision
        /// Expected result: Link and changes are migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Add a hyperlink as well as make other changes in the same revision")]
        public void Linking_Hyperlink_ChangeWIFieldsAndAddLink()
        {
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(true);
            workItem1.SourceWorkItem["WST.String"] = Guid.NewGuid().ToString();
            workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario6: Add multiple hyperlinks in the same revision
        /// Expected result: Links and changes are migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Add multiple hyperlinks in the same revision")]
        public void Linking_Hyperlink_MultipleLinksInSameRevision()
        {
            // Initial Rev(s)
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(true);

            // Rev 2 - Add 3 hyperlinks
            workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.SourceWorkItem.Save();

            // Rev 3 - Make WI edit
            workItem1.SourceWorkItem["WST.String"] = Guid.NewGuid().ToString();
            workItem1.SourceWorkItem.Save();

            // Rev 4 - Add 2 more hyperlinks
            workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.LinkSourceWorkItemTo(GetUniqueURL());

            // Migrate
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario7: Update link comment on already migrated work item
        /// Expected result: No-op
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Update link comment on already migrated work item")]
        public void Linking_Hyperlink_UpdateCommentPostMigration()
        {
            // Create item with hyperlink and migrate
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false);
            MigrationLink srcSideLink = workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);

            // Change comment on the source side
            srcSideLink.Link.Comment = "Changed comment - source side";
            workItem1.Migrate(true);
            Assert.IsFalse(workItem1.LinksOutOfSyncEventReceived, "We should not have gotten a links out-of-sync event");

            // Change comment on the destination side
            srcSideLink.ReflectedLinks[0].Comment = "Changed comment - destination side";
            workItem1.Migrate(true);
            Assert.IsFalse(workItem1.LinksOutOfSyncEventReceived, "We should not have gotten a links out-of-sync event");
        }

        /// <summary>
        /// Scenario8: Same link added to both source and destination - different comment
        /// Expected result: No-op
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Same link added to both source and destination - different comment")]
        public void Linking_Hyperlink_SameLinkAddedToBothSides()
        {
            // Create item and migrate
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);

            // Add the same URL to both source and destination
            string linkURL = GetUniqueURL();
            MigrationLink srcLink = workItem1.LinkSourceWorkItemTo(linkURL);
            srcLink.Link.Comment = "Source link";
            MigrationLink dstLink = workItem1.LinkDestinationWorkItemTo(linkURL);
            dstLink.Link.Comment = "Destination link";

            // Migrate the work item
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario9: Change already-migrated link comment on both source and destination - different comment
        /// Expected result: No-op
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Change already-migrated link comment on both source and destination - different comment")]
        public void Linking_Hyperlink_ChangeMigratedLinkCommentDifferent()
        {
            // Create item with hyperlink and migrate
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false);
            MigrationLink srcSideLink = workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);

            // Change comment on both sides
            srcSideLink.Link.Comment = "Changed comment - source";
            srcSideLink.ReflectedLinks[0].Comment = "Changed comment - destination";

            // Migrate the work item
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario10: Delete migrated link from source-side
        /// Expected result: Link remains with default policy of Union
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Delete migrated link from source-side")]
        public void Linking_Hyperlink_DeleteMigratedLinkFromSource()
        {
            // Create item with hyperlink and migrate
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false);
            MigrationLink srcSideLink = workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);

            // Remove the link from the source side
            srcSideLink.DeleteLink();
            srcSideLink.ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            MigrationWorkItem.LinksConflictReaction = WitConflictReaction.Union;

            // Migrate the work item
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario11: Delete migrated link from destination-side
        /// Expected result: Link remains with default policy of Union
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Delete migrated link from destination-side")]
        public void Linking_Hyperlink_DeleteMigratedLinkFromDestination()
        {
            // Create item with hyperlink and migrate
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false);
            MigrationLink srcSideLink = workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);

            // Remove the link from the destination side
            srcSideLink.DeleteReflectedLinks();
            srcSideLink.ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            MigrationWorkItem.LinksConflictReaction = WitConflictReaction.Union;

            // Migrate the work item
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario12: Delete migrated link from both sides
        /// Expected result: No-op
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Delete migrated link from both sides")]
        public void Linking_Hyperlink_DeleteMigratedLinkFromBothSides()
        {
            // Create item with hyperlink and migrate
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false);
            MigrationLink srcSideLink = workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);

            // Remove the link from both sides
            srcSideLink.DeleteLink();
            srcSideLink.DeleteReflectedLinks();

            // Migrate the work item and make sure we are on the same rev
            Assert.IsFalse(workItem1.Migrate(true), "Item was rev'd even though no changes were migrated");
        }

        /// <summary>
        /// Scenario13: Delete migrated link on one side and change comments on the other
        /// Expected result: Link remains with new comment on both sides
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Delete migrated link on one side and change comments on the other")]
        public void Linking_Hyperlink_DeleteAndChangeMigratedLinkFromDifferentSides()
        {
            // Create item with hyperlink and migrate
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false);
            MigrationLink srcSideLink = workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            workItem1.Migrate(true);

            // Change comment on source side and Remove the link from the destination side
            srcSideLink.DeleteReflectedLinks();
            srcSideLink.Link.Comment = "Changed comment - source side";
            srcSideLink.ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            MigrationWorkItem.LinksConflictReaction = WitConflictReaction.Union;

            // Migrate the work item
            workItem1.Migrate(true);

            // Comment should be the same on both sides
            Assert.AreEqual("Changed comment - source side", srcSideLink.ReflectedLinks[0].Comment,
                "Reflected side comment does not match the source side's");
        }

        /// <summary>
        /// Scenario14: Add links with odd characters (non-standard URLs)
        /// Expected result: Links are migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Add links with odd characters (non-standard URLs)")]
        public void Linking_Hyperlink_NonStandardURLs()
        {
            string[] oddHyperlinks = new string[] {
                "http://testLink",
                "http://ALLCAPSLINK",
                "http://!@#$%^&^&*()-_=+{[}]|\\:;'\",<.>/?`~",
                "non-URL",
                "'",
                "link http://www.microsoft.com http://www.microsoft.com/2, http://www.microsoft.com/3"
            };

            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, Side.Left);
            foreach (string oddURL in oddHyperlinks)
            {
                workItem1.LinkSourceWorkItemTo(oddURL);
            }
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario15: Set linking change policy to throw and trigger a link-out-of-sync event
        /// Expected result: Linking change exception
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Set linking conflict policy to throw and trigger a link conflict")]
        public void Linking_Hyperlink_TriggerLinkChangedException()
        {
            // Set the MigrationWorkItem settings to NOT use events (will throw instead)
            MigrationWorkItem.UsingMigrationEvents = false;
            MigrationWorkItem.LinksConflictReaction = WitConflictReaction.Throw;

            // Create item and migrate
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);

            // Add the same URL to both source and destination
            string linkURL = GetUniqueURL();
            workItem1.LinkSourceWorkItemTo(linkURL);

            // Migrate the work item - the linking conflict reaction policy should trigger a
            // MigrationException which will cause a migration failure event which encapsulates
            // the exception. Since we are using events, we will just expect migration failure
            // which will look for/verify the event.
            workItem1.ExpectingWitMigrationFailure = true;
            workItem1.Migrate(false);
        }
            
        /// <summary>
        /// Scenario16: Test link batching size left to right
        /// Expected result: Links are migrated in the approprite number of revisions
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Test link batching size left to right")]
        public void Linking_Hyperlink_BatchingLeftToRight()
        {
            // Set link-batching limits to 5 (source/Right) and 10 (target/Left)
            ChangeLinksPerUpdate(5, 10);

            // Create a work item (source = target/Left) and add 16 links
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, Side.Left);
            for (int i = 0; i < 16; i++)
            {
                workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            }

            // Migrate the work item
            workItem1.Migrate(true);

            // Check the number of revisions: 
            // Source WI (target/Left) should just have the original 1
            // Destination WI (source/Right) should have 4 (16 divided by 5, rounded up)
            Assert.AreEqual(1, workItem1.SourceWorkItem.Revision, "Number of source-side revisions differs");
            Assert.AreEqual(4, workItem1.DestinationWorkItem.Revision, "Number of destination-side revisions differs");
        }

        /// <summary>
        /// Scenario17: Test link batching size right to left
        /// Expected result: Links are migrated in the approprite number of revisions
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Test link batching size right to left")]
        public void Linking_Hyperlink_BatchingRightToLeft()
        {
            // Set link-batching limits to 15 (source/Right) and 2 (target/Left)
            ChangeLinksPerUpdate(15, 2);

            // Create a work item (source = source/Right) and add 15 links
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, Side.Right);
            for (int i = 0; i < 15; i++)
            {
                workItem1.LinkSourceWorkItemTo(GetUniqueURL());
            }

            // Migrate the work item
            workItem1.Migrate(true);

            // Check the number of revisions: 
            // Source WI (source/Right) should just have the original 1
            // Destination WI (target/Left) should have 8 (15 divided by 2, rounded up)
            Assert.AreEqual(1, workItem1.SourceWorkItem.Revision, "Number of source-side revisions differs");
            Assert.AreEqual(8, workItem1.DestinationWorkItem.Revision, "Number of destination-side revisions differs");
        }
    }
}
