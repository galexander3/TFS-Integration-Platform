//****************************************************************************
// WitToMixedLinksTest.cs
// Owner: nickkirc
//
// Tests for Migrating WorkItems with links to multiple types of items.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.Linking
{
    /// <summary>
    /// Tests for WIT to mixed links linkings
    /// </summary>
    [TestClass]
    public class WitToMixedLinksTest : LinkingTestcaseBase
    {
        /// <summary>
        /// Constructor: Version control session needed for WIT-to-Mixed tests
        /// </summary>
        public WitToMixedLinksTest() : base()
        {
            VCSessionNeeded = true;
        }

        /// <summary>
        /// Link given work item to all different types of items
        /// </summary>
        /// <param name="migWorkItem">Work item to add links to</param>
        public void LinkToMultipleItemTypes(MigrationWorkItem migWorkItem)
        {
            // Link to hyperlinks
            for (int i = 0; i < 3; i++)
            {
                migWorkItem.LinkSourceWorkItemTo(GetUniqueURL());
            }

            // Link to work items
            for (int i = 0; i < 2; i++)
            {
                MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
                migWorkItem.LinkSourceWorkItemTo(workItem1);
            }

            // Link to changesets
            for (int i = 0; i < 2; i++)
            {
                migWorkItem.LinkSourceWorkItemTo(CreateAndMigrateChangeset(migWorkItem.SourceSide),
                    MigrationLinkResult.MigratedSuccessfully);
            }

            // Link to VC items
            for (int i = 0; i < 2; i++)
            {
                migWorkItem.LinkSourceWorkItemTo(CreateAndMigrateVcItem(true, migWorkItem.SourceSide),
                    MigrationLinkResult.MigratedSuccessfully);
            }
        }

        /// <summary>
        /// Scenario1: Create multiple types of links with one deferred WIT link
        /// Expected result: wit link deferral � other links migrated successfully
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Create multiple types of links with one deferred WIT link")]
        public void Linking_Mixed_WITLinkDeferral()
        {
            // Start with an already migrated work item
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            LinkToMultipleItemTypes(workItem1);

            // Add a link to a non-migrated work item and migrate the link
            MigrationWorkItem workItem2 = CreateMigrationWorkItem(true);
            MigrationLink migLink = workItem1.LinkSourceWorkItemTo(workItem2, MigrationLinkResult.Deferred);
            workItem1.Migrate(true);

            // Migrate the deferred link target and make sure the link is now fully migrated
            migLink.ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            workItem2.Migrate(true);
            workItem1.VerifyLinkMigration();
        }

        /// <summary>
        /// Scenario2: Create multiple types of links with one deferred changeset link
        /// Expected result: changeset link deferral � other links migrated successfully
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Create multiple types of links with one deferred changeset link")]
        public void Linking_Mixed_ChangesetLinkDeferral()
        {
            // Start with an already migrated work item
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            LinkToMultipleItemTypes(workItem1);

            // Add a link to a non-migrated changeset and migrate the link
            MigrationChangeset migChangeset = CreateChangeset(workItem1.SourceSide);
            MigrationLink migLink = workItem1.LinkSourceWorkItemTo(migChangeset, MigrationLinkResult.Deferred);
            workItem1.Migrate(true);

            // Migrate the deferred link target and make sure the link is now fully migrated
            migLink.ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            MigrationWorkspace.MigrateAllVCItems();
            workItem1.ProcessDeferredLinks(true);
        }

        /// <summary>
        /// Scenario3: End-to-End: Multiple links created/deleted/modified to each side, and attachments added also
        /// Expected result: Successful migration
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("End-to-End: Multiple links created/deleted/modified to each side, and attachments added also")]
        public void Linking_Mixed_EndToEnd()
        {
            // Migrate: Rev 1
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false);
            LinkToMultipleItemTypes(workItem1);
            workItem1.AddAttachments(workItem1.SourceSide, 4);
            workItem1.Migrate(true);

            // Add more and migrate: Rev 2
            LinkToMultipleItemTypes(workItem1);
            workItem1.AddAttachments(workItem1.SourceSide, 4);
            workItem1.ExpectingAttachmentConflict = true;
            workItem1.Migrate(true);
            workItem1.ExpectingAttachmentConflict = false;

            // Link to another migrated WI and migrate link
            MigrationWorkItem workItem2 = CreateAndMigrateWorkItem(true);
            MigrationLink migLink = workItem1.LinkSourceWorkItemTo(workItem2);
            workItem1.Migrate(true);

            // Now delete the WIT link on the source and add another on the destination
            MigrationWorkItem workItem3 = CreateAndMigrateWorkItem(true);
            migLink.DeleteLink();
            migLink.DeleteReflectedLinks();
            workItem1.LinkDestinationWorkItemTo(workItem3);
            workItem1.Migrate(true);
        }
    }
}
