//****************************************************************************
// WitToExternalLinksTest.cs
// Owner: nickkirc
//
// Tests for Migrating WorkItems with external links.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.Linking
{
    /// <summary>
    /// Tests for WIT-to-Hyperlink linkings
    /// </summary>
    [TestClass]
    public class WitToExternalLinksTest : LinkingTestcaseBase
    {
        /// <summary>
        /// Scenario1: Create a workitem with an external link and migrate (left to right)
        /// Expected result: Successful migration
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a workitem with an external link left to right")]
        public void Linking_External_BasicLtoR()
        {
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, Side.Left);
            workItem1.LinkSourceWorkItemToExternal("test1");
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario2: Create a workitem with an external link and migrate (right to left)
        /// Expected result: Successful migration
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a workitem with an external link right to left")]
        public void Linking_External_BasicRtoL()
        {
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, Side.Right);
            workItem1.LinkSourceWorkItemToExternal("test1");
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario3: Add an external link to an already migrated WI and migrate (left to right)
        /// Expected result: Successful migration
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Add an external link to an already migrated WI and migrate left to right")]
        public void Linking_External_PostMigrationLtoR()
        {
            DefaultSourceSide = Side.Left;
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            workItem1.LinkSourceWorkItemToExternal("test1");
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario4: Add an external link to an already migrated WI and migrate (right to left)
        /// Expected result: Successful migration
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Add an external link to an already migrated WI and migrate right to left")]
        public void Linking_External_PostMigrationRtoL()
        {
            DefaultSourceSide = Side.Right;
            MigrationWorkItem workItem1 = CreateAndMigrateWorkItem(true);
            workItem1.LinkSourceWorkItemToExternal("test1");
            workItem1.Migrate(true);
        }
    }
}
