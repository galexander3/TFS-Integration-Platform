//****************************************************************************
// WitToVcLinkingTest.cs
// Owner: nickkirc
//
// Tests for Migrating WorkItems with links to version controlled items.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.TeamFoundation.VersionControl.Common;

namespace Tests.Linking
{
    /// <summary>
    /// Tests for WIT-to-VC linkings
    /// </summary>
    [TestClass]
    public class WitToVcLinkingTest : LinkingTestcaseBase
    {
        /// <summary>
        /// Constructor: Version control session needed for WIT-to-VC tests
        /// </summary>
        public WitToVcLinkingTest() : base()
        {
            VCSessionNeeded = true;
        }

        /// <summary>
        /// Create a new work item, link it to the given changeset, and migrate the work item
        /// </summary>
        /// <param name="changeset">Changeset to link new work item to</param>
        /// <param name="expectedResult">Expected link migration result</param>
        /// <returns>MigrationWorkItem</returns>
        protected MigrationWorkItem LinkNewWorkItemAndMigrate(MigrationChangeset changeset, MigrationLinkResult expectedResult)
        {
            // Create a work item, link to the changeset, and migrate
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, changeset.SourceSide);
            workItem1.LinkSourceWorkItemTo(changeset, expectedResult);
            workItem1.Migrate(true);
            return workItem1;
        }

        /// <summary>
        /// Create a new work item, link it to the given vc item, and migrate the work item
        /// </summary>
        /// <param name="vcItem">VC Item to link new work item to</param>
        /// <param name="expectedResult">Expected link migration result</param>
        /// <returns>MigrationWorkItem</returns>
        protected MigrationWorkItem LinkNewWorkItemAndMigrate(MigrationVcItem vcItem, MigrationLinkResult expectedResult)
        {
            // Create a work item, link to the changeset, and migrate
            MigrationWorkItem workItem1 = CreateMigrationWorkItem(false, vcItem.SourceSide);
            workItem1.LinkSourceWorkItemTo(vcItem, expectedResult);
            workItem1.Migrate(true);
            return workItem1;
        }

        /// <summary>
        /// Migrate link to a partially migrated changeset, fully migrate the changeset, and migrate
        /// the link again - should result in dual destination-side links
        /// </summary>
        /// <returns>MigrationWorkItem with a MigrationLink with 1 source and 2 dst-side links</returns>
        protected MigrationWorkItem GetIncrementallyMigratedChangesetLink()
        {
            // Link to partially migrated changeset
            MigrationChangeset changeset1 = CreatePartiallyMigratedChangeset(DefaultSourceSide);
            MigrationWorkItem workItem1 = LinkNewWorkItemAndMigrate(changeset1, MigrationLinkResult.Partial);

            // Migrate rest of item - should result in 2 actual links
            MigrationWorkspace.MigrateAllVCItems();
            workItem1.MigrationLinks[0].ExpectedResult = MigrationLinkResult.MultipleDestinationLinks;
            workItem1.ProcessDeferredLinks(true);

            // Make sure the deferred entry is removed
            workItem1.ProcessDeferredLinks(false);
            Assert.IsFalse(workItem1.MigrationLinks[0].HasDeferredLink,
                "The deferred link entry was not removed after the link was fully migrated");

            return workItem1;
        }

        /// <summary>
        /// Scenario1: Migrate a link to a completely-migrated changeset Left-To-Right
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a completely-migrated changeset left-to-right")]
        public void Linking_VC_CompletelyMigratedChangeSetLtoR()
        {
            MigrationChangeset changeset1 = CreateAndMigrateChangeset(Side.Left);
            LinkNewWorkItemAndMigrate(changeset1, MigrationLinkResult.MigratedSuccessfully);
        }

        /// <summary>
        /// Scenario2: Migrate a link to a completely-migrated changeset Right-to-Left
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a completely-migrated changeset right-to-left")]
        public void Linking_VC_CompletelyMigratedChangeSetRtoL()
        {
            MigrationChangeset changeset1 = CreateAndMigrateChangeset(Side.Right);
            LinkNewWorkItemAndMigrate(changeset1, MigrationLinkResult.MigratedSuccessfully);
        }

        /// <summary>
        /// Scenario3: Migrate a link to a completely migrated VC item (latest version)
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a completely migrated VC item (latest version)")]
        public void Linking_VC_LinkToMigratedVcItemLatest()
        {
            MigrationVcItem vcItem1 = CreateAndMigrateVcItem(true, DefaultSourceSide);
            LinkNewWorkItemAndMigrate(vcItem1, MigrationLinkResult.MigratedSuccessfully);
        }

        /// <summary>
        /// Scenario4: Migrate a link to a completely migrated VC item (specific version)
        /// Expected result: Link is migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a completely migrated VC item (specific version)")]
        public void Linking_VC_LinkToMigratedVcItemSpecific()
        {
            MigrationVcItem vcItem1 = CreateAndMigrateVcItem(false, DefaultSourceSide);
            LinkNewWorkItemAndMigrate(vcItem1, MigrationLinkResult.MigratedSuccessfully);
        }

        /// <summary>
        /// Scenario5: Migrate a link to an unmigrated VC item then migrate VC item (latest version)
        /// Expected result: Link is deferred then actual
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to an unmigrated VC item then migrate VC item (latest version)")]
        public void Linking_VC_LinkToUnMigratedVcItemLatest()
        {
            Linking_VC_LinkToUnMigratedVcItem(true);
        }

        /// <summary>
        /// Scenario6: Migrate a link to an unmigrated VC item then migrate VC item (specific version)
        /// Expected result: Link is deferred then actual
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to an unmigrated VC item then migrate VC item (specific version)")]
        public void Linking_VC_LinkToUnMigratedVcItemSpecific()
        {
            Linking_VC_LinkToUnMigratedVcItem(false);
        }

        /// <summary>
        /// Linking_VC_LinkToUnMigratedVcItem test cases based on specified latest/specific input
        /// </summary>
        /// <param name="useLatest">If true, link VC item to the latest version, otherwise specific</param>
        public void Linking_VC_LinkToUnMigratedVcItem(bool useLatest)
        {
            // Link to unmigrated item - get deferred link
            MigrationVcItem vcItem = CreateVcItem(useLatest, DefaultSourceSide);
            MigrationWorkItem workItem1 = LinkNewWorkItemAndMigrate(vcItem, MigrationLinkResult.Deferred);

            // Migrate vc item - should now get actual link
            MigrationWorkspace.MigrateAllVCItems();
            workItem1.MigrationLinks[0].ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            workItem1.ProcessDeferredLinks(true);

            // Make sure the deferred entry is removed
            workItem1.ProcessDeferredLinks(false);
            Assert.IsFalse(workItem1.MigrationLinks[0].HasDeferredLink,
                "The deferred link entry was not removed after the link was fully migrated");
        }

        /// <summary>
        /// Scenario7: Migrate a link to a partially-migrated VC changeset
        /// Expected result: Link is partially migrated (1 actual + 1 deferred)
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a partially-migrated VC changeset")]
        [Ignore]
        public void Linking_VC_LinkToPartiallyMigratedChangeset()
        {
            Assert.Inconclusive("Orcas Bug 256333: Toolkit does not handle partially migrated changesets.");
            MigrationChangeset changeset1 = CreatePartiallyMigratedChangeset(DefaultSourceSide);
            LinkNewWorkItemAndMigrate(changeset1, MigrationLinkResult.Partial);
        }

        /// <summary>
        /// Scenario8: Migrate a link to a not-yet-migrated VC changeset, then migrate changeset
        /// Expected result: Deferred link, then actual link
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a not-yet-migrated VC changeset, then migrate changeset")]
        public void Linking_VC_LinkToUnMigratedChangeset()
        {
            // Migrate to unmigrated changeset and get deferred link
            MigrationChangeset changeset1 = CreateChangeset();
            MigrationWorkItem workItem1 = LinkNewWorkItemAndMigrate(changeset1, MigrationLinkResult.Deferred);

            // Migrate changeset and get actual link
            MigrationWorkspace.MigrateAllVCItems();
            workItem1.MigrationLinks[0].ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            workItem1.ProcessDeferredLinks(true);

            // Make sure the deferred entry is removed
            workItem1.ProcessDeferredLinks(false);
            Assert.IsFalse(workItem1.MigrationLinks[0].HasDeferredLink,
                "The deferred link entry was not removed after the link was fully migrated");
        }

        /// <summary>
        /// Scenario9: Delete a link in the target system after migration with 'Master' conflict policy
        /// Expected result: Link deletion is mirrored
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Delete a link in the target system after migration")]
        [Ignore]
        public void Linking_VC_DeleteChangesetLinkFromTarget()
        {
            Assert.Inconclusive("Orcas Bug 253591: Deletion of non-WIT links is not supported.");
            
            // Migrate with link to migrated changeset
            MigrationChangeset changeset1 = CreateAndMigrateChangeset(Side.Left);
            MigrationWorkItem workItem1 = LinkNewWorkItemAndMigrate(changeset1, MigrationLinkResult.MigratedSuccessfully);

            // Delete target-side link
            MigrationWorkItem.LinksConflictReaction = WitConflictReaction.Master;
            workItem1.MigrationLinks[0].DeleteLink();
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario10: Update a link comment in both source and target - different
        /// Expected result: No-op
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Update a link comment in both source and target - different")]
        public void Linking_VC_ConflictingCommentsPostMigration()
        {
            // Migrate with link to migrated changeset
            MigrationChangeset changeset1 = CreateAndMigrateChangeset(DefaultSourceSide);
            MigrationWorkItem workItem1 = LinkNewWorkItemAndMigrate(changeset1, MigrationLinkResult.MigratedSuccessfully);

            // Change comments - conflicting
            MigrationLink migLink = workItem1.MigrationLinks[0];
            migLink.Link.Comment = "Source-side comment change";
            migLink.ReflectedLinks[0].Comment = "Destination-side comment change";
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario11: Migrate a link to a partially-migrated changeset, then migrate rest of changeset
        /// Expected result: Partial (actual + deferred) then 2 actual links
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Migrate a link to a partially-migrated changeset, then migrate rest of changeset")]
        [Ignore]
        public void Linking_VC_PartialThenFullChangesetMigration()
        {
            Assert.Inconclusive("Orcas Bug 256333: Toolkit does not handle partially migrated changesets.");
            GetIncrementallyMigratedChangesetLink();
        }

        /// <summary>
        /// Scenario12: Delete first link of an incrementally-migrated changeset
        /// Expected result: Links remain with Union policy
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Delete actual link of a partially-migrated changeset")]
        [Ignore]
        public void Linking_VC_DeleteIncrementalLinkFirst()
        {
            Assert.Inconclusive("Orcas Bug 256333: Toolkit does not handle partially migrated changesets.");
            MigrationWorkItem workItem1 = GetIncrementallyMigratedChangesetLink();
            workItem1.MigrationLinks[0].DeleteReflectedLink(0);
            workItem1.MigrationLinks[0].ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            MigrationWorkItem.LinksConflictReaction = WitConflictReaction.Union;
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario13: Delete last link of an incrementally-migrated changeset
        /// Expected result: Links remain with Union policy
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Delete deferred link of a partially-migrated changeset")]
        [Ignore]
        public void Linking_VC_DeleteIncrementalLinkLast()
        {
            Assert.Inconclusive("Orcas Bug 256333: Toolkit does not handle partially migrated changesets.");
            MigrationWorkItem workItem1 = GetIncrementallyMigratedChangesetLink();
            workItem1.MigrationLinks[0].DeleteReflectedLink(1);
            workItem1.MigrationLinks[0].ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            MigrationWorkItem.LinksConflictReaction = WitConflictReaction.Union;
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario14: Delete source link after an incrementally-migrated changeset
        /// Expected result: Links remain with Union policy
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Delete source link after a partially-migrated changeset")]
        [Ignore]
        public void Linking_VC_DeleteIncrementalLinkSource()
        {
            Assert.Inconclusive("Orcas Bug 256333: Toolkit does not handle partially migrated changesets.");
            MigrationWorkItem workItem1 = GetIncrementallyMigratedChangesetLink();
            workItem1.MigrationLinks[0].DeleteLink();
            workItem1.MigrationLinks[0].ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            MigrationWorkItem.LinksConflictReaction = WitConflictReaction.Union;
            workItem1.Migrate(true);
        }

        /// <summary>
        /// Scenario15: Delete source link after a partially-migrated changeset
        /// Expected result: Links remain with Union policy
        /// </summary>
        [TestMethod, Priority(1), Owner("nickkirc")]
        [Description("Delete source link after a partially-migrated changeset")]
        [Ignore]
        public void Linking_VC_DeletePartialLinkSource()
        {
            Assert.Inconclusive("Orcas Bug 256333: Toolkit does not handle partially migrated changesets.");
            MigrationChangeset changeset1 = CreatePartiallyMigratedChangeset(DefaultSourceSide);
            MigrationWorkItem workItem1 = LinkNewWorkItemAndMigrate(changeset1, MigrationLinkResult.Partial);
            workItem1.MigrationLinks[0].DeleteLink();
            workItem1.MigrationLinks[0].ExpectedResult = MigrationLinkResult.MigratedSuccessfully;
            MigrationWorkItem.LinksConflictReaction = WitConflictReaction.Union;
            workItem1.Migrate(true);
        }
    }
}
