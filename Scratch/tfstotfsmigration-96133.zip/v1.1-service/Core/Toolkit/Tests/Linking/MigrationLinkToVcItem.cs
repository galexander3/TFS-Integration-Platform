//****************************************************************************
// MigrationLinkToVcItem.cs
// Owner: nickkirc
//
// Encapsulates a WIT-to-VCItem link used in migration tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Class to encapsulate a WIT-to-VCItem link used in migration
    /// </summary>
    public class MigrationLinkToVcItem : MigrationLink
    {
        protected const string c_registeredVcItemLinkTypeName = "Source Code File";

        protected MigrationVcItem m_tgtVcItem;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="parentMigrationWorkItem">The migration work item that is the source of the link</param>
        /// <param name="srcWorkItemSide">Side that the source of the link is on</param>
        /// <param name="tgtVersionedItem">The versioned item to link to</param>
        /// <param name="expectedResult">The link's expected migration result</param>
        public MigrationLinkToVcItem(MigrationWorkItem parentMigrationWorkItem, Side srcWorkItemSide,
                MigrationVcItem tgtVersionedItem, MigrationLinkResult expectedResult)
            : base(new ExternalLink(
                parentMigrationWorkItem[srcWorkItemSide].Store.RegisteredLinkTypes[c_registeredVcItemLinkTypeName],
                tgtVersionedItem.SourceArtifactUri), 
                c_defaultWITLinkComment, parentMigrationWorkItem, srcWorkItemSide, expectedResult)
        {
            m_tgtVcItem = tgtVersionedItem;
        }

        /// <summary>
        /// Compare this link with another and return true if they are equivalent
        /// </summary>
        /// <param name="srcSideLink">Link1</param>
        /// <param name="sideOfLink1">Side of Link1</param>
        /// <returns>True if the same, otherwise false</returns>
        protected override bool IsLinkEquivalent(Link link1, Side sideOfLink1)
        {
            // Make sure the links are of the same type
            if (link1.BaseType.CompareTo(BaseLinkType.ExternalLink) == 0)
            {
                // May have to convert this link's vc item if not on the same side
                string thisLinkTargetUri = m_tgtVcItem.SourceArtifactUri;
                if (sideOfLink1 != m_srcWorkItemSide)
                {
                    thisLinkTargetUri = m_tgtVcItem.DestinationArtifactUri;
                }
                if (thisLinkTargetUri != null)
                {
                    return ((ExternalLink)link1).LinkedArtifactUri.CompareTo(thisLinkTargetUri) == 0;
                }
            }
            return false;
        }

        /// <summary>
        /// Compare the link with the given target URI and return true if they are the same
        /// </summary>
        /// <param name="targetUri">Target URI of the link</param>
        /// <returns>True if the same, otherwise false</returns>
        public override bool IsLinkEquivalent(string targetUri)
        {
            return targetUri.CompareTo(m_tgtVcItem.SourceArtifactUri) == 0;
        }

        /// <summary>
        /// ToString
        /// </summary>
        /// <returns>Description of migration link</returns>
        public override string ToString()
        {
            return "Link from workitem " + SourceWorkItem.Id.ToString() + " (on " +
                m_srcWorkItemSide.ToString() + " side) to versioned item: " + m_tgtVcItem.ToString();
        }
    }
}
