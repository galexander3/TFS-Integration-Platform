//****************************************************************************
// LinkingTestcaseBase.cs
// Owner: nickkirc
//
// Base class for linking tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Tests.Framework;
using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.Linking
{
    /// <summary>
    /// Base class for Linking tests
    /// </summary>
    public abstract class LinkingTestcaseBase
    {
        protected static Random s_random = new Random();

        private LinkMigrationSettings m_linkMigSettings = null;
        private Side m_defaultSrcSide = Side.Left;
        private bool m_vcSessionNeeded = false;
        private MigrationVcWorkspace m_vcWorkspace = null;
        private TestContext testContextInstance;

        /// <summary>
        /// Default side of source work item
        /// </summary>
        protected Side DefaultSourceSide { get { return m_defaultSrcSide; } set { m_defaultSrcSide = value; } }

        /// <summary>
        /// VC Migration Workspace
        /// </summary>
        protected MigrationVcWorkspace MigrationWorkspace 
        { 
            get 
            {
                if (m_vcWorkspace == null)
                {
                    throw new Exception("MigrationWorkspace is null. VCSessionNeeded should be set to True " +
                        "before testcase Init to have a workspace automatically generated");
                }
                return m_vcWorkspace; 
            } 
        }

        /// <summary>
        /// Used by testcase Init - If true, MigrationWorkspace is allocated
        /// </summary>
        protected bool VCSessionNeeded
        {
            get { return m_vcSessionNeeded; }
            set { m_vcSessionNeeded = value; }
        }

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        /// <summary>
        /// Shared test initialization function.
        /// </summary>
        [TestInitialize]
        public void Init()
        {
            // Set the default source side
            m_defaultSrcSide = (s_random.Next() % 2 == 0) ? Side.Left : Side.Right;

            // Setup the WIT migration settings
            TestEnvironment.Load();
            m_linkMigSettings = LinkMigrationSettings.GetInstance(
                TestEnvironment.MasterServer, TestEnvironment.DependentServer,
                TestEnvironment.MasterProject, TestEnvironment.DependentProject, 
                TestEnvironment.SqlServer, TestEnvironment.LinkingWitSessionName,
                TestEnvironment.LinkingVcSessionName);

            // Get a VC workspace if needed
            if (m_vcSessionNeeded)
            {
                // Get a workspace for the project
                m_vcWorkspace = new MigrationVcWorkspace(
                    TestEnvironment.MasterServer, TestEnvironment.DependentServer,
                    TestEnvironment.MasterProject, TestEnvironment.DependentProject, 
                    m_linkMigSettings.VCSessionName, m_linkMigSettings.LinkingWorkspaceName);

                // Set the VC migration mapping to only include the linking test subfolders
                m_linkMigSettings.ChangeVCMapping(m_vcWorkspace.SourceWorkingServerPath, 
                    m_vcWorkspace.TargetWorkingServerPath);
            }

            // Setup use of MigrationWorkItem's (with events)
            MigrationWorkItem.WITSessionName = m_linkMigSettings.WITSessionName;
            MigrationWorkItem.UsingMigrationEvents = true;
        }

        /// <summary>
        /// Test cleanup function.
        /// </summary>
        [TestCleanup]
        public void Cleanup()
        {
            // Cleanup the migration event handlers and settings
            MigrationWorkItem.UsingMigrationEvents = false;
            m_linkMigSettings = null;

            // Delete any existing workspace
            if (m_vcWorkspace != null)
            {
                m_vcWorkspace.Dispose();
                m_vcWorkspace = null;
            }
        }

        /// <summary>
        /// After migration settings are changed, call this function to re-initialize
        /// the WorkItem and Vc workspace settings.
        /// </summary>
        /// <param name="migSettings">New migration settings to use</param>
        private void RefreshMigrationSettings()
        {
            // After any time the migration settings are reloaded, we will need to re-add any migration
            // event handlers.
            MigrationWorkItem.UsingMigrationEvents = MigrationWorkItem.UsingMigrationEvents;
        }

        #region "Methods"

        /// <summary>
        /// Create a work item on the default source side and migrate.
        /// </summary>
        /// <param name="verifyMigration">If true, then verify the migration</param>
        /// <returns>The migrated work item</returns>
        protected MigrationWorkItem CreateAndMigrateWorkItem(bool verifyMigration)
        {
            MigrationWorkItem workItem = CreateMigrationWorkItem(true);
            workItem.Migrate(verifyMigration);
            return workItem;
        }

        /// <summary>
        /// Create a new work item on the default source side and optionally save some different revisions
        /// </summary>
        /// <param name="saveInitialRevisions">If true, create and save a random number of revisions</param>
        /// <returns>New work item</returns>
        protected MigrationWorkItem CreateMigrationWorkItem(bool saveInitialRevisions)
        {
            return CreateMigrationWorkItem(saveInitialRevisions, m_defaultSrcSide);
        }

        /// <summary>
        /// Create a new work item on the specified source side and optionally save some different revisions
        /// </summary>
        /// <param name="saveInitialRevisions">If true, create and save a random number of revisions</param>
        /// <param name="srcSide">The side to create the source work item on</param>
        /// <returns>New work item</returns>
        protected MigrationWorkItem CreateMigrationWorkItem(bool saveInitialRevisions, Side srcSide)
        {
            int revisions = 0;
            if (saveInitialRevisions)
            {
                revisions = s_random.Next(1, 4);
            }
            return MigrationWorkItem.GetInstance(TestContext.TestName, srcSide, 
                m_linkMigSettings.Projects[srcSide].WorkItemTypes[m_linkMigSettings.TestWorkItemTypeName], 
                m_linkMigSettings.Stores, revisions);
        }

        /// <summary>
        /// Create a changeset and migrate it
        /// </summary>
        /// <param name="srcSide">Side to create changeset on</param>
        /// <returns>Migrated changeset</returns>
        protected MigrationChangeset CreateAndMigrateChangeset(Side srcSide)
        {
            MigrationChangeset newChangeset = CreateChangeset(srcSide);
            MigrationWorkspace.MigrateAllVCItems();
            Assert.AreEqual(1, newChangeset.DestinationChangesets.Count, "Changeset did not migrate: {0}", newChangeset);
            return newChangeset;
        }

        /// <summary>
        /// Create a VC item and migrate it
        /// </summary>
        /// <param name="useLatestRevision">If true, get the latest version - otherwise a specific version</param>
        /// <param name="srcSide">Side to create vc item on</param>
        /// <returns>Migrated VcItem</returns>
        protected MigrationVcItem CreateAndMigrateVcItem(bool useLatestRevision, Side srcSide)
        {
            MigrationVcItem newVcItem = CreateVcItem(useLatestRevision, srcSide);
            MigrationWorkspace.MigrateAllVCItems();
            Assert.IsNotNull(newVcItem.DestinationItem, "VC Item did not migrate: {0}", newVcItem);
            return newVcItem;
        }

        /// <summary>
        /// Create a changeset with some items mapped and some not mapped. Migrate the changeset, then
        /// change the mappings back to the original values
        /// </summary>
        /// <param name="srcSide">Side to create changeset on</param>
        /// <returns>Partially migrated changeset</returns>
        protected MigrationChangeset CreatePartiallyMigratedChangeset(Side srcSide)
        {
            //
            // Create initial changeset
            //

            string subFolderName = "Partial";

            // Create a changeset with items in both the working and subfolder paths
            List<string> foldersForChangeset = new List<string>();
            foldersForChangeset.Add(string.Empty); // root folder
            foldersForChangeset.Add(subFolderName);
            MigrationChangeset migChangeSet = MigrationWorkspace.CreateChangeSet(srcSide, 1, 1, 1, foldersForChangeset);

            //
            // Modify mappings
            //

            // Remember previous mapping
            string prevSourceMapping = MigrationWorkspace.VCSession.Mappings[0].Source;
            string prevTargetMapping = MigrationWorkspace.VCSession.Mappings[0].Target;

            // Only map a subfolder
            string newSourceMapping = MigrationWorkspace.SourceWorkingServerPath + "/" + subFolderName;
            string newTargetMapping = MigrationWorkspace.TargetWorkingServerPath + "/" + subFolderName;

            // Mapped folder must exist on the server
            m_linkMigSettings.ChangeVCMapping(newSourceMapping, newTargetMapping);

            //
            // Migrate - Partially mapped
            //

            MigrationWorkspace.MigrateAllVCItems();
            Assert.AreEqual(1, migChangeSet.DestinationChangesets.Count, 
                "Partial migration changeset was not migrated: {0}", migChangeSet);

            //
            // Restore mappings
            //

            m_linkMigSettings.ChangeVCMapping(prevSourceMapping, prevTargetMapping);
            RefreshMigrationSettings();

            return migChangeSet;
        }

        /// <summary>
        /// Create a random changeset on the default source side
        /// </summary>
        /// <returns>New Changeset</returns>
        protected MigrationChangeset CreateChangeset()
        {
            return CreateChangeset(m_defaultSrcSide);
        }

        /// <summary>
        /// Create a random changeset on the specified side
        /// </summary>
        /// <param name="srcSide">The side to create the changeset on</param>
        /// <returns>New Changeset</returns>
        protected MigrationChangeset CreateChangeset(Side srcSide)
        {
            return MigrationWorkspace.CreateChangeSet(srcSide,
                s_random.Next(1, 4), s_random.Next(1, 3), s_random.Next(0, 2));
        }

        /// <summary>
        /// Create a random VC item on the default source side
        /// </summary>
        /// <returns>New VC item</returns>
        protected MigrationVcItem CreateVcItem(bool useLatestRevision)
        {
            return CreateVcItem(useLatestRevision, m_defaultSrcSide);
        }

        /// <summary>
        /// Create a random VC item on the specified side
        /// </summary>
        /// <param name="useLatestRevision">If true, get the latest version - otherwise a specific version</param>
        /// <param name="srcSide">The side to create the VC item on</param>
        /// <returns>New VC item</returns>
        protected MigrationVcItem CreateVcItem(bool useLatestRevision, Side srcSide)
        {
            return MigrationWorkspace.CreateVcItem(srcSide, useLatestRevision);
        }

        /// <summary>
        /// Get a unique URL
        /// </summary>
        /// <returns></returns>
        protected string GetUniqueURL()
        {
            return "http://www.microsoft.com/" + Guid.NewGuid().ToString() + "/";
        }

        /// <summary>
        /// Change the linksPerUpdate value for the source and target servers
        /// </summary>
        /// <param name="srcLinksPerUpdate">Number of links per update on source (0 = no change)</param>
        /// <param name="tgtLinksPerUpdate">Number of links per update on target (0 = no change)</param>
        protected void ChangeLinksPerUpdate(int srcLinksPerUpdate, int tgtLinksPerUpdate)
        {
            m_linkMigSettings.ChangeLinksPerUpdate(srcLinksPerUpdate, tgtLinksPerUpdate);
            RefreshMigrationSettings();
        }

        #endregion
    }
}
