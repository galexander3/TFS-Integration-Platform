//****************************************************************************
// MigrationLink.cs
// Owner: nickkirc
//
// Encapsulates a link used in migration tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Globalization;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;
using Microsoft.TeamFoundation.Migration.Linking;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Possible results for migrating a link
    /// </summary>
    public enum MigrationLinkResult
    {
        NotMigrated,
        MigratedSuccessfully,
        Deferred,
        Deleted,
        Partial,
        MultipleDestinationLinks
    }

    /// <summary>
    /// Class to encapsulate a link used in migration
    /// </summary>
    public abstract class MigrationLink
    {
        protected MigrationWorkItem m_parentMigrationWorkItem;
        protected Side m_srcWorkItemSide;
        protected MigrationLinkResult m_expectedResult;

        protected const string c_defaultWITLinkComment = "Test WIT Link []()<>/\\!@#$*";
        protected const string c_defaultHyperlinkComment = "Test Hyperlink =+-_{}':;\"";
        protected const string c_defaultVCLinkComment = "Test VC Link \t\r\n^&";
        protected const string c_defaultExternalLinkComment = "Test External Link (to Test Result)";

        #region "Properties"
        /// <summary>
        /// The link's source work item
        /// </summary>
        public WorkItem SourceWorkItem { get { return m_parentMigrationWorkItem[m_srcWorkItemSide]; } }

        /// <summary>
        /// Side that link's work item is on
        /// </summary>
        public Side SideOfLink { get { return m_srcWorkItemSide; } }

        /// <summary>
        /// The expected migration result
        /// </summary>
        public virtual MigrationLinkResult ExpectedResult
        { 
            get 
            { 
                return m_expectedResult; 
            }
            set
            {
                m_expectedResult = value;
            }
        }

        /// <summary>
        /// The current link (or link equivalent) on the work item's list of links
        /// </summary>
        public Link Link
        {
            get
            {
                foreach (Link workItemLink in SourceWorkItem.Links)
                {
                    if (IsLinkEquivalent(workItemLink, m_srcWorkItemSide))
                    {
                        return workItemLink;
                    }
                }
                return null;
            }
        }

        /// <summary>
        /// The link on the opposite side (if migrated)
        /// </summary>
        public List<Link> ReflectedLinks
        {
            get
            {
                List<Link> reflectedLinks = new List<Link>();
                foreach (Link workItemLink in ReflectedWorkItem.Links)
                {
                    if (IsLinkEquivalent(workItemLink, ReflectionSide))
                    {
                        reflectedLinks.Add(workItemLink);
                    }
                }
                return reflectedLinks;
            }
        }

        /// <summary>
        /// The opposite side of the work item
        /// </summary>
        public Side ReflectionSide { get { return !m_srcWorkItemSide; } }

        /// <summary>
        /// The opposite work item
        /// </summary>
        public WorkItem ReflectedWorkItem { get { return m_parentMigrationWorkItem[ReflectionSide]; } }

        /// <summary>
        /// Is this link deferred on the reflection side
        /// </summary>
        public virtual bool HasDeferredLink 
        { 
            get 
            {
                // Get deferred links for the link's source work item
                ReadOnlyCollection<ILink> deferredLinks = MigrationWorkItem.LinkEngine.GetDeferredLinks(
                     m_srcWorkItemSide == Side.Left ? SystemType.Tfs : SystemType.Other,
                     m_parentMigrationWorkItem[m_srcWorkItemSide].Uri.ToString());

                // See if we have a match
                foreach (ILink deferredLink in deferredLinks)
                {
                    if (IsLinkEquivalent(deferredLink.TargetUri))
                    {
                        return true;
                    }
                }
                return false;
            } 
        }

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="link">The link</param>
        /// <param name="linkComment">Comment for new link</param>
        /// <param name="parentMigrationWorkItem">The migration work item that is the source of the link</param>
        /// <param name="srcWorkItemSide">Side that the source of the link is on</param>
        /// <param name="expectedResult">The link's expected migration result</param>
        protected MigrationLink(Link link, string linkComment, MigrationWorkItem parentMigrationWorkItem, 
            Side srcWorkItemSide, MigrationLinkResult expectedResult)
        {
            m_parentMigrationWorkItem = parentMigrationWorkItem;
            m_srcWorkItemSide = srcWorkItemSide;
            m_expectedResult = expectedResult;

            link.Comment = linkComment;
            m_parentMigrationWorkItem[m_srcWorkItemSide].Links.Add(link);
        }

        /// <summary>
        /// Determine if the given link is one of the source-side or reflected-side links for this item
        /// </summary>
        /// <param name="link1">Link to check</param>
        /// <returns>True if it is a source/reflected-side link</returns>
        public bool IsLinkEquivalent(Link link1)
        {
            if (Link == link1)
            {
                return true;
            }
            foreach (Link reflectedLink in ReflectedLinks)
            {
                if (reflectedLink == link1)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Compare the link with the given target URI and return true if they are the same
        /// </summary>
        /// <param name="targetUri">Target URI of the link</param>
        /// <returns>True if the same, otherwise false</returns>
        public abstract bool IsLinkEquivalent(string targetUri);

        /// <summary>
        /// Compare this link with another and return true if they are equivalent
        /// </summary>
        /// <param name="srcSideLink">Link1</param>
        /// <param name="sideOfLink1">Side of Link1</param>
        /// <returns>True if the same, otherwise false</returns>
        protected abstract bool IsLinkEquivalent(Link link1, Side sideOfLink1);

        /// <summary>
        /// Delete the link
        /// </summary>
        public void DeleteLink()
        {
            SourceWorkItem.Links.Remove(Link);
            m_expectedResult = MigrationLinkResult.Deleted;
        }

        /// <summary>
        /// Delete the reflected links
        /// </summary>
        public void DeleteReflectedLinks()
        {
            foreach (Link reflectedLink in ReflectedLinks)
            {
                ReflectedWorkItem.Links.Remove(reflectedLink);
            }
            m_expectedResult = MigrationLinkResult.Deleted;
        }

        /// <summary>
        /// Delete a single reflected link (by index)
        /// <param name="linkToDeleteIndex">Index of destination link to delete</param>
        /// </summary>
        public void DeleteReflectedLink(int linkToDeleteIndex)
        {
            List<Link> reflectedlinks = ReflectedLinks;
            if (linkToDeleteIndex >= reflectedlinks.Count)
            {
                throw new Exception("Invalid linkToDeleteIndex");
            }
            ReflectedWorkItem.Links.Remove(reflectedlinks[linkToDeleteIndex]);
            m_expectedResult = MigrationLinkResult.Deleted;
        }

        /// <summary>
        /// Verify the link migration result with what was expected
        /// </summary>
        public void VerifyMigrationResult()
        {
            switch (m_expectedResult)
            {
                case MigrationLinkResult.Deferred:
                    Assert.IsNotNull(Link, "Source link was deleted, but we expected deferral: {0}", this);
                    Assert.AreEqual(0, ReflectedLinks.Count, "We expected link to be deferred, but it was migrated: {0}", this);
                    Assert.IsTrue(HasDeferredLink, "There is no deferred link entry for link: {0}", this);
                    break;

                case MigrationLinkResult.Deleted:
                    Assert.IsNull(Link, "We expected link to be deleted, but it is still on the {1} side: {0}", this, m_srcWorkItemSide);
                    Assert.AreEqual(0, ReflectedLinks.Count, "We expected link to be deleted, but it is still on the reflected/{1} side: {0}", this, ReflectionSide);
                    break;

                case MigrationLinkResult.MigratedSuccessfully:
                    Assert.IsNotNull(Link, "Source link was deleted, but we expected successful migration: {0}", this);
                    Assert.AreEqual(1, ReflectedLinks.Count, "Link was not migrated as expected: {0}", this);
                    break;

                case MigrationLinkResult.NotMigrated:
                    Assert.IsNotNull(Link, "Source link was deleted, but we expected not migrated: {0}", this);
                    Assert.AreEqual(0, ReflectedLinks.Count, "We expected link not to be migrated, but it was: {0}", this);
                    break;

                case MigrationLinkResult.Partial:
                    Assert.IsNotNull(Link, "Source link was deleted, but we expected partial migration: {0}", this);
                    Assert.AreEqual(1, ReflectedLinks.Count, "We expected link to be partially migrated, but none of it was migrated: {0}", this);
                    Assert.IsTrue(HasDeferredLink, "We expected link to be partially migrated, but there is no deferred link: {0}", this);
                    break;

                case MigrationLinkResult.MultipleDestinationLinks:
                    Assert.IsNotNull(Link, "Source link was deleted, but we expected multi-link migration: {0}", this);
                    Assert.IsTrue(ReflectedLinks.Count > 1, "Link did not have multiple destination links as expected: {0}", this);
                    break;

                default:
                    Assert.Fail("Unknown link migration result type");
                    break;
            }
        }
    }
}
