//****************************************************************************
// MigrationChangeset.cs
// Owner: nickkirc
//
// Encapsulates a changeset used in migration tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Class to encapsulate a Changeset used in migration
    /// </summary>
    public class MigrationChangeset
    {
        Side m_srcSide = Side.Left;
        Changeset m_srcChangeset = null;
        List<Changeset> m_dstChangesets = new List<Changeset>();
        MigrationVcWorkspace m_vcWorkspace = null;

        /// <summary>
        /// Changeset's source-side
        /// </summary>
        public Side SourceSide { get { return m_srcSide; } }

        /// <summary>
        /// Changeset's destination-side
        /// </summary>
        public Side DestinationSide { get { return (m_srcSide == Side.Left) ? Side.Right : Side.Left; } }

        /// <summary>
        /// Source-side changeset
        /// </summary>
        public Changeset SourceChangeset { get { return m_srcChangeset; } }

        /// <summary>
        /// Destination-side changeset
        /// </summary>
        public List<Changeset> DestinationChangesets
        {
            get
            {
                m_dstChangesets = m_vcWorkspace.GetReflectedChangesets(m_srcChangeset, m_srcSide);
                return m_dstChangesets;
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="srcChangeset">Changeset</param>
        /// <param name="vcWorkspace">VC Workspace</param>
        /// <param name="srcSide">Side of changeset</param>
        public MigrationChangeset(Changeset srcChangeset, MigrationVcWorkspace vcWorkspace, Side srcSide)
        {
            m_srcChangeset = srcChangeset;
            m_vcWorkspace = vcWorkspace;
            m_srcSide = srcSide;
        }

        /// <summary>
        /// Migration changeset description
        /// </summary>
        /// <returns>Description</returns>
        public override string ToString()
        {
            string description = String.Format(
                "Migration changeset: Source[Id={0} Side={1} CreationDate={2} NumChanges={3} Comment={4} Owner={5}]",
                m_srcChangeset.ChangesetId, m_srcSide, m_srcChangeset.CreationDate, m_srcChangeset.Changes.Length, 
                m_srcChangeset.Comment, m_srcChangeset.Owner);

            foreach (Changeset dstChangeset in m_dstChangesets)
            {
                description += String.Format(" Destination[Id={0} Side={1} CreationDate={2} NumChanges={3} Comment={4} Owner={5}]",
                    dstChangeset.ChangesetId, DestinationSide, dstChangeset.CreationDate, dstChangeset.Changes.Length,
                    dstChangeset.Comment, dstChangeset.Owner);
            }
            return description;
        }
    }
}
