//****************************************************************************
// MigrationWorkItem.cs
// Owner: nickkirc
//
// Encapsulates a work item used in migration tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.IO;

using Tests.Framework;
using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Class to encapsulate a work item used in the migration tests
    /// </summary>
    public class MigrationWorkItem
    {
        #region "Members"
        
        protected WorkItem m_srcWorkItem = null;
        protected WorkItem m_dstWorkItem = null;
        protected Side m_srcSide = Side.Left;
        protected bool m_expectingWitMigrationFailure = false;
        protected bool m_expectingAttachmentConflict = false;
        protected bool m_attachmentConflictOcurred = false;
        protected bool m_linksOutOfSyncEventReceived = false;
        protected int m_numLinkDeferrals = 0;
        protected List<MigrationLink> m_migrationLinks = new List<MigrationLink>();
        protected int m_srcPreMigrationRevs = 0;
        protected int m_dstPreMigrationRevs = 0;
        protected Pair<WorkItemStore> m_witStores = null;

        protected static MigrationWitEvents s_migrationEvents = null;
        protected static string s_witSessionName = "TestSession1";
        protected static Random s_random = new Random();

        #endregion

        #region "Properties

        /// <summary>
        /// Side of source work item
        /// </summary>
        public Side SourceSide { get { return m_srcSide; } }

        /// <summary>
        /// Side of source work item
        /// </summary>
        public Side DestinationSide { get { return !m_srcSide; } }

        /// <summary>
        /// Source-side work item
        /// </summary>
        public WorkItem SourceWorkItem { get { return m_srcWorkItem; } }

        /// <summary>
        /// Destination-side work item. Throws if work item has not yet been migrated
        /// </summary>
        public WorkItem DestinationWorkItem
        { 
            get 
            {
                if (m_dstWorkItem != null)
                {
                    return m_dstWorkItem;
                }
                else
                {
                    throw new Exception("Work Item has not been migrated");
                }
            }
        }

        /// <summary>
        /// Return the work item from the specified side
        /// </summary>
        /// <param name="workItemSide">Side of the migration</param>
        /// <returns>The work item from the specified side</returns>
        public WorkItem this[Side workItemSide] { get { return (workItemSide == m_srcSide) ? m_srcWorkItem : DestinationWorkItem; } }

        /// <summary>
        /// True if the item has already migrated
        /// </summary>
        public bool HasMigrated { get { return (m_dstWorkItem != null); } }

        /// <summary>
        /// True if the links changed event was received during migration
        /// </summary>
        public bool LinksOutOfSyncEventReceived { get { return m_linksOutOfSyncEventReceived; } }

        /// <summary>
        /// Do we expect a link conflict to occur?
        /// </summary>
        public bool ExpectingAttachmentConflict
        {
            get { return m_expectingAttachmentConflict; }
            set { m_expectingAttachmentConflict = value; }
        }

        /// <summary>
        /// Do we expect the WIT migration to fail?
        /// </summary>
        public bool ExpectingWitMigrationFailure
        {
            get { return m_expectingWitMigrationFailure; }
            set { m_expectingWitMigrationFailure = value; }
        }

        /// <summary>
        /// List of migration links
        /// </summary>
        public List<MigrationLink> MigrationLinks { get { return m_migrationLinks; } }

        /// <summary>
        /// Returns the WIT session
        /// </summary>
        protected static WorkItemTrackingSession WITSession
        {
            get { return MigrationConfiguration.Current.Wit.Sessions[s_witSessionName]; }
        }

        /// <summary>
        /// Returns the Linking Engine for the WIT Session
        /// </summary>
        public static ILinkEngine LinkEngine
        {
            get { return WITSession.LinkEngine; }
        }

        /// <summary>
        /// Get/Sets the static WIT session name
        /// </summary>
        public static string WITSessionName
        {
            get { return s_witSessionName; }
            set { s_witSessionName = value; }
        }

        /// <summary>
        /// Whether or not we're using migration event handlers
        /// </summary>
        public static bool UsingMigrationEvents 
        { 
            get { return s_migrationEvents != null && s_migrationEvents.EventHandlersAdded; }
            set
            {
                // Remove previous event handlers (if there were any)
                if (s_migrationEvents != null)
                {
                    s_migrationEvents.RemoveEventHandlers();
                    s_migrationEvents = null;
                }
                if (value)
                {
                    s_migrationEvents = MigrationWitEvents.GetInstance(WITSession);
                }
            }
        }

        /// <summary>
        /// The WIT session's link-conflict reaction policy
        /// </summary>
        public static WitConflictReaction LinksConflictReaction
        {
            get { return WITSession.Policies.LinksConflict.Reaction; }
            set { WITSession.Policies.LinksConflict.Reaction = value; }
        }

        #endregion

        #region "Methods"

        /// <summary>
        /// Constructor: Create the source work item
        /// </summary>
        /// <param name="title">Work item title</param>
        /// <param name="srcSide">Side of source work item</param>
        /// <param name="witType">Work item type of new source work item to create</param>
        /// <param name="witStores">Pair of left/right work item stores</param>
        /// <param name="savedRevisions">Num of revs to create and save (0 = only create initial rev - don't save)</param>
        protected MigrationWorkItem(string title, Side srcSide, WorkItemType witType, 
            Pair<WorkItemStore> witStores, int savedRevisions)
        {
            m_srcWorkItem = witType.NewWorkItem();
            m_srcSide = srcSide;
            m_witStores = witStores;

            // Special case for 0 revisions: Create 1 revision but don't save it
            bool saveChanges = true;
            if (savedRevisions < 1)
            {
                saveChanges = false;
                savedRevisions = 1;
            }

            // create all desired revisions
            for (int rev = 1; rev <= savedRevisions; rev++)
            {
                m_srcWorkItem[CoreField.Title] = title + " (" + rev.ToString() + ")";
                m_srcWorkItem["WST.String"] = Guid.NewGuid().ToString();
                m_srcWorkItem["WST.Int"] = s_random.Next();
                m_srcWorkItem["WST.InternalRevision"] = rev;

                if (saveChanges)
                {
                    m_srcWorkItem.Save();
                }
            }
        }

        /// <summary>
        /// Create a work item for migration with a single saved revision (must call Init first)
        /// </summary>
        /// <param name="title">Work item title</param>
        /// <param name="srcSide">Side of source work item</param>
        /// <param name="witType">Work item type of new source work item to create</param>
        /// <param name="witStores">Pair of left/right work item stores</param>
        /// <returns>New MigrationWorkItem</returns>
        public static MigrationWorkItem GetInstance(string title, Side srcSide, WorkItemType witType,
            Pair<WorkItemStore> witStores)
        {
            return GetInstance(title, srcSide, witType, witStores, 1);
        }

        /// <summary>
        /// Creates a work item for migration with the specified source side and number of revisions
        /// (must call Init first)
        /// </summary>
        /// <param name="title">Work item title</param>
        /// <param name="srcSide">Side of source work item</param>
        /// <param name="witType">Work item type of new source work item to create</param>
        /// <param name="witStores">Pair of left/right work item stores</param>
        /// <param name="savedRevisions">Num of revs to create and save (0 = only create initial rev - don't save)</param>
        /// <returns>New MigrationWorkItem</returns>
        public static MigrationWorkItem GetInstance(string title, Side srcSide, WorkItemType witType, 
            Pair<WorkItemStore> witStores, int savedRevisions)
        {
            return new MigrationWorkItem(title, srcSide, witType, witStores, savedRevisions);
        }

        /// <summary>
        /// Migrate the work items and optionally verify that the migration succeeded
        /// </summary>
        /// <param name="verify">If true, verify the migration</param>
        /// <param name="itemsToMigrate">List of migration work items to migrate</param>
        /// <returns>True if either the source or destination items were rev'd. False = No-op</returns>
        public static bool Migrate(bool verify, params MigrationWorkItem[] itemsToMigrate)
        {
            bool anyItemReved = false;

            // Reset any previous events
            if (UsingMigrationEvents)
            {
                s_migrationEvents.ResetEvents();
            }

            // Perform pre-migration steps
            foreach (MigrationWorkItem itemToMigrate in itemsToMigrate)
            {
                itemToMigrate.PreMigrationSteps();
            }

            // Migrate by Synchronize method (TODO: add other methods later)
            MigrateBySyncMethod(itemsToMigrate);

            // Perform post-migration steps
            foreach (MigrationWorkItem itemToMigrate in itemsToMigrate)
            {
                bool itemReved = itemToMigrate.PostMigrationSteps(verify);
                anyItemReved = anyItemReved || itemReved;
            }

            return anyItemReved;
        }

        /// <summary>
        /// Migrates work items by passing their IDs to Synchronize
        /// </summary>
        /// <param name="itemsToMigrate">MigrationWorkItems to migrate</param>
        protected static void MigrateBySyncMethod(params MigrationWorkItem[] itemsToMigrate)
        {
            // Synchronize any items from
            Side[] sidesToMigrate = new Side[] { Side.Left, Side.Right };
            foreach (Side side in sidesToMigrate)
            {
                // Get list of items from this side
                List<string> itemIdList = new List<string>(itemsToMigrate.Length);
                foreach (MigrationWorkItem itemToMigrate in itemsToMigrate)
                {
                    if (itemToMigrate.m_srcSide == side)
                    {
                        itemIdList.Add(Convert.ToString(itemToMigrate.m_srcWorkItem.Id, CultureInfo.InvariantCulture));
                    }
                }
                if (itemIdList.Count > 0)
                {
                    WITSession.Synchronize(side == Side.Left ? SystemType.Tfs : SystemType.Other, itemIdList.ToArray());
                }
            }
        }

        /// <summary>
        /// Migrate the work item and optionally verify that the migration succeeded
        /// </summary>
        /// <param name="verify">If true, verify the migration</param>
        /// <returns>True if either the source or destination items were rev'd. False = No-op</returns>
        public bool Migrate(bool verify)
        {
            return Migrate(verify, this);
        }

        /// <summary>
        /// Prepare the work item for migration
        /// </summary>
        protected void PreMigrationSteps()
        {
            // Save the work item(s) if there are unsaved changes
            if (m_srcWorkItem.IsDirty)
            {
                m_srcWorkItem.Save();
            }
            if (m_dstWorkItem != null && m_dstWorkItem.IsDirty)
            {
                m_dstWorkItem.Save();
            }

            // Remember the number of revisions before the migration
            m_srcPreMigrationRevs = m_srcWorkItem.Revision;
            m_dstPreMigrationRevs = (m_dstWorkItem == null) ? 0 : m_dstWorkItem.Revision;

            // Clear any existing attachment/link conflicts in our list
            m_attachmentConflictOcurred = false;
            m_linksOutOfSyncEventReceived = false;
            m_numLinkDeferrals = 0;
        }

        /// <summary>
        /// Set the destination work item and verify the migration if desired
        /// </summary>
        /// <param name="verify">If true, verify the migration</param>
        /// <returns>True if either the source or destination items were rev'd. False = No-op</returns>
        protected bool PostMigrationSteps(bool verify)
        {
            if (UsingMigrationEvents)
            {
                // Verify that we got a start migration event
                if (verify)
                {
                    Assert.IsTrue(s_migrationEvents.GetWitMigrationStartEventArgs(this).Count > 0,
                        "We did not get a migration start event");
                }

                // Check for migration failure
                List<WorkItemMigrationEventArgs> migFailedArgs = s_migrationEvents.GetWitMigrationFailedEventArgs(this);
                if (migFailedArgs.Count > 0)
                {
                    Assert.IsTrue(m_expectingWitMigrationFailure, "WIT migration failed unexpectedly: {0};{1}",
                        migFailedArgs[0].Description, migFailedArgs[0].Exception);
                    return false;
                }
                else
                {
                    Assert.IsFalse(m_expectingWitMigrationFailure, "WIT migration did not fail as expected");
                }

                // Verify that we got a migration completed event
                if (verify)
                {
                    Assert.IsTrue(s_migrationEvents.GetWitMigrationCompleteEventArgs(this).Count > 0,
                        "We did not get a migration complete event to match the migration start event");
                }
            }

            // Get the reflected work item
            m_dstWorkItem = GetReflectedWorkItem(m_srcWorkItem, m_srcSide);
            Assert.IsNotNull(m_dstWorkItem, "Could not find reflected work item");

            m_srcWorkItem.SyncToLatest();
            m_dstWorkItem.SyncToLatest();
            
            // Check for conflicts and link deferrals
            if (UsingMigrationEvents)
            {
                m_linksOutOfSyncEventReceived = s_migrationEvents.GetLinkConflictEventArgs(this).Count > 0;
                m_attachmentConflictOcurred = s_migrationEvents.GetAttachmentConflictEventArgs(this).Count > 0;
                m_numLinkDeferrals = s_migrationEvents.GetLinksOutOfSyncEvents(this).Count;
            }

            // verify the migration if desired
            if (verify)
            {
                VerifyMigration();
            }

            // Detect any changes in revisions
            return (m_srcPreMigrationRevs != m_srcWorkItem.Revision || m_dstPreMigrationRevs != m_dstWorkItem.Revision);
        }

        /// <summary>
        /// Verify that everything was migrated as expected
        /// </summary>
        public void VerifyMigration()
        {
            // Compare the source and destination work item fields and attachments
            CompareWorkItems(m_srcWorkItem, DestinationWorkItem);

            // Compare attachments
            if (m_attachmentConflictOcurred)
            {
                Assert.IsTrue(m_expectingAttachmentConflict, "There was an unexpected attachment conflict");
            }
            else
            {
                Assert.IsFalse(m_expectingAttachmentConflict, "We expected an attachment conflict but did not get one");
                CompareAttachments(m_srcWorkItem, DestinationWorkItem);
            }

            // Make sure the links migrated properly
            VerifyLinkMigration(true);
        }

        /// <summary>
        /// Get the reflected work item from a migration
        /// </summary>
        /// <param name="workItemId">Work item to look for</param>
        /// <param name="sideOfWorkItem">Side that workItem is on</param>
        /// <returns>The equivalent work item on the other side, or null if not found</returns>
        protected WorkItem GetReflectedWorkItem(WorkItem workItem, Side sideOfWorkItem)
        {
            string srcId = Convert.ToString(workItem.Id, CultureInfo.InvariantCulture);
            SystemType sourceSystem = (sideOfWorkItem == Side.Left) ? SystemType.Tfs : SystemType.Other;
            string[] reflectionResults = WITSession.FindReflections(sourceSystem, srcId);
            if (reflectionResults.Length != 1 || reflectionResults[0] == null)
            {
                return null;
            }
            else
            {
                return m_witStores[!sideOfWorkItem].GetWorkItem(Convert.ToInt32(reflectionResults[0]));
            }
        }

        /// <summary>
        /// Add attachments to the specified work item side
        /// </summary>
        /// <param name="side">Side of work item to add attachments to</param>
        /// <param name="numAttachments">Number of attachments to add</param>
        public void AddAttachments(Side side, int numAttachments)
        {
            for (int i = 0; i < numAttachments; i++)
            {
                string tempFileName = Path.GetTempFileName();
                TestUtils.CreateRandomFile(tempFileName, s_random.Next(1, 100));
                this[side].Attachments.Add(new Attachment(tempFileName, "Linking tests attachment"));
            }
        }

        #endregion

        #region "WIT Comparison Functions"

        /// <summary>
        /// Compares two work items.
        /// </summary>
        /// <param name="item1">Work item 1</param>
        /// <param name="item2">Work item 2</param>
        protected static void CompareWorkItems(WorkItem item1, WorkItem item2)
        {
            // For now, just compare the final revision. A migrated work item
            // will not necessarily contain equivalent revisions - such as when
            // the work item has been changed on both sides, or when attachments
            // and links are added.
            CompareRevision(item1.Fields, item2.Fields);
        }

        /// <summary>
        /// Compares fields in a single revision.
        /// </summary>
        /// <param name="src">Source fields</param>
        /// <param name="dst">Target fields</param>
        protected static void CompareRevision(FieldCollection src, FieldCollection dst)
        {
            Assert.AreEqual(src.Count, dst.Count, "Different number of fields between the revisions being compared");
            for (int j = 0; j < src.Count; j++)
            {
                Field srcField = src[j];

                if (IsComparableField(srcField))
                {
                    Field dstField = dst.GetById(srcField.Id);

                    Assert.IsTrue(
                        CompareValues(GetFieldValue(srcField), GetFieldValue(dstField)),
                        "Different values for the " + srcField.Name + "field.");
                }
            }
        }

        /// <summary>
        /// Compares values according to TFS rules.
        /// </summary>
        /// <param name="value1">Value 1</param>
        /// <param name="value2">Value 2</param>
        /// <returns>True if values are identical</returns>
        protected static bool CompareValues(object value1, object value2)
        {
            bool isNull1 = IsNullValue(value1);
            bool isNull2 = IsNullValue(value2);

            if (isNull1 ^ isNull2)
            {
                return false;
            }
            else if (isNull1 && isNull2)
            {
                return true;
            }
            else
            {
                return value1.Equals(value2);
            }
        }

        /// <summary>
        /// Checks whether value is null according to TFS standards.
        /// </summary>
        /// <param name="value">Value</param>
        /// <returns>True if null/empty</returns>
        protected static bool IsNullValue(object value)
        {
            return value == null || value is DBNull || value is string && ((string)value).Length == 0;
        }

        /// <summary>
        /// Tells whether the field should be compared.
        /// </summary>
        /// <param name="f">Field</param>
        /// <returns>True if the field should be compared</returns>
        protected static bool IsComparableField(Field f)
        {
            FieldDefinition fd = f.FieldDefinition;

            switch (fd.Id)
            {
                case (int)CoreField.AreaPath:
                case (int)CoreField.IterationPath:
                    return true;

                case (int)CoreField.AreaId:
                case (int)CoreField.IterationId:
                case (int)CoreField.ChangedDate:
                case (int)CoreField.CreatedDate:
                    return false;

                default:
                    return !fd.IsComputed && fd.IsEditable;
            }
        }

        /// <summary>
        /// Gets normalized field's value.
        /// </summary>
        /// <param name="f">Field</param>
        /// <returns>Value</returns>
        protected static object GetFieldValue(Field f)
        {
            if (f.Id == (int)CoreField.AreaPath || f.Id == (int)CoreField.IterationPath)
            {
                // Get rid of the project part
                string val = (string)f.Value;
                int idx = val.IndexOf('/');

                return idx == -1 ? string.Empty : val.Substring(idx + 1);
            }
            return f.Value;
        }

        /// <summary>
        /// Compares the attachments on two work items.
        /// </summary>
        /// <param name="item1">Item 1</param>
        /// <param name="item2">Item 2</param>
        protected static void CompareAttachments(WorkItem item1, WorkItem item2)
        {
            Assert.AreEqual(item1.AttachedFileCount, item2.AttachedFileCount, "Different number of file attachments!  " + item1.AttachedFileCount.ToString() + " vs. " + item2.AttachedFileCount.ToString());

            List<IMigrationFileAttachment> list1 = ConvertToMigrationFileAttachmentList(item1.Attachments);
            List<IMigrationFileAttachment> list2 = ConvertToMigrationFileAttachmentList(item2.Attachments);

            FileAttachmentAnalyzer analyzer = FileAttachmentAnalyzer.Create(
                AttachmentComparisonAttributes.All,
                new Pair<List<IMigrationFileAttachment>>(list1, list2));

            Assert.IsTrue(analyzer.InSync, "File attachments are not in sync!");
        }

        /// <summary>
        /// Converts WIT OM Attachment Collection into a list of IMigrationFileAttachment
        /// so we can reuse the comparison logic in the toolkit.
        /// </summary>
        /// <param name="coll">Attachment Collection</param>
        /// <returns>List of IMigrationFileAttachment</returns>
        protected static List<IMigrationFileAttachment> ConvertToMigrationFileAttachmentList(AttachmentCollection coll)
        {
            List<IMigrationFileAttachment> list = new List<IMigrationFileAttachment>();
            foreach (Attachment a in coll)
            {
                list.Add(new TfsMigrationFileAttachment(a, null));
            }
            return list;
        }

        /// <summary>
        /// Checks history of changes for the given field.
        /// </summary>
        /// <param name="item">Work item</param>
        /// <param name="field">Field name</param>
        /// <param name="values">Chain of values</param>
        protected static void CheckFieldHistory(WorkItem item, string field, params object[] values)
        {
            Assert.AreEqual(item.Revisions.Count, values.Length, "Wrong number of revisions!");

            for (int i = 0; i < item.Revisions.Count; i++)
            {
                Assert.IsTrue(CompareValues(values[i], item.Revisions[i][field]), "Field values do not match!");
            }
        }

        #endregion

        #region "Linking Methods"

        /// <summary>
        /// Verifies that the migration of links went as expected (syncs work items first).
        /// </summary>
        public void VerifyLinkMigration()
        {
            m_srcWorkItem.SyncToLatest();
            if (m_dstWorkItem != null)
            {
                m_dstWorkItem.SyncToLatest();
            }
            VerifyLinkMigration(false);
        }

        /// <summary>
        /// Verifies that the migration of links went as expected.
        /// </summary>
        /// <param name="checkEvents">If true, verify the link migration events</param>
        protected void VerifyLinkMigration(bool checkEvents)
        {
            // Check our MigrationLinks
            foreach (MigrationLink migLink in m_migrationLinks)
            {
                migLink.VerifyMigrationResult();
            }

            // Verify the number of link conflict and deferral events
            if (checkEvents && UsingMigrationEvents)
            {
                Assert.AreEqual(ExpectedLinksWithResult(MigrationLinkResult.Deferred), m_numLinkDeferrals,
                    "We did not get the expected number of link deferral events");
            }

            // Check other links - make sure we didn't get an extra one
            foreach (Link link in m_srcWorkItem.Links)
            {
                Assert.IsNotNull(GetMigrationLinkFromLink(link),
                    "Unexpected extra link ({0}) found in source work item links.", link);
            }
            foreach (Link link in m_dstWorkItem.Links)
            {
                Assert.IsNotNull(GetMigrationLinkFromLink(link),
                    "Unexpected extra link ({0}) found in destination work item links.", link);
            }
        }

        /// <summary>
        /// Get a MigrationLink that is associated with the give Link
        /// </summary>
        /// <param name="link">Link to find MigrationLink of</param>
        /// <returns>MigrationLink if found, otherwise null</returns>
        protected MigrationLink GetMigrationLinkFromLink(Link link)
        {
            foreach (MigrationLink migLink in m_migrationLinks)
            {
                if (migLink.IsLinkEquivalent(link))
                {
                    return migLink;
                }
            }
            return null;
        }

        /// <summary>
        /// Deterimine how many (unique) links we expect to have the specified result
        /// </summary>
        /// <returns>Number of expected (unique) links with the specified result</returns>
        protected int ExpectedLinksWithResult(MigrationLinkResult expectedResultType)
        {
            List<MigrationLink> linksWithResult = new List<MigrationLink>();
            foreach (MigrationLink migLink in m_migrationLinks)
            {
                if (migLink.ExpectedResult == expectedResultType)
                {
                    // Make sure an equivalent link is not already in the list
                    bool foundEquivalentLink = false;
                    foreach (MigrationLink linkWithResult in linksWithResult)
                    {
                        if (migLink.IsLinkEquivalent(linkWithResult.Link))
                        {
                            foundEquivalentLink = true;
                            break;
                        }
                    }

                    // Add if unique
                    if (!foundEquivalentLink)
                    {
                        linksWithResult.Add(migLink);
                    }
                }
            }
            return linksWithResult.Count;
        }

        /// <summary>
        /// Add a link to a work item to the source side
        /// </summary>
        /// <param name="targetWorkItem">Work item to link to</param>
        /// <returns>Added link</returns>
        public MigrationLinkToWit LinkSourceWorkItemTo(MigrationWorkItem targetWorkItem)
        {
            targetWorkItem.LinkToWorkItem(this, MigrationLinkResult.MigratedSuccessfully, m_srcSide);
            return LinkToWorkItem(targetWorkItem, MigrationLinkResult.MigratedSuccessfully, m_srcSide);
        }

        /// <summary>
        /// Add a link to a work item to the source side with the given expected result
        /// </summary>
        /// <param name="targetWorkItem">Work item to link to</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <returns>Added link</returns>
        public MigrationLinkToWit LinkSourceWorkItemTo(MigrationWorkItem targetWorkItem, MigrationLinkResult expectedResult)
        {
            targetWorkItem.LinkToWorkItem(this, expectedResult, m_srcSide);
            return LinkToWorkItem(targetWorkItem, expectedResult, m_srcSide);
        }

        /// <summary>
        /// Add a link to a work item to the destination side
        /// </summary>
        /// <param name="targetWorkItem">Work item to link to</param>
        /// <returns>Added link</returns>
        public MigrationLinkToWit LinkDestinationWorkItemTo(MigrationWorkItem targetWorkItem)
        {
            targetWorkItem.LinkToWorkItem(this, MigrationLinkResult.MigratedSuccessfully, DestinationSide);
            return LinkToWorkItem(targetWorkItem, MigrationLinkResult.MigratedSuccessfully, DestinationSide);
        }

        /// <summary>
        /// Add a link to a work item to the destination side with the given expected result
        /// </summary>
        /// <param name="targetWorkItem">Work item to link to</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <returns>Added link</returns>
        public MigrationLinkToWit LinkDestinationWorkItemTo(MigrationWorkItem targetWorkItem, MigrationLinkResult expectedResult)
        {
            targetWorkItem.LinkToWorkItem(this, expectedResult, DestinationSide);
            return LinkToWorkItem(targetWorkItem, expectedResult, DestinationSide);
        }

        /// <summary>
        /// Link two work items and set the expected result
        /// </summary>
        /// <param name="wiLinkTarget">Target work item to link to</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <param name="sideOfLink">Side of new link</param>
        /// <returns>Added link</returns>
        protected MigrationLinkToWit LinkToWorkItem(MigrationWorkItem wiLinkTarget, MigrationLinkResult expectedResult, Side sideOfLink)
        {
            if (wiLinkTarget[sideOfLink].Id == 0)
            {
                wiLinkTarget[sideOfLink].Save();
            }
            MigrationLinkToWit newLink = new MigrationLinkToWit(this, sideOfLink, wiLinkTarget, expectedResult);
            m_migrationLinks.Add(newLink);
            return newLink;
        }

        /// <summary>
        /// Add a hyperlink to the source side
        /// </summary>
        /// <param name="hyperlinkLocation">Hyperlink location/URL</param>
        /// <returns>Added link</returns>
        public MigrationLinkToHyperlink LinkSourceWorkItemTo(string hyperlinkLocation)
        {
            return LinkToHyperlink(hyperlinkLocation, MigrationLinkResult.MigratedSuccessfully, m_srcSide);
        }

        /// <summary>
        /// Add a hyperlink to the source side with the given expected result
        /// </summary>
        /// <param name="hyperlinkLocation">Hyperlink location/URL</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <returns>Added link</returns>
        public MigrationLinkToHyperlink LinkSourceWorkItemTo(string hyperlinkLocation, MigrationLinkResult expectedResult)
        {
            return LinkToHyperlink(hyperlinkLocation, expectedResult, m_srcSide);
        }

        /// <summary>
        /// Add a hyperlink to the destination side
        /// </summary>
        /// <param name="hyperlinkLocation">Hyperlink location/URL</param>
        /// <returns>Added link</returns>
        public MigrationLinkToHyperlink LinkDestinationWorkItemTo(string hyperlinkLocation)
        {
            return LinkToHyperlink(hyperlinkLocation, MigrationLinkResult.MigratedSuccessfully, DestinationSide);
        }

        /// <summary>
        /// Add a hyperlink to the destination side with the given expected result
        /// </summary>
        /// <param name="hyperlinkLocation">Hyperlink location/URL</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <returns>Added link</returns>
        public MigrationLinkToHyperlink LinkDestinationWorkItemTo(string hyperlinkLocation, MigrationLinkResult expectedResult)
        {
            return LinkToHyperlink(hyperlinkLocation, expectedResult, DestinationSide);
        }

        /// <summary>
        /// Add a hyperlink to a work item
        /// </summary>
        /// <param name="hyperlinkLocation">Hyperlink location/URL</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <param name="sideOfLink">Side of new link</param>
        /// <returns>Added link</returns>
        protected MigrationLinkToHyperlink LinkToHyperlink(string hyperlinkLocation, MigrationLinkResult expectedResult, Side sideOfLink)
        {
            MigrationLinkToHyperlink newLink = new MigrationLinkToHyperlink(this, sideOfLink, hyperlinkLocation, expectedResult);
            m_migrationLinks.Add(newLink);
            return newLink;
        }

        /// <summary>
        /// Add a Changeset link to the source side with the given expected result
        /// </summary>
        /// <param name="changesetId">Id of changeset to link to</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <returns>Added link</returns>
        public MigrationLinkToChangeset LinkSourceWorkItemTo(MigrationChangeset changeset, MigrationLinkResult expectedResult)
        {
            return LinkToChangeset(changeset, expectedResult, SourceSide);
        }

        /// <summary>
        /// Add a Changeset link to the destination side with the given expected result
        /// </summary>
        /// <param name="changesetId">Id of changeset to link to</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <returns>Added link</returns>
        public MigrationLinkToChangeset LinkDestinationWorkItemTo(MigrationChangeset changeset, MigrationLinkResult expectedResult)
        {
            return LinkToChangeset(changeset, expectedResult, DestinationSide);
        }

        /// <summary>
        /// Add a Changeset link
        /// </summary>
        /// <param name="changeset">Changeset to link to</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <param name="sideOfLink">Side of new link</param>
        /// <returns>Added link</returns>
        protected MigrationLinkToChangeset LinkToChangeset(MigrationChangeset changeset, MigrationLinkResult expectedResult, Side sideOfLink)
        {
            MigrationLinkToChangeset newLink = new MigrationLinkToChangeset(this, sideOfLink, changeset, expectedResult);
            m_migrationLinks.Add(newLink);
            return newLink;
        }

        /// <summary>
        /// Add a VC item link to the source side with the given expected result
        /// </summary>
        /// <param name="vcItem">Version controlled item to link to</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <returns>Added link</returns>
        public MigrationLinkToVcItem LinkSourceWorkItemTo(MigrationVcItem vcItem, MigrationLinkResult expectedResult)
        {
            return LinkToVcItem(vcItem, expectedResult, SourceSide);
        }

        /// <summary>
        /// Add a VC item link to the destination side with the given expected result
        /// </summary>
        /// <param name="vcItem">Version controlled item to link to</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <returns>Added link</returns>
        public MigrationLinkToVcItem LinkDestinationWorkItemTo(MigrationVcItem vcItem, MigrationLinkResult expectedResult)
        {
            return LinkToVcItem(vcItem, expectedResult, DestinationSide);
        }

        /// <summary>
        /// Add a VC Item link
        /// </summary>
        /// <param name="vcItem">Version controlled item to link to</param>
        /// <param name="expectedResult">Expected migration result</param>
        /// <param name="sideOfLink">Side of new link</param>
        /// <returns>Added link</returns>
        protected MigrationLinkToVcItem LinkToVcItem(MigrationVcItem vcItem, MigrationLinkResult expectedResult, Side sideOfLink)
        {
            MigrationLinkToVcItem newLink = new MigrationLinkToVcItem(this, sideOfLink, vcItem, expectedResult);
            m_migrationLinks.Add(newLink);
            return newLink;
        }

        /// <summary>
        /// Add an external link to the source side
        /// </summary>
        /// <param name="externalUri">External Uri to link to</param>
        /// <returns>Added link</returns>
        public MigrationLinkToExternal LinkSourceWorkItemToExternal(string externalUri)
        {
            MigrationLinkToExternal newLink = new MigrationLinkToExternal(this, SourceSide, externalUri, 
                MigrationLinkResult.MigratedSuccessfully);
            m_migrationLinks.Add(newLink);
            return newLink;
        }

        /// <summary>
        /// Process any deferred links and re-verify the link migration
        /// </summary>
        /// <param name="verify">If true, re-verify the link migration</param>
        public void ProcessDeferredLinks(bool verify)
        {
            WITSession.ProcessDeferredLinks();
            if (verify)
            {
                VerifyLinkMigration();
            }
        }

        #endregion
    }
}
