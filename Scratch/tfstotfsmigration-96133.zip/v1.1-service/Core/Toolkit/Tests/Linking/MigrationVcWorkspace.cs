//****************************************************************************
// MigrationVcWorkspace.cs
// Owner: nickkirc
//
// Encapsulates version controlled operations in migration tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using Tests.Framework;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.TeamFoundation.VersionControl.Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    public class MigrationVcWorkspace : IDisposable
    {
        // By default - allow 60 seconds for a single migration
        protected const int c_defaultMigrationTimeoutMs = 60000;

        protected Pair<TeamFoundationServer> m_tfsServers = null;
        protected Pair<VersionControlServer> m_vcServers = null;
        protected Pair<TeamProject> m_projects = null;
        protected Pair<Workspace> m_workspaces = null;

        protected string m_vcSessionName = string.Empty;
        protected string m_workspaceDirRoot = string.Empty;
        protected string m_subfolderName = string.Empty;

        /// <summary>
        /// The VC Workspaces
        /// </summary>
        public Pair<Workspace> Workspaces { get { return m_workspaces; } }

        /// <summary>
        /// The VC Servers
        /// </summary>
        public Pair<VersionControlServer> VCServers { get { return m_vcServers; } }

        /// <summary>
        /// The VC Session
        /// </summary>
        public VersionControlSession VCSession { get { return MigrationConfiguration.Current.VC.Sessions[m_vcSessionName]; } }

        /// <summary>
        /// Team projects
        /// </summary>
        public Pair<TeamProject> TeamProjects { get { return m_projects; } }

        /// <summary>
        /// Local directory for Source project side
        /// </summary>
        protected string LocalSourceDir { get { return Path.Combine(m_workspaceDirRoot, Path.Combine("source", m_subfolderName)); } }

        /// <summary>
        /// Local directory for Target project side
        /// </summary>
        protected string LocalTargetDir { get { return Path.Combine(m_workspaceDirRoot, Path.Combine("target", m_subfolderName)); } }

        /// <summary>
        /// Source working folder path on server
        /// </summary>
        public string SourceWorkingServerPath { get { return m_projects.Right.ServerItem + "/" + m_subfolderName.Replace('\\', '/'); } }

        /// <summary>
        /// Target working folder path on server
        /// </summary>
        public string TargetWorkingServerPath { get { return m_projects.Left.ServerItem + "/" + m_subfolderName.Replace('\\', '/'); } }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tfsServerName">Target/Left/Master/Tfs server name</param>
        /// <param name="otherServerName">Source/Right/Dependent/Other server name</param>
        /// <param name="tfsProjectName">Target/Left/Master/Tfs project name</param>
        /// <param name="otherProjectName">Source/Right/Dependent/Other project name</param>
        /// <param name="vcSessionName">Name of VersionControl Session</param>
        /// <param name="workspaceName">Name of workspace to create</param>
        public MigrationVcWorkspace(string tfsServerName, string otherServerName, string tfsProjectName, 
            string otherProjectName, string vcSessionName, string workspaceName)
        {
            m_tfsServers = new Pair<TeamFoundationServer>(
                TeamFoundationServerFactory.GetServer(tfsServerName),
                TeamFoundationServerFactory.GetServer(otherServerName));

            m_vcServers = new Pair<VersionControlServer>(
                (VersionControlServer)m_tfsServers.Left.GetService(typeof(VersionControlServer)),
                (VersionControlServer)m_tfsServers.Right.GetService(typeof(VersionControlServer)));

            m_projects = new Pair<TeamProject>(
                m_vcServers.Left.GetTeamProject(tfsProjectName),
                m_vcServers.Right.GetTeamProject(otherProjectName));

            m_workspaces = new Pair<Workspace>(
                CreateWorkspace(m_vcServers.Left, workspaceName + "_Left", Environment.UserName),
                CreateWorkspace(m_vcServers.Right, workspaceName + "_Right", Environment.UserName));

            m_vcSessionName = vcSessionName;

            // Add mappings to project roots
            m_workspaceDirRoot = CreateDirectory(Path.Combine(Path.GetTempPath(), workspaceName));
            m_workspaces.Left.Map(m_projects.Left.ServerItem, CreateDirectory(LocalTargetDir));
            m_workspaces.Right.Map(m_projects.Right.ServerItem, CreateDirectory(LocalSourceDir));

            // Create new subfolders (<ProjectRoot>/LinkingTests/<Timestamp>)
            m_subfolderName = Path.Combine("LinkingTests", DateTime.Now.Ticks.ToString());
            CreateDirectory(LocalSourceDir);
            CreateDirectory(LocalTargetDir);
        }

        /// <summary>
        /// Create a workspace with the given name. If it already exists, delete it first, then add.
        /// </summary>
        /// <param name="vcServer">Version control server for workspace</param>
        /// <param name="workspaceName">Workspace name</param>
        /// <param name="userName">User name for workspace</param>
        /// <returns>Newly created workspace</returns>
        protected Workspace CreateWorkspace(VersionControlServer vcServer, string workspaceName, string userName)
        {
            // Delete existing workspace with this name
            try
            {
                Workspace oldWorkspace = vcServer.GetWorkspace(workspaceName, userName);
                oldWorkspace.Delete();
            }
            catch (WorkspaceNotFoundException) { }

            // Create the workspace
            return vcServer.CreateWorkspace(workspaceName, userName);
        }

        /// <summary>
        /// Dispose method to cleanup workspace
        /// </summary>
        public void Dispose()
        {
            if (m_workspaces.Left != null)
            {
                m_workspaces.Left.Delete();
            }
            if (m_workspaces.Right != null)
            {
                m_workspaces.Right.Delete();
            }

            // Try to delete local files, but don't fail if we can't
            try
            {
                TestUtils.DeleteDirectory(LocalSourceDir);
                TestUtils.DeleteDirectory(LocalTargetDir);
            }
            catch { }
        }

        /// <summary>
        /// Create the specified folder if it doesn't already exist and return the folder name
        /// </summary>
        /// <param name="directoryName">Name of folder to create</param>
        /// <returns>directoryName</returns>
        protected static string CreateDirectory(string directoryName)
        {
            if (!Directory.Exists(directoryName))
            {
                Directory.CreateDirectory(directoryName);
            }
            return directoryName;
        }

        /// <summary>
        /// Gets a random filename for the specified side
        /// </summary>
        /// <param name="side">Side on which to create file (Left = Target, Right = Source)</param>
        /// <param name="subfolderName">Subfolder to create/use</param>
        /// <returns>New temporary filename</returns>
        protected string GetRandomFilename(Side side, string subfolderName)
        {
            string newFilename = string.Empty;
            string folderName = (side == Side.Left) ? LocalTargetDir : LocalSourceDir;
            if (subfolderName != null && subfolderName != string.Empty)
            {
                folderName = CreateDirectory(Path.Combine(folderName, subfolderName));
            }

            bool nameNotUnique = true;
            while (nameNotUnique)
            {
                Guid newGuid = Guid.NewGuid();
                newFilename = Path.Combine(folderName, newGuid.ToString().Substring(0, 16) + ".txt");
                nameNotUnique = File.Exists(newFilename);
            }
            return newFilename;
        }

        /// <summary>
        /// Create a changeset with a certain number of adds, edits, and deletes
        /// </summary>
        /// <param name="side">Side on which to create the changeset (Left = Target/Tfs, Right = Source/Other)</param>
        /// <param name="numAdds">Number of adds in changeset</param>
        /// <param name="numEdits">Number of edits in changeset</param>
        /// <param name="numDeletes">Number of deletes in changeset</param>
        /// <returns>New MigrationChangeset</returns>
        public MigrationChangeset CreateChangeSet(Side side, int numAdds, int numEdits, int numDeletes)
        {
            int creationDummyId = 0;
            return CreateChangeSet(side, numAdds, numEdits, numDeletes, null, out creationDummyId);
        }

        /// <summary>
        /// Create a changeset with a certain number of adds, edits, and deletes under the specified subfolder
        /// </summary>
        /// <param name="side">Side on which to create the changeset (Left = Target/Tfs, Right = Source/Other)</param>
        /// <param name="numAdds">Number of adds in changeset</param>
        /// <param name="numEdits">Number of edits in changeset</param>
        /// <param name="numDeletes">Number of deletes in changeset</param>
        /// <param name="subFolders">List of subfolders to create items under. Null for root only</param>
        /// <returns>New MigrationChangeset</returns>
        public MigrationChangeset CreateChangeSet(Side side, int numAdds, int numEdits, int numDeletes, List<string> subFolders)
        {
            int creationDummyId = 0;
            return CreateChangeSet(side, numAdds, numEdits, numDeletes, subFolders, out creationDummyId);
        }

        /// <summary>
        /// Create a changeset with a certain number of adds, edits, and deletes
        /// </summary>
        /// <param name="side">Side on which to create the changeset (Left = Target/Tfs, Right = Source/Other)</param>
        /// <param name="numAdds">Number of adds in changeset</param>
        /// <param name="numEdits">Number of edits in changeset</param>
        /// <param name="numDeletes">Number of deletes in changeset</param>
        /// <param name="creationChangesetId">Changeset id of creation changeset</param>
        /// <param name="subFolders">List of subfolders to create items under. Null for root only</param>
        /// <returns>New MigrationChangeset</returns>
        protected MigrationChangeset CreateChangeSet(Side side, int numAdds, int numEdits, int numDeletes, 
            List<string> subFolders, out int creationChangesetId)
        {
            List<string> createdFilenames = new List<string>();
            creationChangesetId = 0;

            // Create list of subfolder with root only if null was passed in
            if (subFolders == null)
            {
                subFolders = new List<string>();
                subFolders.Add(string.Empty);
            }

            // Edits, deletes, and renames require files to be added first
            int numInitialFiles = numEdits + numDeletes;
            if (numInitialFiles > 0)
            {
                foreach (string subFolder in subFolders)
                {
                    for (int i = 0; i < numInitialFiles; i++)
                    {
                        string newFilename = TestUtils.CreateRandomFile(GetRandomFilename(side, subFolder), 10);
                        createdFilenames.Add(newFilename);
                        m_workspaces[side].PendAdd(newFilename);
                    }
                }

                // Initial Creation Checkin
                creationChangesetId = m_workspaces[side].CheckIn(m_workspaces[side].GetPendingChanges(), "Initial file creation");
            }

            // Actual edit/delete/adds
            int createdFilenamesStartIndex = 0;
            foreach (string subFolder in subFolders)
            {
                // Perform edits
                for (int i = 0; i < numEdits; i++)
                {
                    m_workspaces[side].PendEdit(TestUtils.EditRandomFile(createdFilenames[createdFilenamesStartIndex + i]));
                }

                // Perform Deletes
                for (int i = numEdits; i < numEdits + numDeletes; i++)
                {
                    TestUtils.DeleteFile(createdFilenames[createdFilenamesStartIndex + i]);
                    m_workspaces[side].PendDelete(createdFilenames[createdFilenamesStartIndex + i]);
                }
               
                createdFilenamesStartIndex += numEdits + numDeletes;

                // Perform adds
                for (int i = 0; i < numAdds; i++)
                {
                    m_workspaces[side].PendAdd(TestUtils.CreateRandomFile(GetRandomFilename(side, subFolder), 10));
                }
            }

            // Final checkin
            int newChangesetId = m_workspaces[side].CheckIn(m_workspaces[side].GetPendingChanges(), 
                "MigrationVcWorkspace.CreateChangeset");

            // Get the changeset we just created
            Changeset newChangeset = m_vcServers[side].GetChangeset(newChangesetId);
            Assert.IsNotNull(newChangeset, "Could not get newly created changeset (id: {0})", newChangesetId);

            return new MigrationChangeset(newChangeset, this, side);
        }

        /// <summary>
        /// Create a version controlled item
        /// </summary>
        /// <param name="side">Side on which to create the changeset (Left = Target/Tfs, Right = Source/Other)</param>
        /// <param name="latestVersion">If true, return the latest version of the item, otherwise chose a specific version</param>
        /// <returns>New MigrationVcItem</returns>
        public MigrationVcItem CreateVcItem(Side side, bool latestVersion)
        {
            // Create a changeset with an edit (makes 2 submits/versions)
            int creationChangesetId = 0;
            MigrationChangeset changeset = CreateChangeSet(side, 0, 1, 0, null, out creationChangesetId);

            // Get the first version
            Item newItem = m_vcServers[side].GetItem(changeset.SourceChangeset.Changes[0].Item.ItemId, creationChangesetId);
            return new MigrationVcItem(newItem, this, side, latestVersion);
        }

        /// <summary>
        /// Migrate all VC items in this session with the default timeout
        /// </summary>
        public void MigrateAllVCItems()
        {
            MigrateAllVCItems(c_defaultMigrationTimeoutMs);
        }

        /// <summary>
        /// Migrate all VC items in this session with the specified timeout (0 for no timeout)
        /// </summary>
        /// <param name="timeoutMs"></param>
        public void MigrateAllVCItems(int timeoutMs)
        {
            int sleepTimeMs = 200;
            int totalSleptTime = 0;

            VersionControlSession vcSession = VCSession;
            vcSession.SynchronizeFull();
            while (vcSession.IsRunning)
            {
                System.Threading.Thread.Sleep(sleepTimeMs);

                if (timeoutMs > 0)
                {
                    totalSleptTime += sleepTimeMs;
                    if (totalSleptTime >= timeoutMs || totalSleptTime < 0)
                    {
                        throw new Exception("Timed out waiting for VC migration to complete");
                    }
                }
            }
            Assert.IsFalse(vcSession.IsAborted, "Migration was unexpectedly aborted");
        }

        /// <summary>
        /// Gets the reflected changeset(s) of the specified changeset
        /// </summary>
        /// <param name="changeset">Changeset to find reflection of</param>
        /// <param name="sideOfChangeset">Side of changeset</param>
        /// <returns>List of reflected changesets</returns>
        public List<Changeset> GetReflectedChangesets(Changeset changeset, Side sideOfChangeset)
        {
            List<int> reflectedChangesetIds = GetReflectedChangesetIds(changeset.ChangesetId, sideOfChangeset);
            List<Changeset> reflectedChangesets = new List<Changeset>();
            foreach (int reflectedChangesetId in reflectedChangesetIds)
            {
                reflectedChangesets.Add(m_vcServers[!sideOfChangeset].GetChangeset(reflectedChangesetId));
            }
            return reflectedChangesets;
        }

        /// <summary>
        /// Gets the reflected changeset id(s) of the specified changeset id
        /// </summary>
        /// <param name="changesetId">Id of Changeset to find reflection of</param>
        /// <param name="sideOfChangeset">Side of changesetId</param>
        /// <returns>Reflected changeset Id (or -1 if not found)</returns>
        public List<int> GetReflectedChangesetIds(int changesetId, Side sideOfChangeset)
        {
            // Query the appropriate change id
            string sqlQuery = String.Format("SELECT TfsChangesetId FROM dbo.ConversionHistory WHERE " +
                "SessionId='{0}' AND SourceChangeId={1} AND FromSource='{2}'", m_vcSessionName,
                changesetId, (sideOfChangeset == Side.Left) ? "false" : "true");

            // Return the reflected changeset id
            List<int> reflectedChangesetIds = new List<int>();

            using (SqlConnection conn = DataAccessManager.Current.GetSqlConnection())
            using (SqlCommand cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = sqlQuery;
                cmd.CommandType = CommandType.Text;

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        reflectedChangesetIds.Add(reader.GetInt32(0));
                    }
                }
            }

            return reflectedChangesetIds;
        }
    }
}
