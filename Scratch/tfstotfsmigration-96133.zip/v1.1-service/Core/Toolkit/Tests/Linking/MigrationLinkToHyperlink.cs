//****************************************************************************
// MigrationLinkToHyperlink.cs
// Owner: nickkirc
//
// Encapsulates a hyperlink used in migration tests.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Class to encapsulate a link used in migration
    /// </summary>
    public class MigrationLinkToHyperlink : MigrationLink
    {
        protected string m_location = string.Empty;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="parentMigrationWorkItem">The migration work item that is the source of the link</param>
        /// <param name="srcWorkItemSide">Side that the source of the link is on</param>
        /// <param name="hyperlinkLocation">The URL/location of the hyperlink</param>
        /// <param name="expectedResult">The link's expected migration result</param>
        public MigrationLinkToHyperlink(MigrationWorkItem parentMigrationWorkItem, Side srcWorkItemSide, 
                string hyperlinkLocation, MigrationLinkResult expectedResult) 
            : base(new Hyperlink(hyperlinkLocation), c_defaultHyperlinkComment, parentMigrationWorkItem, 
                srcWorkItemSide, expectedResult)
        {
            m_location = hyperlinkLocation;
        }

        /// <summary>
        /// Compare this link with another and return true if they are equivalent
        /// </summary>
        /// <param name="srcSideLink">Link1</param>
        /// <param name="sideOfLink1">Side of Link1</param>
        /// <returns>True if the same, otherwise false</returns>
        protected override bool IsLinkEquivalent(Link link1, Side sideOfLink1)
        {
            // Make sure the links are of the same type
            if (link1.BaseType.CompareTo(BaseLinkType.Hyperlink) == 0)
            {
                // Just check the URL/Location
                return ((Hyperlink)link1).Location.CompareTo(m_location) == 0;
            }
            return false;
        }

        /// <summary>
        /// Compare the link with the given target URI and return true if they are the same
        /// </summary>
        /// <param name="targetUri">Target URI of the link</param>
        /// <returns>True if the same, otherwise false</returns>
        public override bool IsLinkEquivalent(string targetUri)
        {
            return targetUri.CompareTo(TfsHyperlinkHandler.UriFromId(m_location)) == 0;
        }

        /// <summary>
        /// ToString
        /// </summary>
        /// <returns>Description of migration link</returns>
        public override string ToString()
        {
            return "Link from workitem " + SourceWorkItem.Id.ToString() + 
                " (on " + m_srcWorkItemSide.ToString() + " side) to " + m_location;
        }
    }
}
