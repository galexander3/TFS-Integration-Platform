//****************************************************************************
// MigrationEvents.cs
// Owner: nickkirc
//
// Container for handling migration events.
//
// Copyright(c) Microsoft Corporation, 2007
//****************************************************************************

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml;

using Tests.Framework;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.Linking
{
    /// <summary>
    /// Container for WIT migration events
    /// </summary>
    public class MigrationWitEvents
    {
        protected WorkItemTrackingSession m_witSession;
        protected bool m_eventHandlersAdded = false;
        protected List<WorkItemMigrationEventArgs> m_witMigrationStartEventArgs = new List<WorkItemMigrationEventArgs>();
        protected List<MigrationCompleteEventArgs> m_witMigrationCompleteEventArgs = new List<MigrationCompleteEventArgs>();
        protected List<WorkItemMigrationEventArgs> m_witMigrationFailedEventArgs = new List<WorkItemMigrationEventArgs>();
        protected List<FieldConflictEventArgs> m_fieldConflictEventArgs = new List<FieldConflictEventArgs>();
        protected List<CollectionEventArgs> m_attachmentConflictEventArgs = new List<CollectionEventArgs>();
        protected List<CollectionEventArgs> m_linksOutOfSync = new List<CollectionEventArgs>();
        protected List<LinkingEventArgs> m_linkDeferredEventArgs = new List<LinkingEventArgs>();

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="witSession">WIT Session to add event handlers to</param>
        protected MigrationWitEvents(WorkItemTrackingSession witSession)
        {
            m_witSession = witSession;
            AddEventHandlers();
        }

        /// <summary>
        /// Create a MigrationEvents member for the given session and add the event handlers
        /// </summary>
        /// <param name="witSession">WIT Session to add event handlers to</param>
        /// <returns>New MigrationEvents member</returns>
        public static MigrationWitEvents GetInstance(WorkItemTrackingSession witSession)
        {
            return new MigrationWitEvents(witSession);
        }

        /// <summary>
        /// Subscribe to the work item events
        /// </summary>
        public void AddEventHandlers()
        {
            if (!m_eventHandlersAdded)
            {
                // Subscribe to the necessary event handlers
                m_witSession.WorkItemMigrationStart += new EventHandler<WorkItemMigrationEventArgs>(OnMigrationStart);
                m_witSession.WorkItemMigrationComplete += new EventHandler<MigrationCompleteEventArgs>(OnMigrationComplete);
                m_witSession.WorkItemMigrationFailed += new EventHandler<WorkItemMigrationEventArgs>(OnMigrationFailed);
                m_witSession.WorkItemFieldConflict += new EventHandler<FieldConflictEventArgs>(OnFieldConflict);
                m_witSession.WorkItemAttachmentsOutOfSync += new EventHandler<CollectionEventArgs>(OnAttachmentConflict);
                m_witSession.WorkItemLinksOutOfSync += new EventHandler<CollectionEventArgs>(OnLinksOutOfSync);

                if (m_witSession.LinkEngine != null)
                {
                    m_witSession.LinkEngine.LinkDeferred += new EventHandler<LinkingEventArgs>(OnLinkDeferred);
                }
            }
            m_eventHandlersAdded = true;
        }

        /// <summary>
        /// Remove all the migration event handlers
        /// </summary>
        public void RemoveEventHandlers()
        {
            if (m_eventHandlersAdded)
            {
                m_witSession.WorkItemMigrationStart -= new EventHandler<WorkItemMigrationEventArgs>(OnMigrationStart);
                m_witSession.WorkItemMigrationComplete -= new EventHandler<MigrationCompleteEventArgs>(OnMigrationComplete);
                m_witSession.WorkItemMigrationFailed -= new EventHandler<WorkItemMigrationEventArgs>(OnMigrationFailed);
                m_witSession.WorkItemFieldConflict -= new EventHandler<FieldConflictEventArgs>(OnFieldConflict);
                m_witSession.WorkItemAttachmentsOutOfSync -= new EventHandler<CollectionEventArgs>(OnAttachmentConflict);
                m_witSession.WorkItemLinksOutOfSync -= new EventHandler<CollectionEventArgs>(OnLinksOutOfSync);

                if (m_witSession.LinkEngine != null)
                {
                    m_witSession.LinkEngine.LinkDeferred -= new EventHandler<LinkingEventArgs>(OnLinkDeferred);
                }
            }
            m_eventHandlersAdded = false;
        }

        /// <summary>
        /// True if the event handlers were added to the session and listening for events
        /// </summary>
        public bool EventHandlersAdded { get { return m_eventHandlersAdded; } }

        /// <summary>
        /// List of Migration Start Events
        /// </summary>
        public List<WorkItemMigrationEventArgs> WITMigrationStartEventArgs { get { return m_witMigrationStartEventArgs; } }
        
        /// <summary>
        /// List of Migration Complete Events
        /// </summary>
        public List<MigrationCompleteEventArgs> WITMigrationCompleteEventArgs { get { return m_witMigrationCompleteEventArgs; } }
        
        /// <summary>
        /// List of Migration Failed Events
        /// </summary>
        public List<WorkItemMigrationEventArgs> WITMigrationFailedEventArgs { get { return m_witMigrationFailedEventArgs; } }
        
        /// <summary>
        /// List of Field Conflict Events
        /// </summary>
        public List<FieldConflictEventArgs> FieldConflictEventArgs { get { return m_fieldConflictEventArgs; } }
        
        /// <summary>
        /// List of Attachment Conflict Events
        /// </summary>
        public List<CollectionEventArgs> AttachmentConflictEventArgs { get { return m_attachmentConflictEventArgs; } }
        
        /// <summary>
        /// List of Link Conflict Events
        /// </summary>
        public List<CollectionEventArgs> LinksOutOfSyncEventArgs { get { return m_linksOutOfSync; } }

        /// <summary>
        /// List of Link Deferred Events
        /// </summary>
        public List<LinkingEventArgs> LinkDeferredEventArgs { get { return m_linkDeferredEventArgs; } }

        /// <summary>
        /// Get the Migration Start events associated with a specific work item
        /// </summary>
        /// <param name="workItem">Work item to return events for</param>
        /// <returns>The Migration start events associated with workItem</returns>
        public List<WorkItemMigrationEventArgs> GetWitMigrationStartEventArgs(MigrationWorkItem workItem)
        {
            List<WorkItemMigrationEventArgs> retList = new List<WorkItemMigrationEventArgs>();
            foreach (WorkItemMigrationEventArgs args in WITMigrationStartEventArgs)
            {
                if (args.SourceId.Id == workItem.SourceWorkItem.Id.ToString())
                {
                    retList.Add(args);
                }
            }
            return retList;
        }

        /// <summary>
        /// Get the Migration Complete events associated with a specific work item
        /// </summary>
        /// <param name="workItem">Work item to return events for</param>
        /// <returns>The Migration complete events associated with workItem</returns>
        public List<MigrationCompleteEventArgs> GetWitMigrationCompleteEventArgs(MigrationWorkItem workItem)
        {
            List<MigrationCompleteEventArgs> retList = new List<MigrationCompleteEventArgs>();
            foreach (MigrationCompleteEventArgs args in WITMigrationCompleteEventArgs)
            {
                if (args.SourceId.Id == workItem.SourceWorkItem.Id.ToString() ||
                    args.TargetId.Id == workItem.SourceWorkItem.Id.ToString())
                {
                    retList.Add(args);
                }
            }
            return retList;
        }

        /// <summary>
        /// Get the Migration Failed events associated with a specific work item
        /// </summary>
        /// <param name="workItem">Work item to return events for</param>
        /// <returns>The Migration failed events associated with workItem</returns>
        public List<WorkItemMigrationEventArgs> GetWitMigrationFailedEventArgs(MigrationWorkItem workItem)
        {
            List<WorkItemMigrationEventArgs> retList = new List<WorkItemMigrationEventArgs>();
            foreach (WorkItemMigrationEventArgs args in WITMigrationFailedEventArgs)
            {
                if (args.SourceId.Id == workItem.SourceWorkItem.Id.ToString())
                {
                    retList.Add(args);
                }
            }
            return retList;
        }

        /// <summary>
        /// Get the Attachment conflicts associated with a specific work item
        /// </summary>
        /// <param name="workItem">Work item to return attachment conflicts for</param>
        /// <returns>The attachment conflicts associated with workItem</returns>
        public List<CollectionEventArgs> GetAttachmentConflictEventArgs(MigrationWorkItem workItem)
        {
            List<CollectionEventArgs> retList = new List<CollectionEventArgs>();
            foreach (CollectionEventArgs args in AttachmentConflictEventArgs)
            {
                if (args.SourceId.Id == workItem.SourceWorkItem.Id.ToString() ||
                    args.TargetId.Id == workItem.SourceWorkItem.Id.ToString())
                {
                    retList.Add(args);
                }
            }
            return retList;
        }

        /// <summary>
        /// Get the Link conflicts associated with a specific work item
        /// </summary>
        /// <param name="workItem">Work item to return link conflicts for</param>
        /// <returns>The link conflicts associated with workItem</returns>
        public List<CollectionEventArgs> GetLinkConflictEventArgs(MigrationWorkItem workItem)
        {
            List<CollectionEventArgs> retList = new List<CollectionEventArgs>();
            foreach (CollectionEventArgs args in LinksOutOfSyncEventArgs)
            {
                if (args.SourceId.Id == workItem.SourceWorkItem.Id.ToString() ||
                    args.TargetId.Id == workItem.SourceWorkItem.Id.ToString())
                {
                    retList.Add(args);
                }
            }
            return retList;
        }

        /// <summary>
        /// Get the Link Deferred events associated with a specific work item
        /// </summary>
        /// <param name="workItem">Work item to return events for</param>
        /// <returns>The events associated with workItem</returns>
        public List<LinkingEventArgs> GetLinksOutOfSyncEvents(MigrationWorkItem workItem)
        {
            List<LinkingEventArgs> retList = new List<LinkingEventArgs>();
            foreach (LinkingEventArgs args in m_linkDeferredEventArgs)
            {
                if (String.Compare(args.Link.SourceUri, workItem.SourceWorkItem.Uri.ToString(), true) == 0 ||
                    (workItem.HasMigrated && String.Compare(args.Link.SourceUri, workItem.DestinationWorkItem.Uri.ToString(), true) == 0))
                {
                    retList.Add(args);
                }
            }
            return retList;
        }

        /// <summary>
        /// Reset all lists of event args
        /// </summary>
        public void ResetEvents()
        {
            m_witMigrationStartEventArgs.Clear();
            m_witMigrationCompleteEventArgs.Clear();
            m_witMigrationFailedEventArgs.Clear();
            m_fieldConflictEventArgs.Clear();
            m_attachmentConflictEventArgs.Clear();
            m_linksOutOfSync.Clear();
            m_linkDeferredEventArgs.Clear();
        }

        /// <summary>
        /// Callback function for the "work item migration start" event.
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="args">Argumenrs</param>
        private void OnMigrationStart(object sender, WorkItemMigrationEventArgs args)
        {
            Assert.IsInstanceOfType(sender, typeof(WorkItemTrackingSession), "Invalid sender!");
            Assert.IsNotNull(args, "Null arguments!");
            m_witMigrationStartEventArgs.Add(args);
        }

        /// <summary>
        /// Callback function for the "work item migration complete" event.
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="args">Argumenrs</param>
        private void OnMigrationComplete(object sender, MigrationCompleteEventArgs args)
        {
            Assert.IsInstanceOfType(sender, typeof(WorkItemTrackingSession), "Invalid sender!");
            Assert.IsNotNull(args, "Null arguments!");
            m_witMigrationCompleteEventArgs.Add(args);
        }

        /// <summary>
        /// Callback function for the "work item migration failed" event.
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="args">Argumenrs</param>
        private void OnMigrationFailed(object sender, WorkItemMigrationEventArgs args)
        {
            Assert.IsInstanceOfType(sender, typeof(WorkItemTrackingSession), "Invalid sender!");
            Assert.IsNotNull(args, "Null arguments!");
            m_witMigrationFailedEventArgs.Add(args);
        }

        /// <summary>
        /// Field conflict event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="args">Arguments</param>
        private void OnFieldConflict(object sender, FieldConflictEventArgs args)
        {
            Assert.IsInstanceOfType(sender, typeof(WorkItemTrackingSession), "Invalid sender!");
            Assert.IsNotNull(args, "Null arguments!");
            m_fieldConflictEventArgs.Add(args);
        }

        /// <summary>
        /// File attachment conflict event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="args">Arguments</param>
        private void OnAttachmentConflict(object sender, CollectionEventArgs args)
        {
            Assert.IsInstanceOfType(sender, typeof(WorkItemTrackingSession), "Invalid sender!");
            Assert.IsNotNull(args, "Null arguments!");
            m_attachmentConflictEventArgs.Add(args);
        }

        /// <summary>
        /// Link conflict event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnLinksOutOfSync(object sender, CollectionEventArgs args)
        {
            Assert.IsInstanceOfType(sender, typeof(WorkItemTrackingSession), "Invalid sender!");
            Assert.IsNotNull(args, "Null arguments!");
            m_linksOutOfSync.Add(args);
        }

        /// <summary>
        /// Callback function for the "link deferred" event.
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="args">Argumenrs</param>
        private void OnLinkDeferred(object sender, LinkingEventArgs args)
        {
            Assert.IsNotNull(args, "Null arguments!");
            m_linkDeferredEventArgs.Add(args);
        }
    }
}
