// Copyright (c) Microsoft Corporation. All rights reserved.

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.TeamFoundation.Migration.Toolkit;
namespace Tests
{
    /// <summary>
    /// Summary description for IVersionControlSessionTest
    /// </summary>
    [TestClass]
    public class IVersionControlSessionTest : EventManagerTestcaseBase
    {
        

        /// <summary>
        ///A test for OnAnalysisAborted (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnAnalysisAbortedTest()
        {  
            target.OnAnalysisAborted(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.AnalysisAborted);
        }

        /// <summary>
        ///A test for OnAnalysisComplete (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnAnalysisCompleteTest()
        {
            target.OnAnalysisComplete(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.AnalysisComplete);

        }
        /// <summary>
        ///A test for OnAnalysisError (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnAnalysisErrorTest()
        {
            target.OnAnalysisError(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.AnalysisError);
        }

        /// <summary>
        ///A test for OnAnalyzingChangeComplete (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnAnalyzingChangeCompleteTest()
        {
            target.OnAnalyzingChangeComplete(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.AnalyzingChangeComplete);
        }

        /// <summary>
        ///A test for OnAnalyzingChangeStarting (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnAnalyzingChangeStartingTest()
        {
            target.OnAnalyzingChangeStarting(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.AnalyzingChangeStarting);
        }

        /// <summary>
        ///A test for OnBeforeAnalysis (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnBeforeAnalysisTest()
        {
            target.OnBeforeAnalysis(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.BeforeAnalysis);
        }

        /// <summary>
        ///A test for OnBeforeMigration (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnBeforeMigrationTest()
        {
            target.OnBeforeMigration(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.BeforeMigration);
        }

        /// <summary>
        ///A test for OnMigratingChangeComplete (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnMigratingChangeCompleteTest()
        {
            target.OnMigratingChangeComplete(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.MigratingChangeComplete);
        }
        
        /// <summary>
        ///A test for OnMigratingChangeStarting (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnMigratingChangeStartingTest()
        {
            target.OnMigratingChangeStarting(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.MigratingChangeStarting);
        }

        /// <summary>
        ///A test for OnMigrationAborted (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnMigrationAbortedTest()
        {
            target.OnMigrationAborted(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.MigrationAborted);
        }

        /// <summary>
        ///A test for OnMigrationComplete (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnMigrationCompleteTest()
        {
            target.OnMigrationComplete(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.MigrationComplete);
        }

        /// <summary>
        ///A test for OnMigrationError (VersionControlEventArgs)
        ///</summary>
        [TestMethod()]
        public void OnMigrationErrorTest()
        {
            target.OnMigrationError(eventArgs);

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.MigrationError);
        }
        
    }
         
}
