// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Tests
{
    /// <summary>
    /// Summary description for MigrationEventArgsTest
    /// </summary>
    [TestClass]
    public class MigrationEventArgsTest :EventManagerTestcaseBase
    {

        [TestMethod]
        public void MaxMigratedItemCountTest()
        {
            MigrationSessionEventArgs eventArgs = new MigrationSessionEventArgs(initializer.validDescription(), long.MaxValue, initializer.validLong());
            Assert.AreEqual(long.MaxValue, eventArgs.MigratedItemCount);
        }

        [TestMethod]
        public void MaxMigratedFailureCountTest()
        {
            MigrationSessionEventArgs eventArgs = new MigrationSessionEventArgs(initializer.validDescription(), initializer.validLong(), long.MaxValue);
            Assert.AreEqual(long.MaxValue, eventArgs.FailedItemCount);
        }

        [TestMethod]
        public void DefaultMigratedItemCountTest()
        {
            MigrationSessionEventArgs eventArgs = new MigrationSessionEventArgs(initializer.validDescription());
            Assert.AreEqual<long>(0, eventArgs.MigratedItemCount);
        }

        [TestMethod]
        public void DefualtMigratedFailureCountTest()
        {
            MigrationSessionEventArgs eventArgs = new MigrationSessionEventArgs(initializer.validDescription());
            Assert.AreEqual<long>(0, eventArgs.FailedItemCount);
        }


        [TestMethod]
        public void NegativeItemCountTest()
        {
            MigrationSessionEventArgs eventArgs = new MigrationSessionEventArgs(initializer.validDescription(), long.MinValue, initializer.validLong());
            Assert.AreEqual(long.MinValue, eventArgs.MigratedItemCount);

        }

        [TestMethod]
        public void NegativeFailureCountTest()
        {
            MigrationSessionEventArgs eventArgs = new MigrationSessionEventArgs(initializer.validDescription(), initializer.validLong(), long.MinValue);
            Assert.AreEqual(long.MinValue, eventArgs.FailedItemCount);
        }

        [TestMethod]
        public void EmptyDescriptionTest()
        {
            VersionControlEventArgs eventArgs = new VersionControlEventArgs("", SystemType.Other);
            Assert.AreEqual("", eventArgs.Description);
        }
    }
}
