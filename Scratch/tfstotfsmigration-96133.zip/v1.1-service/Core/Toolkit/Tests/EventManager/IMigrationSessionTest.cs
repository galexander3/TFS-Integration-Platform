// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Tests
{
    /// <summary>
    /// Summary description for IMigratioTest
    /// </summary>
    [TestClass]
    public class IMigrationSessionTest : EventManagerTestcaseBase
    {
        #region Additional test attributes
        private void verifyNotStarted()
        {
            Assert.IsFalse(target.IsAborted, "Abort should be false for a session that is not started");
            Assert.IsFalse(target.IsComplete);
            Assert.IsFalse(target.IsRunning);
        }

        private void verifyStarted()
        {
            Assert.IsFalse(target.IsAborted);
            Assert.IsFalse(target.IsComplete);
            Assert.IsTrue(target.IsRunning);
        }

        private void verifyAborted()
        {
            Assert.IsTrue(target.IsAborted);
            Assert.IsFalse(target.IsComplete);
            Assert.IsFalse(target.IsRunning);
        }

        private void verifyCompleted()
        {
            Assert.IsFalse(target.IsAborted);
            Assert.IsTrue(target.IsComplete);
            Assert.IsFalse(target.IsRunning);
        }
        #endregion

        [TestMethod]
        public void newStartTest()
        {
            target.Start();
            verifyStarted();

            OnlyEventFired(sink, (int) TestEventSink.VersionControlEvents.SessionStart);
        }

        [TestMethod]
        public void AbortTest()
        {
            List<int> expectedEvents = new List<int>();

            target.Start();
            expectedEvents.Add((int)TestEventSink.VersionControlEvents.SessionStart);
            target.Abort();
            expectedEvents.Add((int)TestEventSink.VersionControlEvents.SessionAborted);

            verifyAborted();

            EventsFired(sink, expectedEvents);
        }

        [TestMethod]
        public void StopTest()
        {
            List<int> expectedEvents = new List<int>();

            target.Start();
            expectedEvents.Add((int)TestEventSink.VersionControlEvents.SessionStart);
            target.Stop();
            expectedEvents.Add((int)TestEventSink.VersionControlEvents.SessionComplete);

            verifyCompleted();

            EventsFired(sink, expectedEvents);
        }

        [TestMethod]
        public void StartOnStaredTest()
        {
            target.Start();
            verifyStarted();
            target.Start();
            verifyStarted();

            OnlyEventFired(sink, (int)TestEventSink.VersionControlEvents.SessionStart);
            
        }

        [TestMethod]
        public void AbortNotStaredTest()
        {
                target.Abort();
                verifyNotStarted();
                NoEventsFired(sink);
        }

        [TestMethod]
        public void StartOnAborted()
        {
            List<int> expectedEvents = new List<int>();

            target.Start();
            expectedEvents.Add((int)TestEventSink.VersionControlEvents.SessionStart);
            target.Abort();
            expectedEvents.Add((int)TestEventSink.VersionControlEvents.SessionAborted);
            target.Start();
            expectedEvents.Add((int)TestEventSink.VersionControlEvents.SessionStart);

            verifyStarted();

            EventsFired(sink, expectedEvents);
        }
    }
}
