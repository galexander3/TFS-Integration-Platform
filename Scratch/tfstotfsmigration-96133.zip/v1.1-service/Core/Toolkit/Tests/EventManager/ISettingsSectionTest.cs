// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using System.Xml;
using Tests.Framework;

namespace Tests
{
    /// <summary>
    /// Summary description for ISettingsSectionTest
    /// </summary>
    [TestClass]
    public class ISettingsSectionTest : ConfigManagerTestCaseBase
    {
        #region Additional test attributes

        private string defaultValue = "DefaultSettingsValue";

        #endregion

        #region TryGetValueTests

        //Name exists, value exists	
        [TestMethod]
        public void MainLineTryGetValueTest()
        {
            configFile.WriteAndLoad();

            String name = "SettingName";
            String value = "SettingValue";
            MigrationConfiguration.Current.AddSetting(name, value);
            String outValue;
            Assert.IsTrue(MigrationConfiguration.Current.TryGetValue(name, out outValue), "Did not find the value");
            Assert.AreEqual(value, outValue, "Values Did not Match");
        }

        //Name is null
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullNameTryGetValueTest()
        {
            configFile.WriteAndLoad();

            String name = "SettingName";
            String value = "SettingValue";
            MigrationConfiguration.Current.AddSetting(name, value);
            String outValue;
            MigrationConfiguration.Current.TryGetValue(null, out outValue);
        }

        //Name does not exist	
        [TestMethod]
        public void BogusNameTryGetValueTest()
        {
            configFile.WriteAndLoad();

            String name = "BogusSettingName";

            String outValue;
            Assert.IsFalse(MigrationConfiguration.Current.TryGetValue(name, out outValue), "Found a bougus setting");
            Assert.IsNull(outValue, "Value for bogus setting should be null");
        }

        //Value is empty	
        [TestMethod]
        public void EmptyValueTryGetValueTest()
        {
            configFile.WriteAndLoad();

            String name = "SettingName";
            String value = "";
            MigrationConfiguration.Current.AddSetting(name, value);
            String outValue;
            Assert.IsTrue(MigrationConfiguration.Current.TryGetValue(name, out outValue), "Did not find the value");
            Assert.AreEqual("", outValue, "Values Did not Match");
        }

        [TestMethod]
        public void CascadingLookupTryGetValueTest()
        {

            configFile.WriteAndLoad();

            String name = "SettingName";
            String value = "SettingsValue";

            MigrationConfiguration.Current.AddSetting(name, value);

            int loopIndex = 0;
            foreach(VersionControlSession session in MigrationConfiguration.Current.VC.Sessions.Values)
            {
                XmlNode sessionNode = doc.SelectSingleNode("/Migration/VC/Sessions").ChildNodes[loopIndex++];

                String outValue;

                foreach (XmlNode settingNode in sessionNode.SelectSingleNode("Settings").ChildNodes)
                {
                    //Check that no values are overridden in the VC Sessions
                    session.TryGetValue(settingNode.Attributes["name"].InnerText, out outValue);
                    Assert.AreEqual(settingNode.Attributes["value"].InnerText, outValue);
                }
                //Check that a session can find a value which was defined in the global settings        
                session.TryGetValue(name, out outValue);
                Assert.AreEqual(value, outValue);

            }

            //WorkItemTrackingSessions Are stored in a dictionary which we cannot access via index
            //so must use for each loop and track index seperatly
            loopIndex = 0;
            foreach (WorkItemTrackingSession session in MigrationConfiguration.Current.Wit.Sessions.Values)
            {
                XmlNode sessionNode = doc.SelectSingleNode("/Migration/WIT/Sessions").ChildNodes[loopIndex];

                String outValue;
                foreach (XmlNode settingNode in sessionNode.SelectSingleNode("Settings").ChildNodes)
                {
                    //Check that no values are overridden in the WIT Sessions
                    session.TryGetValue(settingNode.Attributes["name"].InnerText, out outValue);
                    Assert.AreEqual(settingNode.Attributes["value"].InnerText, outValue);
                }
                loopIndex++;
                //Check that a session can find a value which was defined in the global settings
                session.TryGetValue(name, out outValue);
                Assert.AreEqual(value, outValue);
            }

        }

        #endregion

        #region GetValueTests

        [TestMethod]
        public void CascadingLookupGetValueTest()
        {

            configFile.WriteAndLoad();

            String name = "SettingName";
            String value = "SettingsValue";

            MigrationConfiguration.Current.AddSetting(name, value);

            int loopIndex = 0;
            foreach(VersionControlSession session in MigrationConfiguration.Current.VC.Sessions.Values)
            {
                XmlNode sessionNode = doc.SelectSingleNode("/Migration/VC/Sessions").ChildNodes[loopIndex++];

                foreach (XmlNode settingNode in sessionNode.SelectSingleNode("Settings").ChildNodes)
                {
                    //Check that no values are overridden in the VC Sessions
                    Assert.AreEqual(settingNode.Attributes["value"].InnerText, session.GetValue(settingNode.Attributes["name"].InnerText));
                }
                //Check that a session can find a value which was defined in the global settings        
                Assert.AreEqual(value, session.GetValue(name));

            }

            //WorkItemTrackingSessions Are stored in a dictionary which we cannot access via index
            //so must use for each loop and track index seperatly
            loopIndex = 0;
            foreach (WorkItemTrackingSession session in MigrationConfiguration.Current.Wit.Sessions.Values)
            {
                XmlNode sessionNode = doc.SelectSingleNode("/Migration/WIT/Sessions").ChildNodes[loopIndex];

                foreach (XmlNode settingNode in sessionNode.SelectSingleNode("Settings").ChildNodes)
                {
                    //Check that no values are overridden in the WIT Sessions
                    Assert.AreEqual(settingNode.Attributes["value"].InnerText, session.GetValue(settingNode.Attributes["name"].InnerText));
                }
                loopIndex++;
                //Check that a session can find a value which was defined in the global settings
                Assert.AreEqual(value, session.GetValue(name));
            }

        }


        //Name exists, value exists
        [TestMethod]
        public void MainLineGetValueTest()
        {
            configFile.WriteAndLoad();

            String name = "SettingName";
            String value = "SettingValue";

            MigrationConfiguration.Current.AddSetting(name, value);
            String outValue = MigrationConfiguration.Current.GetValue(name, defaultValue);
            Assert.AreEqual(value, outValue, "Values Did not Match");
        }

        //Name does not exist; has default
        [TestMethod]
        public void DefaultGetValueTest()
        {
            configFile.WriteAndLoad();

            String name = "BogusSettingName";

            String outValue = MigrationConfiguration.Current.GetValue(name, defaultValue);

            Assert.AreEqual(defaultValue, outValue, "Default value should have returned for bogus setting name");
        }

        //Name is null
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullNameGetValueTest()
        {
            configFile.WriteAndLoad();

            String name = "SettingName";
            String value = "SettingValue";

            MigrationConfiguration.Current.AddSetting(name, value);
            String outValue = MigrationConfiguration.Current.GetValue(null, defaultValue);
        }
        //Name does not exist; no default

        [TestMethod]
        public void BogusGetValueTest()
        {
            configFile.WriteAndLoad(); ;

            String name = "BogusSettingName";
            String outValue = null;
            try
            {
                outValue = MigrationConfiguration.Current.GetValue(name);
                Assert.Fail("SHould have thown a MigrationException");
            }
            catch (MigrationException e)
            {
                Assert.AreEqual(String.Format(Microsoft_TeamFoundation_Migration_Toolkit_MigrationToolkitResourcesAccessor.SettingNotFound, name), e.Message);
            }

            Assert.IsNull(outValue, "Null should have returned for bogus setting name");
        }

        #endregion GetValueTests
    }
}
