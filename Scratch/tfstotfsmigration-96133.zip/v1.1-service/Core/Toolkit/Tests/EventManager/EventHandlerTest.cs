// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;

namespace Tests
{
    /// <summary>
    /// Summary description for EventHandlerTest
    /// </summary>
    [TestClass]
    public class EventHandlerTest : EventManagerTestcaseBase
    {

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void SessionStartTest()
        {
            configFile.WriteAndLoad();

            MigrationConfiguration.Current.VC.Sessions["Session0"].OnSessionStart(null);
        }


        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void BeforeAnalysisTest()
        {
            configFile.WriteAndLoad();

            MigrationConfiguration.Current.VC.Sessions["Session0"].OnBeforeAnalysis(null);
        }

    }
}
