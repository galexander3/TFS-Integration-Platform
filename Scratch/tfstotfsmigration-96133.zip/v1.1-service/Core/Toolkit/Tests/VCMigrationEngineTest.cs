// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;
using Tests.Framework;
using System.Diagnostics;

namespace Tests
{

    [TestClass]
    public class VCMigrationEngineTest : MigrationTestCaseBase
    {

        ///<summary>
        ///Scenario: Call ProcessChangeGroup passing in null
        ///Expected Result: ArgumentNullException
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Call ProcessChangeGroup passing in null")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ProcessNullChangeGroupTest()
        {
            ChangeGroupingMananger manager = new SqlChangeGroupingMananger(null, null, CreateVcWssSession, MigrationDirection.SourceToTfs);

            DataAccessManager.Current.CreateSchema(false);
            TestVCMigrationEngine engine = new TestVCMigrationEngine(CreateVcWssSession, manager);

            engine.CallProcessChangeGroup(null);
        }

        ///<summary>
        ///Scenario: Create a VCMigrationEngine with a null session
        ///Expected Result: ArgumentNullException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Create a VCMigrationEngine with a null session")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullSessionTest()
        {
            ChangeGroupingMananger manager = new SqlChangeGroupingMananger(null, null, CreateVcWssSession, MigrationDirection.TfsToSource);
            TestVCMigrationEngine engine = new TestVCMigrationEngine(null, manager);
        }

        ///<summary>
        ///Scenario: Create a VCMigrationEngine with a null ChangeGroupManager
        ///Expected Result: ArgumentNullException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Create a VCMigrationEngine with a null ChangeGroupManager")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullChangeGroupManagerTest()
        {
            TestVCMigrationEngine engine = new TestVCMigrationEngine(CreateVcWssSession, null);
        }
    }
}
