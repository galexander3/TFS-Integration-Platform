// Copyright (c) Microsoft Corporation. All rights reserved.
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.TeamFoundation.Client;
using System.Xml;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Tests.Framework;
using Microsoft.TeamFoundation.VersionControl.Common;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;

namespace Tests
{
    /// <summary>
    ///This is a test class for Microsoft.TeamFoundation.Migration.VersionControl.BatchingContext and is intended
    ///to contain all Microsoft.TeamFoundation.Migration.VersionControl.BatchingContext Unit Tests
    ///</summary>
    [TestClass()]
    public class BatchingContextTest : MigrationTestCaseBase
    {
        private Workspace workspace;
        private string rootPath;
        private BatchingContext ctx;
        private TestVCEventListeners listeners;

        /// <summary>
        ///A test for PendAdd (string)
        ///</summary>
        [TestMethod()]
        public void BasicBatchTest()
        {
            Stopwatch sw = new Stopwatch();

            sw.Start();

            Microsoft_TeamFoundation_Migration_Toolkit_BatchingContextAccessor ctxAccessor = new Microsoft_TeamFoundation_Migration_Toolkit_BatchingContextAccessor(ctx);
            Assert.AreEqual(200, ctxAccessor._batchSize);

            ctx.PendAdd(TestUtils.CreateRandomFile(Path.Combine(rootPath, "added1.dat"), 1024), new BatchingContextTestItem("added1.dat"));
            ctx.PendAdd(TestUtils.CreateRandomFile(Path.Combine(rootPath, "added2.dat"), 1024), new BatchingContextTestItem("added2.dat"));

            ctx.Flush();

            workspace.CheckIn(
                workspace.GetPendingChanges(),
                "batch 1");

            string editFilePath = TestUtils.EditRandomFile(Path.Combine(rootPath, "added1.dat"));
            ctx.PendEdit(editFilePath, editFilePath, new BatchingContextTestItem("added1.dat"));
            ctx.PendAdd(TestUtils.CreateRandomFile(Path.Combine(rootPath, "added3.dat"), 1024), new BatchingContextTestItem("added3.dat"));

            ctx.Flush();

            workspace.CheckIn(
                workspace.GetPendingChanges(),
                "batch 2");

            ctx.PendDelete(workspace.GetServerItemForLocalItem(Path.Combine(rootPath, "added1.dat")), workspace.GetServerItemForLocalItem(Path.Combine(rootPath, "added1.dat")));
            ctx.PendDelete(Path.Combine(rootPath, "added2.dat"), Path.Combine(rootPath, "added2.dat"));
            ctx.PendDelete(Path.Combine(rootPath, "added3.dat"), Path.Combine(rootPath, "added3.dat"));

            ctx.Flush();

            int changeset = workspace.CheckIn(
                workspace.GetPendingChanges(),
                "batch 3");
            string editFile1Path = TestUtils.EditRandomFile(Path.Combine(rootPath, "added1.dat"));
            ctx.PendEdit(editFile1Path, editFile1Path, new BatchingContextTestItem("added1.dat"));
            ctx.PendUndelete(Path.Combine(rootPath, "added1.dat"), Path.Combine(rootPath, "added1.dat"), changeset.ToString());
            ctx.PendUndelete(Path.Combine(rootPath, "added2.dat"), Path.Combine(rootPath, "added2.dat"), changeset.ToString());
            ctx.PendUndelete(Path.Combine(rootPath, "added3.dat"), Path.Combine(rootPath, "added3.dat"), changeset.ToString());

            string editFile3Path = TestUtils.EditRandomFile(Path.Combine(rootPath, "added3.dat"));
            ctx.PendEdit(editFile3Path, editFile3Path, new BatchingContextTestItem("added3.dat"));

            ctx.Flush();

            workspace.CheckIn(
                workspace.GetPendingChanges(),
                "batch 4");

            ctx.PendDelete(Path.Combine(rootPath, "added1.dat"), Path.Combine(rootPath, "added1.dat"));
            ctx.PendDelete(Path.Combine(rootPath, "added2.dat"), Path.Combine(rootPath, "added2.dat"));
            ctx.PendDelete(Path.Combine(rootPath, "added3.dat"), Path.Combine(rootPath, "added3.dat"));

            ctx.Flush();

            changeset = workspace.CheckIn(
                workspace.GetPendingChanges(),
                "batch 5");
            string editFile12Path = TestUtils.EditRandomFile(Path.Combine(rootPath, "added1.dat"));
            ctx.PendEdit(editFile12Path, editFile12Path, new BatchingContextTestItem("added1.dat"));
            ctx.PendUndelete(Path.Combine(rootPath, "added1.dat"), Path.Combine(rootPath, "added1.dat"), changeset.ToString());
            ctx.PendUndelete(Path.Combine(rootPath, "added2.dat"), Path.Combine(rootPath, "added2.dat"), changeset.ToString());
            ctx.PendUndelete(Path.Combine(rootPath, "added3.dat"), Path.Combine(rootPath, "added3.dat"), changeset.ToString());

            string editFile32Path = TestUtils.EditRandomFile(Path.Combine(rootPath, "added3.dat"));
            ctx.PendEdit(editFile32Path, editFile32Path, new BatchingContextTestItem("added3.dat"));

            ctx.Flush();

            workspace.CheckIn(
                workspace.GetPendingChanges(),
                "batch 6");


            for (int i = 0; i < 1111; i++)
            {
                ctx.PendAdd(TestUtils.CreateRandomFile(Path.Combine(rootPath,
                    string.Format(@"SubFolder\added{0}.dat", i)), 1024), 
                    new BatchingContextTestItem(string.Format(@"SubFolder\added{0}.dat", i)));
            }

            ctx.Flush();

            workspace.CheckIn(
                workspace.GetPendingChanges(),
                "batch 7");

            ctx.PendDelete(Path.Combine(rootPath, "Subfolder"), Path.Combine(rootPath, "Subfolder"));
            ctx.Flush();

            changeset = workspace.CheckIn(
                workspace.GetPendingChanges(),
                "batch 8");

            ctx.PendUndelete(Path.Combine(rootPath, "Subfolder"), Path.Combine(rootPath, "Subfolder"), changeset.ToString());
            ctx.Flush();

            workspace.CheckIn(
                workspace.GetPendingChanges(),
                "batch 9");

            sw.Stop();

            TraceManager.TraceInformation("Test body took {0}", sw.Elapsed);
            sw.Reset();
        }

        #region Test Helpers
        private string getTestRoot()
        {
            return TestUtils.TextReportRoot;
        }

        private Workspace GetWorkspace(string localPath, string glob)
        {
            MasterTfsClient.CommitCheckin += new CommitCheckinEventHandler(tfsClient_CommitCheckin);
            MasterTfsClient.Conflict += new ConflictEventHandler(tfsClient_Conflict);
            MasterTfsClient.Getting += new GettingEventHandler(tfsClient_Getting);
            MasterTfsClient.NewPendingChange += new PendingChangeEventHandler(tfsClient_NewPendingChange);
            MasterTfsClient.NonFatalError += new ExceptionEventHandler(tfsClient_NonFatalError);
            MasterTfsClient.UndonePendingChange += new PendingChangeEventHandler(tfsClient_UndonePendingChange);

            Workspace ws = MasterTfsClient.CreateWorkspace(testWorkspace);

            Directory.CreateDirectory(localPath);

            ws.Map(getProjectRoot() + glob, localPath);

            return ws;
        }

        private string getProjectRoot()
        {
            return String.Format("$/{0}/", TestEnvironment.MasterProject);
        }

        private void tfsClient_UndonePendingChange(object sender, PendingChangeEventArgs e)
        {
            Console.WriteLine("Undoing {0}", e.PendingChange.ServerItem);
        }

        private void tfsClient_NonFatalError(object sender, ExceptionEventArgs e)
        {
            // Exceptions are always rethrown
            if (e.Exception != null)
                throw e.Exception;

            // For starters, log the message
            Console.Error.WriteLine(e.Failure.Message);

            if (e.Failure.Severity == SeverityType.Error && throwOnNonFatalErrors)
            {
                throw new Exception(e.Failure.Message);
            }
        }

        private void tfsClient_CommitCheckin(object sender, CommitCheckinEventArgs e)
        {
            Console.WriteLine("Checked in change {0}", e.ChangesetId);
        }

        private void tfsClient_Conflict(object sender, ConflictEventArgs e)
        {
            Console.Error.WriteLine("Conflict: " + e.Message);
        }

        private void tfsClient_NewPendingChange(object sender, PendingChangeEventArgs e)
        {
            Console.WriteLine("Pending change {0} for {1}", e.PendingChange.ChangeTypeName, e.PendingChange.ServerItem);
        }

        private void tfsClient_Getting(object sender, GettingEventArgs e)
        {
            string error;
            string message = e.GetMessage(null, out error);
            Console.WriteLine(message);
            if (error != null)
            {
                Console.Error.WriteLine(error);
            }
        }

        private bool throwOnNonFatalErrors = true;

        [TestInitialize]
        public override void Initialize()
        {
            base.Initialize();
            ConfigFile.WriteAndLoad(ConfigParameters);

            /* setup */
            string glob = TestUtils.GetRandomAsciiString(10);
            rootPath = Path.Combine(getTestRoot(), glob);
            Directory.CreateDirectory(rootPath);

            try
            {
                workspace = GetWorkspace(rootPath, glob);
            }
            catch (VersionControlException)
            {
                CleanUpWorkspace(MasterTfsClient, MasterWorkspace);
                workspace = GetWorkspace(rootPath, glob);
            }
            ctx = new BatchingContext(workspace);

            listeners = new TestVCEventListeners();
            ctx.BatchedItemError += listeners.BatchedItemError;
            ctx.MergeError += listeners.MergeItemError;
        }

        [TestCleanup]
        public override void Cleanup()
        {
            MasterTfsClient.CommitCheckin -= new CommitCheckinEventHandler(tfsClient_CommitCheckin);
            MasterTfsClient.Conflict -= new ConflictEventHandler(tfsClient_Conflict);
            MasterTfsClient.Getting -= new GettingEventHandler(tfsClient_Getting);
            MasterTfsClient.NewPendingChange -= new PendingChangeEventHandler(tfsClient_NewPendingChange);
            MasterTfsClient.NonFatalError -= new ExceptionEventHandler(tfsClient_NonFatalError);
            MasterTfsClient.UndonePendingChange -= new PendingChangeEventHandler(tfsClient_UndonePendingChange);

            try
            {
                workspace.PendDelete(workspace.Folders[0].ServerItem);
                workspace.CheckIn(workspace.GetPendingChanges(), "Clean up");
            }
            catch (Exception e)
            {
                Trace.TraceError(e.ToString());
            }

            CleanUpWorkspace(MasterTfsClient, MasterWorkspace);

            base.Cleanup();
        }
        #endregion Test Helpers

        #region Verification methods

        List<string> pendedAdds = new List<string>();
        Dictionary<string, string> pendedBranches = new Dictionary<string, string>();
        Dictionary<string, string> pendedMerges = new Dictionary<string, string>();

        private void PendAdd(string fileName)
        {
            string path = TestUtils.CreateRandomFile(Path.Combine(rootPath, fileName), 24);
            ctx.PendAdd(path, new BatchingContextTestItem(path));
            pendedAdds.Add(path);
        }

        private void PendBranch(string parentPath, string childPath, string branchFromVersion)
        {
            ctx.PendBranch(parentPath, childPath, branchFromVersion);
            pendedBranches.Add(parentPath, childPath);
        }

        private void PendMerge(string parentPath, string childPath, IMigrationItem downloadItem)
        {
            ctx.PendMerge(parentPath, childPath, RecursionType.Full, "1", "1", downloadItem);
            pendedMerges.Add(parentPath, childPath);
        }

        private void Flush()
        {
            ctx.Flush();
            foreach (string add in pendedAdds)
            {
                Assert.AreEqual(1, workspace.GetPendingChanges(add).Length);
                Assert.IsTrue(workspace.GetPendingChanges(add)[0].IsAdd);
            }

            foreach (string branch in pendedBranches.Keys)
            {
                Assert.IsTrue(workspace.GetPendingChanges(branch)[0].IsBranch);
                Assert.AreEqual(1, workspace.GetPendingChanges(branch).Length);
            }

            foreach (string merge in pendedMerges.Keys)
            {
                Assert.IsTrue(workspace.GetPendingChanges(merge)[0].IsMerge);
                Assert.AreEqual(1, workspace.GetPendingChanges(merge).Length);
            }
            Assert.AreEqual(pendedAdds.Count + pendedBranches.Count + pendedMerges.Count, workspace.GetPendingChanges().Length, "There were unexpected pending changes");
            Assert.IsFalse(listeners.batchedItemError);
            Assert.IsFalse(listeners.mergeItemError);
        }

        private void CheckIn()
        {
            workspace.CheckIn(workspace.GetPendingChanges(), "Checking in");
            pendedAdds.Clear();
            pendedBranches.Clear();
            pendedMerges.Clear();
        }

        #endregion verification methods

        ///<summary>
        ///Scenario: A flush is called after all the operations have already been flushed
        ///Expected Result: No Op
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("A flush is called after all the operations have already been flushed")]
        public void FlushAfterFlushTest()
        {
            PendAdd("added1.dat");
            Flush();
            CheckIn();
            Flush();
        }

        ///<summary>
        ///Scenario: Flush is called before any operations have been pended
        ///Expected Result: No Op
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Flush is called before any operations have been pended")]
        public void FlushNoPendTest()
        {
            Flush();
        }

        ///<summary>
        ///Scenario: Flush is called when there are operations already in the workspace
        ///Expected Result: The new operations are combined with the existing 
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Flush is called when there are operations already in the workspace")]
        public void FlushUsedWorkspaceTest()
        {
            string path = TestUtils.CreateRandomFile(Path.Combine(rootPath, "Non-batchedItem.dat"), 24);
            workspace.PendAdd(path);
            pendedAdds.Add(path);

            PendAdd("Batched item.dat");
            Flush();
            CheckIn();
        }

        ///<summary>
        ///Scenario: An add and a merge are pended; the workspace is deleted; flush
        ///Expected Result: BatchedItemError and MergeItemError
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("An add and a merge are pended; the workspace is deleted; flush")]
        public void FlushItemErrorTest()
        {
            string source = Path.Combine(rootPath, "source");
            Directory.CreateDirectory(source);
            workspace.PendAdd(source);
            int changeset = workspace.CheckIn(workspace.GetPendingChanges(), "Checkin");

            PendMerge(Path.Combine(rootPath, "target"), source, 
                new TfsMigrationItem(workspace.VersionControlServer, source, new VersionControlSession(), changeset));
            ctx.Flush();

            Assert.IsTrue(listeners.mergeItemError, "Should have caused a mergeItem error");
            listeners.Reset();
            PendAdd("workspace not there");
            workspace.Delete();
            ctx.Flush();

            Assert.IsTrue(listeners.batchedItemError, "Should have caused a single Item error");

        }

        ///<summary>
        ///Scenario: Pass a collection that is over optimal batch size.
        ///Expected Result: The List of collections returned has a collection of optimal batch size in the first position and one operation in the second position.  All of the passed in operations are preserved. 
        ///</summary>
        [TestMethod(), Priority(1), Owner("curtisp")]
        [Description("Pass a collection that is over optimal batch size.")]
        public void ChunkCollectionTest()
        {
            List<int> collection = new List<int>();
            for (int i = 0; i < 201; i++)
            {
                collection.Add(i);
            }
            List<int[]> lists = ctx.chunkCollection(collection);
            Assert.AreEqual(2, lists.Count, "The collection was not broken into the right number");
            Assert.AreEqual(200, lists[0].Length, "Collection was wrong size");
            Assert.AreEqual(1, lists[1].Length, "Collection was wrong size");

            for (int i = 0; i < lists[0].Length; i++)
            {
                Assert.AreEqual(i, lists[0][i], "Chunking collection did not preserve Collection contents");
            }

            Assert.AreEqual(200, lists[1][0], "Chunking collection did not preserve Collection contents");
        }

        ///<summary>
        ///Scenario: PendBranch called with a path that does not exist
        ///Expected Result: No-Op
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("PendBranch called with a path that does not exist")]
        public void PendBranchInvalidSourceTest()
        {
            Directory.CreateDirectory(Path.Combine(rootPath, "target"));
            PendBranch("source", Path.Combine(rootPath, "target"), MasterTfsClient.GetLatestChangesetId().ToString());
            ctx.Flush();

            Assert.AreEqual(0, workspace.GetPendingChanges().Length, "Pending a branch from an invalid path should not have resulted in an pendingChange");
        }

        ///<summary>
        ///Scenario: PendBranch called with an invalid path
        ///Expected Result: No-Op
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("PendBranch called with a path that already exists")]
        public void PendBranchInvalidTargetTest()
        {
            Directory.CreateDirectory(Path.Combine(rootPath, "source"));
            PendAdd("source/file.txt");

            Flush();
            CheckIn();

            PendBranch(Path.Combine(rootPath, "source"), "target", MasterTfsClient.GetLatestChangesetId().ToString());
            ctx.Flush();

            Assert.AreEqual(0, workspace.GetPendingChanges().Length, "Pending a branch from an invalid path should not have resulted in an pendingChange");
        }

        ///<summary>
        ///Scenario: Call tryGetAsServerPath on a path that is not mapped.
        ///Expected Result: Returns false
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Call tryGetAsServerPath on a path that is not mapped.")]
        public void TryGetAsServerPathUnmappedTest()
        {
            Microsoft_TeamFoundation_Migration_Toolkit_BatchingContextAccessor ctxAccessor = new Microsoft_TeamFoundation_Migration_Toolkit_BatchingContextAccessor(ctx);
            string path;
            Assert.IsFalse(ctxAccessor.tryGetAsServerPath("$/" + TestEnvironment.MasterProject + "otherPath", out path));
            Assert.IsNull(path);
        }
    }

    /// <summary>
    /// BatchingContextTestItem an implementation of ImigrationItem that is used in BatchingContext tests only. 
    /// </summary>
    public class BatchingContextTestItem : IMigrationItem
    {
        string m_displayName;
        public void Download(string localPath)
        {
            //Do nothing, the item should already been created.
        }

        public string DisplayName
        {
            get
            {
                return m_displayName;
            }
        }

        public VersionControlSession Session
        {
            get
            {
                throw new Exception("Session is not defined for BatchingContextTestItem");
            }
            set
            {
                throw new Exception("Session is not defined for BatchingContextTestItem");
            }
        }

        public BatchingContextTestItem(string displayName)
        {
            m_displayName = displayName;
        }
    }
}