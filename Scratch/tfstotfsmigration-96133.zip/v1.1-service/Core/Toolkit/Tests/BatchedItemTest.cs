// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.VC;
using Microsoft.TeamFoundation.VersionControl.Client;

namespace Tests
{

    [TestClass]
    public class BatchedItemTest
    {
        ///<summary>
        ///Scenario: Create a Batched Item with 100 as the change type
        ///Expected Result: ArgumentNullException 
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Create a Batched Item with 100 as the change type")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void InvlaidChangeActionTest()
        {
            BatchedItem item = new BatchedItem(null, (ChangeAction)100);
        }

        ///<summary>
        ///Scenario: Create a batched item with a null target
        ///Expected Result: InvalidArgumentException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Create a batched item with a null target")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullTargetTest()
        {
            BatchedItem item = new BatchedItem(null, ChangeAction.Unknown);
        }

        ///<summary>
        ///Scenario: Create a batched item with a empty target
        ///Expected Result: ArgumentNullException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Create a batched item with a empty target")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void EmptyTargetTest()
        {
            BatchedItem item = new BatchedItem(string.Empty, ChangeAction.Unknown);
        }

        ///<summary>
        ///Scenario: Create a batched item with a null source
        ///Expected Result: ArgumentNullException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Create a batched item with a null source")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullSourceTest()
        {
            BatchedItem item = new BatchedItem(null, "target", ChangeAction.Unknown);
        }

        ///<summary>
        ///Scenario: Create a batched item with an empty source
        ///Expected Result: InvalidArgumentException
        ///</summary>
        [TestMethod(), Priority(3), Owner("curtisp")]
        [Description("Create a batched item with an empty source")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void EmptySourceTest()
        {
            BatchedItem item = new BatchedItem(string.Empty, "target", ChangeAction.Unknown);
        }

        ///<summary>
        ///Scenario: Create a batched item passing in merge options and recursivity
        ///Expected Result: The Batched item ChangeAction is merge
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Create a batched item passing in merge options and recursivity")]
        public void BatchedMergeItemTest()
        {
            BatchedItem item = new BatchedItem("source", "target", RecursionType.Full, "1", "2", null);

            Assert.AreEqual(ChangeAction.Merge, item.Action, "A merge item was not created");
            Assert.AreEqual(RecursionType.Full, item.Recursion, "Recursivity was not preserved");
            Assert.AreEqual("1", item.Version, "Merge version from was not preserved");
            Assert.AreEqual("2", item.MergeVersionTo, "Merge version to was not preserved");
        }
    }
}
