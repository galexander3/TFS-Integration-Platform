// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Fields migration tests
    /// </summary>
    [TestClass]
    public class WitFieldsMigrationTest : WitTestBase
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        public WitFieldsMigrationTest()
            : base("TestSession1")
        {
        }

        /// <summary>
        /// Does the migration test for the given field and its values.
        /// </summary>
        /// <param name="fieldName">Field name</param>
        /// <param name="values">Values</param>
        private void FieldMigrationTest(
            string fieldName,
            params object[] values)
        {
            // Create requested revisions
            WorkItem src = Projects.Left.WorkItemTypes["WitSyncTest"].NewWorkItem();
            Field srcField = src.Fields[fieldName];
            Field revField = src.Fields["WST.InternalRevision"];

            for (int i = 0; i < values.Length; i++)
            {
                srcField.Value = values[i];
                revField.Value = i + 1;
                src.Save();
            }

            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(src.Revisions.Count == dst.Revisions.Count, "Revisions do not match!");
            for (int i = 0; i < src.Revisions.Count; i++)
            {
                object srcValue = values[i];
                object dstValue = dst.Revisions[i][fieldName];

                Assert.IsTrue(CompareValues(srcValue, src.Revisions[i][fieldName]), "Field was not set properly!");
                Assert.IsTrue(CompareValues(srcValue, dstValue), "Values do not match!");
            }
        }

        /// <summary>
        /// Scenario: migrating multiple revisions of a string field.
        /// Expected result: all revisions have been migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Simple migration of revisions of a new work item")]
        public void WIT_MigrateStringField()
        {
            FieldMigrationTest("WST.String", "Foo", null, "", "Foo", "Foo", "Bar");
        }

        /// <summary>
        /// Scenario: migrating multiple revisions of an integer field.
        /// Expected result: all revisions have been migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migration of multiple revisions of an integer field")]
        public void WIT_MigrateIntField()
        {
            FieldMigrationTest("WST.Int", 1, null, 3, 3, 4);
        }

        /// <summary>
        /// Scenario: migrating multiple revisions of a double field.
        /// Expected result: all revisions have been migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migration of multiple revisions of a double field")]
        public void WIT_MigrateDoubleField()
        {
            FieldMigrationTest("WST.Double", 1.0, null, null, 1.1, 1.1, 3.1);
        }

        /// <summary>
        /// Scenario: migrating multiple revisions of a date/time field.
        /// Expected result: all revisions have been migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migration of multiple revisions of a date/time field")]
        public void WIT_MigrateDateTimeField()
        {
            FieldMigrationTest(
                "WST.DateTime",
                new DateTime(2007, 3, 14, 10, 00, 00),
                null,
                null,
                new DateTime(2006, 3, 14, 23, 00, 00),
                new DateTime(2006, 3, 14, 23, 00, 00),
                new DateTime(2007, 5, 12, 3, 15, 00));
        }

        /// <summary>
        /// Scenario: migrating multiple revisions of a plain text field.
        /// Expected result: all revisions have been migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migration of multiple revisions of a plain text field")]
        public void FMT_MigratePlainTextField()
        {
            FieldMigrationTest("WST.PlainText", "Foo", null, null, "Bar", "Bar", "Foo");
        }
    }
}
