// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

using TestQueue = Microsoft.TeamFoundation.Migration.Toolkit.Wit.ProcessingQueue<int>;

namespace Tests.WIT
{
    /// <summary>
    /// Queue writers class.
    /// </summary>
    class QueueWriters: IDisposable
    {
        private TestQueue m_queue;                          // Queue
        private volatile bool m_isAborted;                  // Aborted flag
        private Random m_rnd;                               // Random numbers generator
        private Thread[] m_threads;                         // Working threads

        public QueueWriters(
            TestQueue q,
            int threadCount)
        {
            m_queue = q;
            m_isAborted = false;
            m_rnd = new Random();

            m_threads = new Thread[threadCount];
            ThreadStart threadProc = new ThreadStart(ThreadProc);

            for (int i = 0; i < threadCount; i++)
            {
                m_threads[i] = new Thread(threadProc);
                m_threads[i].Start();
            }
        }

        /// <summary>
        /// Disposes the class.
        /// </summary>
        public void Dispose()
        {
            m_isAborted = true;

            for (int i = 0; i < m_threads.Length; i++)
            {
                m_threads[i].Join();
            }
        }

        /// <summary>
        /// Thread function.
        /// </summary>
        private void ThreadProc()
        {
            while (!m_isAborted)
            {
                m_queue.Add(m_rnd.Next());
            }
        }
    }
}
