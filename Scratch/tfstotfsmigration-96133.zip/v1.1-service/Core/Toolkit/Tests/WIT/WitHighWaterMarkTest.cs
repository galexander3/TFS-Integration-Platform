﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tests.Framework;


namespace Tests
{
    [TestClass()]
    public class WitHighWaterMarkTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        [TestMethod()]
        public void WitWaterMarkInputValidationTest()
        {

            try
            {
                Watermark mark = new Watermark("1234", 10);
            }
            catch (Exception)
            {
                Assert.Fail("can not create Water mark object");
            }

            try
            {
                Watermark mark = new Watermark(null, 10);
                Assert.Fail("id can not be null string");
            }
            catch(Exception)
            {
            }

            try
            {
                Watermark mark = new Watermark("12", -1);
                Assert.Fail("revision number can not be minus");
            }
            catch (Exception)
            {
                Assert.IsTrue(true, "revision number is minus");
            }


        }

    }
}
