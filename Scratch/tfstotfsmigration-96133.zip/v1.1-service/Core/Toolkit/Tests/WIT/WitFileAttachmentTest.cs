// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Tests.Framework;

namespace Tests.WIT
{
    /// <summary>
    /// Tests for file attachment migration.
    /// </summary>
    [TestClass]
    public class WitFileAttachmentTest : WitTestBase
    {
        private List<string> m_tempFiles;                   // List of temp files, created by the test

        /// <summary>
        /// Constructor.
        /// </summary>
        public WitFileAttachmentTest()
            : base("FileAttachments")
        {
            m_tempFiles = new List<string>();
        }

        /// <summary>
        /// Scenario: attachments are out of sync; resolution set to throw.
        /// Expected result: no synchronization.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Attachments are out of sync; resolution set to 'throw'")]
        public void WITAttach_NoMigrationOnConflict()
        {
            WorkItem src = CreateWorkItem(Side.Left, 2, "Foo");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            src.Attachments.Add(
                CreateAttachment(100));
            src.Title = "Bar";
            src.Save();
            dst.Attachments.Add(
                CreateAttachment(200));
            dst.Title = "Bar";
            dst.Save();

            int srcRev = src.Rev;
            int dstRev = dst.Rev;

            Session.Policies.AttachmentsConflict.Reaction = WitConflictReaction.Throw;

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Rev == srcRev, "Source item was updated!");
            Assert.IsTrue(dst.Rev == dstRev, "Target item was updated!");
        }

        /// <summary>
        /// Scenario: migrating a single attachment from left to right.
        /// Expected result: new attachment is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Migrating an attachment from left to right")]
        public void WITAttach_LtoRMigration1()
        {
            SideToSideMigration(Side.Left, 1, 1);
        }

        /// <summary>
        /// Scenario: migrating 50 attachments from left to right.
        /// Expected result: new attachments are migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Migrating 50 attachments from left to right")]
        public void WITAttach_LtoRMigration50()
        {
            SideToSideMigration(Side.Left, 50, 5);
        }

        /// <summary>
        /// Scenario: migrating a single attachment from right to left.
        /// Expected result: new attachment is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Migrating an attachment from right to left")]
        public void WITAttach_RtoLMigration1()
        {
            SideToSideMigration(Side.Right, 1, 1);
        }

        /// <summary>
        /// Scenario: migrating 50 attachments from from right to left.
        /// Expected result: new attachment is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Migrating 50 attachments from right to left")]
        public void WITAttach_RtoLMigration50()
        {
            SideToSideMigration(Side.Right, 50, 50);
        }
        
        
        /// <summary>
        /// Scenario: migrating attachments to match the master side.
        /// Expected result: attachments on both sides match the master side.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Migrating attachments to match the master side")]
        public void WITAttach_MatchMasterMigrationSmall()
        {
            MatchMasterMigration(2, 1);
        }

        /// <summary>
        /// Scenario: migrating attachments to match the master side.
        /// Expected result: attachments on both sides match the master side.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Migrating attachments to match the master side")]
        public void WITAttach_MatchMasterMigrationMedium()
        {
            MatchMasterMigration(50, 17);
        }
        
        /// <summary>
        /// Scenario: migrating attachments to match the master side.
        /// Expected result: attachments on both sides match the master side.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("(Very Slow!) Migrating attachments to match the master side")]
        public void WITAttach_MatchMasterMigrationLARGE()
        {
            MatchMasterMigration(250, 80);
        }

        /// <summary>
        /// Scenario: migrating attachments to union both sides.
        /// Expected result: attachments on both sides match and are the union of the two sides.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Migrating attachments to union both sides")]
        public void WITAttach_UnionMigrationSmall()
        {
            UnionBothMigration(2, 1, 1);
        }

        /// <summary>
        /// Scenario: migrating attachments to union both sides.
        /// Expected result: attachments on both sides match and are the union of the two sides.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Migrating attachments to union both sides")]
        public void WITAttach_UnionMigrationMedium()
        {
            UnionBothMigration(50, 17, 13);
        }

        /// <summary>
        /// Scenario: migrating attachments to union both sides.
        /// Expected result: attachments on both sides match and are the union of the two sides.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("(Very Slow!) Migrating attachments to union both sides")]
        public void WITAttach_UnionMigrationLARGE()
        {
            UnionBothMigration(250, 80, 60);
        }

        /// <summary>
        /// Scenario: attachment conflict with "throw" policy.
        /// Expected result: items are not synchronized.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Conflict in file attachments with 'throw' reaction")]
        public void WITAttach_ThrowPolicyTest()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            src.Attachments.Add(CreateAttachment(10));
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];

            src.Attachments.Add(CreateAttachment(10));
            src.Save();
            dst.Attachments.Add(CreateAttachment(10));
            dst.Save();

            int srcRev = src.Revision;
            int dstRev = dst.Revision;

            Session.Policies.AttachmentsConflict.Reaction = WitConflictReaction.Throw;
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Rev == srcRev, "Source item was updated!");
            Assert.IsTrue(dst.Rev == dstRev, "Target item was updated!");
        }

        /// <summary>
        /// Scenario: migrating attachment with size is very big.
        /// Expected result: The attachment was migrated.
        /// </summary>
        [TestMethod, Priority(2), Owner("johe")]
        [Description("migrating big size attachment")]
        public void WITAttach_BigSizeTest()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            src.Attachments.Add(CreateAttachment(4000000));
            src.Save();
            WorkItem dst = Synchronize(Side.Left, src)[0];
            CompareAttachments(src, dst);
        }
        
        /// <summary>
        /// Scenario: migrating attachment with size 0.
        /// Expected result: The attachment was migrated.
        /// </summary>
        [TestMethod, Priority(2), Owner("johe")]
        [Description("migrating attachment with zero size")]
        public void WITAttach_LToRZeroSizeTest()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            src.Attachments.Add(CreateAttachment(0));
            src.Save();
            WorkItem dst = Synchronize(Side.Left, src)[0];
            CompareAttachments(src, dst);
        }

        /// <summary>
        /// Scenario: migrating attachment is the same size on both side.
        /// Expected result: attachments on both sides match the master side.
        /// </summary>
        [TestMethod, Priority(2), Owner("johe")]
        [Description("migrating attachment with same size")]
        public void WITAttach_SameSizeOnBothSide()
        {
            Session.Policies.AttachmentsConflict.Reaction = WitConflictReaction.Master;

            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];
            src.Attachments.Add(CreateAttachment(40));
            src.Save();

            dst.Attachments.Add(CreateAttachment(40));
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            dst.SyncToLatest();
            CompareAttachments(src, dst);
        }

        /// <summary>
        /// Scenario: migrating attachment conflicts throw policy.
        /// Expected result: no exception.
        /// </summary>
        [TestMethod, Priority(2), Owner("johe")]
        [Description("migrating attachment conflicts throw policy")]
        public void WITAttach_ThrowMigration()
        {


        }

        /// <summary>
        /// Scenario: End to end scenario for attachment testing 
        /// Expected result: no error
        /// </summary>
        [TestMethod, Priority(2), Owner("johe")]
        [Description("End to end scenario for attachment testing")]
        public void WITEndToEnd_Attachments()
        {
            Session.Policies.AttachmentsConflict.Reaction = WitConflictReaction.Master;
            // new work item . new attachment migration, left to right
            WorkItem src = CreateWorkItem(Side.Left, 1);
            Attachment att = CreateAttachment(30);
            src.Attachments.Add(att);
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];
            CompareAttachments(src, dst);

            //remove attachment then sync it
            src.Attachments.Remove(att);
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue(src.Attachments.Count == 0, "There should be no attachment");
            CompareAttachments(src, dst);

            //modify work item and  add attachments
            src["WST.String1"] = new Guid().ToString();
            src.Attachments.Add(CreateAttachment(10));
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            Assert.IsTrue(src.Attachments.Count == 1, "There should be one attachment");
            CompareAttachments(src, dst);

            //modify workitem in one side and add attachment in the other
            src["WST.String1"] = new Guid().ToString();
            src.Save();
            dst.Attachments.Add(CreateAttachment(10));
            dst.Save();
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            Assert.IsTrue(src.Attachments.Count == 1, "There should be one attachment");
            CompareAttachments(src, dst);

            // change policy to union
            Session.Policies.AttachmentsConflict.Reaction = WitConflictReaction.Union;
            
            src.Attachments.Add(CreateAttachment(40));
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            Assert.IsTrue(dst.Attachments.Count == 2, "There should be two attachment");
            CompareAttachments(src, dst);

            // change policy to throw
            Session.Policies.AttachmentsConflict.Reaction = WitConflictReaction.Throw;
            src.Attachments.Add(CreateAttachment(34));
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            Assert.IsTrue(src.Attachments.Count == 3, "There should be three attachment");
            Assert.IsTrue(dst.Attachments.Count == 2, "There should be two attachment");
        }

        #region Protected Methods

        /// <summary>
        /// Tests cleanup function.
        /// </summary>
        protected override void OnTestCleanup()
        {
            base.OnTestCleanup();
            for (int i = 0; i < m_tempFiles.Count; i++)
            {
                File.Delete(m_tempFiles[i]);
            }
            m_tempFiles.Clear();
        }


        /// <summary>
        /// Migrate attachments from one side to the other.
        /// </summary>
        /// <param name="startingSide">Side where initial attachments should be created.</param>
        /// <param name="attachmentCount">Number of attachments.</param>
        /// <param name="expectedRevisions">Number of revisions expected on target side after syncing.</param>
        protected void SideToSideMigration(Side startingSide, int attachmentCount, int expectedRevisions)
        {
            WorkItem src = CreateWorkItem(startingSide, attachmentCount, 
                "SideToSideMigration-" + startingSide.ToString() + " to " + (!startingSide).ToString()
                + "-" + attachmentCount.ToString());

            WorkItem dst = Synchronize(startingSide, src)[0];
            CompareAttachments(src, dst);

            Assert.IsTrue((dst.Revision == expectedRevisions), 
                "Wrong number of revisions! Expected " + expectedRevisions.ToString() 
                + ", but there are " + dst.Revision.ToString() + "." );

            int srcRev = src.Rev;
            int dstRev = dst.Rev;

            dst = Synchronize(startingSide, src)[0];
            src.SyncToLatest();
            src = Synchronize(!startingSide, dst)[0];
            dst.SyncToLatest();

            Assert.IsTrue(srcRev == src.Rev, "Source item was updated!");
            Assert.IsTrue(dstRev == dst.Rev, "Target item was updated!");
        }


        /// <summary>
        /// Migrate attachments so that they match the master side.
        /// </summary>
        /// <param name="origAttachCount">Number of attachments for original sync.</param>
        /// <param name="newAttachCount">Number of attachments to add after the original sync.</param>
        protected void MatchMasterMigration(int origAttachCount, int newAttachCount)
        {
            base.Session.Policies.AttachmentsConflict.MasterSystem = SystemType.Other;
            base.Session.Policies.AttachmentsConflict.Reaction = WitConflictReaction.Master;

            //Put source on right side because our config says "Other" is master
            WorkItem src = CreateWorkItem(Side.Right, origAttachCount, "MatchMasterMigration");
            WorkItem dst = Synchronize(Side.Right, src)[0];

            //Remove old attachments and add a new one
            src.Attachments.Clear();
            Random r = new Random();
            for (int i = 0; i < newAttachCount; i++)
            {
                src.Attachments.Add(CreateAttachment(r.Next(500)));
            }
            src.Save();

            //Also, add a couple to the dst side to make sure they are removed.
            dst.Attachments.Add(CreateAttachment(r.Next(500)));
            dst.Attachments.Add(CreateAttachment(r.Next(500)));
            dst.Save();

            //Now, they should only have the new attachment (not the original 2 since they were removed from master)
            dst = Synchronize(Side.Right, src)[0];
            src.SyncToLatest();
            CompareAttachments(src, dst);

            //Check that we have the right number of attachments per side.
            Assert.IsTrue((dst.AttachedFileCount == newAttachCount), "Should have " + newAttachCount.ToString() +
                " attachments per side!  There are " + dst.AttachedFileCount.ToString() + ".");
        }

        /// <summary>
        /// Migrate attachments so that they create a union on both sides.
        /// </summary>
        /// <param name="origAttachCount">Number of attachments for original sync.</param>
        /// <param name="newSourceAttachCount">Number of attachments to add to the source side after the original sync.</param>
        /// <param name="newTargetAttachCount">Number of attachments to add to the source side after the original sync.</param>
        protected void UnionBothMigration(int origAttachCount, int newSourceAttachCount, int newTargetAttachCount)
        {
            base.Session.Policies.AttachmentsConflict.MasterSystem = SystemType.Other;
            base.Session.Policies.AttachmentsConflict.Reaction = WitConflictReaction.Union;

            //Put source on right side because our config says "Other" is master
            WorkItem src = CreateWorkItem(Side.Right, origAttachCount, "UnionBothMigration");
            WorkItem dst = Synchronize(Side.Right, src)[0];

            //Add new ones to source
            Random r = new Random();
            for (int i = 0; i < newSourceAttachCount; i++)
            {
                src.Attachments.Add(CreateAttachment(r.Next(500)));
            }
            src.Save();

            //Add new ones to target
            for (int i = 0; i < newTargetAttachCount; i++)
            {
                dst.Attachments.Add(CreateAttachment(r.Next(500)));
            }
            dst.Save();

            //Now, they should each have a new attachment
            dst = Synchronize(Side.Right, src)[0];
            src.SyncToLatest();
            CompareAttachments(src, dst);

            //Check that we have the right number of attachments per side.
            int expectedCount = origAttachCount + newSourceAttachCount + newTargetAttachCount;
            Assert.IsTrue((dst.AttachedFileCount == expectedCount), "Should be " + expectedCount.ToString() + 
                " attachments per side!  There are "+ dst.AttachedFileCount.ToString()+".");
        }

        /// <summary>
        /// Creates a work item with the given number of attachments.
        /// </summary>
        /// <param name="side">Side on which the work item should be created</param>
        /// <param name="attachCount">Number of attachments to create</param>
        /// <param name="title">Work item title</param>
        /// <returns>Work item</returns>
        protected WorkItem CreateWorkItem(Side side, int attachCount, string title)
        {
            WorkItem wi = Projects[side].WorkItemTypes["WitSyncTest"].NewWorkItem();
            Random r = new Random();

            wi.Title = title;
            for (int i = 0; i < attachCount; i++)
            {
                wi.Attachments.Add(CreateAttachment(r.Next(500)));
            }
            wi.Save();
            return wi;
        }

        /// <summary>
        /// Creates an attachment.
        /// </summary>
        /// <param name="length">Desired file size</param>
        /// <returns>Attachment</returns>
        protected Attachment CreateAttachment(int length)
        {
            string tempFileName = Path.GetTempFileName();
            TestUtils.CreateRandomFile(tempFileName, length);
            m_tempFiles.Add(tempFileName);
            return new Attachment(tempFileName, "Length: " + length.ToString() + "  Comment: " + TestUtils.GetRandomAsciiString(25));
        }
        #endregion
    }
}
