// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Tests.WIT
{
    /// <summary>
    /// Local attachment class.
    /// </summary>
    class LocalAttachment: IDisposable, IEquatable<LocalAttachment>
    {
        private string m_name;                              // Name of the attachment.
        private string m_tempFile;                          // Temporary file with data.
        private long m_size;                                // Size of the attachment

        public string Name { get { return m_name; } }
        public long Size { get { return m_size; } }
        public string LocalFile { get { return m_tempFile; } }

        /// <summary>
        /// Constructor for an existing attachment.
        /// </summary>
        /// <param name="name">Name of the attachment</param>
        /// <param name="data">Stream with the data</param>
        public LocalAttachment(string name, Stream data)
        {
            m_name = name;

            // Store content in a local file
            string tempFile = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            FileStream stream = new FileStream(tempFile, FileMode.CreateNew, FileAccess.ReadWrite);
            try
            {
                using (stream)
                {
                    byte[] buf = new byte[4096];
                    int bytes;

                    while ((bytes = data.Read(buf, 0, buf.Length)) > 0)
                    {
                        stream.Write(buf, 0, bytes);
                        m_size += bytes;
                    }
                }
                m_tempFile = tempFile;
            }
            catch
            {
                File.Delete(tempFile);
                throw;
            }
        }

        /// <summary>
        /// Creates a random attachment with the given name.
        /// </summary>
        /// <param name="name">Name of the attachment</param>
        public LocalAttachment(string name)
        {
            m_name = name;
            string tempFile = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            FileStream stream = new FileStream(tempFile, FileMode.CreateNew, FileAccess.Write);
            try
            {
                using (stream)
                {
                    Random r = new Random();
                    m_size = r.Next(1024);
                    byte[] bytes = new byte[m_size];

                    r.NextBytes(bytes);
                    stream.Write(bytes, 0, bytes.Length);
                }
                m_tempFile = tempFile;
            }
            catch
            {
                File.Delete(tempFile);
                throw;
            }
        }

        /// <summary>
        /// Disposes the object.
        /// </summary>
        public void Dispose()
        {
            if (!string.IsNullOrEmpty(m_tempFile))
            {
                File.Delete(m_tempFile);
            }
        }

        /// <summary>
        /// Compares with another attachment.
        /// </summary>
        /// <param name="other">Attachment to compare with</param>
        /// <returns>True if attachemnts are equal</returns>
        public bool Equals(LocalAttachment other)
        {
            if (!(m_size == other.m_size && m_name.Equals(other.m_name, StringComparison.InvariantCultureIgnoreCase)))
            {
                return false;
            }

            // Compare content
            using (FileStream thisFile = new FileStream(m_tempFile, FileMode.Open, FileAccess.Read))
            using (FileStream thatFile = new FileStream(other.m_tempFile, FileMode.Open, FileAccess.Read))
            {
                int bufSize = 1024;
                byte[] thisBuf = new byte[bufSize];
                byte[] thatBuf = new byte[bufSize];

                for (; ; )
                {
                    int thisRead = thisFile.Read(thisBuf, 0, thisBuf.Length);
                    int thatRead = thatFile.Read(thatBuf, 0, thatBuf.Length);

                    if (thatRead != thisRead)
                    {
                        return false;
                    }
                    if (thisRead == 0)
                    {
                        break;
                    }

                    for (int i = 0; i < thisRead; i++)
                    {
                        if (thisBuf[i] != thatBuf[i])
                        {
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Loads attachment into memory and returns it.
        /// </summary>
        /// <returns>Array of bytes with the content</returns>
        public byte[] GetContent()
        {
            byte[] bytes = new byte[m_size];
            using (FileStream stream = new FileStream(m_tempFile, FileMode.Open, FileAccess.Read))
            {
                stream.Read(bytes, 0, bytes.Length);
            }
            return bytes;
        }
    }
}
