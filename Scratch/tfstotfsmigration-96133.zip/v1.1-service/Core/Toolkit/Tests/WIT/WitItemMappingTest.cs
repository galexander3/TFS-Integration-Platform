// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Summary description for WitItemMappingTest
    /// </summary>
    [TestClass]
    public class WitItemMappingTest : WitTestBase
    {
        public WitItemMappingTest()
            : base("TestSession1")
        {
        }

        /// <summary>
        /// Scenario: mapping during left to right migration.
        /// Expected result: mapping is stored properly.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Mapping during left-to-right migration")]
        public void WIT_ItemMappingLeftToRight()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            string srcId = Session.FindReflections(SystemType.Other, dst.Id.ToString())[0];
            string dstId = Session.FindReflections(SystemType.Tfs, src.Id.ToString())[0];

            Assert.IsTrue(!string.IsNullOrEmpty(srcId), "Source id was not obtained!");
            Assert.IsTrue(!string.IsNullOrEmpty(dstId), "Target id was not obtained!");

            Assert.IsTrue(src.Id == Convert.ToInt32(srcId), "Invalid source id!");
            Assert.IsTrue(dst.Id == Convert.ToInt32(dstId), "Invalid destination id!");
        }

        /// <summary>
        /// Scenario: Mapping during right-to-left migration.
        /// Expected result: mapping is created.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Mapping during right-to-left migration")]
        public void WIT_ItemMappingRightToLeft()
        {
            WorkItem src = CreateWorkItem(Side.Right, 1);
            WorkItem dst = Synchronize(Side.Right, src)[0];

            string dstId = Session.FindReflections(SystemType.Other, src.Id.ToString())[0];
            string srcId = Session.FindReflections(SystemType.Tfs, dst.Id.ToString())[0];

            Assert.IsTrue(!string.IsNullOrEmpty(dstId), "Invalid id!");
            Assert.IsTrue(!string.IsNullOrEmpty(srcId), "Invalid id!");

            Assert.IsTrue(Convert.ToInt32(srcId) == src.Id, "Invalid source item id!");
            Assert.IsTrue(Convert.ToInt32(dstId) == dst.Id, "Invalid target item id!");
        }

        /// <summary>
        /// Scenario: obtaining mapping for two existing items.
        /// Expected result: mapping obtained.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Obtaining mapping for two existing items")]
        public void WIT_ItemMappingTwoItems()
        {
            WorkItem src1 = CreateWorkItem(Side.Left, 1);
            WorkItem src2 = CreateWorkItem(Side.Left, 1);

            WorkItem[] dst = Synchronize(Side.Left, src1, src2);

            string[] dstIds = Session.FindReflections(SystemType.Tfs, src1.Id.ToString(), src2.Id.ToString());

            Assert.IsTrue(!string.IsNullOrEmpty(dstIds[0]), "Empty id!");
            Assert.IsTrue(!string.IsNullOrEmpty(dstIds[1]), "Empty id!");

            Assert.IsTrue(Convert.ToInt32(dstIds[0]) != Convert.ToInt32(dstIds[1]), "Ids are equal!");
        }

        /// <summary>
        /// Scenario: obtaining mapping information for a non-mapped item.
        /// Expected result: null should be returned
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Obtaining mapping for a non-mapped item")]
        public void WIT_ItemMappingUnknownItem()
        {
            string res = Session.FindReflections(SystemType.Tfs, Guid.NewGuid().ToString())[0];
            Assert.IsTrue(res == null, "Id is not null!");

            res = Session.FindReflections(SystemType.Other, Guid.NewGuid().ToString())[0];
            Assert.IsTrue(res == null, "Id is not null!");
        }
    }
}
