// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.Xml;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation;
using Microsoft.TeamFoundation.Server;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Summary description for TfsMetadataSyncTest
    /// </summary>
    [TestClass]
    public class TfsMetadataSyncTest : WitTestBase
    {
        #region Internals

        /// <summary>
        /// Group type.
        /// </summary>
        enum GroupType
        {
            Global,
            Project,
        };

        /// <summary>
        /// Constructor.
        /// </summary>
        public TfsMetadataSyncTest()
            : base("TestSession1")
        {
        }

        /// <summary>
        /// Returns GSS service.
        /// </summary>
        private IGroupSecurityService Gss
        {
            get { return (IGroupSecurityService)Store.TeamFoundationServer.GetService(typeof(IGroupSecurityService)); }
        }

        /// <summary>
        /// Returns metadata synchronization policy.
        /// </summary>
        private TfsMetadataPolicy MetadataPolicy 
        { 
            get { return Session.OtherMigrationSource.TfsSource.MetadataSynchronizationPolicy; } 
        }

        /// <summary>
        /// Creates a group on the given side.
        /// </summary>
        /// <param name="side">Side where the group must be created</param>
        /// <param name="type"></param>
        /// <param name="name"></param>
        /// <returns>Group id</returns>
        private string CreateGroup(
            Side side,
            GroupType type,
            string name)
        {
            string uri = type == GroupType.Global ? null : Projects[side].Uri.ToString();

            return Gss.CreateApplicationGroup(uri, name, "Unit test group");
        }

        /// <summary>
        /// Deletes groups
        /// </summary>
        /// <param name="side">Side the group belongs to</param>
        /// <param name="ids">Groups to be deleted</param>
        private void DeleteGroups(
            Side side,
            params string[] ids)
        {
            IGroupSecurityService gss = Gss;

            for (int i = 0; i < ids.Length; i++)
            {
                try
                {
                    gss.DeleteApplicationGroup(ids[i]);
                }
                catch (Exception)
                {
                    // Cleanup function; do not throw
                }
            }
        }

        /// <summary>
        /// Finds a group by its display name.
        /// </summary>
        /// <param name="side">Side where the group resides</param>
        /// <param name="type">Group type (global/project)</param>
        /// <param name="displayName">Group's display name</param>
        /// <returns></returns>
        private string FindGroup(
            Side side,
            GroupType type,
            string displayName)
        {
            string uri = type == GroupType.Global? null : Projects[side].Uri.ToString();
            Identity[] groups = Gss.ListApplicationGroups(uri);

            foreach (Identity g in groups)
            {
                if (!g.Deleted && TFStringComparer.UserName.Equals(displayName, g.DisplayName))
                {
                    return g.Sid;
                }
            }
            throw new Exception("Group not found!");
        }

        #endregion

        /// <summary>
        /// Scenario: Accounts synchronization.
        /// Expected results: global- and project-scoped groups moved from TFS to Other side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Accounts synchronization")]
        public void WIT_AccountsSynchronization()
        {
            // Enable accounts synchronization
            MetadataPolicy.Types = MetadataTypes.Accounts;

            // Create groups on the source side
            string globName = Guid.NewGuid().ToString();
            string projName = Guid.NewGuid().ToString();

            string lGlobGroup = CreateGroup(Side.Left, GroupType.Global, globName);
            string lProjGroup = CreateGroup(Side.Left, GroupType.Project, projName);
            string rGlobGroup = null;
            string rProjGroup = null;

            try
            {
                Synchronize(Side.Left);

                // Groups must be found
                rGlobGroup = FindGroup(Side.Right, GroupType.Global, globName);
                rProjGroup = FindGroup(Side.Right, GroupType.Project, projName);
            }
            finally
            {
                DeleteGroups(Side.Left, lGlobGroup, lProjGroup);
                DeleteGroups(Side.Right, rGlobGroup, rProjGroup);
            }
        }

        /// <summary>
        /// Scenario: synchronization of work item types between two TFS stores.
        /// Expected results: types must be synchronized.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Synchronization of work item types during TFS 2 TFS migration")]
        public void WIT_WorkItemTypeSynchronization()
        {
            MetadataPolicy.Types = MetadataTypes.Types;
            WorkItemType src = Projects.Left.WorkItemTypes["WitSyncTest"];
            XmlDocument srcXml = src.Export(false);
            XmlElement e = (XmlElement)srcXml.DocumentElement.SelectSingleNode("WORKITEMTYPE/DESCRIPTION");
            string val = Guid.NewGuid().ToString();

            e.InnerText = val;
            Projects.Left.WorkItemTypes.Import(srcXml.DocumentElement);

            Synchronize(Side.Left);
            Refresh();

            WorkItemType dst = Projects.Right.WorkItemTypes["WitSyncTest"];

            Assert.IsTrue(dst.Description == val, "Work item types are out of sync!");
        }
    }
}
