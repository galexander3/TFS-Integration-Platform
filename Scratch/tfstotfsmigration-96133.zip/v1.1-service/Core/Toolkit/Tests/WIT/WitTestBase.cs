// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml;

using Tests.Framework;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.WIT
{
    /// <summary>
    /// WIT testing base class.
    /// </summary>
    public abstract class WitTestBase
    {
        private string m_testStoreName;                     // Test work item store
        private Pair<string> m_projectNames;                // Project names
        private XmlDocument m_defaultConfig;                // Default configuration
        private string m_sessionName;                       // Name of the session which will be used for migration
            
        private WorkItemStore m_store;                      // Test work item store
        private Pair<Project> m_projects;                   // Projects on both sides
        private bool m_hasTypes;                            // Tells whether the project has types

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="sessionName">Name of the session which will be used for migration</param>
        public WitTestBase(
            string sessionName)
        {
            ChangeSessions(sessionName);
        }

        /// <summary>
        /// Returns TFS work item store used for testing.
        /// </summary>
        internal WorkItemStore Store { get { return m_store; } }

        /// <summary>
        /// Returns projects.
        /// </summary>
        internal Pair<Project> Projects { get { return m_projects; } }

        /// <summary>
        /// Shared test initialization function.
        /// </summary>
        [TestInitialize]
        public void Init()
        {
            // Provision shared work item type into both projects when running for the first time
            if (!m_hasTypes)
            {
                XmlDocument sharedType = LoadXml("Tests.WIT.Data.testwit.xml");
                m_projects.Left.WorkItemTypes.Import(sharedType.DocumentElement);
                m_projects.Right.WorkItemTypes.Import(sharedType.DocumentElement);

                Refresh();
                m_hasTypes = true;
            }

            // Load the configuration
            SettingsHelper.LoadSettings(m_defaultConfig);

            // Call the virtual function
            OnTestInitialize();
        }

        /// <summary>
        /// Test cleanup function.
        /// </summary>
        [TestCleanup]
        public void Cleanup()
        {
            // Stop the session if it is currently running
            try
            {
                if (Session.IsRunning)
                {
                    Session.Abort();
                }
            }
            catch
            {
                // Do nothing.
            }
            // Call the virtual function.
            OnTestCleanup();
        }

        /// <summary>
        /// Initialization function
        /// </summary>
        protected virtual void OnTestInitialize()
        {
        }

        /// <summary>
        /// Virtual test cleanup function.
        /// </summary>
        protected virtual void OnTestCleanup()
        {
        }

        /// <summary>
        /// Changes the session.
        /// </summary>
        /// <param name="sessionName">Name of the session which will be used for migration</param>
        internal void ChangeSessions(string sessionName)
        {
            TestEnvironment.Load();

            m_sessionName = sessionName;
            m_testStoreName = TestEnvironment.MasterServer;
            m_projectNames = new Pair<string>(TestEnvironment.MasterProject, TestEnvironment.DependentProject);

            m_defaultConfig = LoadConfigXml("Tests.WIT.Data.config.xml");

            m_store = new WorkItemStore(m_testStoreName);
            Refresh();
        }

        /// <summary>
        /// Creates a work item of the default type with the given number of revisions.
        /// </summary>
        /// <param name="side">Side where the item should be created</param>
        /// <param name="revisions">Number of revisions to create</param>
        /// <returns></returns>
        internal WorkItem CreateWorkItem(
            Side side,
            int revisions)
        {
            WorkItem wi = Projects[side].WorkItemTypes["WitSyncTest"].NewWorkItem();
            Random r = new Random();

            for (int i = 0; i < revisions; i++)
            {
                wi[CoreField.Title] = Guid.NewGuid().ToString();
                wi["WST.String"] = Guid.NewGuid().ToString();
                wi["WST.Int"] = r.Next();
                wi["WST.InternalRevision"] = i + 1;
                wi.Save();
            }
            return wi;
        }

        /// <summary>
        /// Returns current session from the config file.
        /// </summary>
        internal WorkItemTrackingSession Session
        {
            get { return MigrationConfiguration.Current.Wit.Sessions[m_sessionName]; }
        }

        /// <summary>
        /// 
        /// </summary>
        protected void ResetFilterOnBothSide()
        {
            Query query = new Query(Store, "SELECT [System.Id] FROM WorkItems WHERE [System.Id] = -1");
            string curTime = query.EndQuery(query.BeginQuery()).AsOfUTC.ToString("u");
            string filter = string.Format(CultureInfo.InvariantCulture,
                "[System.ChangedDate] >= '{0}'", curTime);
            Session.TfsMigrationSource.Filter = filter;
            Session.OtherMigrationSource.TfsSource.Filter = filter;
        }


        /// <summary>
        /// Loads document from resources.
        /// </summary>
        /// <param name="name">Resource name</param>
        /// <returns>XML document</returns>
        protected static XmlDocument LoadXml(
            string name)
        {
            using (Stream stream = typeof(WitTestBase).Assembly.GetManifestResourceStream(name))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(stream);
                return doc;
            }
        }

        /// <summary>
        /// Loads configuration XML from resources and replaces configurable values.
        /// </summary>
        /// <param name="name">Resource name</param>
        /// <returns>Configuration document</returns>
        private XmlDocument LoadConfigXml(
            string name)
        {
            XmlDocument doc = LoadXml(name);

            // Substitution
            m_testStoreName = SetElementValue(doc, "/Migration/Servers/Tfs[@id='TestServer']/Server", m_testStoreName);
            m_projectNames.Left = SetElementValue(doc, "/Migration/WIT/Sessions/Session/Tfs[@server='TestServer']/Project", m_projectNames.Left);
            m_projectNames.Right = SetElementValue(doc, "/Migration/WIT/Sessions/Session/Source/Tfs[@server='TestServer']/Project", m_projectNames.Right);

            SetElementValue(doc, "/Migration/WIT/Sessions/Session/Source/Provider/InitializationData/BaseUrl", TestEnvironment.WssUrl);            
            // Set up test SQL server
            string server = TestEnvironment.SqlServer;
            server = SetElementValue(doc, "/Migration/Sql/Server", server);
            XmlNode connStringNode = doc.SelectSingleNode("/Migration/Sql/ConnectionString");
            connStringNode.InnerText = string.Format(
                CultureInfo.InvariantCulture, "server={0};Integrated Security=SSPI", server);
            return doc;
        }

        /// <summary>
        /// Sets value of all nodes returned by the query.
        /// </summary>
        /// <param name="doc">XML document</param>
        /// <param name="xpath">XPath query</param>
        /// <param name="value">Value</param>
        /// <returns>Node's value</returns>
        private static string SetElementValue(
            XmlDocument doc,
            string xpath,
            string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                XmlNode node = doc.SelectSingleNode(xpath);
                value = node.InnerText;
            }
            XmlNodeList nodes = doc.SelectNodes(xpath);

            foreach (XmlNode node in nodes)
            {
                node.InnerText = value;
            }
            return value;
        }

        /// <summary>
        /// Synchronizes given items and returns ids of their reflections
        /// </summary>
        /// <param name="side">Side where original items reside</param>
        /// <param name="items">Items to synchronize</param>
        /// <returns>Reflections from the opposite side</returns>
        internal WorkItem[] Synchronize(
            Side side,
            params WorkItem[] items)
        {
            string[] ids = new string[items.Length];

            for (int i = 0; i < items.Length; i++)
            {
                ids[i] = Convert.ToString(items[i].Id, CultureInfo.InvariantCulture);
            }

            SystemType sourceSystem = side == Side.Left ? SystemType.Tfs : SystemType.Other;
            Session.Synchronize(sourceSystem, ids);

            return FindReflections(side, ids);
        }

        /// <summary>
        /// Finds reflections for given items from the specified side
        /// </summary>
        /// <param name="side">Side items belong to</param>
        /// <param name="ids">Ids of items on the source side</param>
        /// <returns>Reflections from the opposite side</returns>
        protected WorkItem[] FindReflections(
            Side side,
            params string[] ids)
        {
            return FindReflections(side, false, ids);
        }

        /// <summary>
        /// Finds reflections for given items from the specified side
        /// </summary>
        /// <param name="side">Side items belong to</param>
        /// <param name="allowMissing">When true a missing reflection is returned as null item in the result array, otherwise the test is failed using hte Assert.Fail method.</param>
        /// <param name="ids">Ids of items on the source side</param>
        /// <returns>Reflections from the opposite side</returns>
        protected WorkItem[] FindReflections(
            Side side,
            bool allowMissing,
            params string[] ids)
        {
            string[] results = Session.FindReflections(side == Side.Left? SystemType.Tfs : SystemType.Other, ids);
            WorkItem[] reflections = new WorkItem[results.Length];

            Assert.IsTrue(results.Length == ids.Length, "Wrong number of reflections!");

            for (int i = 0; i < results.Length; i++)
            {
                int id = 0;

                if (!string.IsNullOrEmpty(results[i]))
                {
                    id = Convert.ToInt32(results[i]);
                }

                if (!allowMissing && id == 0)
                {
                    Assert.Fail("The workitem {0} was not migrated.", ids[i]);
                }

                reflections[i] = (id != 0) ? m_store.GetWorkItem(id) : null;
            }

            return reflections;
        }

        /// <summary>
        /// Compares values according to TFS rules.
        /// </summary>
        /// <param name="value1">Value 1</param>
        /// <param name="value2">Value 2</param>
        /// <returns>True if values are identical</returns>
        protected static bool CompareValues(
            object value1,
            object value2)
        {
            bool isNull1 = IsNullValue(value1);
            bool isNull2 = IsNullValue(value2);


            if (isNull1 ^ isNull2)
            {
                return false;
            }
            else if (isNull1 && isNull2)
            {
                return true;
            }
            else
            {
                return value1.Equals(value2);
            }
        }

        /// <summary>
        /// Checks whether value is null according to TFS standards.
        /// </summary>
        /// <param name="value">Value</param>
        /// <returns>True if null/empty</returns>
        protected static bool IsNullValue(
            object value)
        {
            return value == null || value is DBNull || value is string && ((string)value).Length == 0;
        }

        /// <summary>
        /// Compares two items.
        /// </summary>
        /// <param name="item1">Item 1</param>
        /// <param name="item2">Item 2</param>
        protected void CompareItems(
            WorkItem item1,
            WorkItem item2)
        {
            Assert.IsTrue(item1.Revisions.Count == item2.Revisions.Count, "Different number of revisions!");

            //Compare revisions
            for (int i = 0; i < item1.Revisions.Count; i++)
            {
                Revision srcRev = item1.Revisions[i];
                Revision dstRev = item2.Revisions[i];

                CompareRevision(srcRev.Fields, dstRev.Fields);
            }
        }

        /// <summary>
        /// Compares fields in a single revision.
        /// </summary>
        /// <param name="src">Source fields</param>
        /// <param name="dst">Target fields</param>
        protected void CompareRevision(
            FieldCollection src,
            FieldCollection dst)
        {
            Assert.IsTrue(src.Count == dst.Count, "Different number of fields!");
            for (int j = 0; j < src.Count; j++)
            {
                Field srcField = src[j];

                if (IsComparableField(srcField))
                {
                    Field dstField = dst.GetById(srcField.Id);

                    Assert.IsTrue(
                        CompareValues(GetFieldValue(srcField), GetFieldValue(dstField)),
                        "Different values!");
                }
            }
        }

        /// <summary>
        /// Tells whether the field should be compared.
        /// </summary>
        /// <param name="f">Field</param>
        /// <returns>True if the field should be compared</returns>
        private static bool IsComparableField(
            Field f)
        {
            FieldDefinition fd = f.FieldDefinition;

            switch (fd.Id)
            {
                case (int)CoreField.AreaPath:
                case (int)CoreField.IterationPath:
                    return true;

                case (int)CoreField.AreaId:
                case (int)CoreField.IterationId:
                case (int)CoreField.ChangedDate:
                case (int)CoreField.CreatedDate:
                    return false;

                default:
                    return !fd.IsComputed && fd.IsEditable;
            }
        }

        /// <summary>
        /// Gets normalized field's value.
        /// </summary>
        /// <param name="f">Field</param>
        /// <returns>Value</returns>
        private static object GetFieldValue(
            Field f)
        {
            if (f.Id == (int)CoreField.AreaPath || f.Id == (int)CoreField.IterationPath)
            {
                // Get rid of the project part
                string val = (string)f.Value;
                int idx = val.IndexOf('/');

                return idx == -1 ? string.Empty : val.Substring(idx + 1);
            }
            return f.Value;
        }


        /// <summary>
        /// Compares the attachments on two work items.
        /// </summary>
        /// <param name="item1">Item 1</param>
        /// <param name="item2">Item 2</param>
        protected void CompareAttachments(
            WorkItem item1,
            WorkItem item2)
        {
            Assert.IsTrue(item1.AttachedFileCount == item2.AttachedFileCount, "Different number of file attachments!  " + item1.AttachedFileCount.ToString() + " vs. " + item2.AttachedFileCount.ToString());

            List<IMigrationFileAttachment> list1 = ConvertToMigrationFileAttachmentList(item1.Attachments);
            List<IMigrationFileAttachment> list2 = ConvertToMigrationFileAttachmentList(item2.Attachments);

            FileAttachmentAnalyzer analyzer = FileAttachmentAnalyzer.Create(
                Session.Policies.AttachmentsConflict.ExtraComparisonAttributes,
                new Pair<List<IMigrationFileAttachment>>(list1, list2));

            Assert.IsTrue(analyzer.InSync, "File attachments are not in sync!");
        }

        /// <summary>
        /// Converts WIT OM Attachment Collection into a list of IMigrationFileAttachment
        /// so we can reuse the comparison logic in the toolkit.
        /// </summary>
        /// <param name="coll">Attachment Collection</param>
        /// <returns>List of IMigrationFileAttachment</returns>
        private List<IMigrationFileAttachment> ConvertToMigrationFileAttachmentList(AttachmentCollection coll)
        {
            List<IMigrationFileAttachment> list = new List<IMigrationFileAttachment>();
            foreach (Attachment a in coll)
            {
                list.Add(new TfsMigrationFileAttachment(a, null));
            }
            return list;
        }

        /// <summary>
        /// Checks history of changes for the given field.
        /// </summary>
        /// <param name="item">Work item</param>
        /// <param name="field">Field name</param>
        /// <param name="values">Chain of values</param>
        protected void CheckFieldHistory(
            WorkItem item,
            string field,
            params object[] values)
        {
            Assert.IsTrue(item.Revisions.Count == values.Length, "Wrong number of revisions!");

            for (int i = 0; i < item.Revisions.Count; i++)
            {
                Assert.IsTrue(CompareValues(values[i], item.Revisions[i][field]), "Field values do not match!");
            }
        }

        /// <summary>
        /// Creates path of the given type on the given side.
        /// </summary>
        /// <param name="side">Side</param>
        /// <param name="type">Path type (area/iteration)</param>
        /// <param name="path">Path to create</param>
        /// <returns>Path id</returns>
        internal int CreatePath(
            Side side,
            Node.TreeType type,
            string path)
        {
            WitMigrationConflictPolicy policy = new WitMigrationConflictPolicy(WitConflictReaction.Create);
            TfsCore core = new TfsCore(
                side == Side.Left ? Session.TfsMigrationSource : Session.OtherMigrationSource.TfsSource,
                policy, policy);
            int id = core.TranslatePath(type, path);
            m_store.SyncToCache();
            return id;
        }

        /// <summary>
        /// Compares two paths.
        /// </summary>
        /// <param name="path1">Path 1</param>
        /// <param name="path2">Path 2</param>
        /// <returns>True if paths are identical</returns>
        internal static bool ComparePaths(
            string path1,
            string path2)
        {
            return string.Compare(TrimProject(path1), TrimProject(path2), true, CultureInfo.InvariantCulture) == 0;
        }

        /// <summary>
        /// Trims project (first node) from the path.
        /// </summary>
        /// <param name="path">Path</param>
        /// <returns>Trimmed string</returns>
        private static string TrimProject(
            string path)
        {
            int pos = path.IndexOf('\\');
            return pos == -1 ? string.Empty : path.Substring(pos + 1);
        }

        /// <summary>
        /// Refreshes cached WIT objects.
        /// </summary>
        protected void Refresh()
        {
            m_store.SyncToCache();
            m_projects = new Pair<Project>(
                m_store.Projects[m_projectNames.Left],
                m_store.Projects[m_projectNames.Right]);
        }

        /// <summary>
        /// Compares two collection of links
        /// </summary>
        /// <param name="left">Collection on the left</param>
        /// <param name="right">Collection on the right</param>
        protected void CompareLinks(
            LinkCollection l,
            LinkCollection r)
        {
            Assert.IsTrue(l.Count == r.Count, "Wrong number of items in the collection!");

            List<Link> left = new List<Link>(l.Count);
            List<Link> right = new List<Link>(r.Count);

            for (int i = 0; i < l.Count; i++)
            {
                left.Add(l[i]);
            }
            for (int i = 0; i < r.Count; i++)
            {
                right.Add(r[i]);
            }
            WorkItemLinkComparer cmp = WorkItemLinkComparer.Current;

            left.Sort(cmp);
            right.Sort(cmp);

            for (int i = 0; i < left.Count; i++)
            {
                Assert.IsTrue(cmp.Compare(left[i], right[i]) == 0, "Different links!");
            }
        }
    }
}
