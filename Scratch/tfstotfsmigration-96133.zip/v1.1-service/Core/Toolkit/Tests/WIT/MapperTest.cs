// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Tests.WIT
{
    /// <summary>
    /// Unit tests for the internal mapper class.
    /// </summary>
    [TestClass]
    public class MapperTest : WitTestBase
    {
        private SystemPair<IMigrationWorkItemStore> m_stores;
        private SystemPair<IMigrationWorkItemStore> m_inverseStores;

        #region Internals
        /// <summary>
        /// Constructor.
        /// </summary>
        public MapperTest()
            : base("TestSession1")
        {
        }

        /// <summary>
        /// Tests initialization method.
        /// </summary>
        protected override void OnTestInitialize()
        {
            base.OnTestInitialize();
            m_stores = new SystemPair<IMigrationWorkItemStore>(
                Session.TfsMigrationSource.CreateWorkItemStore(),
                Session.OtherMigrationSource.CreateWorkItemStore());
            m_inverseStores = new SystemPair<IMigrationWorkItemStore>(
                m_stores.Other,
                m_stores.Tfs);

            // Reset high watermarks
            Mapper m = new Mapper(m_stores);
            m.SaveWatermark(SystemType.Tfs, null);
            m.SaveWatermark(SystemType.Other, null);
        }

        /// <summary>
        /// Tests cleanup.
        /// </summary>
        protected override void OnTestCleanup()
        {
            base.OnTestCleanup();

            using (MigrationSqlTransaction trn = (MigrationSqlTransaction)DataAccessManager.Current.StartTransaction())
            {
                using (SqlCommand cmd = trn.CreateCommand())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "UPDATE Sessions SET LeftWatermark = null, RightWatermark=null";
                    cmd.ExecuteNonQuery();
                }
                trn.Complete();
            }
        }

        /// <summary>
        /// Creates a direct/inverse mapper.
        /// </summary>
        /// <param name="isDirect">Direct flag</param>
        /// <returns>Mapper object</returns>
        private Mapper CreateMapper(
            bool isDirect)
        {
            return new Mapper(isDirect ? m_stores : m_inverseStores);
        }

        #endregion

        #region Tests

        /// <summary>
        /// Tests setting the high watermark.
        /// </summary>
        /// <param name="type">System type for which high watermark will be set</param>
        /// <param name="isDirect">Direct/inverse mode</param>
        public void SetWatermark(
            SystemType type,
            bool isDirect)
        {
            SystemType otherType = type == SystemType.Tfs ? SystemType.Other : SystemType.Tfs;
            Mapper m1 = CreateMapper(isDirect);
            string wm = Guid.NewGuid().ToString();

            m1.SaveWatermark(type, wm);
            Assert.IsTrue(m1.HighWatermark[type] == wm, "Watermark was not cached!");
            Assert.IsTrue(m1.HighWatermark[otherType] == null, "Other watermark was updated!");

            Mapper m2 = CreateMapper(isDirect);
            Assert.IsTrue(m2.HighWatermark[type] == wm, "Watermark was not saved!");
            Assert.IsTrue(m2.HighWatermark[otherType] == null, "Other watermark was updated in the database!");
        }

        #endregion


        /// <summary>
        /// Scenario: setting high watermark on the TFS with direct mapping.
        /// Expected result: watermark is set and can be read.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Setting high watermark on the TFS with direct mapping")]
        public void WIT_SetWatermarkTfsDirect()
        {
            SetWatermark(SystemType.Tfs, true);
        }

        /// <summary>
        /// Scenario: setting high watermark on the TFS with inverse mapping.
        /// Expected result: watermark is set and can be read.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Setting high watermark on the TFS side with inverse mapping")]
        public void WIT_SetWatermarkTfsInverse()
        {
            SetWatermark(SystemType.Tfs, false);
        }

        /// <summary>
        /// Scenario: setting high watermark on the non-TFS with direct mapping.
        /// Expected result: watermark is set and can be read.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Setting high watermark on the non-TFS with direct mapping")]
        public void WIT_SetWatermarkOtherDirect()
        {
            SetWatermark(SystemType.Other, true);
        }

        /// <summary>
        /// Scenario: setting high watermark on the non-TFS with inverse mapping.
        /// Expected result: watermark is set and can be read.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Setting high watermark on the non-TFS with inverse mapping")]
        public void WIT_SetWatermarkOtherInverse()
        {
            SetWatermark(SystemType.Other, false);
        }

        /// <summary>
        /// Scenario: creating a mapper which is initially in the inverse mode.
        /// Expected result: mapper works as expected.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Creating a mapper initially in the reverse mode")]
        public void WIT_CreateReverseMapper()
        {
            Mapper m = CreateMapper(false);
            string tfsWm = Guid.NewGuid().ToString();
            string otherWm = Guid.NewGuid().ToString();

            m.SaveWatermark(SystemType.Tfs, tfsWm);
            m.SaveWatermark(SystemType.Other, otherWm);

            // Were watermarks cached properly?
            Assert.IsTrue(m.HighWatermark.Tfs == tfsWm, "TFS watermark was not cached properly!");
            Assert.IsTrue(m.HighWatermark.Other == otherWm, "Non-TFS watermark was not cached properly!");

            // Were watermarks stored properly?
            Mapper m1 = CreateMapper(false);
            Assert.IsTrue(m.HighWatermark.Tfs == tfsWm, "TFS watermark was not saved properly!");
            Assert.IsTrue(m.HighWatermark.Other == otherWm, "Non-TFS watermark was not saved properly!");
            Assert.IsTrue(m.SourceId.Tfs == m1.SourceId.Tfs, "Source ids on the left do not match!");
            Assert.IsTrue(m.SourceId.Other == m1.SourceId.Other, "Source ids on the right do not match!");
        }
    }
}
