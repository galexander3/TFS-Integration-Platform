// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

using TestQueue = Microsoft.TeamFoundation.Migration.Toolkit.Wit.ProcessingQueue<int>;

namespace Tests.WIT
{
    /// <summary>
    /// Processing queue tests.
    /// </summary>
    [TestClass]
    public class ProcessingQueueTest
    {
        #region Internals

        private const int DefaultBatchSize = 11;            // Default batch size
        private Random m_rnd;                               // Random numbers generator
        private volatile int m_count;                       // Processed items count

        /// <summary>
        /// Constructor.
        /// </summary>
        public ProcessingQueueTest()
        {
            m_rnd = new Random();
        }

        /// <summary>
        /// Test initialization routine.
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            m_count = 0;
        }

        /// <summary>
        /// Default callback function for the queue.
        /// </summary>
        /// <param name="items">Items to be processed</param>
        /// <param name="itemsLock">Synchronization object for accessing items</param>
        private void ProcessItems(
            List<int> items,
            TestQueue queue)
        {
            m_count += items.Count;
            Thread.Sleep(m_rnd.Next(500));
        }

        /// <summary>
        /// Creates a queue with the given number of threads and default batch size.
        /// </summary>
        /// <param name="threadCount">Number of threads</param>
        /// <returns>Test queue</returns>
        private TestQueue CreateQueue(
            int threadCount)
        {
            QueueConfiguration cfg = new QueueConfiguration(threadCount, DefaultBatchSize);
            return new TestQueue(cfg, new TestQueue.ProcessItems(ProcessItems));
        }

        /// <summary>
        /// Thread procedure for ManyAddThreads test.
        /// </summary>
        /// <param name="queue">Queue to test</param>
        private void AddThreadProc(
            object queue)
        {
            TestQueue q = (TestQueue)queue;
            Random rnd = new Random();

            for (int i = 0; i < 150; i++)
            {
                q.Add(0);
                Thread.Sleep(rnd.Next(100));
            }
        }

        #endregion

        #region Tests Implementation

        /// <summary>
        /// Creating and flushing a queue.
        /// </summary>
        /// <param name="threadCount">Number of threads</param>
        private void CreateAndFlush(
            int threadCount)
        {
            TestQueue q = CreateQueue(threadCount);
            q.FlushAndWait();
        }

        /// <summary>
        /// Flushing the queue when batch size limit has been reached
        /// </summary>
        /// <param name="threadCount">Number of threads</param>
        private void FlushOnLimit(
            int threadCount)
        {
            TestQueue q = CreateQueue(threadCount);

            for (int i = 0; i < DefaultBatchSize - 1; i++)
            {
                q.Add(0);
            }

            Assert.IsTrue(m_count == 0, "Some items have been processed!");
            q.Add(0);
            q.DoneEvent.WaitOne();

            Assert.IsTrue(m_count == DefaultBatchSize, "Items have not been processed!");
        }

        /// <summary>
        /// Flushing pending items in the queue.
        /// </summary>
        /// <param name="threadCount">Number of threads</param>
        private void FlushPending(
            int threadCount)
        {
            TestQueue q = CreateQueue(threadCount);

            for (int i = 0; i < DefaultBatchSize - 1; i++)
            {
                q.Add(0);
            }

            q.FlushAndWait();
            Assert.IsTrue(m_count == DefaultBatchSize - 1, "Wrong number of processed items!");
        }

        /// <summary>
        /// Processes more items that the queue can handle simultaneously.
        /// </summary>
        /// <param name="threadCount">Number of threads</param>
        private void ProcessManyItems(
            int threadCount,
            int itemCount)
        {
            TestQueue q = CreateQueue(threadCount);

            for (int i = 0; i < itemCount; i++)
            {
                q.Add(0);
            }

            q.FlushAndWait();
            Assert.IsTrue(m_count == itemCount, "Wrong number of items!");
        }

        /// <summary>
        /// Flushes the queue while it's processing some items
        /// </summary>
        /// <param name="threadCount">Number of threads</param>
        private void FlushWhileProcessing(
            int threadCount)
        {
            TestQueue q = CreateQueue(threadCount);

            for (int i = 0; i < DefaultBatchSize * 2 - 1; i++)
            {
                q.Add(0);
            }

            q.FlushAndWait();
            Assert.IsTrue(m_count == DefaultBatchSize * 2 - 1, "Wrong number of items!");
        }

        /// <summary>
        /// Adding to the queue from multiple threads.
        /// </summary>
        /// <param name="threadCount">Number of threads in the queue</param>
        private void ManyAddThreads(
            int threadCount)
        {
            TestQueue q = CreateQueue(threadCount);
            ParameterizedThreadStart pts = new ParameterizedThreadStart(AddThreadProc);

            int c = 5;
            Thread[] threads = new Thread[c];

            for (int i = 0; i < c; i++)
            {
                threads[i] = new Thread(pts);
            }

            // Start all of them
            for (int i = 0; i < c; i++)
            {
                threads[i].Start(q);
            }

            // Wait until all threads finish
            for (int i = 0; i < c; i++)
            {
                threads[i].Join();
            }

            q.FlushAndWait();

            Assert.IsTrue(m_count == 5 * 150, "Wrong number of processed items!");
        }

        #endregion

        /// <summary>
        /// Scenario: creating and flushing a queue in the async mode.
        /// Expected result: no exceptions
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(5000)]
        [Description("Creating and flushing a queue in the async mode")]
        public void PQ_AsyncCreateAndFlush()
        {
            CreateAndFlush(2);
        }

        /// <summary>
        /// Scenario: creating and flushing a queue in the sync mode.
        /// Expected result: no exceptions
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(5000)]
        [Description("Creating and flushing a queue in the sync mode")]
        public void PQ_SyncCreateAndFlush()
        {
            CreateAndFlush(0);
        }

        /// <summary>
        /// Scenario: flushing items in async mode when batch limit has been reached.
        /// Expected result: no exceptions, all items have been processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(5000)]
        [Description("Flushing items in async mode when batch limit has been reached")]
        public void PQ_AsyncFlushOnLimitReached()
        {
            FlushOnLimit(2);
        }

        /// <summary>
        /// Scenario: flushing items in sync mode when batch limit has been reached.
        /// Expected result: no exceptions, all items have been processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(5000)]
        [Description("Flushing items in sync mode when batch limit has been reached")]
        public void PQ_SyncFlushOnLimit()
        {
            FlushOnLimit(0);
        }

        /// <summary>
        /// Scenario: Flushing pending items from the async queue.
        /// Expected result: no exceptions, items have been flushed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(5000)]
        [Description("Flushing pending items in the async queue")]
        public void PQ_AsyncFlushPending()
        {
            FlushPending(2);
        }

        /// <summary>
        /// Scenario: Flushing pending items from the sync queue.
        /// Expected result: no exceptions, items have been flushed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(5000)]
        [Description("Flushing pending items in the sync queue")]
        public void PQ_SyncFlushPending()
        {
            FlushPending(0);
        }

        /// <summary>
        /// Scenario: Processing more items that can be handled simultaneously in async mode.
        /// Expected result: all items have been processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(60000)]
        [Description("Exceeding the number of items that can be handled simultaneously in async mode")]
        public void PQ_AsyncProcessManyItems()
        {
            ProcessManyItems(3, 200);
        }

        /// <summary>
        /// Scenario: Processing more items that can be handled simultaneously in sync mode.
        /// Expected result: all items have been processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Exceeding the number of items that can be handled simultaneously in sync mode")]
        public void PQ_SyncProcessManyItems()
        {
            ProcessManyItems(0, 100);
        }

        /// <summary>
        /// Scenario: Flushing an async queue while it's processing some items
        /// Expected result: all items have been processed
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(5000)]
        [Description("Flushing an async queue while it's processing some items")]
        public void PQ_AsyncFlushWhileProcessing()
        {
            FlushWhileProcessing(2);
        }

        /// <summary>
        /// Scenario: Flushing a sync queue while it's processing some items
        /// Expected result: all items have been processed
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(5000)]
        [Description("Flushing a sync queue while it's processing some items")]
        public void PQ_SyncFlushWhileProcessing()
        {
            FlushWhileProcessing(0);
        }

        /// <summary>
        /// Scenario: adding to async processing queue from multiple threads.
        /// Expected result: all items have been processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(60000)]
        [Description("Writing into async queue from multiple threads")]
        public void PQ_AsyncManyAddThreads()
        {
            ManyAddThreads(2);
        }

        /// <summary>
        /// Scenario: adding to sync processing queue from multiple threads.
        /// Expected result: all items have been processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb"), Timeout(120000)]
        [Description("Writing into sync queue from multiple threads")]
        public void PQ_SyncManyAddThreads()
        {
            ManyAddThreads(0);
        }
    }
}
