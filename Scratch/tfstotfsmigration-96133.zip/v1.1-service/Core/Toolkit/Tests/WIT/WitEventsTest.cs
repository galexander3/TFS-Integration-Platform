// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Tests.Framework;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Summary description for WorkItemEventsTest
    /// </summary>
    [TestClass]
    public class WitEventsTest : WitTestBase
    {
        private WorkItemMigrationEventArgs m_startArgs;     // Start event args
        private MigrationCompleteEventArgs m_completeArgs;  // Complete event args
        private FieldConflictEventArgs m_conflictArgs;      // Field conflict event args
        private CollectionEventArgs m_attachArgs;           // Attachment conflict event args
        private CollectionEventArgs m_linkArgs;             // link conflict event args
        private WorkItemMigrationEventArgs m_failedArgs;   // Failure event args
        private List<string> m_tempFiles;                   // List of temp files created by the test

        #region Internals

        /// <summary>
        /// Constructor.
        /// </summary>
        public WitEventsTest()
            : base("TestSession1")
        {
            m_tempFiles = new List<string>();
        }

        /// <summary>
        /// Handler for the "work item migration failed" event.
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="args">Arguments</param>
        private void OnWorkItemMigrationFailed(
            object sender,
            WorkItemMigrationEventArgs args)
        {
            Assert.IsTrue(sender is WorkItemTrackingSession, "Invalid sender!");
            Assert.IsTrue(args != null, "Null arguments!");
            m_failedArgs = args;
        }

        /// <summary>
        /// Handler for the "work item migration complete" event.
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="args">Arguments</param>
        private void OnWorkItemMigrationComplete(
            object sender,
            MigrationCompleteEventArgs args)
        {
            Assert.IsTrue(sender is WorkItemTrackingSession, "Invalid sender!");
            Assert.IsTrue(args != null, "Null arguments!");
            m_completeArgs = args;
        }

        /// <summary>
        /// Callback function for the "work item migration start" event.
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="args">Argumenrs</param>
        private void OnWorkItemMigrationStart(
            object sender,
            WorkItemMigrationEventArgs args)
        {
            Assert.IsTrue(sender is WorkItemTrackingSession, "Invalid sender!");
            Assert.IsTrue(args != null, "Null arguments!");
            m_startArgs = args;
        }

        /// <summary>
        /// Field conflict event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="args">Arguments</param>
        private void OnFieldConflict(
            object sender,
            FieldConflictEventArgs args)
        {
            Assert.IsTrue(sender is WorkItemTrackingSession, "Invalid sender!");
            Assert.IsTrue(args != null, "Null arguments!");
            m_conflictArgs = args;
        }

        /// <summary>
        /// File attachment conflict event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="args">Arguments</param>
        private void OnAttachmentConflict(
            object sender,
            CollectionEventArgs args)
        {
            Assert.IsTrue(sender is WorkItemTrackingSession, "Invalid sender!");
            Assert.IsTrue(args != null, "Null arguments!");
            m_attachArgs = args;
        }

        private void OnWorkItemLinksConflict(
            object sender,
            CollectionEventArgs args)
        {
            Assert.IsTrue(sender is WorkItemTrackingSession, "Invalid sender!");
            Assert.IsTrue(args != null, "Null arguments!");
            m_linkArgs = args;
        }

        /// <summary>
        /// Test initialization function.
        /// </summary>
        protected override void OnTestInitialize()
        {
            base.OnTestInitialize();

            // Sign up for events
            EventHandler<WorkItemMigrationEventArgs> start = new EventHandler<WorkItemMigrationEventArgs>(
                OnWorkItemMigrationStart);
            EventHandler<MigrationCompleteEventArgs> complete = new EventHandler<MigrationCompleteEventArgs>(
                 OnWorkItemMigrationComplete);
            EventHandler<FieldConflictEventArgs> conflict = new EventHandler<FieldConflictEventArgs>(
                OnFieldConflict);
            EventHandler<CollectionEventArgs> attachConflict = new EventHandler<CollectionEventArgs>(
                OnAttachmentConflict);
            EventHandler<WorkItemMigrationEventArgs> failed = new EventHandler<WorkItemMigrationEventArgs>(
                OnWorkItemMigrationFailed);

            EventHandler<CollectionEventArgs> linkConflict = new EventHandler<CollectionEventArgs>(OnWorkItemLinksConflict);

            Session.WorkItemMigrationStart += start;
            Session.WorkItemMigrationComplete += complete;
            Session.WorkItemMigrationFailed += failed;
            Session.WorkItemFieldConflict += conflict;
            Session.WorkItemAttachmentsOutOfSync += attachConflict;
            Session.WorkItemLinksOutOfSync += linkConflict;

            m_startArgs = null;
            m_failedArgs = null;
            m_completeArgs = null;
            m_conflictArgs = null;
            m_attachArgs = null;
            m_linkArgs = null;
        }

        /// <summary>
        /// Creates a file attachment.
        /// </summary>
        /// <returns>File attachment object</returns>
        private Attachment CreateAttachment()
        {
            string name = Path.GetTempFileName();
            TestUtils.CreateRandomFile(name, 100);
            m_tempFiles.Add(name);

            Attachment a = new Attachment(name, "Created by test");
            return a;
        }

        /// <summary>
        /// Test cleanup function.
        /// </summary>
        protected override void OnTestCleanup()
        {
            base.OnTestCleanup();

            // Unsubscribe from events
            Session.WorkItemMigrationStart -= new EventHandler<WorkItemMigrationEventArgs>(OnWorkItemMigrationStart);
            Session.WorkItemMigrationComplete -= new EventHandler<MigrationCompleteEventArgs>(OnWorkItemMigrationComplete);
            Session.WorkItemMigrationFailed -= new EventHandler<WorkItemMigrationEventArgs>(OnWorkItemMigrationFailed);
            Session.WorkItemFieldConflict -= new EventHandler<FieldConflictEventArgs>(OnFieldConflict);
            Session.WorkItemAttachmentsOutOfSync -= new EventHandler<CollectionEventArgs>(OnAttachmentConflict);
            Session.WorkItemLinksOutOfSync -= new EventHandler<CollectionEventArgs>(OnWorkItemLinksConflict);

            m_startArgs = null;
            m_completeArgs = null;
            m_failedArgs = null;
            m_conflictArgs = null;

            // Delete temp files
            for (int i = 0; i < m_tempFiles.Count; i++)
            {
                File.Delete(m_tempFiles[i]);
            }
            m_tempFiles.Clear();
        }

        #endregion


        /// <summary>
        /// Scenario: firing the "work item migration start/complete" events.
        /// Expected result: events should be fired; parameters must be valid.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Work item migration complete event")]
        public void Events_WorkItemMigrationStartComplete()
        {
            WorkItem src = CreateWorkItem(Side.Left, 2);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(m_startArgs != null, "Start event was not fired!");
            Assert.IsTrue(Convert.ToInt32(m_startArgs.SourceId.Id) == src.Id, "Invalid source work item id!");

            Assert.IsTrue(m_completeArgs != null, "Complete event was not fired!");
            Assert.IsTrue(Convert.ToInt32(m_completeArgs.SourceId.Id) == src.Id, "Invalid source work item id!");
            Assert.IsTrue(Convert.ToInt32(m_completeArgs.TargetId.Id) == dst.Id, "Invalid target work item id!");

            Assert.IsTrue(m_completeArgs.SourceRevisions == 2, "Wrong number of source revisions reported!");
            Assert.IsTrue(m_completeArgs.TargetRevisions == 2, "Wrong number of target revisions reported!");
        }

        /// <summary>
        /// Scenario: migrating a new revision should set right id of the target work item.
        /// Expected result: Target work item id must be set.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Tests the 'complete' event while migrating a new revision")]
        public void Events_WorkItemCompleteOnNewRevision()
        {
            WorkItem src = CreateWorkItem(Side.Left, 2);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            src[CoreField.Title] = Guid.NewGuid().ToString();
            src.Save();

            dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue(m_completeArgs != null, "Complete event was not fired!");
            Assert.IsTrue(Convert.ToInt32(m_completeArgs.SourceId.Id) == src.Id, "Invalid source item!");
            Assert.IsTrue(Convert.ToInt32(m_completeArgs.TargetId.Id) == dst.Id, "Invalid target item!");
            Assert.IsTrue(m_completeArgs.SourceRevisions == 1, "Wrong number of revisions on the source side!");
            Assert.IsTrue(m_completeArgs.TargetRevisions == 1, "Wrong number of revisions on the target side!");
        }

        /// <summary>
        /// Scenario: no changes on both sides during synchronization.
        /// Expected result: complete event is fired.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Firing Complete event when there were no changes")]
        public void Events_WorkItemCompleteOnNoChanges()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            m_completeArgs = null;

            Synchronize(Side.Left, src);
            Assert.IsTrue(m_completeArgs != null, "Complete event was not fired!");
        }

        /// <summary>
        /// Scenario: exception occurs during synchronization of work items.
        /// Expected result: complete event is fired
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Firing Complete event after migration have failed")]
        public void Events_WorkItemCompleteOnError()
        {
            Session.Policies.FieldConflict.Reaction = WitConflictReaction.Throw;

            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            src[CoreField.Title] = Guid.NewGuid().ToString();
            src.Save();
            dst[CoreField.Title] = Guid.NewGuid().ToString();
            dst.Save();

            m_completeArgs = null;

            Synchronize(Side.Left, src);
            Assert.IsTrue(m_completeArgs != null, "Complete event was not fired!");
        }

        /// <summary>
        /// Scenario: firing an event when conflict is detected.
        /// Expected result: event should be fired.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Firing the 'field conflict' event")]
        public void Events_FieldConflict()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(m_conflictArgs == null, "The event was fired on new work item!");

            src[CoreField.Title] = Guid.NewGuid().ToString();
            src.Save();
            dst[CoreField.Title] = Guid.NewGuid().ToString();
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            Assert.IsTrue(m_conflictArgs != null, "The event was not fired!");
            Assert.IsTrue(m_conflictArgs.FieldName == CoreFieldReferenceNames.Title, "Wrong field name!");
            Assert.IsTrue(m_conflictArgs.Revisions.Left.Revision == 2, "Wrong revision number on the left side");
            Assert.IsTrue(Convert.ToInt32(m_conflictArgs.Revisions.Left.Id) == src.Id, "Wrong source item id!");
            Assert.IsTrue(m_conflictArgs.Revisions.Right.Revision == 2, "Wropng revision on the right side!");
            Assert.IsTrue(Convert.ToInt32(m_conflictArgs.Revisions.Right.Id) == dst.Id, "Wrong target item id!");
        }

        /// <summary>
        /// Scenario: identical changes on both sides.
        /// Expected result: no field conflict events should be fired.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Identical changes on both fields should not cause field conflict event")]
        public void Events_NoFieldConflictEventOnIdenticalChanges()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            for (int i = 0; i < 2; i++)
            {
                src[CoreField.Title] = dst[CoreField.Title] = Guid.NewGuid().ToString();
                src.Save();
                dst.Save();
            }

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(m_conflictArgs == null, "Event was fired on identical changes!");
        }

        /// <summary>
        /// Scenario: different attachment collections.
        /// Expected result: an event is fired.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Attachment conflict event")]
        public void Events_FileAttachmentConflict()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            src.Attachments.Add(CreateAttachment());
            dst.Attachments.Add(CreateAttachment());
            dst.Attachments.Add(CreateAttachment());

            src.Save();
            dst.Save();


            m_attachArgs = null;
            dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(m_attachArgs != null, "Event was not fired on file attachment conflict!");
            Assert.IsTrue(src.Id == Convert.ToInt32(m_attachArgs.SourceId.Id), "Invalid source item id!");
            Assert.IsTrue(dst.Id == Convert.ToInt32(m_attachArgs.TargetId.Id), "Invalid target item id!");
        }

        /// <summary>
        /// Scenario: No changes in the attachments collection on both sides.
        /// Expected result: no event is fired
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("No event should occur in case of no changes")]
        public void Events_NoFileAttachmentEventOnNoConflict()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            src.Attachments.Add(CreateAttachment());
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];
            src.Title = Guid.NewGuid().ToString();
            dst["WST.String"] = Guid.NewGuid().ToString();

            src.Save();
            dst.Save();

            Synchronize(Side.Left, src);

            Assert.IsTrue(m_attachArgs == null, "Attachment conflict was detected!");
        }
    }
}
