// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Tests for flat work items.
    /// </summary>
    [TestClass]
    public class WitFlatItemsTest : WitTestBase
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        public WitFlatItemsTest()
            : base("FlatItems")
        {
        }

        /// <summary>
        /// Scenario: migration of a flat work item.
        /// Expected result: work item should be migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Tests migration of a flat work item")]
        public void WIT_FlatWorkItemMigration()
        {
            WorkItem src = CreateWorkItem(Side.Left, 2);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.Revision == 1, "Too many revisions were created!");
            CompareRevision(src.Fields, dst.Fields);
        }

        /// <summary>
        /// Scenario: migration of a flat work item from right side to left side.
        /// Expected result: work item should be migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("Tests migration of a flat work item from right to left")]
        public void WIT_RToLFlatWorkItemMigration()
        {
            WorkItem src = CreateWorkItem(Side.Right, 5);
            WorkItem dst = Synchronize(Side.Right, src)[0];

            Assert.IsTrue(dst.Revision == 1, "Too many revisions were created!");
            CompareRevision(src.Fields, dst.Fields);
        }

        /// <summary>
        /// Scenario: moving a single update.
        /// Expected result: an update must be migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Tests synchronizing a single change for a flat work item")]
        public void WIT_FlatWorkItemUpdate()
        {
            WorkItem src = CreateWorkItem(Side.Left, 2);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            src["WST.String"] = Guid.NewGuid().ToString();
            src.Save();
            src["WST.String"] = Guid.NewGuid().ToString();
            src.Save();

            dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.Revision == 2, "Wrong number of revisions!");
            CompareRevision(src.Fields, dst.Fields);
        }

        /// <summary>
        /// Scenario: synchronizing a work item with no changes.
        /// Expected result: nothing should happen.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Synchronizing flat items with no changes")]
        public void WIT_FlatWorkItemNoChanges()
        {
            WorkItem src = CreateWorkItem(Side.Left, 2);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            int srcRev = src.Revision;
            int dstRev = dst.Revision;

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == srcRev, "Source item was updated!");
            Assert.IsTrue(dst.Revision == dstRev, "Destination item was updated!");
        }

        /// <summary>
        /// Scenario: throwing on field conflict in flat work items.
        /// Expected result: revisions are not synchronized.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Throwing on conflict in flat work items")]
        public void WIT_FlatWorkItemsThrowOnConflict()
        {
            Session.Policies.FieldConflict.Reaction = WitConflictReaction.Throw;
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            // Create a conflict
            src[CoreField.Title] = Guid.NewGuid().ToString();
            dst[CoreField.Title] = Guid.NewGuid().ToString();
            src.Save();
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == 2, "Source item was updated!");
            Assert.IsTrue(dst.Revision == 2, "Target work item was updated!");
        }
    }
}
