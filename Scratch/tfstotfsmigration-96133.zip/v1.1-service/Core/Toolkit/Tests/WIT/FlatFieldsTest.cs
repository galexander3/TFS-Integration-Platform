﻿using System;
using System.Text;
using System.Collections.Generic;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tests.Framework;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Summary description for FlatFieldsTest
    /// </summary>
    [TestClass]
    public class FlatFieldsTest : WitTestBase
    {
        #region Internals
        
        /// <summary>
        /// Constructor.
        /// </summary>
        public FlatFieldsTest()
            : base("TestSession1")
        {
        }

        /// <summary>
        /// Initialization routine.
        /// </summary>
        protected override void OnTestInitialize()
        {
            base.OnTestInitialize();
            Session.TfsMigrationSource.FlatFields.Add("WST.String");
            Session.TfsMigrationSource.FlatFields.Add("WST.String1");
            Session.OtherMigrationSource.TfsSource.FlatFields.Add("WST.String2");
        }

        /// <summary>
        /// Cleanup routine.
        /// </summary>
        protected override void OnTestCleanup()
        {
            Session.TfsMigrationSource.FlatFields.Clear();
            Session.OtherMigrationSource.TfsSource.FlatFields.Clear();
            base.OnTestCleanup();
        }

        /// <summary>
        /// Initial synchronization test.
        /// </summary>
        /// <param name="sourceSide">Source side</param>
        private void InitialSynchronization(Side sourceSide)
        {
            WorkItem src = CreateWorkItem(sourceSide, 0);
            src["WST.String"] = "WST String";
            src["WST.String1"] = "WST String 1";
            src["WST.String2"] = "WST String 2";
            src.Save();

            WorkItem dst = Synchronize(sourceSide, src)[0];

            // Must have correct values.
            Assert.IsTrue((string)dst["WST.String"] == "WST String");
            Assert.IsTrue((string)dst["WST.String1"] == "WST String 1");
            Assert.IsTrue((string)dst["WST.String2"] == "WST String 2");
        }

        /// <summary>
        /// Tests initial synchronization of flat fields with the value map.
        /// </summary>
        /// <param name="sourceSide">Source side</param>
        private void InitialSynchronizationWithValueMap(Side sourceSide)
        {
            ChangeSessions("FlatFieldsValueMap");
            try
            {
                WorkItem src = CreateWorkItem(sourceSide, 0);
                src["WST.String"] = sourceSide.ToString();
                src.Save();

                WorkItem dst = Synchronize(sourceSide, src)[0];
                Assert.IsTrue((string)dst["WST.String"] == (!sourceSide).ToString(), "Invalid value!");
            }
            finally
            {
                ChangeSessions("TestSession1");
            }
        }

        /// <summary>
        /// Tests initial synchronization of flat fields with the fields map.
        /// </summary>
        /// <param name="sourceSide">Source side</param>
        private void InitialSynchronizationWithFieldMap(Side sourceSide)
        {
            ChangeSessions("FlatFieldsFieldMap");
            try
            {
                string sourceField, targetField;
                if (sourceSide == Side.Left)
                {
                    sourceField = "WST.String1";
                    targetField = "WST.String2";
                }
                else
                {
                    sourceField = "WST.String2";
                    targetField = "WST.String1";
                }
                WorkItem src = CreateWorkItem(sourceSide, 0);
                src[sourceField] = "Test";
                src.Save();

                WorkItem dst = Synchronize(sourceSide, src)[0];
                Assert.IsTrue((string)dst[targetField] == "Test", "Invalid value!");
            }
            finally
            {
                ChangeSessions("TestSession1");
            }
        }

        /// <summary>
        /// Multiple synchronization passes test.
        /// </summary>
        /// <param name="side">Side where original item resides</param>
        private void MultiSync(Side side)
        {
            WorkItem src = CreateWorkItem(side, 0);
            src["WST.String"] = "String";
            src["WST.String1"] = "String 1";
            src["WST.String2"] = "String 2";
            src.Save();
            WorkItem dst = Synchronize(side, src)[0];

            Pair<WorkItem> items = new Pair<WorkItem>(null, null);
            items[side] = src;
            items[!side] = dst;

            for (int i = 0; i < 4; i++)
            {
                side = !side;
                items[!side] = Synchronize(side, items[side])[0];

                Assert.IsTrue(items[side] != null, "Missing item!");
                Assert.IsTrue(items[!side] != null, "Missing item!");

                src.SyncToLatest();
                dst.SyncToLatest();
            }
        }

        #endregion

        /// <summary>
        /// Scenario: initial synchronization of flat fields from left to right.
        /// Expected result: all fields are moved to the opposite side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Initial migration of a flat field from left to right")]
        public void WIT_FlatFields_InitialSyncLR()
        {
            InitialSynchronization(Side.Left);
        }

        /// <summary>
        /// Scenario: initial synchronization of a flat field from right to left.
        /// Expected result: all flat fields are moved to the opposite side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Initial migration of a flat field from right to left")]
        public void WIT_FlatFields_InitialSyncRL()
        {
            InitialSynchronization(Side.Right);
        }

        /// <summary>
        /// Scenario: automatic conflict resolution for flat fields.
        /// Expected result: the conflict is resolved according to the settings.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Automatic conflict resolution for flat fields")]
        public void WIT_FlatFields_SyncConflictBothChanged()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            src["WST.String"] = "Left";
            src.Save();
            dst["WST.String"] = "Right";
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue((string)src["WST.String"] == "Left", "Invalid value!");
            Assert.IsTrue((string)dst["WST.String"] == "Left", "Invalid value!");
        }

        /// <summary>
        /// Scenario: automatic conflict resolution copying changes on the master side.
        /// Expected result: change on the master side is copied.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Conflict resolution after changing the master side")]
        public void WIT_FlatFields_SyncConflictMasterChanged()
        {
            WorkItem src = CreateWorkItem(Side.Left, 0);
            src["WST.String"] = "Value 1";
            src.Save();
            WorkItem dst = Synchronize(Side.Left, src)[0];
            src["WST.String"] = "Value 2";
            src.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == 2, "Invalid revision on the source side!");
            Assert.IsTrue((string)src["WST.String"] == "Value 2", "The value was changed!");
            Assert.IsTrue(dst.Revision == 2, "Invalid revision on the target side!");
            Assert.IsTrue((string)dst["WST.String"] == "Value 2", "The value was not changed!");
        }

        /// <summary>
        /// Scenario: automatic conflict resolution copying changes to the slave side.
        /// Expected result: value from the master side is restored.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Conflict resolution after changing the slave side")]
        public void WIT_FlatFields_SyncConflictSlaveChanged()
        {
            WorkItem src = CreateWorkItem(Side.Left, 0);
            src["WST.String"] = "Master";
            src.Save();
            WorkItem dst = Synchronize(Side.Left, src)[0];
            dst["WST.String"] = "Slave";
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == 1, "Invalid revision on the master side!");
            Assert.IsTrue((string)src["WST.String"] == "Master", "Invalid value on the master side!");
            Assert.IsTrue(dst.Revision == 3, "Invalid revision on the slave side!");
            Assert.IsTrue((string)dst["WST.String"] == "Master", "Invalid value on the slave side!");
        }

        /// <summary>
        /// Scenario: initial synchronization of flat fields with value mappings from left to right.
        /// Expected result: fields are migrated using value map.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Initial synchronization of flat fields with value mapping from left to right")]
        public void WIT_FlatFields_InitialSyncWithValueMappingLR()
        {
            InitialSynchronizationWithValueMap(Side.Left);
        }

        /// <summary>
        /// Scenario: initial synchronization of flat fields with value mappings from right to left.
        /// Expected result: fields are migrated using the value map.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Initial synchronization of flat fields with value mappings from right to left")]
        public void WIT_FlatFields_InitialSyncWithValueMappingRL()
        {
            InitialSynchronizationWithValueMap(Side.Right);
        }

        /// <summary>
        /// Scenario: initial synchronization of flat fields with field mappings from left to right.
        /// Expected result: fields are migrated using the field map.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Initial synchronization of flat fields with the field mapping from left to right")]
        public void WIT_FlatFields_InitialSyncWithFieldMappingLR()
        {
            InitialSynchronizationWithFieldMap(Side.Left);
        }

        /// <summary>
        /// Scenario: initial synchronization of flat fields with field mappings from right to left.
        /// Expected result: fields are migrated using the field map.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Initial synchronization of flat fields with the value mapping from right to left")]
        public void WIT_FlatFields_InitialSyncWithFieldMappingRL()
        {
            InitialSynchronizationWithFieldMap(Side.Right);
        }

        /// <summary>
        /// Scenario: multiple synchronization passes with the initial work item on the left.
        /// Expected result: successful synchronization.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Multiple passes with the initial work item on the left")]
        public void WIT_FlatFields_MultiSyncLR()
        {
            MultiSync(Side.Left);
        }

        /// <summary>
        /// Scenario: multiple synchronization passes with the initial work item on the right.
        /// Expected result: successful synchronization.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Multiple passes with the initial work item on the right")]
        public void WIT_FlatFields_MultiSyncRL()
        {
            MultiSync(Side.Right);
        }
    }
}
