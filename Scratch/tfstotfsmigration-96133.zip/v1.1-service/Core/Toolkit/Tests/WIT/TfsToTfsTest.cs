﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.Migration.Toolkit.WIT;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tests.Framework;

namespace Tests
{
    [TestClass()]
    public class TfsToTfsTest : MigrationTestCaseBase
    {

        #region Additional test attributes

        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public override void Initialize()
        {
            base.Initialize();

            ConfigFile.WriteAndLoad(ConfigParameters);

        }

        [TestCleanup]
        public override void Cleanup()
        {
            base.Cleanup();
        }

        #endregion

        [TestMethod, Description("Test new work item migration")]
        public void MigrationNewWorkItemTest()
        {
            Assert.Inconclusive("MigrationNewWorkItemTest");

            string server = ConfigParameters.WorkItemTracking.WitSessions[0].TFS.ServerName;

            WorkItemStore wiStore = new WorkItemStore(server);
            TeamFoundationServer tfs = TeamFoundationServerFactory.GetServer(server);

            Project proj = wiStore.Projects[0];

            TfsProjectUtils projUtils = new TfsProjectUtils(proj);
            TfsWorkItemStoreUtils wiStoreUtils = new TfsWorkItemStoreUtils(wiStore, projUtils);

            foreach (WorkItemType wiType in proj.WorkItemTypes)
            {
                try
                {

                    wiStoreUtils.CreateNewWorkItem(wiType, "MigrationWorkItemTest");
                }
                catch (Exception ex)
                {

                }
            }
        }

        [TestMethod, Description("Test work item with multiple revisions migration")]
        public void MigrationWorkItemWithRevisionsTest()
        {
            Assert.Inconclusive("MigrationWorkItemWithRevisionsTest");

            string server = ConfigParameters.WorkItemTracking.WitSessions[0].TFS.ServerName;

            WorkItemStore wiStore = new WorkItemStore(server);
            TeamFoundationServer tfs = TeamFoundationServerFactory.GetServer(server);

            Project proj = wiStore.Projects[0];

            TfsProjectUtils projUtils = new TfsProjectUtils(proj);
            TfsWorkItemStoreUtils wiStoreUtils = new TfsWorkItemStoreUtils(wiStore, projUtils);

            foreach (WorkItemType wiType in proj.WorkItemTypes)
            {
                try
                {

                    WorkItem wi = wiStoreUtils.CreateNewWorkItem(wiType, "MigrationWorkItemTest");
                    wiStoreUtils.ModifyWorkItems(wi, 10);

                }
                catch (Exception ex)
                {

                }
            }
        }

        [TestMethod, Description("Test work item with multiple revisions migration")]
        public void MigrationWorkItemWithLinksTest()
        {
            Assert.Inconclusive("MigrationWorkItemWithLinksTest");

            string server = ConfigParameters.WorkItemTracking.WitSessions[0].TFS.ServerName;

            WorkItemStore wiStore = new WorkItemStore(server);
            TeamFoundationServer tfs = TeamFoundationServerFactory.GetServer(server);

            Project proj = wiStore.Projects[0];

            TfsProjectUtils projUtils = new TfsProjectUtils(proj);
            TfsWorkItemStoreUtils wiStoreUtils = new TfsWorkItemStoreUtils(wiStore, projUtils);

        }

        [TestMethod, Description("Test work item with attachment migration")]
        public void MigrationWorkItemWithAttachmentTest()
        {
            Assert.Inconclusive("MigrationWorkItemWithAttachmentTest");

            WorkItemTrackingConfiguration config = MigrationConfiguration.Current.Wit;
            WorkItemTrackingSession session = config.Sessions["WitSession1"];
                

            WorkItemStore wiStore = new WorkItemStore("http://jhe2:8080");
            TeamFoundationServer tfs = TeamFoundationServerFactory.GetServer("http://jhe2:8080");

            Project proj = wiStore.Projects[0];

            TfsProjectUtils projUtils = new TfsProjectUtils(proj);
            TfsWorkItemStoreUtils wiStoreUtils = new TfsWorkItemStoreUtils(wiStore, projUtils);

        }
    }
}
