// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Summary description for ThrowPolicyTest
    /// </summary>
    [TestClass]
    public class ThrowPolicyTest: WitTestBase
    {
        WitConflictReaction m_reaction;

        #region Internals

        public ThrowPolicyTest()
            : base("TestSession1")
        {
        }

        protected override void OnTestInitialize()
        {
            base.OnTestInitialize();
            m_reaction = Session.Policies.FieldConflict.Reaction;
            Session.Policies.FieldConflict.Reaction = WitConflictReaction.Throw;
        }

        protected override void OnTestCleanup()
        {
            base.OnTestCleanup();
            Session.Policies.FieldConflict.Reaction = m_reaction;
        }

        #endregion


        /// <summary>
        /// Scenario: conflicting field change with 'throw' resolution policy.
        /// Expected result: conflicting changes are not migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Rejecting conflicting changes with 'throw' policy")]
        public void WIT_ThrowOnConflict()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            // Create normal revision.
            src[CoreField.Title] = Guid.NewGuid().ToString();
            src.Save();

            // Create a conflict
            src["WST.Int"] = 1;
            dst["WST.Int"] = 2;
            src.Save();
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == 3, "Extra revision was created!");
            Assert.IsTrue(dst.Revision == 3, "Extra revision was created!");
            Assert.IsTrue((int)src["WST.Int"] == 1, "Wrong value on the source side!");
            Assert.IsTrue((int)dst["WST.Int"] == 2, "Wrong value on the target side!");

            // Further attempt must not change anything
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            Assert.IsTrue(src.Revision == 3, "Extra revision was created!");
            Assert.IsTrue(dst.Revision == 3, "Extra revision was created!");
        }

        /// <summary>
        /// Scenario: manual resolution of a conflict on the left side.
        /// Expected results: changes from the right side must be accepted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Manual resolution of a conflict on the left side")]
        public void WIT_LeftManualResolutionOnThrow()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];
            object first = src["WST.Int"];

            for (int i = 0; i < 3; i++)
            {
                src["WST.Int"] = i;
                dst["WST.Int"] = 3 - i;
                src.Save();
                dst.Save();
            }

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == 4, "New revisions were created on the left side!");
            Assert.IsTrue(dst.Revision == 4, "New revisions were created on the right side!");

            // Fixing the conflict on the left side.
            src["WST.Int"] = 3;
            src.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(dst.Revision == 4, "Right work item was changed!");

            CheckFieldHistory(src, "WST.Int", first, 0, 1, 2, 3, 2, 1);
        }

        /// <summary>
        /// Scenario: manual resolution of a conflict on the right side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Manual resolution of a conflict on the right side")]
        public void WIT_RightManualResolutionOnThrow()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];
            object first = src["WST.Int"];

            for (int i = 0; i < 3; i++)
            {
                src["WST.Int"] = i;
                dst["WST.Int"] = 3 - i;
                src.Save();
                dst.Save();
            }

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == 4, "New revisions were created on the left side!");
            Assert.IsTrue(dst.Revision == 4, "New revisions were created on the right side!");

            // Fix the problem on the right side
            dst["WST.Int"] = 0;
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == 4, "Revisions on the left have changed!");
            Assert.IsTrue(dst.Revision == 7, "Revisions on the right side have changed!");

            CheckFieldHistory(dst, "WST.Int", first, 3, 2, 1, 0, 1, 2);
        }

        /// <summary>
        /// Scenario: Ignoring revisions above the conflict.
        /// Expected result: Revisions above the conflict do not get migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Ignoring revisions above the conflict")]
        public void WIT_IgnoreRevisionsAboveConflict()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            // Create a conflict
            src[CoreField.Title] = Guid.NewGuid().ToString();
            dst[CoreField.Title] = Guid.NewGuid().ToString();
            src.Save();
            dst.Save();

            // Create a non-conflicting revisions on both sides
            src["WST.Int"] = 1;
            dst["WST.String"] = "Foo";
            src.Save();
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == 3, "Wrong revision on the left side!");
            Assert.IsTrue(dst.Revision == 3, "Wrong revision on the right side!");
        }
    }
}
