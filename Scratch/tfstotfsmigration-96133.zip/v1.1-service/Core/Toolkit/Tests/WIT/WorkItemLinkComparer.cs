using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Comparer class for WIT links.
    /// </summary>
    class WorkItemLinkComparer : IComparer<Link>
    {
        static WorkItemLinkComparer s_current = new WorkItemLinkComparer();

        public static WorkItemLinkComparer Current { get { return s_current; } }

        #region IComparer<Link> Members

        public int Compare(Link x, Link y)
        {
            // Compare types
            int res = string.CompareOrdinal(x.GetType().Name, y.GetType().Name);

            // Compare comments
            if (res == 0)
            {
                if (string.IsNullOrEmpty(x.Comment))
                {
                    res = string.IsNullOrEmpty(y.Comment) ? 0 : 1;
                }
                else if (string.IsNullOrEmpty(y.Comment))
                {
                    res = 1;
                }
                else
                {
                    res = string.CompareOrdinal(x.Comment, y.Comment);
                }
            }

            if (res == 0)
            {
                if (x is Hyperlink)
                {
                    res = Compare((Hyperlink)x, (Hyperlink)y);
                }
                else if (x is RelatedLink)
                {
                    res = Compare((RelatedLink)x, (RelatedLink)y);
                }
                else if (x is ExternalLink)
                {
                    res = Compare((ExternalLink)x, (ExternalLink)y);
                }
            }
            return res;
        }

        #endregion

        private int Compare(
            Hyperlink x,
            Hyperlink y)
        {
            return string.CompareOrdinal(x.Location, y.Location);
        }

        private int Compare(
            RelatedLink x,
            RelatedLink y)
        {
            return x.RelatedWorkItemId.CompareTo(y.RelatedWorkItemId);
        }

        private int Compare(
            ExternalLink x,
            ExternalLink y)
        {
            return string.CompareOrdinal(x.LinkedArtifactUri, y.LinkedArtifactUri);
        }
    }
}
