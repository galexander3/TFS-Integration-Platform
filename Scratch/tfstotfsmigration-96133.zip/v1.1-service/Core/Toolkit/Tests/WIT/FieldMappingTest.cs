﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Tests.Framework;

namespace Tests
{
    [TestClass]
    public class FieldMappingTest : MigrationTestCaseBase
    {
        #region Additional test attributes

        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public override void Initialize()
        {
            base.Initialize();
             
            ConfigFile.WriteAndLoad(ConfigParameters);

        }

        [TestCleanup]
        public override void Cleanup()
        {
            base.Cleanup();
        }

        #endregion

        [TestMethod, Description("Test default config file created from test environment")]
        public void DefaultConfigLoadTest()
        {
            WorkItemTrackingConfiguration config = MigrationConfiguration.Current.Wit;
            Dictionary<string, FieldMap> fieldMaps = config.FieldMaps;

            FieldMap map = fieldMaps["default"];
            Assert.IsTrue(map.Fields.Count == 2 , "There are two fields");
            Assert.IsTrue(map.Exclusions.Count == 1, "there are two exclusions");

            FieldMapEntry field = map.Fields[0];
            Assert.IsTrue(field.TfsName == "System.State", "tfs field name is not right");
            Assert.IsTrue(field.OtherName == "Status", "other field name is not right");

            field = map.Fields[1];
            Assert.IsTrue(field.TfsName == "Tfs.Field", "tfs field name is not right");
            Assert.IsTrue(field.OtherName == "Custom Field", "other field name is not right");

            FieldMapExclusion ex = map.Exclusions[0];
            Assert.IsTrue(ex.System == SystemType.Tfs, "system type wrong");
            Assert.IsTrue(ex.FieldName == "Some.Dummy.Field", "field name is not right!");


        }

    }
}
