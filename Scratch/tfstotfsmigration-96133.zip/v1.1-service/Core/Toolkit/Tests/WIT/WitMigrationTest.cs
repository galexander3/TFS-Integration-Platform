// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Summary description for WitMigrationTest
    /// </summary>
    [TestClass]
    public class WitMigrationTest : WitTestBase
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        public WitMigrationTest()
            : base("TestSession1")
        {
        }

        /// <summary>
        /// Scenario: migrating a new item from left to right.
        /// Expected result: all fields & revisions have been migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a new item from left to right")]
        public void WIT_LeftToRightMigration()
        {
            WorkItem src = CreateWorkItem(Side.Left, 2);
            WorkItem dst = Synchronize(Side.Left, src)[0];
            CompareItems(src, dst);
        }

        /// <summary>
        /// Scenario: migrating a new item from right to left.
        /// Expected result: all fields & revisions have been migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a new item from right to left")]
        public void WIT_RightToLeftMigration()
        {
            WorkItem src = CreateWorkItem(Side.Right, 2);
            WorkItem dst = Synchronize(Side.Right, src)[0];
            CompareItems(src, dst);
        }

        /// <summary>
        /// Scenario: migrating a single revision of already synchronized items from left to right.
        /// Expected result: the revision is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a single revision of already synced items from left to right")]
        public void WIT_RevisionMigration()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            // Revision on the left; start from the left
            src["WST.String"] = Guid.NewGuid().ToString();
            src.Save();

            dst = Synchronize(Side.Left, src)[0];
            CompareItems(src, dst);

            // New revision on the right; start from the left
            dst["WST.String"] = Guid.NewGuid().ToString();
            dst.Save();
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            CompareItems(src, dst);

            // New revision on the right; start from the right
            dst["WST.String"] = Guid.NewGuid().ToString();
            dst.Save();
            src = Synchronize(Side.Right, dst)[0];
            CompareItems(src, dst);
        }

        /// <summary>
        /// Scenario: synchronization of a single item fails.
        /// Expected result: other items should be synchronized.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Synchronization of a single item fails")]
        public void WIT_SingleItemFailure()
        {
            int count = 10;
            int conflict = count / 2;
            WorkItem[] src = new WorkItem[count];

            for (int i = 0; i < count; i++)
            {
                src[i] = CreateWorkItem(Side.Left, 1);
            }

            WorkItem[] dst = Synchronize(Side.Left, src);

            // Create revisions on both sides
            for (int i = 0; i < count; i++)
            {
                src[i].Title = Guid.NewGuid().ToString();
                if (i == conflict)
                {
                    // Create conflicting revisions
                    dst[i].Title = Guid.NewGuid().ToString();
                }
                else
                {
                    // Create non-conflicting revision
                    dst[i]["WST.String"] = Guid.NewGuid().ToString();
                }
                src[i].Save();
                dst[i].Save();
            }

            Session.Policies.FieldConflict.Reaction = WitConflictReaction.Throw;

            dst = Synchronize(Side.Left, src);

            for (int i = 0; i < count; i++)
            {
                src[i].SyncToLatest();

                if (i == conflict)
                {
                    Assert.IsTrue(src[i].Rev == 2, "Source item was updated!");
                    Assert.IsTrue(dst[i].Rev == 2, "Target item was updated!");
                }
                else
                {
                    Assert.IsTrue(src[i].Rev == 3, "Source item was not updated!");
                    Assert.IsTrue(dst[i].Rev == 3, "Target item was not updated!");
                }
            }
        }

        /// <summary>
        /// Scenario: specifying invalid ids in the Synchronize method.
        /// Expected result: no errors.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Specifying invalid ids in Synchronize method")]
        public void WIT_InvalidIds()
        {
            string[] ids = new string[]
            {
                Guid.NewGuid().ToString(),
                Guid.NewGuid().ToString(),
                null,
                string.Empty,
                Guid.NewGuid().ToString()
            };

            Session.Synchronize(SystemType.Tfs, ids);
        }

        /// <summary>
        /// Scenario: skipping conflicting revisions.
        /// Expected result: conflicting revisions are skipped; new revisions accepted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Skipping conflicting revisions")]
        public void WIT_SkipConflictingRevisions()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            // Create a conflict
            src[CoreField.Title] = "Foo";
            src.Save();
            dst[CoreField.Title] = "Bar";
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue((string)src[CoreField.Title] == "Foo", "Source item was updated!");
            Assert.IsTrue((string)dst[CoreField.Title] == "Foo", "Target item was not updated!");

            dst[CoreField.Title] = "Test";
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue((string)src[CoreField.Title] == "Test", "Source item was not updated!");
            Assert.IsTrue((string)dst[CoreField.Title] == "Test", "Target item was updated!");
        }

        /// <summary>
        /// Scenario: multiple conflicting revisions between master and slave
        /// Expected result: changes from the master side are accepted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Multiple conflicting revisions between master and slave")]
        public void WIT_MultipleConflictingRevisions()
        {
            WorkItem l = CreateWorkItem(Side.Left, 1);
            WorkItem r = Synchronize(Side.Left, l)[0];

            l["WST.String"] = "Left String";
            l.Save();
            l["System.Title"] = "Left Title";
            l.Save();

            r["WST.String"] = "Right String";
            r.Save();
            r["System.Title"] = "Right Title";
            r.Save();

            r = Synchronize(Side.Left, l)[0];
            l.SyncToLatest();

            Assert.IsTrue((string)l["WST.String"] == "Left String", "Invalid field on the left!");
            Assert.IsTrue((string)l["System.Title"] == "Left Title", "Invalid field on the left!");

            Assert.IsTrue((string)r["WST.String"] == "Left String", "Invalid field on the left!");
            Assert.IsTrue((string)r["System.Title"] == "Left Title", "Invalid field on the left!");
        }

        /// <summary>
        /// Scenario: exception during VerifySettings call.
        /// Expected result: exception caught and processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Tests handling of exceptions that occurred during VerifySettings call")]
        public void WIT_ValidationException()
        {
            Exception e = null;

            WorkItemTrackingSession.SettingsValidationMethod validation = delegate(
                WorkItemTrackingSession session,
                WorkItemStore tfsStore)
            {
                throw new ApplicationException("This is a test");
            };
            EventHandler<MigrationSessionEventArgs> errorHandler = delegate(object sender, MigrationSessionEventArgs args)
            {
                e = args.Exception;
            };

            Session.TfsSettingsVerifier = validation;
            Session.SessionError += errorHandler;

            try
            {
                Session.Synchronize(SystemType.Tfs);
            }
            finally
            {
                Session.TfsSettingsVerifier = null;
                Session.SessionError -= errorHandler;
            }
            Assert.IsTrue(e is ApplicationException, "Invalid exception!");
        }
    }
}
