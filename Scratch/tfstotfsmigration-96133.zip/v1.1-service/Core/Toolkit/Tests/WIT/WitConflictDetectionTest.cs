// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.WIT;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Tests for conflicts detection and resolution.
    /// </summary>
    [TestClass]
    public class WitConflictDetectionTest : WitTestBase
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        public WitConflictDetectionTest()
            : base("TestSession1")
        {
        }

        /// <summary>
        /// Scenario: synchronizing a non-flat work item with no changes on both sides.
        /// Expected result: no new revisions on both sides.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating an item with no changes")]
        public void WIT_NoNewChangesInItems()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            int srcRev = src.Revision;
            int dstRev = dst.Revision;

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == srcRev, "Source item was updated!");
            Assert.IsTrue(dst.Revision == dstRev, "Target work item was updated!");
        }

        /// <summary>
        /// Scenario: accepting changes from master when conflict is detected.
        /// Expected result: changes from master are accepted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Conflict; accepting changes from master")]
        public void WIT_ChangesFromMaster()
        {
            WitMasterPolicy policy = Session.Policies.FieldConflict;

            Assert.IsTrue(policy.MasterSystem == SystemType.Tfs, "Invalid master system!");
            Assert.IsTrue(policy.Reaction == WitConflictReaction.Master, "Invalid reaction!");

            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            string masterVal = Guid.NewGuid().ToString();
            src[CoreField.Title] = masterVal;
            src.Save();

            dst[CoreField.Title] = Guid.NewGuid().ToString();
            dst.Save();

            int srcRev = src.Revision;
            int dstRev = dst.Revision;

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue((string)src[CoreField.Title] == masterVal, "Master value was affected!");
            Assert.IsTrue((string)dst[CoreField.Title] == masterVal, "Master value was not taken!");
            Assert.IsTrue(src.Revision == srcRev, "Master side was updated!");
            Assert.IsTrue(dst.Revision > dstRev, "Slave side was not updated!");
        }

        /// <summary>
        /// Scenario: syncing a work item with no changes after a conflict was resolved.
        /// Expected result: No new revisions should be created.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Syncing items with no changes after a conflict was detected and resolved")]
        public void WIT_NoChangesAfterConflict()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            src[CoreField.Title] = Guid.NewGuid().ToString();
            src.Save();
            dst[CoreField.Title] = Guid.NewGuid().ToString();
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];

            int srcRev = src.Revision;
            int dstRev = dst.Revision;

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == srcRev, "Source item was updated!");
            Assert.IsTrue(dst.Revision == dstRev, "Target item was updated!");

            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();

            Assert.IsTrue(src.Revision == srcRev, "Source item was updated!");
            Assert.IsTrue(dst.Revision == dstRev, "Target item was updated!");
        }

        /// <summary>
        /// Scenario: a non-conflicting change on the slave side.
        /// Expected result: the change should be migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Accepting changes from the slave side if there's no conflict")]
        public void WIT_ChangeOnSlaveWithNoConflict()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            string val = Guid.NewGuid().ToString();
            dst[CoreField.Title] = val;
            dst.Save();
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue((string)src[CoreField.Title] == val, "Value from the slave side was not migrated!");
        }

        /// <summary>
        /// Scenario: a chain of identical changes on both sides.
        /// Expected result: no migration.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Chain of identical changes on both sides")]
        public void WIT_IdenticalChanges() 
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            for (int i = 0; i < 3; i++)
            {
                src[CoreField.Title] = dst[CoreField.Title] = Guid.NewGuid().ToString();
                src["WST.Int"] = dst["WST.Int"] = i;
                src.Save();
                dst.Save();
            }

            int srcRev = src.Revision;
            int dstRev = dst.Revision;

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == srcRev, "Source item was updated!");
            Assert.IsTrue(dst.Revision == dstRev, "Target item was updated!");
        }
    }
}
