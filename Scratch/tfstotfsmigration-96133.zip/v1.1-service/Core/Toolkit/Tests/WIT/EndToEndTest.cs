﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.IO;
using System.Globalization;
using System.Data;
using System.Xml;
using System.Data.SqlClient;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Tests.Framework;

namespace Tests.WIT
{
    [TestClass()]
    public class EndToEndTest : WitTestBase
    {
        private Exception m_sessionException;

        /// <summary>
        /// Constructor.
        /// </summary>
        public EndToEndTest()
            : base("TestSession1")
        {
        }

        [AssemblyInitialize]
        public static void InitializeAssembly(TestContext ctx)
        {
            try
            {
                TestEnvironment.Load();
            }
            //This is the testcase that creates the environment file
            //We expect the file not to exist before this test;
            //but the AssemblyInitialize is always run before the testcase;
            //so we have to handle this exception. 
            catch (AssertInconclusiveException)
            {
                if (ctx.TestName.Equals("RunCreateEnvironmentFile"))
                {
                    return;
                }
                else
                {
                    throw;
                }
            }

            XmlDocument cfg = LoadXml("Tests.WIT.Data.config.xml");

            string connection = "server=" + TestEnvironment.SqlServer + ";Integrated Security=SSPI;";
            string dbname = cfg.SelectSingleNode("/Migration/Sql/Database").InnerText;//"WitSyncTest";

            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();

                if (Microsoft.TeamFoundation.Migration.Toolkit.SqlUtil.DoesDbExist(conn, dbname))
                {
                    Microsoft.TeamFoundation.Migration.Toolkit.SqlUtil.DropDb(conn, dbname);
                }

                Microsoft.TeamFoundation.Migration.Toolkit.SqlUtil.CreateDB(conn, dbname);
                conn.Close();
            }

            using (SqlConnection conn = new SqlConnection(connection + "Database=" + dbname + ";"))
            {
                LoadSqlScripts("Microsoft.TeamFoundation.Migration.Toolkit.Wit.SQL.MigrationDatabase.sql", conn);
                LoadSqlScripts("Microsoft.TeamFoundation.Migration.Toolkit.Wit.SQL.MigrationSprocs.sql", conn);
                LoadSqlScripts("Microsoft.TeamFoundation.Migration.Toolkit.VC.SQL.MigrationDatabase.sql", conn);
                LoadSqlScripts("Microsoft.TeamFoundation.Migration.Toolkit.VC.SQL.MigrationSprocs.sql", conn);
                LoadSqlScripts("Microsoft.TeamFoundation.Migration.Toolkit.Linking.SQL.MigrationDatabase.sql", conn);
                LoadSqlScripts("Microsoft.TeamFoundation.Migration.Toolkit.Linking.SQL.MigrationSprocs.sql", conn);
            }

        }

        /// <summary>
        /// Callback function for session errors.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="args">Arguments</param>
        private void OnSessionError(object sender, MigrationEventArgs args)
        {
            m_sessionException = args.Exception; ;
        }

        #region Test Case Methods
        /// <summary>
        /// Scenario: End to end testing for WIT migration
        /// Expected result: work item was migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("End to End testing for WIT migration, service mode testing")]
        public void WIT_TfsToTfsSyncTest()
        {
            TfsMigrationDataSource ds = Session.TfsMigrationSource;

            // new work item migration
            WorkItem src = CreateWorkItem(Side.Left, 1);
            ds.Filter = ds.Filter + " AND [System.Id] = " + src.Id;
            Session.Synchronize(SystemType.Tfs);
            WorkItem dst = FindReflections(Side.Left, src.Id.ToString())[0];
            CompareItems(src, dst);

            // new revision migration from source to target
            src[CoreField.Title] = Guid.NewGuid().ToString();
            src.Save();
            Session.Synchronize(SystemType.Tfs);
            dst = FindReflections(Side.Left, src.Id.ToString())[0];
            CompareItems(src, dst);

        }
        /// <summary>
        ///    End to End testing for revision migration scenario
        ///    Expected result: revisions were migrated 
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("End to End testing for Revisions migration")]
        public void WITEndToEnd_RevisionMigration()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            // Single field, single revision migration
            src["WST.String1"] = Guid.NewGuid().ToString();
            src.Save();

            dst = Synchronize(Side.Left, src)[0];
            CompareItems(src, dst);

            //Multiple fields changes in a revision
            src["WST.String"] = Guid.NewGuid().ToString();
            src["WST.PlainText"] = "<HTML><Title>Hello World!</Title><Body>hello world!</Body></HTML>";

            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            CompareItems(src, dst);

            //multiple revisions, multiple fields
            src["WST.String"] = Guid.NewGuid().ToString();
            src.Save();

            src["WST.String"] = Guid.NewGuid().ToString();
            src.Save();

            src["WST.Double"] = 12.121;
            src.Save();

            dst = Synchronize(Side.Left, src)[0];
            CompareItems(src, dst);

            // test revision migration switching between left and right system
            dst["WST.InternalRevision"] = 7;
            dst.Save();

            dst["WST.IgnoredField"] = "ignore this";
            dst.Save();
            src = Synchronize(Side.Right, dst)[0];
            CompareItems(src, dst);

            // migraion dirty work item
            dst["WST.IgnoredField"] = "next ignore";
            int rev = src.Revisions.Count;
            src = Synchronize(Side.Right, dst)[0];
            Assert.Equals(rev, src.Revisions.Count); // no change in migration
            CompareItems(src, dst);

            dst.Save();
            rev = src.Revisions.Count;
            src = Synchronize(Side.Right, dst)[0];
            Assert.IsTrue(rev == src.Revisions.Count - 1);
            CompareItems(src, dst);

            //Edit both side, no conflicts
            dst["WST.InternalRevision"] = 10;
            dst.Save();

            src["WST.IgnoredField"] = "not ignore this";
            src.Save();
            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();

            Assert.Equals(src.Revisions.Count, dst.Revisions.Count);
            Assert.Equals(src["WST.InternalRevision"], 10);
            Assert.Equals(dst["WST.IgnoredField"], "not ignore this");

            //multiple work items, multiple revision migration
            WorkItem[] wi = new WorkItem[20];
            Random r = new Random(16);
            for (int i = 0; i < wi.Length; i++)
            {
                wi[i] = CreateWorkItem(Side.Left, r.Next(1, 16));
            }

            WorkItem[] other = Synchronize(Side.Left, wi);

            for (int i = 0; i < wi.Length; i++)
            {
                CompareItems(wi[i], other[i]);
            }
        }
        /// <summary>
        ///     Scenario: End to end testing for flat work item migrations
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("End to End testing for flat workitem migration")]
        public void WITEndToEnd_FlatWorkItemMigration()
        {
            // change test session to flat work item configuration           
            ChangeSessions("FlatItems");

            //migrate from master side
            WorkItem src = CreateWorkItem(Side.Left, 3);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.Revision == 1, "Too many revisions were migrated!");
            CompareRevision(src.Fields, dst.Fields);

            dst["WST.String"] = Guid.NewGuid().ToString();
            dst.Save();
            dst["WST.Int"] = 38;
            dst.Save();

            string oldStr = (string)src["WST.String"];
            int oldInt = (int)src["WST.Int"];

            // Migrate from slave side
            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();

            CompareRevision(src.Fields, dst.Fields);
            Assert.Equals(dst["WST.String"], oldStr);
            Assert.Equals(dst["WST.Int"], oldInt);

            //switch master to the other side
            SystemType oldST = Session.Policies.MasterSystem;
            Session.Policies.MasterSystem = SystemType.Other;

            //change in right, migrate from right to left
            dst["WST.String"] = "Hello World!";
            dst.Save();
            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();
            CompareRevision(src.Fields, dst.Fields);
            Assert.Equals(dst["WST.String"], "Hello World!");

            // change in left, migrate from right to left
            src["WST.String"] = "new test";
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            CompareRevision(src.Fields, dst.Fields);
            Assert.Equals(dst["WST.String"], "Hello World!");

            Session.Policies.MasterSystem = oldST;
            // change conflict policy
            Session.Policies.FieldConflict.Reaction = WitConflictReaction.Throw;

            // Create a conflict
            src[CoreField.Title] = Guid.NewGuid().ToString();
            string srcTitle = (string)src[CoreField.Title];
            dst[CoreField.Title] = Guid.NewGuid().ToString();
            string dstTitle = (string)dst[CoreField.Title];

            src.Save();
            dst.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            Assert.IsTrue((string)src[CoreField.Title] == srcTitle, "should not be updated");
            Assert.IsTrue((string)dst[CoreField.Title] == dstTitle, "should not be updated");
        }
        /// <summary>
        /// Scenario: End to end testing for metadata synchronization
        /// Expected result: metedata were migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("End to end testing for metadata synchronization")]
        public void WITEndToEnd_MetadataSync()
        {
            Session.OtherMigrationSource.TfsSource.MetadataSynchronizationPolicy.Types = MetadataTypes.Types;
            WorkItemType src = Projects.Left.WorkItemTypes["WitSyncTest"];
            XmlDocument srcXml = src.Export(false);

            //create new field
            XmlElement newfield = srcXml.CreateElement("FIELD");
            newfield.SetAttribute("refname", "WIT.String");
            newfield.SetAttribute("name", "WIT String");
            newfield.SetAttribute("type", "String");

            XmlElement fields = (XmlElement)srcXml.DocumentElement.SelectSingleNode("WORKITEMTYPE/FIELDS");
            fields.AppendChild(newfield);
            //import new field
            Projects.Left.WorkItemTypes.Import(srcXml.DocumentElement);
            Synchronize(Side.Left);
            Refresh();

            WorkItemType dst = Projects.Right.WorkItemTypes["WitSyncTest"];
            Assert.IsTrue(dst.FieldDefinitions.Contains("WIT.String"));

            WorkItem wsrc = CreateWorkItem(Side.Left, 3);
            string s = Guid.NewGuid().ToString();
            wsrc["WIT.String"] = s;
            wsrc.Save();
            WorkItem wdst = Synchronize(Side.Left, wsrc)[0];
            CompareItems(wsrc, wdst);
            Assert.Equals((string)wdst["WIT.String"], s);

            // migrate from right to left
            s = Guid.NewGuid().ToString();
            wdst["WIT.String"] = s;
            wsrc = Synchronize(Side.Left, wdst)[0];
            wdst.SyncToLatest();
            CompareItems(wsrc, wdst);
            Assert.Equals((string)wdst["WIT.String"], s);

            //Restore the orginal work item types
            fields.RemoveChild(newfield);
            Projects.Left.WorkItemTypes.Import(srcXml.DocumentElement);
            Synchronize(Side.Left);
            Refresh();

            Assert.IsFalse(src.FieldDefinitions.Contains("WIT.String"));
        }
        /// <summary>
        /// Scenario: large work item collection WIT migration
        /// Expected result: work item was migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("End to End testing for large work item collections migration")]
        public void WIT_LargeVolumeWorkItemsMigration()
        {
            WorkItem[] src = new WorkItem[200];

            for (int i = 0; i < src.Length; i++)
            {
                src[i] = CreateWorkItem(Side.Left, 3);
            }

            WorkItem[] dst = Synchronize(Side.Left, src);

            for (int i = 0; i < src.Length; i++)
            {
                CompareItems(src[i], dst[i]);
            }
        }

        /// <summary>
        /// Scenario: Test multiple session migration
        /// Expected result: work items were migrated in different sessions.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("Test multiple session migration")]
        public void WIT_MultiSessionMigrationTest()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            TfsMigrationDataSource ds = Session.TfsMigrationSource;
            ds.Filter = ds.Filter + " AND [System.Id] = " + src.Id;
            Session.Synchronize(SystemType.Tfs);
            WorkItem dst = FindReflections(Side.Left, src.Id.ToString())[0];
            CompareItems(src, dst);

            ChangeSessions("FileAttachments");
            ds = Session.TfsMigrationSource;
            src = CreateWorkItem(Side.Left, 1);
            ds.Filter = ds.Filter + " AND [System.Id] = " + src.Id;
            Session.Synchronize(SystemType.Tfs);
            dst = FindReflections(Side.Left, src.Id.ToString())[0];
            CompareItems(src, dst);
        }

        /// <summary>
        /// Scenario: source project does not exist
        /// Expected result: session error event
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("Test for source project does not exist")]
        public void WIT_NoSourceProject()
        {
            TfsMigrationDataSource ds = Session.TfsMigrationSource;

            ds.Project = "BogusBogusProject";
            Session.SessionError += new EventHandler<MigrationSessionEventArgs>(OnSessionError);
            m_sessionException = null;
            Session.Synchronize(SystemType.Tfs);
            Session.SessionError -= new EventHandler<MigrationSessionEventArgs>(OnSessionError);
            Assert.IsTrue(m_sessionException is DeniedOrNotExistException, "Invalid exception!");
        }

        /// <summary>
        /// Scenario: target project does not exist
        /// Expected result: session error event
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("Target project does not exist")]
        public void WIT_NoTargetProject()
        {
            OtherMigrationDataSource ds = Session.OtherMigrationSource;

            ds.TfsSource.Project = "BogusBogusProject";
            Session.SessionError += new EventHandler<MigrationSessionEventArgs>(OnSessionError);
            m_sessionException = null;
            Session.Synchronize(SystemType.Tfs);
            Session.SessionError -= new EventHandler<MigrationSessionEventArgs>(OnSessionError);
            Assert.IsTrue(m_sessionException is DeniedOrNotExistException, "Invalid exception!");
        }

        /// <summary>
        /// Scenario: source store does not exist
        /// Expected result: migration should not be started, should throw InitializationException.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("Test for source work item store does not exist")]
        public void WIT_NoSourceStore()
        {
            TfsMigrationDataSource ds = Session.TfsMigrationSource;

            ds.Server = "BogusBogusServer";
            Session.SessionError += new EventHandler<MigrationSessionEventArgs>(OnSessionError);
            m_sessionException = null;
            Session.Synchronize(SystemType.Tfs);
            Session.SessionError -= new EventHandler<MigrationSessionEventArgs>(OnSessionError);
            Assert.IsTrue(m_sessionException != null, "No exception occured!");
        }

        /// <summary>
        /// Scenario: Target work item store is unavailable
        /// Expected result: should throw KeyNotFoundException
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("Target WorkItem Store is unaviable")]
        public void WIT_NoTargetStore()
        {
            OtherMigrationDataSource ds = Session.OtherMigrationSource;

            ds.TfsSource.Server = "BogusServer";
            Session.SessionError += new EventHandler<MigrationSessionEventArgs>(OnSessionError);
            m_sessionException = null;
            Session.Synchronize(SystemType.Tfs);
            Session.SessionError -= new EventHandler<MigrationSessionEventArgs>(OnSessionError);
            Assert.IsTrue(m_sessionException != null, "No exception occured!");
        }

        /// <summary>
        /// Scenario: End to End Scenario -  full pass synchronization 
        /// Expected result: Change from both side and have a full pass migration
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("Change from both side and have a full pass migration")]
        public void WIT_EndToEndFullPassSync()
        {
            // reset filter on both side
            ResetFilterOnBothSide();

            WorkItem src = CreateWorkItem(Side.Left, 1);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            CompareItems(src, dst);

            // no change, run full pass synchronization
            Session.SynchronizeFull();
            CompareItems(src, dst);

            // Change left, run full pass synchronization
            string text = "Change in left side only";
            src["WST.String"] = text;
            src.Save();
            Session.SynchronizeFull();
            src.SyncToLatest();
            dst.SyncToLatest();
            CompareItems(src, dst);
            Assert.IsTrue((string)dst["WST.String"] == text);

            // Change right, run full pass synchronization
            text = "Change in right side only";
            dst["WST.String"] = text;
            dst.Save();
            Session.SynchronizeFull();
            src.SyncToLatest();
            dst.SyncToLatest();
            Assert.IsTrue((string)src["WST.String"] == text);

            //Conflict scenario, change the same field from both side
            text = "Change in right side";
            dst["WST.String"] = text;
            dst.Save();

            text = "Change in left side";
            src["WST.String"] = text;
            src.Save();

            Session.SynchronizeFull();
            src.SyncToLatest();
            dst.SyncToLatest();
            Assert.IsTrue((string)src["WST.String"] == text);

            //Change different fields in both sides
            text = "Change test";
            dst["WST.String"] = text;
            dst.Save();
            int value = 12;
            src["WST.Int"] = value;
            src.Save();
            Session.SynchronizeFull();
            src.SyncToLatest();
            dst.SyncToLatest();

            Assert.IsTrue((string)src["WST.String"] == text);
            Assert.IsTrue((int)dst["WST.Int"] == value);
        }

        #endregion

        #region Private Methods
        /// <summary>
        ///   Load and run sql scripts
        /// </summary>
        /// <param name="name">stream name</param>
        /// <param name="conn">SqlConnection</param>
        private static void LoadSqlScripts(string name, SqlConnection conn)
        {
            using (Stream stream = typeof(Microsoft.TeamFoundation.Migration.Toolkit.SqlUtil).Assembly.GetManifestResourceStream(name))
            {
                using (StreamReader schemaReader = new StreamReader(stream))
                {
                    while (!schemaReader.EndOfStream)
                    {
                        string sqlString;
                        StringBuilder sqlBuilder = new StringBuilder();

                        while (true)
                        {
                            string current = schemaReader.ReadLine();
                            if (current == null || current.Trim().ToUpper() == "GO")
                            {
                                break;
                            }

                            sqlBuilder.AppendLine(current);
                        }

                        sqlString = sqlBuilder.ToString();

                        if (!string.IsNullOrEmpty(sqlString))
                        {
                            using (SqlCommand cmd = conn.CreateCommand())
                            {
                                if ((conn.State & ConnectionState.Open) == 0)
                                {
                                    conn.Open();
                                }

                                cmd.CommandText = sqlString;
                                cmd.CommandType = CommandType.Text;

                                try
                                {
                                    cmd.ExecuteNonQuery();
                                }
                                catch (SqlException se)
                                {
                                    throw new InitializationException(se.Message);
                                }
                            }
                        }
                    }
                }
            }
        }

        #endregion
    }
}
