// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.WIT
{
    /// <summary>
    /// Field mappings tests
    /// </summary>
    [TestClass]
    public class WitFieldMappingTest : WitTestBase
    {
        private bool m_hasTypes;                            // Tells whether the test has required types

        /// <summary>
        /// Constructor.
        /// </summary>
        public WitFieldMappingTest()
            : base("FieldMapping")
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public WitFieldMappingTest(string sessionName) : base(sessionName)
        {
        }

        /// <summary>
        /// Tests ignored fields that exist on both sides.
        /// </summary>
        /// <param name="side">Source side</param>
        private void IgnoreExistingExcludedField(
            Side side)
        {
            WorkItem src;

            if (side == Side.Left)
            {
                src = Projects.Left.WorkItemTypes["WitSyncTest"].NewWorkItem();
            }
            else
            {
                src = Projects.Right.WorkItemTypes["WitSyncTest.2"].NewWorkItem();
            }
            src.Title = Guid.NewGuid().ToString();
            src["WST.IgnoredField2"] = "Foo";
            src.Save();

            WorkItem dst = Synchronize(side, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(string.IsNullOrEmpty((string)dst["WST.IgnoredField2"]), "Ignored field was migrated!");
            Assert.IsTrue((string)src["WST.IgnoredField2"] == "Foo", "Ignored field was updated on the source!");

            // Updates to the ignored field should not cause any harm either
            src["WST.IgnoredField2"] = "Bar";
            src.Save();

            dst = Synchronize(side, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(string.IsNullOrEmpty((string)dst["WST.IgnoredField2"]), "Ignored field was migrated!");
            Assert.IsTrue((string)src["WST.IgnoredField2"] == "Bar", "Ignored field was updated on the source!");
        }

        /// <summary>
        /// Creates a work item which will be used as a source.
        /// </summary>
        /// <param name="side">Side where the work item must be created</param>
        /// <param name="typeName">Type of the work item to be created</param>
        /// <param name="fieldName">Field name to set</param>
        /// <param name="values">Values to set (one per revision)</param>
        /// <returns>Work item</returns>
        protected WorkItem CreateSourceWorkItem(
            Side side,
            string typeName,
            string fieldName,
            params object[] values)
        {
            WorkItem wi = Projects[side].WorkItemTypes[typeName].NewWorkItem();

            for (int i = 0; i < values.Length; i++)
            {
                wi[fieldName] = values[i];
                wi["WST.InternalRevision"] = i + 1;
                wi.Save();
            }
            return wi;
        }

        /// <summary>
        /// Initializes the test.
        /// </summary>
        protected override void OnTestInitialize()
        {
            base.OnTestInitialize();

            if (!m_hasTypes)
            {
                // Provision missing type on the right side
                XmlDocument doc = LoadXml("Tests.WIT.Data.testwit2.xml");
                Projects.Right.WorkItemTypes.Import(doc.DocumentElement);
                m_hasTypes = true;
            }
        }

        /// <summary>
        /// Compares field values across revisions.
        /// </summary>
        /// <param name="src">Source work item</param>
        /// <param name="srcField">Source field</param>
        /// <param name="dst">Target work item</param>
        /// <param name="dstField">Target field</param>
        protected void CompareValues(
            WorkItem src,
            string srcField,
            WorkItem dst,
            string dstField)
        {
            Assert.IsTrue(src.Revisions.Count == dst.Revisions.Count, "Wrong number of revisions!");

            for (int i = 0; i < src.Revisions.Count; i++)
            {
                Assert.IsTrue(
                    CompareValues(src.Revisions[i][srcField], dst.Revisions[i][dstField]),
                    "Field values do not match!");
            }
        }


        /// <summary>
        /// Scenario: Left to right field mapping.
        /// Expected result: Field changes should be reflected on the right side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Single field mapping from left to right")]
        public void WIT_FieldMappingLeftToRight()
        {
            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "Foo", "Bar");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.Type.Name == "WitSyncTest.2", "Work item type was not mapped!");
            CompareValues(src, "WST.String", dst, "WST.MappedString");
        }

        /// <summary>
        /// Scenario: Right to left field mapping.
        /// Expected result: field changes should be reflected on the left side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Single field mapping from right to left")]
        public void WIT_FieldMappingRightToLeft()
        {
            WorkItem src = CreateSourceWorkItem(Side.Right, "WitSyncTest.2", "WST.MappedString", "Foo", "Bar");
            WorkItem dst = Synchronize(Side.Right, src)[0];

            Assert.IsTrue(dst.Type.Name == "WitSyncTest", "Work item type was not mapped!");
            CompareValues(src, "WST.MappedString", dst, "WST.String");
        }

        /// <summary>
        /// Scenario: Field mapping in new revision.
        /// Expected result: field changes should be reflected on the opposite side
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Tests field mapping after a new revision on top of synchronized items")]
        public void WIT_FieldMappingInNewRevision()
        {
            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "Foo");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            // Change on left, sync from left
            src["WST.String"] = Guid.NewGuid().ToString();
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            CompareValues(src, "WST.String", dst, "WST.MappedString");

            // Change on left, sync from right
            src["WST.String"] = Guid.NewGuid().ToString();
            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();
            CompareValues(src, "WST.String", dst, "WST.MappedString");

            // Change on right, sync from left
            dst["WST.MappedString"] = Guid.NewGuid().ToString();
            dst.Save();
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            CompareValues(src, "WST.String", dst, "WST.MappedString");

            // Change on right, sync from right
            dst["WST.MappedString"] = Guid.NewGuid().ToString();
            dst.Save();
            src = Synchronize(Side.Right, dst)[0];
            CompareValues(src, "WST.String", dst, "WST.MappedString");
        }

        /// <summary>
        /// Scenario: Field is not specified in the mapping.
        /// Expected result: Changes should be migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Tests implicit field mappings, where field is not specified in the config file")]
        public void WIT_ImplicitFieldMapping()
        {
            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.Int", 1, 2);
            WorkItem dst = Synchronize(Side.Left, src)[0];

            CompareValues(src, "WST.Int", dst, "WST.Int");
            Assert.IsTrue(src.Revisions.Count == dst.Revisions.Count, "Wrong number of revisions!");
        }

        /// <summary>
        /// Scenario: Field is excluded from the mapping.
        /// Expected result: Field should not be migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Excluded field in the field mapping")]
        public void WIT_ExcludedFieldInMapping()
        {
            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.IgnoredField", "Foo", "Bar");
            WorkItem dst = Synchronize(Side.Left, src)[0];
        }

        /// <summary>
        /// Scenario: Field exists only on one side and is not mapped.
        /// Expected result: changes to that field must be ignored.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Ignoring non-existing field during synchronization")]
        public void WIT_NonExistingFieldOnOneSide()
        {
            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.MissingField", "Foo", "Bar");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(!dst.Type.FieldDefinitions.Contains("WST.MissingField"), "Field is there!");
        }

        /// <summary>
        ///     Scenario: end to end field mapping test.  
        ///         Same as WITEndToEnd_ValueMapping except there is no value map.
        ///         This will help determine if there is a value mapping issue or a 
        ///             problem with field mapping.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("End to End testing for field mapping")]
        public void WITEndToEnd_FieldMappingStringToInt()
        {
            // field mapping from string to int, value also mapped
            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String2", "1");
            WorkItem dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue((int)dst["WST.Int2"] == 1, "Right work item value map fail");

            //no changes, just sync
            dst = Synchronize(Side.Left, src)[0];

            // field mapping from right to left
            dst["WST.Int2"] = 2;
            dst.Save();
            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();
            Assert.IsTrue((string)src["WST.String2"] == "2", "Left side is not updated");

            //Field conflictions
            dst["WST.Int2"] = 4;
            dst.Save();
            src["WST.String2"] = "3";
            src.Save();
            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();
            Assert.IsTrue((string)src["WST.String2"] == "3", "should not have any changes");
            Assert.IsTrue((int)dst["WST.Int2"] == 3, "not in  sync with other side");

            // change single field from right to left migration
            dst["WST.Int2"] = 5;
            dst.Save();

            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();
            Assert.IsTrue((string)src["WST.String2"] == "5", "Not updated");
            Assert.IsTrue((int)dst["WST.Int2"] == 5, "wrong in value mapping");

            dst = Synchronize(Side.Left, src)[0];
        }

        /// <summary>
        /// Scenario: excluded field exists on both sides; changes occur on the master.
        /// Expected result: Excluded field is not migrated
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Excluded field exists on both sides")]
        public void WIT_IgnoreExistingExcludedFieldMaster()
        {
            IgnoreExistingExcludedField(Side.Left);
        }

        /// <summary>
        /// Scenario: excluded field exists on both sides; changes occur on the slave.
        /// Expected result: Excluded field is not migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Excluded field exists on both sides; changes occur on the slave side")]
        public void WIT_IgnoreExistingExcludedFieldSlave()
        {
            IgnoreExistingExcludedField(Side.Right);
        }
    }
}
