// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Path synchronization tests.
    /// </summary>
    [TestClass]
    public class WitPathSync : WitTestBase
    {
        #region Internals

        private const string ExistingArea = "Area 1\\Area 1-1";
        private const string ExistingIteration = "Iteration 1\\Iteration 1-1";

        /// <summary>
        /// Constructor.
        /// </summary>
        public WitPathSync()
            : base("TestSession1")
        {
        }

        /// <summary>
        /// Creates a random path string
        /// </summary>
        /// <returns>Random path string</returns>
        public string CreateRandomPath()
        {
            StringBuilder path = new StringBuilder();

            for (int i = 0; i < 3; i++)
            {
                path.Append(Guid.NewGuid().ToString());
                path.Append('\\');
            }
            return path.ToString();
        }

        #endregion

        /// <summary>
        /// Scenario: area path migration.
        /// Expected result: missing node should be created.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Creating missing area and iteration")]
        public void WIT_AreaPathCreation()
        {
            string path = CreateRandomPath();
            int srcAreaId = CreatePath(Side.Left, Node.TreeType.Area, path);
            WorkItem src = Projects.Left.WorkItemTypes["WitSyncTest"].NewWorkItem();
            src.AreaId = srcAreaId;
            src.Title = Guid.NewGuid().ToString();
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue(ComparePaths(src.AreaPath, dst.AreaPath), "Different area paths!");
        }

        /// <summary>
        /// Scenario: synchronization of an existing area path.
        /// Expected result: synchronization occurs with no exceptions.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Existing area synchronization")]
        public void WIT_ExistingAreaPathSynchronization()
        {
            int leftId = CreatePath(Side.Left, Node.TreeType.Area, ExistingArea);
            int rightId = CreatePath(Side.Right, Node.TreeType.Area, ExistingArea);

            WorkItem src = Projects.Left.WorkItemTypes["WitSyncTest"].NewWorkItem();
            src.AreaId = leftId;
            src.Title = Guid.NewGuid().ToString();
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue(dst.AreaId == rightId, "Invalid right path!");
        }

        /// <summary>
        /// Scenario: Using default area paths for missing nodes.
        /// Expected Result: Work item gets created under the default node.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Using default area path for missing nodes")]
        public void WIT_DefaultAreaPath()
        {
            string defaultPath = ExistingArea;
            Session.Policies.MissingArea.Reaction = WitConflictReaction.Default;
            Session.OtherMigrationSource.TfsSource.DefaultArea = defaultPath;

            string randomPath = CreateRandomPath();
            int leftId = CreatePath(Side.Left, Node.TreeType.Area, randomPath);
            int rightId = CreatePath(Side.Right, Node.TreeType.Area, defaultPath);

            WorkItem src = Projects.Left.WorkItemTypes["WitSyncTest"].NewWorkItem();
            src.AreaId = leftId;
            src.Title = Guid.NewGuid().ToString();
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.AreaId == rightId, "Not a default area!");
        }

        /// <summary>
        /// Scenario: missing iteration path during synchronization with "create".
        /// Expected result: synchronization works; missing iteration gets created.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Creation of a missing iteration path")]
        public void WIT_IterationPathCreation()
        {
            string path = CreateRandomPath();
            int srcIterationId = CreatePath(Side.Left, Node.TreeType.Iteration, path);
            WorkItem src = Projects.Left.WorkItemTypes["WitSyncTest"].NewWorkItem();
            src.IterationId = srcIterationId;
            src.Title = Guid.NewGuid().ToString();
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue(ComparePaths(src.IterationPath, dst.IterationPath), "Different area paths!");
        }

        /// <summary>
        /// Scenario: synchronization of an existing iteration path.
        /// Expected result: synchronization with no exceptions.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Existing iteration synchronization")]
        public void WIT_ExistingIterationPathSynchronization()
        {
            int leftId = CreatePath(Side.Left, Node.TreeType.Iteration, ExistingIteration);
            int rightId = CreatePath(Side.Right, Node.TreeType.Iteration, ExistingIteration);

            WorkItem src = Projects.Left.WorkItemTypes["WitSyncTest"].NewWorkItem();
            src.IterationId = leftId;
            src.Title = Guid.NewGuid().ToString();
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue(dst.IterationId == rightId, "Invalid right path!");
        }

        /// <summary>
        /// Scenario: Using default iteration paths for missing nodes.
        /// Expected result: Work item gets created under the default node.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Using default iteration path for missing nodes")]
        public void WIT_DefaultIterationPath()
        {
            string defaultPath = ExistingIteration;
            Session.Policies.MissingIteration.Reaction = WitConflictReaction.Default;
            Session.OtherMigrationSource.TfsSource.DefaultIteration = defaultPath;

            string randomPath = CreateRandomPath();
            int leftId = CreatePath(Side.Left, Node.TreeType.Iteration, randomPath);
            int rightId = CreatePath(Side.Right, Node.TreeType.Iteration, defaultPath);

            WorkItem src = Projects.Left.WorkItemTypes["WitSyncTest"].NewWorkItem();
            src.IterationId = leftId;
            src.Title = Guid.NewGuid().ToString();
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.IterationId == rightId, "Not a default area!");
        }
    }
}
