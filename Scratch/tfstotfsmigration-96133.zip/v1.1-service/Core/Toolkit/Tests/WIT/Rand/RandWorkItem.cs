// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Text;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Tests.WIT.Rand
{
    /// <summary>
    /// Random work item.
    /// </summary>
    class RandWorkItem : IMigrationWorkItem
    {
        private Watermark m_watermark;                      // Item's watermark
        private List<MigrationRevision> m_revs;             // Revisions
        private List<RandAttachment> m_attachments;         // Attachments
        private static string[] s_stringFields = new string[]
            {
                "WST String",
                "WST String 1",
                "WST PlainText",
                "Title",
            };

        public RandWorkItem(int revCount)
        {
            m_watermark = new Watermark(
                Guid.NewGuid().ToString(),
                revCount - 1);

            m_revs = new List<MigrationRevision>(revCount);

            Random rnd = new Random();

            for (int i = 0; i < revCount; i++)
            {
                MigrationRevision rev = new MigrationRevision(i, "Dummy", DateTime.UtcNow.AddDays(1 + i - revCount));
                m_revs.Add(rev);

                for (int j = 0; j < s_stringFields.Length; j++)
                {
                    object value = rnd.Next(2) == 0 ? null : Guid.NewGuid().ToString();
                    rev.Fields.Add(new MigrationField(s_stringFields[j], value));
                }
            }

            m_attachments = new List<RandAttachment>();
            if (rnd.Next(5) == 0)
            {
                // One of five work items should have some attachments
                int count = rnd.Next(8);

                for (int i = 0; i < count; i++)
                {
                    m_attachments.Add(
                        new RandAttachment(Guid.NewGuid().ToString()));
                }
            }
        }

        #region IMigrationWorkItem Members

        public string Uri { get { return string.Format(CultureInfo.InvariantCulture, "random:workitem:{0}", m_watermark.Id); } }
        public Watermark Watermark { get { return m_watermark; } }
        public string WorkItemType { get { return "RandomType"; } }
        public MigrationWorkItemData Flags 
        { 
            get 
            {
                MigrationWorkItemData flags = MigrationWorkItemData.None;

                if (m_attachments.Count > 0)
                {
                    flags |= MigrationWorkItemData.Attachments;
                }
                return flags;
            } 
        }

        public ReadOnlyCollection<MigrationRevision> GetRevisions(int revision)
        {
            List<MigrationRevision> revs = new List<MigrationRevision>();

            for (; revision < m_revs.Count; revision++)
            {
                revs.Add(m_revs[revision]);
            }
            return revs.AsReadOnly();
        }

        public ReadOnlyCollection<IMigrationFileAttachment> GetFileAttachments()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void OnTargetUpdate(IWorkItemUpdatePackage target)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public IEnumerable<MigrationField> GetLatestValues(IEnumerable<string> fields)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
