// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Tests.WIT.Rand
{
    /// <summary>
    /// Factory class used by the toolkit to create this custom implementation.
    /// </summary>
    public class RandProviderFactory: IConfigFactory    
    {
        #region IConfigFactory Members

        /// <summary>
        /// Creates an instance of the Wss work item tracking end point (provider).
        /// </summary>
        /// <param name="type">Type expected</param>
        /// <param name="xmlFragment">Xml containing provider specific settings</param>
        /// <returns>Instance of the custom end point.</returns>
        public object CreateInstance(Type type, string xmlFragment)
        {
            if (type == typeof(IWorkItemTrackingEndpoint))
            {
                using (StringReader sr = new StringReader(xmlFragment))
                {
                    XmlSerializer xs = new XmlSerializer(typeof(RandStore));
                    return xs.Deserialize(sr);
                }
            }
            return null;
        }

        #endregion
    }
}
