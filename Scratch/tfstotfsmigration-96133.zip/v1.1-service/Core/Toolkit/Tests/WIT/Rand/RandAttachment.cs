// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Tests.WIT.Rand
{
    class RandAttachment: IMigrationFileAttachment
    {
        private static Random s_random = new Random();

        private string m_name;
        private long m_length;
        private DateTime m_utcCreation;
        private DateTime m_utcLastWrite;
        private string m_comment;

        public RandAttachment(
            string name)
        {
            m_name = name;
            m_length = s_random.Next(0, 1024);
            m_comment = Guid.NewGuid().ToString();

            m_utcCreation = m_utcLastWrite = DateTime.UtcNow.AddMinutes(-s_random.Next(120));
        }

        #region IMigrationFileAttachment Members

        public string Name { get { return m_name; } }
        public long Length { get  {return m_length; } }
        public DateTime UtcCreationDate { get { return m_utcCreation; } }
        public DateTime UtcLastWriteDate { get { return m_utcLastWrite; } }
        public string Comment { get { return m_comment; } }

        public Stream GetFileContents()
        {
            byte[] content = new byte[m_length];

            s_random.NextBytes(content);
            MemoryStream stream = new MemoryStream(content);
            stream.Seek(0, SeekOrigin.Begin);
            return stream;
        }

        #endregion
    }
}
