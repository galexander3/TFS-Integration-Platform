// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Xml.Serialization;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT.Rand
{
    /// <summary>
    /// Work item store implementation.
    /// </summary>
    [XmlType("InitializationData")]
    public class RandStore : IWorkItemTrackingEndpoint, IMigrationWorkItemStore, IMigrationWorkItemStoreFactory
    {
        private int m_count;                                // Number of items to generate
        private Random m_rnd;                               // Random number generator
        private QueueConfiguration m_writeQueueConfig;      //Write queue configuration
        private WorkItemTrackingSession m_session;          //Current session

        [XmlAttribute("items")]
        public int Count
        {
            get { return m_count; }
            set { m_count = value; }
        }

        public RandStore()
        {
            m_count = 0;
            m_rnd = new Random();
        }


        #region IWorkItemTrackingEndpoint Members

        [XmlIgnore]
        public string FullName { get { return StoreName; } }

        /// <summary>
        /// Gets write queue configuration.
        /// </summary>
        [XmlIgnore()]
        public QueueConfiguration WriteQueueConfig
        {
            get { return m_writeQueueConfig; }
            set { m_writeQueueConfig = value; }
        }

        /// <summary>
        /// Returns session the source belongs to.
        /// </summary>
        [XmlIgnore()]
        public WorkItemTrackingSession Session
        {
            get { return m_session; }
            set { m_session = value; }
        }
        #endregion


        #region IMigrationWorkItemStore Members

        public IEnumerable<IMigrationWorkItem> GetItems(ref string highWatermark)
        {
            List<IMigrationWorkItem> items = new List<IMigrationWorkItem>(m_count);

            for (int i = 0; i < items.Count; i++)
            {
                items.Add(new RandWorkItem(m_rnd.Next(1, 30)));
            }
            return items;
        }

        public GetWorkItemResult[] GetItems(string[] ids)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public UpdateResult[] Update(IWorkItemUpdate[] updates)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void VerifySettings(WorkItemTrackingSession session, WorkItemStore tfsStore)
        {
            throw new NotImplementedException();
        }

        public bool IsValidUser(string name)
        {
            return true;
        }

        public bool IsValidField(string workItemType, string fieldName)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public MigrationWorkItemData Flags { get { return MigrationWorkItemData.All; } }

        public IMigrationWorkItemStore Reopen() { return this; }

        public void SynchronizeMetadata(Microsoft.TeamFoundation.WorkItemTracking.Client.Project project)
        {
            // Do nothing
        }

        public void SynchronizeWorkItemType(string typeName, string tfsTypeName, Microsoft.TeamFoundation.WorkItemTracking.Client.WorkItemTypeCollection types)
        {
            // Do nothing
        }

        public void Refresh()
        {
        }

        public void Close()
        {
        }

        public IWorkItemUpdatePackageFactory ChangeListFactory
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public IEnumerable<string> GetFlatFields(string workItemType)
        {
            throw new NotImplementedException();
        }

        public StringComparer StringValueComparer { get { return StringComparer.InvariantCultureIgnoreCase; } }
        public StringComparer FieldNameComparer { get { return StringComparer.InvariantCultureIgnoreCase; } }
        public StringComparer IdComparer { get { return StringComparer.InvariantCultureIgnoreCase; } }

        public string SystemName { get { return "RND"; } }
        public string StoreName { get { return "RND"; } }

        #endregion

        
        #region IMigrationWorkItemStoreFactory Members

        public IMigrationWorkItemStore CreateWorkItemStore()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
}
