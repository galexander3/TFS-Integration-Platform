// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Tests.WIT
{
    /// <summary>
    /// Value mapping tests.
    /// </summary>
    [TestClass]
    public class WitValueMappingTest: WitFieldMappingTest
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        public WitValueMappingTest() : base("ValueMapping")
        {
        }

        /// <summary>
        /// Compares field values across revisions.
        /// </summary>
        /// <param name="src">Source work item</param>
        /// <param name="srcField">Source field</param>
        /// <param name="dst">Target work item</param>
        /// <param name="dstField">Target field</param>
        /// <param name="valueMapName">Name of the value map</param>
        protected void CompareMappedValues(
            WorkItem src,
            string srcField,
            WorkItem dst,
            string dstField, 
            string valueMapName,
            SystemType sourceSystemType)
        {
            ValueMap valMap = MigrationConfiguration.Current.Wit.ValueMaps[valueMapName];
            
            for (int i = 0; i < src.Revisions.Count; i++)
            {
                object dstExpectedValue = valMap.GetValue(src.Revisions[i][srcField], sourceSystemType);
                Assert.IsTrue(
                    CompareValues(dstExpectedValue, dst.Revisions[i][dstField]),
                    "Field values not mapped properly!");
            }
        }

        /// <summary>
        /// Scenario: Mapping values when there is no value map specified for the field.
        /// Expected result: The value on Tfs and Other should be the same.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mappings, where no value mapping is specified for the field")]
        public void WITValMap_LtoRNoMap()
        {
            ChangeSessions("FieldMapping");

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "Foo", "Bar");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.Type.Name == "WitSyncTest.2", "Work item type was not mapped!");
            CompareValues(src, "WST.String", dst, "WST.MappedString");
        }

        /// <summary>
        /// Scenario: Mapping values when there is a value map specified for the field.
        /// Expected result: The value on Tfs and Other should be different. The Other value should match what is in the config file.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mappings where source value does have a mapped value")]
        public void WITValMap_LtoRWithMapWithSourceInMap()
        {
            ChangeSessions("ValueMapping");

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "A", "B");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.Type.Name == "WitSyncTest.2", "Work item type was not mapped!");
            CompareMappedValues(src, "WST.String", dst, "WST.MappedString", "LetterNumber", SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: Mapping values when there is a value map specified for the field, 
        ///             but the Tfs value is not found in the map.
        /// Expected result: The value on Tfs and Other should be the same.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mappings where source value does NOT have a mapped value")]
        public void WITValMap_LtoRWithMapButSourceNotInMap()
        {
            ChangeSessions("ValueMapping");

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "AAAA", "BBBB");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.Type.Name == "WitSyncTest.2", "Work item type was not mapped!");
            CompareValues(src, "WST.String", dst, "WST.MappedString");
        }

        /// <summary>
        /// Scenario: Mapping values when there is a value map specified for the field.
        /// Expected result: The value on Other and Tfs should be different. The Tfs value should match what is in the config file.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mappings where source value does have a mapped value")]
        public void WITValMap_RtoLWithMapWithSourceInMap()
        {
            ChangeSessions("ValueMapping");

            WorkItem src = CreateSourceWorkItem(Side.Right, "WitSyncTest.2", "WST.MappedString", "1", "2");
            WorkItem dst = Synchronize(Side.Right, src)[0];

            Assert.IsTrue(dst.Type.Name == "WitSyncTest", "Work item type was not mapped!");
            CompareMappedValues(src, "WST.MappedString", dst, "WST.String", "LetterNumber", SystemType.Other);
        }


        /// <summary>
        /// Scenario: Mapping values when there is a value map specified for the field. 
        ///             Also, change both sides in an equivalent way.
        /// Expected result: No new revision is created because the changes are equivalent.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mappings where source value does have a mapped value")]
        public void WITValMap_LtoRWithMapWithSourceInMapWithChanges()
        {
            ChangeSessions("ValueMapping");

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "A");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            //Make equivalent modifications to each side
            src.Fields["WST.String"].Value = "B";
            src.Save();
            dst.Fields["WST.MappedString"].Value = "2";
            dst.Save();
            Assert.IsTrue(dst.Revision == 2, "Too many revisions were created!");

            //Resync.  No revisions should be created because the changes to each side were equivalent.
            dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue(dst.Revision == 2, "Mapped values not accounted for in comparison!");

            CompareMappedValues(src, "WST.String", dst, "WST.MappedString", "LetterNumber", SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: Mapping values when there is a value map specified for the field. 
        ///             Also, change both sides in an equivalent way.
        /// Expected result: No new revision is created because the changes are equivalent.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mappings where source value does have a mapped value")]
        public void WITValMap_RtoLWithMapWithSourceInMapWithChanges()
        {
            ChangeSessions("ValueMapping");
            base.Session.Policies.FieldConflict.MasterSystem = SystemType.Other;

            WorkItem src = CreateSourceWorkItem(Side.Right, "WitSyncTest.2", "WST.MappedString", "1");
            WorkItem dst = Synchronize(Side.Right, src)[0];

            //Make equivalent modifications to each side
            src.Fields["WST.MappedString"].Value = "2";
            src.Save();
            dst.Fields["WST.String"].Value = "B";
            dst.Save();
            Assert.IsTrue(dst.Revision == 2, "Too many revisions were created!");

            //Resync.  No revisions should be created because the changes to each side were equivalent.
            dst = Synchronize(Side.Right, src)[0];
            Assert.IsTrue(dst.Revision == 2, "Mapped values not accounted for in comparison!");

            CompareMappedValues(src, "WST.MappedString", dst, "WST.String", "LetterNumber", SystemType.Other);
        }

        /// <summary>
        /// Scenario: Mapping values when there is a value map specified for the field, 
        ///             but the Other value is not found in the map.
        /// Expected result: The value on Other and Tfs should be the same.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mappings where source value does NOT have a mapped value")]
        public void WITValMap_RtoLWithMapButSourceNotInMap()
        {
            ChangeSessions("ValueMapping");

            WorkItem src = CreateSourceWorkItem(Side.Right, "WitSyncTest.2", "WST.MappedString", "111", "222");
            WorkItem dst = Synchronize(Side.Right, src)[0];

            Assert.IsTrue(dst.Type.Name == "WitSyncTest", "Work item type was not mapped!");
            CompareValues(src, "WST.MappedString", dst, "WST.String");
        }


        /// <summary>
        /// Scenario: migration of a flat work item with value mapping
        /// Expected result: work item should be migrated with mapped value
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mapping for flat work items")]
        public void WITValMap_LtoRFlatWorkItems()
        {
            ChangeSessions("ValueMapping");
            base.Session.IgnoreRevisions = true;

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "A");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.Revision == 1, "Too many revisions were created!");
            CompareMappedValues(src, "WST.String", dst, "WST.MappedString", "LetterNumber", SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: migration of a flat work item with value mapping
        /// Expected result: work item should be migrated with mapped value
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mapping for flat work items")]
        public void WITValMap_RtoLFlatWorkItems()
        {
            ChangeSessions("ValueMapping");
            base.Session.IgnoreRevisions = true;

            WorkItem src = CreateSourceWorkItem(Side.Right, "WitSyncTest.2", "WST.MappedString", "1");
            WorkItem dst = Synchronize(Side.Right, src)[0];

            Assert.IsTrue(dst.Revision == 1, "Too many revisions were created!");
            CompareMappedValues(src, "WST.MappedString", dst, "WST.String", "LetterNumber", SystemType.Other);
        }

        /// <summary>
        /// Scenario: migration of a modified flat work item with value mapping. 
        /// Expected result: no new revision after modifications because the values 
        ///                 are equivelent when value mapping is accounted for
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mapping for modified flat work items")]
        public void WITValMap_RtoLFlatWorkItemsWithChanges()
        {
            ChangeSessions("ValueMapping");
            base.Session.IgnoreRevisions = true;
            base.Session.Policies.FieldConflict.MasterSystem = SystemType.Other;
            
            WorkItem src = CreateSourceWorkItem(Side.Right, "WitSyncTest.2", "WST.MappedString", "1");
            WorkItem dst = Synchronize(Side.Right, src)[0];

            Assert.IsTrue(dst.Revision == 1, "Too many revisions were created!");

            //Make equivalent modifications to each side
            src.Fields["WST.MappedString"].Value = "2";
            src.Save();
            dst.Fields["WST.String"].Value = "B";
            dst.Save();
            Assert.IsTrue(dst.Revision == 2, "Too many revisions were created!");

            //Resync.  No revisions should be created because the changes to each side were equivalent.
            dst = Synchronize(Side.Right, src)[0];
            Assert.IsTrue(dst.Revision == 2, "Mapped values not accounted for in comparison!");

            CompareMappedValues(src, "WST.MappedString", dst, "WST.String", "LetterNumber", SystemType.Other);
        }

        /// <summary>
        /// Scenario: migration of a modified flat work item with value mapping. 
        /// Expected result: no new revision after modifications because the values 
        ///                 are equivelent when value mapping is accounted for
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Tests value mapping for modified flat work items")]
        public void WITValMap_LtoRFlatWorkItemsWithChanges()
        {
            ChangeSessions("ValueMapping");
            base.Session.IgnoreRevisions = true;

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "A");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.Revision == 1, "Too many revisions were created!");

            //Make equivalent modifications to each side
            src.Fields["WST.String"].Value = "B";
            src.Save();
            dst.Fields["WST.MappedString"].Value = "2";
            dst.Save();
            Assert.IsTrue(dst.Revision == 2, "Too many revisions were created!");

            //Resync.  No revisions should be created because the changes to each side were equivalent.
            dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue(dst.Revision == 2, "Mapped values not accounted for in comparison!");

            CompareMappedValues(src, "WST.String", dst, "WST.MappedString", "LetterNumber", SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: manual resolution of a conflict on the left side with value mapping
        /// Expected results: changes from the right side must be accepted.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Manual resolution of a conflict on the left side")]
        public void WITValMap_LtoRManualResolutionOnThrow()
        {
            ChangeSessions("ValueMapping");
            base.Session.Policies.FieldConflict.MasterSystem = SystemType.Tfs;
            base.Session.Policies.FieldConflict.Reaction = WitConflictReaction.Throw;

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "A");
            WorkItem dst = Synchronize(Side.Left, src)[0];
            
            src["WST.String"] = "B";
            src.Save();

            dst["WST.MappedString"] = "5";
            dst.Save();

            src["WST.String"] = "C";
            src.Save();

            dst["WST.MappedString"] = "4";
            dst.Save();

            
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Revision == 3, "New revisions were created on the left side!");
            Assert.IsTrue(dst.Revision == 3, "New revisions were created on the right side!");

            // Fixing the conflict on the left side.
            src["WST.String"] = "E";
            src.Save();

            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(dst.Revision == 3, "Right work item was changed!");

            CheckFieldHistory(src, "WST.String", "A", "B", "C", "E", "D");
        }

        /// <summary>
        /// Scenario: test string value mapped to empty string
        /// Expected results: string was mapped to empty.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("testing string value mapped to empty")]
        public void WITValMap_MapToEmpty()
        {
            ChangeSessions("ValueMapping");

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "mapping");
            WorkItem dst = Synchronize(Side.Left, src)[0];
            
            // Test map string value to empty string
            src["WST.String1"] = "F";
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            CompareMappedValues(src, "WST.String1", dst, "WST.MappedSpecial", "SpecialMap", SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: test English string value mapped to International string
        /// Expected results: string was mapped to empty.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("English string value mapped to International string")]
        public void WITValMap_EnglishToIntl()
        {
            ChangeSessions("ValueMapping");

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "test");
            WorkItem dst = Synchronize(Side.Left, src)[0];
            
            // Test map string value to International characters
            src["WST.String1"] = "G";
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            CompareMappedValues(src, "WST.String1", dst, "WST.MappedSpecial", "SpecialMap", SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: testing international string value was mapped to english string
        /// Expected results: string was mapped to empty.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("testing international string value was mapped to English string")]
        public void WITValMap_IntlToEnglish()
        {
            ChangeSessions("ValueMapping");

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "test");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            // Test map string value International characters to English
            src["WST.String1"] = "Arbeit Einzelteil, das Test aufsp�rt";
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            CompareMappedValues(src, "WST.String1", dst, "WST.MappedSpecial", "SpecialMap", SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: test English string value was mapped to special characters
        /// Expected results: string was mapped to empty.
        /// </summary>
        [TestMethod, Priority(2), Owner("johe")]
        [Description("testing string value was mapped to special characters")]
        public void WITValMap_MapToSpecialChars()
        {
            ChangeSessions("ValueMapping");

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "A");
            WorkItem dst = Synchronize(Side.Left, src)[0];
            
            // Test map string value containing special characters
            src["WST.String1"] = ";,!#)#%";
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            CompareMappedValues(src, "WST.String1", dst, "WST.MappedSpecial", "SpecialMap", SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: Multiple values of different fields were mapped
        /// Expected results: the values were mapped.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("Multiple values of different fields were mapped")]
        public void WITValMap_MultiValueMapping()
        {
            ChangeSessions("ValueMapping");

            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String", "A");

            WorkItem dst = Synchronize(Side.Left, src)[0];

            // Test map string value containing special characters
            src["WST.String1"] = ";,!#)#%";
            src["WST.String"] = "E";
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            CompareMappedValues(src, "WST.String1", dst, "WST.MappedSpecial", "SpecialMap", SystemType.Tfs);
            CompareMappedValues(src, "WST.String", dst, "WST.MappedString", "LetterNumber", SystemType.Tfs);
        }
        /// <summary>
        /// Scenario: Multiple values of different fields were mapped
        /// Expected results: the values should not mapped.
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("Mapping ")]
        public void WITValMap_EmptyStringMapping()
        {
            ChangeSessions("ValueMapping");
            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String1", "A");
            WorkItem dst = Synchronize(Side.Left, src)[0];

            // Test map string value containing special characters
            src["WST.String1"] = "";
            src.Save();
            dst = Synchronize(Side.Left, src)[0];

            CompareMappedValues(src, "WST.String1", dst, "WST.MappedSpecial", "SpecialMap", SystemType.Tfs);
        }

        /// <summary>
        ///     Scenario: test value mapping does not exist
        ///     Expected Result: the value was the same as other side 
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("test value mapping does not exist")]
        public void WITValMap_NoMappingTest()
        {
            ChangeSessions("ValueMapping");
            WorkItem src = CreateWorkItem(Side.Left, 1);
            src["WST.String1"] = "X";
            src["WST.String2"] = "2";
            src.Save();
            WorkItem dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue((int)dst["WST.Int2"] == 2);
            Assert.IsTrue((string)dst["WST.MappedSpecial"] == "X");

        }

        /// <summary>
        ///     Scenario: end to end value mapping test
        /// </summary>
        [TestMethod, Priority(1), Owner("johe")]
        [Description("End to End testing for value mapping")]
        public void WITEndToEnd_ValueMapping()
        {
            // change test session to flat work item configuration           
            ChangeSessions("ValueMapping");

            // field mapping from string to int, value also mapped
            WorkItem src = CreateSourceWorkItem(Side.Left, "WitSyncTest", "WST.String2", "A");
            WorkItem dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue((int)dst["WST.Int2"] == 1, "Right work item value map fail");

            //no changes, just sync
            dst = Synchronize(Side.Left, src)[0];

            // field mapping from right to left
            dst["WST.Int2"] = 2;
            dst.Save();
            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();
            Assert.IsTrue((string)src["WST.String2"] == "B", "Left side is not updated");

            //Field conflictions
            dst["WST.Int2"] = 4;
            dst.Save();
            src["WST.String2"] = "C";
            src.Save(); 
            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();
            Assert.IsTrue((string)src["WST.String2"] == "C", "should not have any changes");
            Assert.IsTrue((int)dst["WST.Int2"] == 3, "not in  sync with other side");

            // change single field from right to left migration
            dst["WST.Int2"] = 5;
            dst.Save();

            src = Synchronize(Side.Right, dst)[0];
            dst.SyncToLatest();
            Assert.IsTrue((string)src["WST.String2"] == "E", "Not updated");
            Assert.IsTrue((int)dst["WST.Int2"] == 5, "wrong in value mapping");

            dst = Synchronize(Side.Left, src)[0];

        }        
    }
}
