using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Tests.WIT
{
    /// <summary>
    /// Unit tests for the file attachment analyzer component.
    /// </summary>
    [TestClass]
    public class AttachmentAnalyzer
    {
        /// <summary>
        /// Scenario: using all attachments' properties in comparison.
        /// Expected result: comparison should work.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Comparing all properties of file attachments")]
        public void WIT_CompareAll()
        {
            FileAttachmentAnalyzer analyzer = new FileAttachmentAnalyzer(AttachmentComparisonAttributes.All);

            TestAttachment a1 = new TestAttachment(
                Guid.NewGuid().ToString(),
                100,
                DateTime.UtcNow.AddDays(-2),
                DateTime.UtcNow.AddDays(-1));
            TestAttachment a2 = new TestAttachment(a1.Name, a1.Length, a1.UtcCreationDate, a1.UtcLastWriteDate);

            Assert.IsTrue(analyzer.Compare(a1, a2) == 0, "Attachments are not identical!");
        }

        /// <summary>
        /// Scenario: comparison using last write time.
        /// Expected result: should work.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Comparison using last write time")]
        public void WIT_DifferentLastWriteTime()
        {
            FileAttachmentAnalyzer analyzer = new FileAttachmentAnalyzer(AttachmentComparisonAttributes.All);

            TestAttachment a1 = new TestAttachment(
                Guid.NewGuid().ToString(),
                100,
                DateTime.UtcNow.AddDays(-2),
                DateTime.UtcNow.AddDays(-1));

            TestAttachment a2 = new TestAttachment(a1.Name, a1.Length, a1.UtcCreationDate, DateTime.UtcNow);
            Assert.IsTrue(analyzer.Compare(a1, a2) != 0, "Comparison doesn't work!");
        }

        /// <summary>
        /// Scenario: comparison using creation date.
        /// Expected result: should work.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Comparison using creation time")]
        public void WIT_DifferentCreateTime()
        {
            FileAttachmentAnalyzer analyzer = new FileAttachmentAnalyzer(AttachmentComparisonAttributes.All);

            TestAttachment a1 = new TestAttachment(
                Guid.NewGuid().ToString(),
                100,
                DateTime.UtcNow.AddDays(-2),
                DateTime.UtcNow);
            TestAttachment a2 = new TestAttachment(a1.Name, a1.Length, DateTime.UtcNow, a1.UtcLastWriteDate);
            Assert.IsTrue(analyzer.Compare(a1, a2) != 0, "Comparison doesn't work!");
        }

        /// <summary>
        /// Scenario: comparison using file length.
        /// Expected result: should work.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Comparison using file length")]
        public void WIT_DifferentLength()
        {
            FileAttachmentAnalyzer analyzer = new FileAttachmentAnalyzer(AttachmentComparisonAttributes.All);

            TestAttachment a1 = new TestAttachment(
                Guid.NewGuid().ToString(),
                100,
                DateTime.UtcNow.AddDays(-2),
                DateTime.UtcNow.AddDays(-1));
            TestAttachment a2 = new TestAttachment(a1.Name, 200, a1.UtcCreationDate, a1.UtcLastWriteDate);
            Assert.IsTrue(analyzer.Compare(a1, a2) != 0, "Comparison doesn't work!");
        }

        /// <summary>
        /// Scenario: comparison using file name.
        /// Expected result: should work.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Comparison using file name")]
        public void WIT_DifferentName()
        {
            FileAttachmentAnalyzer analyzer = new FileAttachmentAnalyzer(AttachmentComparisonAttributes.All);

            TestAttachment a1 = new TestAttachment(
                Guid.NewGuid().ToString(),
                100,
                DateTime.UtcNow.AddDays(-2),
                DateTime.UtcNow.AddDays(-1));
            TestAttachment a2 = new TestAttachment(Guid.NewGuid().ToString(), a1.Length, a1.UtcCreationDate, a1.UtcLastWriteDate);
            Assert.IsTrue(analyzer.Compare(a1, a2) != 0, "Comparison doesn't work!");
        }

        /// <summary>
        /// Scenario: ignoring creation date in comparison.
        /// Expected result: should be ignored.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Ignoring creation date in comparison")]
        public void WIT_IgnoreCreateDate()
        {
            FileAttachmentAnalyzer analyzer = new FileAttachmentAnalyzer(AttachmentComparisonAttributes.LastWriteTime);

            TestAttachment a1 = new TestAttachment(
                Guid.NewGuid().ToString(),
                100,
                DateTime.UtcNow.AddDays(-2),
                DateTime.UtcNow.AddDays(-1));
            TestAttachment a2 = new TestAttachment(a1.Name, a1.Length, a1.UtcCreationDate.AddMinutes(5), a1.UtcLastWriteDate);
            Assert.IsTrue(analyzer.Compare(a1, a2) == 0, "Creation time was not ignored!");
        }

        /// <summary>
        /// Scenario: ignoring last write date in comparison.
        /// Expected result: should be ignored.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Ignoring last write date in comparison")]
        public void WIT_IgnoreLastWriteDate()
        {
            FileAttachmentAnalyzer analyzer = new FileAttachmentAnalyzer(AttachmentComparisonAttributes.CreateTime);

            TestAttachment a1 = new TestAttachment(
                Guid.NewGuid().ToString(),
                100,
                DateTime.UtcNow.AddDays(-2),
                DateTime.UtcNow.AddDays(-1));
            TestAttachment a2 = new TestAttachment(a1.Name, a1.Length, a1.UtcCreationDate, a1.UtcLastWriteDate.AddMinutes(5));
            Assert.IsTrue(analyzer.Compare(a1, a2) == 0, "Comparison doesn't work!");
        }
    }
}
