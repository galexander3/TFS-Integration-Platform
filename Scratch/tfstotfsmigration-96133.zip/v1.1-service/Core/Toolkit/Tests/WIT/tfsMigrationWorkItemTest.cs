﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.Migration.Toolkit.WIT;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tests.Framework;

namespace Tests
{
    [TestClass()]
    public class tfsMigrationWorkItemTest : MigrationTestCaseBase
    {

        #region Additional test attributes

        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public override void Initialize()
        {
            base.Initialize();

            ConfigFile.WriteAndLoad(ConfigParameters);

        }

        [TestCleanup]
        public override void Cleanup()
        {
            base.Cleanup();
        }

        #endregion

        [DeploymentItem("Microsoft.TeamFoundation.Migration.Toolkit.dll")]
        [TestMethod, Description("Test single work item migration")]
        public void SingleWorkItemMigrationTest()
        {
            Assert.Inconclusive("SingleWorkItemMigrationTest");

            WorkItemStore wiStore = new WorkItemStore("http://jhe2:8080");
            TeamFoundationServer tfs = TeamFoundationServerFactory.GetServer("http://jhe2:8080");

            Project proj = wiStore.Projects[0];

            TfsProjectUtils projUtils = new TfsProjectUtils(proj);
            TfsWorkItemStoreUtils wiStoreUtils = new TfsWorkItemStoreUtils(wiStore, projUtils);

            foreach (WorkItemType wiType in proj.WorkItemTypes)
            {
                try
                {

                    wiStoreUtils.CreateNewWorkItem(wiType, "Test");
                }
                catch (Exception ex)
                {

                }
            }

            //            WorkItemTrackingSession session = MigrationConfiguration.Current.Wit.Sessions["sessionkey"];

        }

        [TestMethod()]
        public void WorkItemOnlyMigrationTest()
        {


        }
        [TestMethod()]
        public void EmptyTargetProjectMigrationTest()
        {

        }

    }
}
