// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Threading;
using System.Xml;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Summary description for ServiceMode
    /// </summary>
    [TestClass]
    public class ServiceModeTest : WitTestBase
    {
        private int m_count;                                // Number of migrated items

        #region Internals

        /// <summary>
        /// Constructor
        /// </summary>
        public ServiceModeTest()
            : base("ServiceMode")
        {
        }

        /// <summary>
        /// Initializes test.
        /// </summary>
        protected override void OnTestInitialize()
        {
            base.OnTestInitialize();
            m_count = 0;

            // Reset filters on both sides
            Session.TfsMigrationSource.Filter = Session.OtherMigrationSource.TfsSource.Filter = "[System.Id] = 0";
            Session.SleepTime = 0;

            // Sign up for events
            Session.WorkItemMigrationComplete += new EventHandler<MigrationCompleteEventArgs>(OnItemMigrationComplete);
            Session.WorkItemMigrationFailed += new EventHandler<WorkItemMigrationEventArgs>(OnItemMigrationError);
            Session.WorkItemMigrationFailed += new EventHandler<WorkItemMigrationEventArgs>(OnItemFailure);
        }

        /// <summary>
        /// Cleans up tests
        /// </summary>
        protected override void OnTestCleanup()
        {
            base.OnTestCleanup();

            // Unsubscribe from events
            Session.WorkItemMigrationFailed -= new EventHandler<WorkItemMigrationEventArgs>(OnItemMigrationError);
            Session.WorkItemMigrationComplete -= new EventHandler<MigrationCompleteEventArgs>(OnItemMigrationComplete);
            Session.WorkItemMigrationFailed -= new EventHandler<WorkItemMigrationEventArgs>(OnItemFailure);
        }

        /// <summary>
        /// Callback function for migration errors.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="args">Arguments</param>
        private void OnItemMigrationError(
            object sender,
            WorkItemMigrationEventArgs args)
        {
            Assert.Fail("Synchronization of a work item failed!");
        }

        /// <summary>
        /// Callback function for successful migration.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="args">Arguments</param>
        private void OnItemMigrationComplete(
            object sender,
            MigrationCompleteEventArgs args)
        {
            m_count++;
        }

        /// <summary>
        /// Item failure event handler.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="args">Arguments</param>
        private void OnItemFailure(
            object sender,
            WorkItemMigrationEventArgs args)
        {
            Assert.Fail("Synchronization of a work item failed!");
        }

        /// <summary>
        /// Returns reflection of the given work item when it appears.
        /// </summary>
        /// <param name="sourceSide">Source side</param>
        /// <param name="sourceId">Source work item</param>
        /// <returns>Reflection</returns>
        private WorkItem GetReflection(
            Side sourceSide,
            int sourceId)
        {
            // 15 seconds should be enough for a single item to appear
            for (int i = 0; i < 15 ; i++)
            {
                string id = Convert.ToString(sourceId, CultureInfo.InvariantCulture);
                string targetId = Session.FindReflections(
                    sourceSide == Side.Left ? SystemType.Tfs : SystemType.Other,
                    id)[0];

                if (!string.IsNullOrEmpty(targetId))
                {
                    return Store.GetWorkItem(Convert.ToInt32(targetId, CultureInfo.InvariantCulture));
                }

                Thread.Sleep(1000);
            }
            Assert.Fail("Reflection was not found!");
            return null;
        }

        /// <summary>
        /// Sets the filter on the given source to obtain specified items.
        /// </summary>
        /// <param name="source">TFS source</param>
        /// <param name="items">Items to obtain</param>
        private void SetFilter(
            TfsMigrationDataSource source,
            params WorkItem[] items)
        {
            StringBuilder query = new StringBuilder();

            for (int i = 0; i < items.Length; i++)
            {
                if (i != 0)
                {
                    query.Append(" OR ");
                }
                query.AppendFormat(CultureInfo.InvariantCulture, "[System.Id] = {0}", items[i].Id);
            }

            source.Filter = query.ToString();
        }

        /// <summary>
        /// Returns time on the server.
        /// </summary>
        /// <returns>Server time</returns>
        private DateTime GetServerTime()
        {
            Query q = new Query(Store, "SELECT [System.Id] FROM WorkItems WHERE [System.Id] = -1");
            q.EndQuery(q.BeginQuery());

            return q.AsOfUTC;
        }

        /// <summary>
        /// Resets filters on both sides, so they would accept only new items.
        /// </summary>
        private void ResetFilters()
        {
            DateTime serverTime = GetServerTime();
            string filter = string.Format(
                CultureInfo.InvariantCulture,
                "[System.ChangedDate] >= '{0}'",
                serverTime.ToString("u"));

            Session.TfsMigrationSource.Filter = filter;
            Session.OtherMigrationSource.TfsSource.Filter = filter;
        }

        /// <summary>
        /// Configures threads for ST/MT tests.
        /// </summary>
        /// <param name="isMt">MT flag</param>
        private void ConfigureThreads(
            bool isMt)
        {
            if (!isMt)
            {
                Session.SlowQueueConfig.ThreadCount = 0;
                Session.FastQueueConfig.ThreadCount = 0;
                Session.TfsMigrationSource.WriteQueueConfig.ThreadCount = 0;
                Session.OtherMigrationSource.Endpoint.WriteQueueConfig.ThreadCount = 0;
            }
        }

        /// <summary>
        /// Creates given number of items with a random number of revisions between 1 and maxRevCount.
        /// </summary>
        /// <param name="itemCount">Number of items to create</param>
        /// <param name="maxRevCount">Max number of revisions per item</param>
        private void CreateItems(
            int itemCount,
            int maxRevCount)
        {
            System.Diagnostics.Trace.WriteLine(
                string.Format(CultureInfo.InvariantCulture, "Creating {0} item(s)...", itemCount));
            Random rnd = new Random();

            // Create first revision
            WorkItem[] items = new WorkItem[itemCount];

            for (int i = 0; i < itemCount; i++)
            {
                WorkItem wi = Projects.Left.WorkItemTypes["WitSyncTest"].NewWorkItem();
                wi["WST.String"] = Guid.NewGuid().ToString();
                wi["WST.Int"] = rnd.Next();
                wi["WST.InternalRevision"] = 1;

                items[i] = wi;
            }

            Store.BatchSave(items);

            for (int i = 1; i < maxRevCount; i++)
            {
                // Truncate the array
                itemCount = rnd.Next(1, itemCount + 1);
                WorkItem[] newItems = new WorkItem[itemCount];

                Array.Copy(items, newItems, itemCount);
                items = newItems;

                for (int j = 0; j < itemCount; j++)
                {
                    WorkItem wi = items[j];

                    wi["WST.String"] = Guid.NewGuid().ToString();
                    wi["WST.InternalRevision"] = i + 1;
                }

                Store.BatchSave(items);
            }

            System.Diagnostics.Trace.WriteLine("Items created!");
        }

        #endregion

        #region Tests Implementation

        /// <summary>
        /// Tests SynchronizeFull method.
        /// </summary>
        /// <param name="side">Side where change occurs.</param>
        void SynchronizeFull(
            Side side)
        {
            Pair<WorkItem> items = new Pair<WorkItem>(null, null);

            items.Left = CreateWorkItem(Side.Left, 1);
            items.Right = Synchronize(Side.Left, items.Left)[0];
            ResetFilters();

            items[side].Title = Guid.NewGuid().ToString();
            items[side].Save();
            Session.SynchronizeFull();
            items.Left.SyncToLatest();
            items.Right.SyncToLatest();
            CompareItems(items.Left, items.Right);
        }

        /// <summary>
        /// Completes session while it's processing items.
        /// </summary>
        /// <param name="isMt">Multithreaded flag</param>
        void CompleteSession(
            bool isMt)
        {
            const int itemCount = 70;
            ConfigureThreads(isMt);
            ResetFilters();
            CreateItems(itemCount, 3);

            Session.Start();
            Session.SyncProcess.ReadyEvent.WaitOne();
            Session.Stop();

            Assert.IsTrue(m_count == itemCount, "Some items were not processed!");
        }

        /// <summary>
        /// Aborts session while it's processing items.
        /// </summary>
        /// <param name="isMt">Multithreaded flag</param>
        void AbortSession(
            bool isMt)
        {
            const int itemCount = 150;
            ConfigureThreads(isMt);
            ResetFilters();
            CreateItems(itemCount, 3);

            Session.Start();
            Session.SyncProcess.WritingEvent.WaitOne();
            Session.Abort();

            Assert.IsTrue(Session.IsAborted, "Session was not aborted!");
            Assert.IsTrue(m_count < itemCount, "All items have been processed!");
        }

        /// <summary>
        /// Pauses and resumes a session.
        /// </summary>
        /// <param name="isMt">Multithreaded flag</param>
        private void PauseSession(
            bool isMt)
        {
            ConfigureThreads(isMt);
            ResetFilters();

            const int itemCount = 150;
            CreateItems(itemCount, 3);

            Session.Start();
            Session.SyncProcess.WritingEvent.WaitOne();
            Session.Pause();
            Assert.IsTrue(Session.IsPaused, "Session was not paused!");
            Thread.Sleep(5000);

            Session.Resume();
            Session.Stop();
            Assert.IsTrue(m_count == itemCount, "Some items were not processed!");
        }

        /// <summary>
        /// Completes paused session which is processing some items.
        /// </summary>
        /// <param name="isMt">Multithreaded flag</param>
        private void CompletePausedSession(
            bool isMt)
        {
            ConfigureThreads(isMt);
            ResetFilters();

            const int itemCount = 150;
            CreateItems(itemCount, 3);

            Session.Start();
            Session.SyncProcess.WritingEvent.WaitOne();
            Session.Pause();
            Thread.Sleep(5000);

            Session.Stop();
            Assert.IsTrue(m_count == itemCount, "Some items were not processed!");
        }

        #endregion

        /// <summary>
        /// Scenario: completing an inactive session.
        /// Expected result: migration exception is thrown.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Completing an inactive session.")]
        [ExpectedException(typeof(MigrationException))]
        public void WIT_CompleteInactiveSession()
        {
            Session.Stop();
        }

        /// <summary>
        /// Scenario: aborting an inactive session.
        /// Expected result: migration exception is thrown.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Aborting an inactive session")]
        [ExpectedException(typeof(MigrationException))]
        public void WIT_AbortInactiveSession()
        {
            Session.Abort();
        }

        /// <summary>
        /// Scenario: pausing an inactive session.
        /// Expected result: migration exceptin is thrown.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Pausing an inactive session")]
        [ExpectedException(typeof(MigrationException))]
        public void WIT_PauseInactiveSession()
        {
            Session.Pause();
        }

        /// <summary>
        /// Scenario: resuming an inactive exception.
        /// Expected result: migration exception is thrown.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Resuming an inactive session")]
        [ExpectedException(typeof(MigrationException))]
        public void WIT_ResumeInactiveSession()
        {
            Session.Resume();
        }

        /// <summary>
        /// Scenario: stopping working session with no active threads.
        /// Expected results: Session is stopped.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Stopping working session with no pending items")]
        public void WIT_CompleteSessionInactive()
        {
            ResetFilters();
            Session.Start();
            Session.Stop();

            Assert.IsTrue(Session.IsComplete, "The session was not complete!");
            Assert.IsTrue(!Session.IsRunning, "The session is running!");
        }

        /// <summary>
        /// Scenario: Completing a ST session while it's processing items.
        /// Expected result: processing is complete.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Completing a ST session while it's processing items")]
        public void WIT_CompleteSessionST()
        {
            CompleteSession(false);
        }

        /// <summary>
        /// Scenario: Completing a MT session while it's processing items.
        /// Expected result: processing is complete.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Completing a MT session while it's processing items")]
        public void WIT_CompleteSessionMT()
        {
            CompleteSession(true);
        }

        /// <summary>
        /// Scenario: aborting working session with no active threads.
        /// Expected result: session is aborted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Aborting working session with no pending items")]
        public void WIT_AbortSessionInactive()
        {
            ResetFilters();
            Session.Start();
            Session.Abort();

            Assert.IsTrue(Session.IsAborted, "The session was not aborted!");
            Assert.IsTrue(!Session.IsRunning, "The session is running!");
        }

        /// <summary>
        /// Scenario: aborting a ST session while it's processing items.
        /// Expected results: query is aborted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Aborting a ST session while it's processing items.")]
        public void WIT_AbortSessionST()
        {
            AbortSession(false);
        }

        /// <summary>
        /// Scenario: aborting a MT session while it's processing items.
        /// Expected result: query is aborted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Aborting a MT session while it's processing items.")]
        public void WIT_AbortSessionMT()
        {
            AbortSession(true);
        }

        /// <summary>
        /// Scenario: starting a session after it was stopped.
        /// Expected result: session starts.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Starting a session after it was stopped")]
        public void WIT_StopStartSession()
        {
            ResetFilters();
            Session.Start();
            Session.Stop();
            Session.Start();
            Session.Stop();
        }

        /// <summary>
        /// Scenario: stopping a session after it was aborted.
        /// Expected result: session starts.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Starting a session after it was aborted")]
        public void WIT_AbortStartSession()
        {
            ResetFilters();
            Session.Start();
            Session.Abort();
            Session.Start();
            Session.Stop();
        }

        /// <summary>
        /// Scenario: pausing a session with no pending items.
        /// Expected result: session pauses.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Pausing a session with no pending items")]
        public void WIT_PauseSessionInactive()
        {
            ResetFilters();
            Session.Start();
            Session.Pause();
            Session.Resume();
            Session.Stop();
        }

        /// <summary>
        /// Scenario: pausing and resuming a MT session while it's processing items.
        /// Expected results: session pauses and resumes.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Pausing and resuming a MT session while it's processing items")]
        public void WIT_PauseSessionMT()
        {
            PauseSession(true);
        }

        /// <summary>
        /// Scenario: pausing and resuming a ST session while it's processing items.
        /// Expected results: session pauses and resumes.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Pausing and resuming a ST session while it's processing items")]
        public void WIT_PauseSessionST()
        {
            PauseSession(false);
        }

        /// <summary>
        /// Scenario: completing a paused session which is not processing items.
        /// Expected result: process stops.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Completing paused session which is not processing items")]
        public void WIT_CompletePausedSessionInactive()
        {
            ResetFilters();
            Session.Start();
            Session.SyncProcess.ReadyEvent.WaitOne();
            Session.Pause();
            Thread.Sleep(5000);
            Session.Stop();
            
        }

        /// <summary>
        /// Scenario: completing paused MT session which is processing items.
        /// Expected results: all items have been processed.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Completing paused MT session which is processing items")]
        public void WIT_CompletePausedSessionMT()
        {
            CompletePausedSession(true);
        }

        /// <summary>
        /// Scenario: completing paused ST session which is processing items.
        /// Expected results: all items have been processed.
        /// </summary>
        [TestMethod, Priority(2), Owner("aliakb")]
        [Description("Completing paused ST session which is processing items")]
        public void WIT_CompletePausedSessionST()
        {
            CompletePausedSession(false);
        }

        /// <summary>
        /// Scenario: synchronization of work item types while session is running.
        /// Expected result: types are synchronized; changes are picked up during synchronization.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Synchronization of work item types")]
        public void WIT_SynchronizeWorkItemTypes()
        {
            // Create a work item type
            XmlDocument typeDoc = Projects.Left.WorkItemTypes["WitSyncTest"].Export(false);
            XmlElement fieldElement = typeDoc.CreateElement("FIELD");
            fieldElement.SetAttribute("refname", "WST.TestMetadataSync");
            fieldElement.SetAttribute("name", "Test Metadata Synchronization Field");
            fieldElement.SetAttribute("type", "String");

            XmlNode fieldsNode = typeDoc.DocumentElement.SelectSingleNode("WORKITEMTYPE/FIELDS");
            fieldsNode.AppendChild(fieldElement);

            ResetFilters();
            Session.OtherMigrationSource.TfsSource.MetadataSynchronizationPolicy.Types = MetadataTypes.Types;
            Session.Start();

            Session.SyncProcess.ReadyEvent.WaitOne();
            Projects.Left.WorkItemTypes.Import(typeDoc.DocumentElement);
            Refresh();

            WorkItem src = Projects.Left.WorkItemTypes["WitSyncTest"].NewWorkItem();
            src["System.Title"] = Guid.NewGuid().ToString();
            src["WST.TestMetadataSync"] = Guid.NewGuid().ToString();
            src.Save();

            // Skip two passes to make sure the new item gets to the opposite side
            for (int i = 0; i < 2; i++)
            {
                Session.SyncProcess.ReadingEvent.Reset();
                Session.SyncProcess.ReadingEvent.WaitOne();
            }

            Session.Stop();

            WorkItem dst = FindReflections(Side.Left, src.Id.ToString())[0];
            CompareItems(src, dst);

            fieldsNode.RemoveChild(fieldElement);
            Projects.Left.WorkItemTypes.Import(typeDoc.DocumentElement);
            Projects.Right.WorkItemTypes.Import(typeDoc.DocumentElement);

            Refresh();
        }

        /// <summary>
        /// Scenario: using SynchronizeFull to migrate a change on the master side.
        /// Expected: the change is migrated and picked up.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Calling SynchronizeFull to migrate a change on the master side")]
        public void WIT_SynchronizeFullMaster()
        {
            SynchronizeFull(Side.Left);
        }

        /// <summary>
        /// Scenario: using SynchronizeFull to migrate a change on the slave side.
        /// Expected: the change is migrated and picked up.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Calling SynchronizeFull to migrate a change on the slave side")]
        public void WIT_SynchronizeFullSlave()
        {
            SynchronizeFull(Side.Right);
        }
    }
}
