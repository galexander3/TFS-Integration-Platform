// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Tests.WIT
{
    /// <summary>
    /// Test implementation of the IMigrationFileAttachment interface.
    /// </summary>
    class TestAttachment: IMigrationFileAttachment
    {
        private string m_name;                              // File name
        private long m_length;                              // File size
        private DateTime m_createTime;                      // Creation time
        private DateTime m_lastWriteTime;                   // Last write time

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="name">File name</param>
        /// <param name="length">File size</param>
        /// <param name="createTime">Creation time</param>
        /// <param name="lastWriteTime">Last write time</param>
        public TestAttachment(string name, long length, DateTime createTime, DateTime lastWriteTime)
        {
            m_name = name;
            m_length = length;
            m_createTime = createTime;
            m_lastWriteTime = lastWriteTime;
        }


        #region IMigrationFileAttachment Members

        public string Name { get { return m_name; } }

        public long Length { get { return m_length; } }

        public DateTime UtcCreationDate { get { return m_createTime; } }

        public DateTime UtcLastWriteDate { get { return m_lastWriteTime; } }

        public string Comment { get { return string.Empty; } }

        public System.IO.Stream GetFileContents()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
}
