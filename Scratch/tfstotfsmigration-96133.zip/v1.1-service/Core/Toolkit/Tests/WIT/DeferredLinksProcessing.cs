using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;

using System.Text;
using System.Collections.Generic;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace Tests.WIT
{
    /// <summary>
    /// Unit tests for processing deferral links.
    /// </summary>
    [TestClass]
    public class DeferredLinksProcessing : WitTestBase
    {
        #region Internals

        /// <summary>
        /// Constructor.
        /// </summary>
        public DeferredLinksProcessing()
            : base("Links")
        {
        }

        /// <summary>
        /// Test initialization.
        /// </summary>
        protected override void OnTestInitialize()
        {
            base.OnTestInitialize();
            // Delete all pending deferred links
            using (MigrationSqlTransaction trn = (MigrationSqlTransaction)DataAccessManager.Current.StartTransaction())
            {
                using (SqlCommand cmd = trn.CreateCommand())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "DELETE FROM DeferredLinks";

                    cmd.ExecuteNonQuery();
                }
                trn.Complete();
            }
        }

        #endregion

        #region Tests

        /// <summary>
        /// Tests processing many deferred links with a single source.
        /// </summary>
        /// <param name="side">Source side</param>
        private void ProcessManySingleSource(
            Side side)
        {
            SystemType st = side == Side.Left ? SystemType.Tfs : SystemType.Other;
            WorkItem src = CreateWorkItem(side, 1);
            WorkItem[] dst = new WorkItem[10];

            for (int i = 0; i < dst.Length; i++)
            {
                dst[i] = CreateWorkItem(side, 1);
                src.Links.Add(new RelatedLink(dst[i].Id));
            }

            src.Save();
            Synchronize(side, src);
            ReadOnlyCollection<ILink> links = Session.LinkEngine.GetDeferredLinks(st, src.Uri.ToString());
            Assert.IsTrue(links.Count == dst.Length, "Some links were not deferred!");

            Synchronize(side, dst);

            Session.ProcessDeferredLinks();
            links = Session.LinkEngine.GetDeferredLinks(st, src.Uri.ToString());
            Assert.IsTrue(links.Count == 0, "Some deferred links were not resolved!");
        }

        /// <summary>
        /// Tests processing multiple deferred links.
        /// </summary>
        /// <param name="side">Source side.</param>
        private void ProcessMany(
            Side side)
        {
            SystemType st = side == Side.Left ? SystemType.Tfs : SystemType.Other;
            WorkItem dst = CreateWorkItem(side, 1);
            WorkItem[] src = new WorkItem[10];

            for (int i = 0; i < src.Length; i++)
            {
                src[i] = CreateWorkItem(side, 1);
                src[i].Links.Add(new RelatedLink(dst.Id));
                src[i].Save();
            }

            Synchronize(side, src);
            Synchronize(side, dst);

            Session.ProcessDeferredLinks();
            int count = 0;

            Session.LinkEngine.EnumerateDeferredLinkSources(
                delegate(SystemType type, string sourceUri)
                {
                    count++;
                }
            );
            Assert.IsTrue(count == 0, "Some deferred links were not processed!");
        }

        /// <summary>
        /// Tests synchronization of a deferred link when the target does not exist.
        /// </summary>
        /// <param name="side">Source side</param>
        private void KeepDeferred(
            Side side)
        {
            SystemType st = side == Side.Left? SystemType.Tfs : SystemType.Other;
            WorkItem src = CreateWorkItem(side, 1);
            WorkItem dst = CreateWorkItem(side, 1);

            src.Links.Add(new RelatedLink(dst.Id));
            src.Save();

            Synchronize(side, src);
            src.SyncToLatest();
            int rev = src.Rev;

            for (int i = 0; i < 3; i++)
            {
                Session.ProcessDeferredLinks();
                src.SyncToLatest();
                ReadOnlyCollection<ILink> links = Session.LinkEngine.GetDeferredLinks(st, src.Uri.ToString());
                Assert.IsTrue(links.Count == 1, "Wrong number of deferred links!");
                Assert.IsTrue(src.Rev == rev, "Source work item was updated!");
            }
        }

        /// <summary>
        /// Tests processing a deferred link which no longer exists on the source.
        /// </summary>
        /// <param name="side">Source side</param>
        private void ProcessObsoleteNonExisting(
            Side side)
        {
            SystemType st = side == Side.Left ? SystemType.Tfs : SystemType.Other;
            WorkItem src = CreateWorkItem(side, 1);
            WorkItem dst = CreateWorkItem(side, 1);

            src.Links.Add(new RelatedLink(dst.Id));
            src.Save();

            Synchronize(side, src);
            src.Links.Clear();
            src.Save();

            int rev = src.Rev;

            Session.ProcessDeferredLinks();
            src.SyncToLatest();

            Assert.IsTrue(src.Rev == rev, "Source item was updated!");
            ReadOnlyCollection<ILink> links = Session.LinkEngine.GetDeferredLinks(st, src.Uri.ToString());
            Assert.IsTrue(links.Count == 0, "Deferred link was not removed!");
        }

        /// <summary>
        /// Tests processing an obsolete deferred link.
        /// </summary>
        /// <param name="side">Side the original link belongs to</param>
        private void ProcessObsoleteDeferred(
            Side side)
        {
            SystemType st = side == Side.Left ? SystemType.Tfs : SystemType.Other;
            WorkItem oldSrc = CreateWorkItem(side, 1);
            WorkItem oldDst = CreateWorkItem(side, 1);

            oldSrc.Links.Add(new RelatedLink(oldDst.Id));
            oldSrc.Save();

            WorkItem[] newItems = Synchronize(side, oldSrc, oldDst);
            WorkItem newSrc = newItems[0];
            WorkItem newDst = newItems[1];

            Assert.IsTrue(newSrc.Links.Count == 0, "The link was migrated!");
            newSrc.Links.Add(new RelatedLink(newDst.Id));
            newSrc.Save();

            oldSrc.SyncToLatest();
            int oldRev = oldSrc.Rev;
            int newRev = newSrc.Rev;

            Session.ProcessDeferredLinks();

            oldSrc.SyncToLatest();
            newSrc.SyncToLatest();

            Assert.IsTrue(oldRev == oldSrc.Rev, "Item was updated!");
            Assert.IsTrue(newRev == newSrc.Rev, "Item was updated!");

            Assert.IsTrue(newSrc.Links.Count == 1, "Wrong number of links!");
            Assert.IsTrue(oldSrc.Links.Count == 1, "Wrong number of links!");

            ReadOnlyCollection<ILink> links = Session.LinkEngine.GetDeferredLinks(st, oldSrc.Uri.ToString());
            Assert.IsTrue(links.Count == 0, "Deferred link was not removed!");
        }

        /// <summary>
        /// Tests successful processing of a deferred link.
        /// </summary>
        /// <param name="side">Side where the original link was created</param>
        private void ProcessDeferred(
            Side side)
        {
            SystemType st = side == Side.Left? SystemType.Tfs : SystemType.Other;
            WorkItem oldSrc = CreateWorkItem(side, 1);
            WorkItem oldDst = CreateWorkItem(side, 1);
            oldSrc.Links.Add(new RelatedLink(oldDst.Id));
            oldSrc.Save();

            WorkItem[] newItems = Synchronize(side, oldSrc, oldDst);
            WorkItem newSrc = newItems[0];
            WorkItem newDst = newItems[1];

            Assert.IsTrue(newSrc.Links.Count == 0, "The link was migrated!");

            ReadOnlyCollection<ILink> links = Session.LinkEngine.GetDeferredLinks(st, oldSrc.Uri.ToString());
            Assert.IsTrue(links.Count == 1, "The link was not deferred!");

            Session.ProcessDeferredLinks();
            newSrc.SyncToLatest();

            Assert.IsTrue(newSrc.Links.Count == 1, "The link was not migrated!");

            // In the current version we do not immediately delete deferred link that was migrated.
            // One more synchronization pass is required for that.
            Session.ProcessDeferredLinks();

            links = Session.LinkEngine.GetDeferredLinks(st, oldSrc.Uri.ToString());
            Assert.IsTrue(links.Count == 0, "Deferred link was not removed!");

            oldSrc.SyncToLatest();
            newSrc.SyncToLatest();

            Assert.IsTrue(oldSrc.Links.Count == 1, "Source links were modified!");
            Assert.IsTrue(newSrc.Links.Count == 1, "Target links were modified!");
        }

        #endregion

        /// <summary>
        /// Scenario: processing a deferred link from the master side.
        /// Expected result: link gets created; deferred link eventually disappears.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Processing deferred link on the master side")]
        public void WIT_DLP_ProcessDeferredMaster()
        {
            ProcessDeferred(Side.Left);
        }

        /// <summary>
        /// Scenario: processing a deferred link from the slave side.
        /// Expected result: link gets created; deferred link eventually disappears.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Processing deferred link on the slave side")]
        public void WIT_DLP_ProcessDeferredSlave()
        {
            ProcessDeferred(Side.Right);
        }

        /// <summary>
        /// Scenario: processing an obsolete deferred link from the master side.
        /// Expected result: the link is removed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Processing an obsolete deferred link from the master side")]
        public void WIT_DLP_ProcessObsoleteDeferredMaster()
        {
            ProcessObsoleteDeferred(Side.Left);
        }

        /// <summary>
        /// Scenario: processing an obsolete deferred link from the slave side.
        /// Expected result: the link is removed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Processing an obsolete deferred link from the slave side")]
        public void WIT_DLP_ProcessObsoleteDeferredSlave()
        {
            ProcessObsoleteDeferred(Side.Right);
        }

        /// <summary>
        /// Scenario: processing a deferred link from the master side which does no longer exists on the source.
        /// Expected result: Deferred link is removed
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Processing a deferred link from the master side that no longer exists on the source")]
        public void WIT_DLP_ProcessObsoleteNonExistingMaster()
        {
            ProcessObsoleteNonExisting(Side.Left);
        }

        /// <summary>
        /// Scenario: processing a deferred link from the slave side which does no longer exists on the source.
        /// Expected result: Deferred link is removed
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Processing a deferred link from the slave side that no longer exists on the source")]
        public void WIT_DLP_ProcessObsoleteNonExistingSlave()
        {
            ProcessObsoleteNonExisting(Side.Right);
        }

        /// <summary>
        /// Scenario: Keeping a deferred link from master when the target is still missing.
        /// Expected result: deferred link stays.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Keeping a deferred link from master when the target is missing")]
        public void WIT_DLP_KeepDeferredMaster()
        {
            KeepDeferred(Side.Left);
        }

        /// <summary>
        /// Scenario: Keeping a deferred link from slave when the target is still missing.
        /// Expected result: deferred link stays.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Keeping a deferred link from slave when the target is still missing")]
        public void WIT_DLP_KeepDeferredSlave()
        {
            KeepDeferred(Side.Left);
        }

        /// <summary>
        /// Scenario: processing many deferred links from the master side.
        /// Expected result: all deferred links should be processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Processing many deferred links from the master side")]
        public void WIT_DLP_ProcessManyMaster()
        {
            ProcessMany(Side.Left);
        }

        /// <summary>
        /// Scenario: processing many deferred links from the slave side.
        /// Expected result: all deferred links should be processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Processing many deferred links from the slave side")]
        public void WIT_DLP_ProcessManySlave()
        {
            ProcessMany(Side.Right);
        }

        /// <summary>
        /// Scenario: processing many deferred links originating from a single source on master.
        /// Expected result: all deferred links should be processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Processing multiple deferred links originating from a single source on the master")]
        public void WIT_DLP_ProcessManySingleSourceMaster()
        {
            ProcessManySingleSource(Side.Left);
        }

        /// <summary>
        /// Scenario: processing many deferred links originating from a single source on slave.
        /// Expected result: all deferred links should be processed.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Processing multiple deferred links originating from a single source on the slave")]
        public void WIT_DLP_ProcessManySingleSourceSlave()
        {
            ProcessManySingleSource(Side.Right);
        }
    }
}
