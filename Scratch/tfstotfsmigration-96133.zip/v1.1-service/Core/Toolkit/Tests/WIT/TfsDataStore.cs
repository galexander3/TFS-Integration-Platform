﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Tests.Framework;
using System.Diagnostics;

namespace Tests
{
    /// <summary>
    ///  This class will create test work item store and provides the function to remove the data
    /// </summary>
    class TfsDataStore
    {

        public TfsDataStore(string tfsServer)
        {
            wiStore = new WorkItemStore(tfsServer);
            tfs = TeamFoundationServerFactory.GetServer(tfsServer);
           wiList = new List<int>();
        }

        private string tfsServer = string.Empty;
        private WorkItemStore wiStore = null;
        private TeamFoundationServer tfs = null;
        private Project prj = null;

        private List<int> wiList = null;

        public void PreparingTestData()
        {
            Project proj = wiStore.Projects[0];

            TfsProjectUtils projUtils = new TfsProjectUtils(proj);
            TfsWorkItemStoreUtils wiStoreUtils = new TfsWorkItemStoreUtils(wiStore, projUtils);

            //Debug.Assert(true, "The work item store is empty!");

            foreach (WorkItemType wiType in proj.WorkItemTypes)
            {
                try
                {
                    WorkItem w = wiStoreUtils.CreateNewWorkItem(wiType, "WorkItemTrackingTest");
                    wiList.Add(w.Id);
                }
                catch (Exception ex)
                {
                    //Log Error Message
                }   
            }

            //  Debug.Assert(true, "The work items are created");
        }

        /// <summary>
        /// Use the following to delete a team project
        ///  D:\Program Files\Microsoft Visual Studio 8\Common7\IDE\PrivateAssemblies\TFSDeleteProject.exe
        ///  :\>tfsdeleteproject.exe /server:http://jmanning-test:8080 /q SomeTeamProject
        /// </summary>
        public void RemoveTestData()
        {
            foreach (int wid in wiList)
            {
                WorkItem wi = wiStore.GetWorkItem(wid);
                
            }
        }

        /// <summary>
        ///     This static function will compare the work item collections in left side (source) and the right side (target) 
        /// </summary>
        /// <param name="left">source collection</param>
        /// <param name="right">target collection</param>
        /// <returns>if the collections are the same, return true else false</returns>
        static public bool CompareWorkItemCollections(WorkItemCollection left, WorkItemCollection right)
        {
            if (left == null || right == null)
            {
                return false;
            }

            if (left.Count != right.Count)
            {
                return false;
            }

            for (int i = 0; i < left.Count; i++)
            {
                if (!CompareWorkItem(left[i], right[i]))
                {
                    return false;
                }
            }   
 
            return true;
        }

        /// <summary>
        ///     Compare if two work items are the same
        /// </summary>
        /// <param name="left">left work item</param>
        /// <param name="right">right work item</param>
        /// <returns>if the same return true else false</returns>
        static public bool CompareWorkItems(WorkItem left, WorkItem right, string [] exclusion)
        {
            Debug.Assert(left != null, "work item is not null");
            Debug.Assert(right != null, "work item is not null");

            if (left.Revisions.Count != right.Revisions.Count)
                return false;

            for (int i = 0; i < left.Revisions.Count; i++)
            {
                Revision src = left.Revisions[i];
                Revision dst = right.Revisions[i];

                if (src.Fields.Count != dst.Fields.Count)
                    return false;
                for (int j = 0; j < src.Fields.Count; j++)
                {
                    Field srcField = src.Fields[j];

                    if (IsComparableField(srcField))
                    {
                        Field dstField = dst.Fields.GetById(srcField.Id);


                        if (CompareValues(GetFieldValue(srcField), GetFieldValue(dstField)))
                            return false;
                    }
                }

            }

            return true;
        }

        /// <summary>
        /// Compares values according to TFS rules.
        /// </summary>
        /// <param name="value1">Value 1</param>
        /// <param name="value2">Value 2</param>
        /// <returns>True if values are identical</returns>
        protected static bool CompareValues(
            object value1,
            object value2)
        {
            bool isNull1 = IsNullValue(value1);
            bool isNull2 = IsNullValue(value2);


            if (isNull1 ^ isNull2)
            {
                return false;
            }
            else if (isNull1 && isNull2)
            {
                return true;
            }
            else
            {
                return value1.Equals(value2);
            }
        }

        /// <summary>
        /// Checks whether value is null according to TFS standards.
        /// </summary>
        /// <param name="value">Value</param>
        /// <returns>True if null/empty</returns>
        protected static bool IsNullValue(
            object value)
        {
            return value == null || value is DBNull || value is string && ((string)value).Length == 0;
        }

        /// <summary>
        /// Gets normalized field's value.
        /// </summary>
        /// <param name="f">Field</param>
        /// <returns>Value</returns>
        private static object GetFieldValue(
            Field f)
        {
            if (f.Id == (int)CoreField.AreaPath || f.Id == (int)CoreField.IterationPath)
            {
                // Get rid of the project part
                string val = (string)f.Value;
                int idx = val.IndexOf('/');

                return idx == -1 ? string.Empty : val.Substring(idx + 1);
            }
            return f.Value;
        }
        
        /// <summary>
        ///     Compare if two work items are the same
        /// </summary>
        /// <param name="left">left work item</param>
        /// <param name="right">right work item</param>
        /// <returns>if the same return true else false</returns>
        static public bool CompareWorkItems(WorkItem left, WorkItem right)
        {
            Debug.Assert(left != null, "work item is not null");
            Debug.Assert(right != null, "work item is not null");

            if (left.Revisions.Count != right.Revisions.Count)
                return false;

            for (int i = 0; i < left.Revisions.Count; i++)
            {
                WorkItem lhs = left.Revisions[i].WorkItem;
                WorkItem rhs = right.Revisions[i].WorkItem;

                if (lhs.Title != lhs.Title)
                    return false;

                if (lhs.IterationPath != rhs.IterationPath)
                    return false;

                if (lhs.AreaPath != rhs.AreaPath)
                    return false;
            }
            
            return true;
        }

        static public bool CompareDataStore(WorkItemStore store, Project left, Project right)
        {
            Debug.Assert(left != null);
            Debug.Assert(right != null);

            int leftTotal = store.QueryCount("SELECT [System.Title] "
                        + "FROM WorkItems WHERE [System.TeamProject] = \'" + left.Name + "\'");

            int rightTotal = store.QueryCount("SELECT [System.Title] "
                        + "FROM WorkItems WHERE [System.TeamProject] = \'" + right.Name + "\'");

            if (left != right)
                return false;

            WorkItemCollection leftWorkItemCollection = store.Query("SELECT [System.Title] "
                + "FROM WorkItems WHERE [System.TeamProject] = \'" + left.Name + "\' ");

            WorkItemCollection rightWorkItemCollection = store.Query("SELECT [System.Title] "
                + "FROM WorkItems WHERE [System.TeamProject] = \'" + right.Name + "\' ");
            Dictionary<int, WorkItem> map = new Dictionary<int, WorkItem>(rightWorkItemCollection.Count);

            foreach (WorkItem wi in rightWorkItemCollection)
            {
                map.Add(wi.Id, wi);
            }

            foreach (WorkItem wi in leftWorkItemCollection)
            {
                if (!map.ContainsKey(wi.Id))
                    return false;

                WorkItem wiRight = map[wi.Id];
                if (!CompareWorkItem(wi, wiRight))
                {
                    return false;
                }

            }
            return true;
        }

        static public bool CompareWorkItem(WorkItem wiLeft, WorkItem wiRight)
        {
            Debug.Assert(wiLeft != null);
            Debug.Assert(wiRight != null);

            if (wiLeft.Revisions.Count != wiRight.Revisions.Count)
                return false;

            for (int i = 0; i < wiLeft.Revisions.Count; i++)
            {
                Revision revLeft = wiLeft.Revisions[i];
                if(!revLeft.Equals(wiRight.Revisions[i]))
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Tells whether the field should be compared.
        /// </summary>
        /// <param name="f">Field</param>
        /// <returns>True if the field should be compared</returns>
        private static bool IsComparableField(
            Field f)
        {
            FieldDefinition fd = f.FieldDefinition;

            switch (fd.Id)
            {
                case (int)CoreField.AreaPath:
                case (int)CoreField.IterationPath:
                    return true;

                case (int)CoreField.AreaId:
                case (int)CoreField.IterationId:
                case (int)CoreField.ChangedDate:
                case (int)CoreField.CreatedDate:
                    return false;

                default:
                    return !fd.IsComputed && fd.IsEditable;
            }
        }


    }
}
