﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml.Serialization;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests.WIT
{
    /// <summary>
    /// Unit tests for TFS value transformation.
    /// </summary>
    [TestClass]
    public class TfsValueTransformTest : WitTestBase
    {
        #region Internal classes
        /// <summary>
        /// Test value transformer.
        /// </summary>
        public class TestValueTransformer : IFieldValueTransformer
        {
            #region IFieldValueTransformer Members

            public object GetTransformedValue(FieldCollection fields, Microsoft.TeamFoundation.WorkItemTracking.Client.Field field, object value)
            {
                if (value is DateTime)
                {
                    value = ((DateTime)value).Date; 
                }
                return value;
            }

            #endregion
        }

        /// <summary>
        /// Factory class for the test transformer.
        /// </summary>
        public class TestValueTransformerFactory : IConfigFactory
        {
            #region IConfigFactory Members

            public object CreateInstance(Type type, string xmlFragment)
            {
                if (type == typeof(IFieldValueTransformer))
                {
                    return new TestValueTransformer();
                }
                return null; 
            }

            #endregion
        }

        #endregion

        public TfsValueTransformTest()
            : base("TfsValueTransformation")
        {
        }

        /// <summary>
        /// Scenario: initialization of non-default value transformer.
        /// Expected result: proper initialization.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Initialization of the value transformer")]
        public void WIT_TransformField_CreateTransformer()
        {
            var transformer = Session.FieldValueTransformer;
            Assert.IsTrue(transformer is TestValueTransformer, "Invalid type!");
        }

        /// <summary>
        /// Scenario: migrating a change where transformed values are identical.
        /// Expected result: the change is ignored.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Ignoring values that became identical after the transformation")]
        public void WIT_TransformField_IdenticalValues()
        {
            DateTime time1 = Convert.ToDateTime("1/15/2008 13:00:00");
            DateTime time2 = time1.AddHours(2);
            DateTime resTime = time1.Date;

            WorkItem src = CreateWorkItem(Side.Left, 0);
            src["WST.DateTime"] = time1;
            src.Save();
            WorkItem dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue((DateTime)dst["WST.DateTime"] == resTime, "Value was not translated!");
            src["WST.DateTime"] = time2;
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue(dst.Rev == 1, "New revision was created!");

            src = Synchronize(Side.Right, dst)[0];
            Assert.IsTrue(src.Rev == 2, "New revision was created!");
        }

        /// <summary>
        /// Scenario: migrating values that become different after the transformation.
        /// Expected result: the change is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating values that are different after the transformation")]
        public void WIT_TransformField_DifferentValues()
        {
            DateTime time1 = Convert.ToDateTime("1/15/2008 13:00:00");
            DateTime resTime1 = time1.Date;
            DateTime time2 = time1.AddDays(1);
            DateTime resTime2 = time2.Date;

            WorkItem src = CreateWorkItem(Side.Left, 0);
            src["WST.DateTime"] = time1;
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];
            Assert.IsTrue((DateTime)dst["WST.DateTime"] == resTime1, "Invalid transformation!");
            src["WST.DateTime"] = time2;
            src.Save();
            dst = Synchronize(Side.Left, src)[0];
            src.SyncToLatest();
            Assert.IsTrue((DateTime)dst["WST.DateTime"] == resTime2, "Invalid transformation!");
            Assert.IsTrue(src.Rev == 2, "Invalid revision!");
        }
    }
}
