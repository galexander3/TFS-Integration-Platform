﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.Migration.Toolkit.WIT;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tests.Framework;


namespace Tests
{
    [TestClass()]
    public class TFSWorkItemStoreTest : MigrationTestCaseBase
    {
        #region Additional test attributes

        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public override void Initialize()
        {
            base.Initialize();

            ConfigFile.WriteAndLoad(ConfigParameters);
            
        }

        [TestCleanup]
        public override void Cleanup()
        {
            base.Cleanup();
        }

        #endregion

        [DeploymentItem("Microsoft.TeamFoundation.Migration.Toolkit.dll")]
        [TestMethod, Description("Test source workitem store unavailable ")]
        public void SourceWorkItemStoreUnavailable()
        {
            Assert.Inconclusive("SourceWorkItemStoreUnavailable");

            WorkItemTrackingConfiguration config = MigrationConfiguration.Current.Wit;

            WorkItemTrackingSession session = config.Sessions["WitSession1"];

            Assert.IsNotNull(session, "The session should not be null");

            try
            {
                session.Start();
            }
            catch (Exception ex)
            {



            }
        }

        [DeploymentItem("Microsoft.TeamFoundation.Migration.Toolkit.dll")]
        [TestMethod, Description("Test target workitem store unavailable ")]
        public void TargetWorkItemStoreUnavailable()
        {
            Assert.Inconclusive("TargetWorkItemStoreUnavailable");

            WorkItemTrackingConfiguration config = MigrationConfiguration.Current.Wit;

            WorkItemTrackingSession session = config.Sessions["WitSession1"];

            Assert.IsNotNull(session, "The session should not be null");

            try
            {
                session.Start();
            }
            catch (Exception ex)
            {



            }

        }


        [DeploymentItem("Microsoft.TeamFoundation.Migration.Toolkit.dll")]
        [TestMethod, Description("Test Source WorkItem Store Contains Invalid Data ")]
        public void SourceWorkItemStoreContainInvalidData()
        {
            Assert.Inconclusive("SourceWorkItemStoreContainInvalidData");

            WorkItemTrackingConfiguration config = MigrationConfiguration.Current.Wit;

            WorkItemTrackingSession session = config.Sessions["WitSession1"];

            Assert.IsNotNull(session, "The session should not be null");

            try
            {
                session.Start();
            }
            catch (Exception ex)
            {



            }
        }

        [DeploymentItem("Microsoft.TeamFoundation.Migration.Toolkit.dll")]
        [TestMethod, Description("Test migration data store ")]
        public void MigrationDataStore()
        {
            Assert.Inconclusive("MigrationDataStore");

            WorkItemTrackingConfiguration config = MigrationConfiguration.Current.Wit;

            WorkItemTrackingSession session = config.Sessions["WitSession1"];

            Assert.IsNotNull(session, "The session should not be null");

            try
            {
                session.Synchronize(SystemType.Tfs);

//              Assert.IsTrue(TfsDataStore.CompareDataStore());
            }
            catch (Exception ex)
            {



            }
        }

        [DeploymentItem("Microsoft.TeamFoundation.Migration.Toolkit.dll")]
        [TestMethod, Description("Test migration data store and target store has data")]
        public void TestTargetDataStorehasData()
        {
            Assert.Inconclusive("TestTargetDataStorehasData");

            WorkItemTrackingConfiguration config = MigrationConfiguration.Current.Wit;


            WorkItemTrackingSession session = config.Sessions["WitSession1"];

            Assert.IsNotNull(session, "The session should not be null");

            try
            {
                session.Start();
            }
            catch (Exception ex)
            {



            }
        }
    }
}
