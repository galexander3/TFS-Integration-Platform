// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Tests.WIT
{
    /// <summary>
    /// Local attachments collection.
    /// </summary>
    class LocalAttachments: IEquatable<LocalAttachments>, IDisposable, IComparer<LocalAttachment>
    {
        private SortedList<LocalAttachment, bool> m_items;  // All items in the collection

        public int Count { get { return m_items.Count; } }
        public LocalAttachment this[int index] { get { return m_items.Keys[index]; } }

        /// <summary>
        /// Constructor. Initializes the collection with the given number of random attachments.
        /// </summary>
        /// <param name="count">Number of attachments in the collection.</param>
        public LocalAttachments(
            int count)
            : this()
        {
            for (int i = 0; i < count; i++)
            {
                LocalAttachment a = new LocalAttachment(Guid.NewGuid().ToString());
                m_items.Add(a, true);
            }
        }

        /// <summary>
        /// Constructor. Initializes an empty collection.
        /// </summary>
        public LocalAttachments()
        {
            m_items = new SortedList<LocalAttachment, bool>(this);
        }

        /// <summary>
        /// Adds a file to the collection.
        /// </summary>
        /// <param name="file">File to add</param>
        public void Add(
            LocalAttachment file)
        {
            m_items.Add(file, true);
        }

        /// <summary>
        /// Compares with another collection.
        /// </summary>
        /// <param name="other">Another collection</param>
        /// <returns>True if collections are identical</returns>
        public bool Equals(
            LocalAttachments other)
        {
            if (m_items.Count != other.m_items.Count)
            {
                return false;
            }

            for (int i = 0; i < m_items.Count; i++)
            {
                if (!m_items.Keys[i].Equals(other.m_items.Keys[i]))
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Disposes the collection by removing all temporary files.
        /// </summary>
        public void Dispose()
        {
            // Dispose all attachments in the collection
            for (int i = 0; i < m_items.Count; i++)
            {
                m_items.Keys[i].Dispose();
            }
            m_items.Clear();
        }

        /// <summary>
        /// Compares two attachments for sorting purposes.
        /// </summary>
        /// <param name="x">Attachment 1</param>
        /// <param name="y">Attachment 2</param>
        /// <returns>-1,0,1</returns>
        public int Compare(LocalAttachment x, LocalAttachment y)
        {
            int res = string.Compare(x.Name, y.Name, StringComparison.InvariantCultureIgnoreCase);
            if (res == 0)
            {
                res = x.Size.CompareTo(y.Size);
            }
            return res;
        }
    }
}
