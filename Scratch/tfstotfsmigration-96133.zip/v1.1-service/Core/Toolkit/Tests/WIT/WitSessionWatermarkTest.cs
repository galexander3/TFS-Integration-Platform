// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Tests.WIT
{
    /// <summary>
    /// Tests for session watermarks
    /// </summary>
    [TestClass]
    public class WitSessionWatermarkTest: WitTestBase
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        public WitSessionWatermarkTest()
            : base("TestSession1")
        {
        }

        /// <summary>
        /// Scenario: getting a session watermark
        /// Expected result: a string or null returned (no errors)
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Getting a session watermark")]
        public void WIT_GetSessionWatermark()
        {
            string wmark = Session.Mapper.HighWatermark.Tfs;
            //As long as no exception is thrown, the test should pass.
        }


        /// <summary>
        /// Scenario: setting a session watermark
        /// Expected result: the watermark is updated (no errors)
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Setting a session watermark")]
        public void WIT_SetSessionWatermarkLEFT()
        {
            SetSessionWatermark(SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: setting a session watermark
        /// Expected result: the watermark is updated (no errors)
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Setting a session watermark")]
        public void WIT_SetSessionWatermarkRIGHT()
        {
            SetSessionWatermark(SystemType.Other);
        }

        /// <summary>
        /// Scenario: Get items to sync with watermarks
        /// Expected result: Only the updated work items are retrieved for teh second GetItems call.
        /// </summary>
        [TestMethod, Priority(1), Owner("mchaffin")]
        [Description("Get items to sync with watermarks")]
        public void WIT_GetItemsWithWatermark()
        {
            //Get the original watermark
            string watermark = Session.Mapper.HighWatermark[SystemType.Tfs];

            //Create a new work item so we know the DB isn't empty
            WorkItem wi0 = CreateWorkItem(Side.Left, 1); //we won't update this one
            WorkItem wi1 = CreateWorkItem(Side.Left, 1); //we will update this one

            //Get the items to be synch-ed
            TfsMigrationWorkItemStore tfsStore = (TfsMigrationWorkItemStore)Session.TfsMigrationSource.CreateWorkItemStore();
            TfsMigrationWorkItems items = (TfsMigrationWorkItems)tfsStore.GetItems(ref watermark);
            List<IMigrationWorkItem> itemList = new List<IMigrationWorkItem>(items);
            Assert.IsTrue(itemList.Count >= 2, "Not enough work items returned.");

            //Update the first work item
            wi1.Title = Guid.NewGuid().ToString();
            wi1.Save();

            //Create a new work item 
            WorkItem wi2 = CreateWorkItem(Side.Left, 1);
            wi2.Title = Guid.NewGuid().ToString();
            wi2.Save();

            //Get work items again to make sure we get the right ones back
            items = (TfsMigrationWorkItems)tfsStore.GetItems(ref watermark);
            itemList = new List<IMigrationWorkItem>(items);

            Assert.AreEqual<int>(2, itemList.Count);

            //Check the IDs returned
            int[] ids = new int[2];
            ids[0] = ((TfsMigrationWorkItem)itemList[0]).WorkItem.Id;
            ids[1] = ((TfsMigrationWorkItem)itemList[1]).WorkItem.Id;

            Assert.IsTrue(wi1.Id == ids[0] || wi1.Id == ids[1], "Wrong work item returned. Expected " + wi1.Id.ToString());
            Assert.IsTrue(wi2.Id == ids[0] || wi2.Id == ids[1], "Wrong work item returned. Expected " + wi2.Id.ToString());
        }

        /// <summary>
        /// Set the session watermark. 
        /// Should update the left watermark if sysType is Tfs.
        /// Otherwise, it updates the right watermark.
        /// </summary>
        /// <param name="sysType">System type: tfs or other.</param>
        private void SetSessionWatermark(SystemType sysType)
        {
            string origMark = Session.Mapper.HighWatermark[sysType];

            //Update the mark
            string newMark = DateTime.UtcNow.ToString();
            Session.Mapper.SaveWatermark(sysType, newMark);

            //Make sure it was updated programmatically
            Assert.IsTrue(Session.Mapper.HighWatermark[sysType] == newMark, "Watermark not updated appropriately!");

            // Make sure it was updated in the database
            Mapper m = new Mapper(Session.Stores);
            Assert.IsTrue(m.HighWatermark[sysType] == newMark, "Watermark not updated appropriately!");

            //Now, set it back to its original state.
            Session.Mapper.SaveWatermark(sysType, origMark);
        }
    }
}
