// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.Migration.WorkItemTracking.Wss;
using Microsoft.TeamFoundation.Migration.WorkItemTracking.Wss.Generated;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

using Tests.Framework;

namespace Tests.WIT
{
    /// <summary>
    /// Unit tests for WIT synchronization between WSS and TFS
    /// </summary>
    [TestClass]
    public class WssTest : WitTestBase
    {
        private Dictionary<string, string> m_idMapping = new Dictionary<string, string>(StringComparer.InvariantCulture);
        private List<WorkItemMigrationEventArgs> m_failures = new List<WorkItemMigrationEventArgs>();
        private bool m_hasType;
        private WssHelper m_wssHelper;

        private static Dictionary<string, string> s_tfs2wssFieldMap;

        #region Internals

        static WssTest()
        {
            s_tfs2wssFieldMap = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase);

            s_tfs2wssFieldMap.Add("System.Id", "ID");
            s_tfs2wssFieldMap.Add("System.Title", "Title");
            s_tfs2wssFieldMap.Add("System.State", "Status");
            s_tfs2wssFieldMap.Add("System.AssignedTo", "AssignedTo");
            s_tfs2wssFieldMap.Add("System.Description", "Body");
            s_tfs2wssFieldMap.Add("Wss.Priority", "Priority");
            s_tfs2wssFieldMap.Add("Wss.PercentComplete", "PercentComplete");
            s_tfs2wssFieldMap.Add("Wss.StartDate", "StartDate");
            s_tfs2wssFieldMap.Add("Wss.DueDate", "DueDate");
            s_tfs2wssFieldMap.Add("System.CreatedDate", "Created");
            s_tfs2wssFieldMap.Add("System.RevisedDate", "Modified");
            s_tfs2wssFieldMap.Add("System.ChangedBy", "Editor");
        }

        public WssTest()
            : base("Wss2TfsWit")
        {
        }

        private Project TfsProject { get { return Store.Projects[Session.TfsMigrationSource.Project]; } }

        private WssHelper WssHelper
        {
            get
            {
                if (m_wssHelper == null)
                {
                    WssMigrationWorkItemStore store = (WssMigrationWorkItemStore)Session.OtherMigrationSource.Endpoint;
                    m_wssHelper = new WssHelper(store.BaseUrl, store.TaskList);
                }
                return m_wssHelper;
            }
        }

        private string TranslateTfsFieldName(string tfsName)
        {
            ReadOnlyCollection<FieldMapEntry> map = MigrationConfiguration.Current.Wit.FieldMaps["Wss2TfsWit"].Fields;

            for (int i = 0; i < map.Count; i++)
            {
                FieldMapEntry f = map[i];

                if (tfsName.Equals(f.TfsName, StringComparison.InvariantCultureIgnoreCase))
                    return f.OtherName;
            }
            return tfsName;
        }

        protected override void OnTestInitialize()
        {
            base.OnTestInitialize();

            // Provision a work item type if necessary
            if (!m_hasType)
            {
                // Provision WssTask work item type into the target project
                string path = Path.Combine(Directory.GetCurrentDirectory(), "Wss2TfsWit.dll");
                Assembly a = Assembly.LoadFile(path);
                using (Stream s = a.GetManifestResourceStream("Microsoft.TeamFoundation.Migration.WorkItemTracking.Wss.WssTask.xml"))
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(s);

                    TfsProject.WorkItemTypes.Import(doc.DocumentElement);
                    Refresh();
                }
                m_hasType = true;
            }

            m_failures.Clear();
            Session.WorkItemMigrationComplete += new EventHandler<MigrationCompleteEventArgs>(OnWorkItemMigrationComplete);
            Session.WorkItemMigrationFailed += new EventHandler<WorkItemMigrationEventArgs>(OnWorkItemMigrationFailed);
        }

        void OnWorkItemMigrationFailed(object sender, WorkItemMigrationEventArgs e)
        {
            m_failures.Add(e);
        }

        protected override void OnTestCleanup()
        {
            base.OnTestCleanup();

            Session.WorkItemMigrationComplete -= new EventHandler<MigrationCompleteEventArgs>(OnWorkItemMigrationComplete);
            if (m_failures.Count > 0)
            {
                for (int i = 0; i < m_failures.Count; i++)
                {
                    WorkItemMigrationEventArgs e = m_failures[i];
                    string msg = string.Format("{0}: {1}", e.SourceId, e.Exception);
                    System.Diagnostics.Trace.WriteLine(msg);
                }
            }
        }

        void OnWorkItemMigrationComplete(object sender, MigrationCompleteEventArgs e)
        {
            if (e.TargetId != null)
            {
                m_idMapping.Add(e.SourceId.Id, e.TargetId.Id);
            }
        }

        private object CreateCompleteWorkItem(SystemType type)
        {
            object item;

            if (type == SystemType.Tfs)
            {
                item = TfsProject.WorkItemTypes["WssTask"].NewWorkItem();
            }
            else
            {
                item = new WssTask(WssHelper);
            }

            SetFieldValue(item, "System.Title", Guid.NewGuid().ToString());
            SetFieldValue(item, "System.State", "Not Started");
            SetFieldValue(item, "System.AssignedTo", TestEnvironment.WssUser);
            SetFieldValue(item, "System.Description", "Created by a unit test");
            SetFieldValue(item, "Wss.Priority", "(3) Low");
            SetFieldValue(item, "Wss.PercentComplete", "45");
            SetFieldValue(item, "Wss.StartDate", DateTime.Now.AddDays(-2));
            SetFieldValue(item, "Wss.DueDate", DateTime.Now.AddDays(1));

            return item;
        }

        private void CompareItems(object item1, object item2)
        {
            WorkItem tfsItem;
            WssTask wssItem;

            if (item1 is WssTask)
            {
                tfsItem = (WorkItem)item2;
                wssItem = (WssTask)item1;
            }
            else
            {
                tfsItem = (WorkItem)item1;
                wssItem = (WssTask)item2;
            }

            // Compare fields
            foreach (Field f in tfsItem.Fields)
            {
                string wssName;

                if (s_tfs2wssFieldMap.TryGetValue(f.ReferenceName, out wssName) && !WssFields.IsReadOnly(wssName))
                {
                    object tfsValue = f.Value;
                    object wssValue = wssItem.Fields[wssName];

                    Assert.IsTrue(Compare(tfsValue, wssValue), "Different field values!");
                }
            }

            // Compare attachments
            using (LocalAttachments tfsFiles = LoadAttachments(tfsItem))
            using (LocalAttachments wssFiles = LoadAttachments(wssItem))
            {
                Assert.IsTrue(tfsFiles.Equals(wssFiles), "Different attachments!");
            }
        }

        /// <summary>
        /// Compares two field values.
        /// </summary>
        /// <param name="o1">Value 1</param>
        /// <param name="o2">Value 2</param>
        private static bool Compare(object o1, object o2)
        {
            bool isEmpty1 = o1 == null || o1 is string && ((string)o1).Length == 0;
            bool isEmpty2 = o2 == null || o2 is string && ((string)o2).Length == 0;

            if (isEmpty1 ^ isEmpty2) return false;
            if (isEmpty1 && isEmpty2) return true;

            if (o1 is DateTime)
            {
                // Compare with 1 second precision
                DateTime d1 = (DateTime)o1;
                DateTime d2 = (DateTime)o2;

                TimeSpan s = d2 - d1;
                return s.Seconds == 0;
            }

            return object.Equals(o1, o2);
        }

        /// <summary>
        /// Synchronizes given items and returns their reflections from the opposite side.
        /// </summary>
        /// <param name="type">System original items belong to</param>
        /// <param name="items">Items to synchronize</param>
        /// <returns>Reflections of original items</returns>
        private object[] Synchronize(SystemType type, params object[] items)
        {
            string[] ids = new string[items.Length];

            if (type == SystemType.Tfs)
            {
                for (int i = 0; i < items.Length; i++)
                {
                    ids[i] = ((WorkItem)items[i]).Id.ToString(CultureInfo.InvariantCulture);
                }
            }
            else
            {
                for (int i = 0; i < items.Length; i++)
                {
                    ids[i] = ((WssTask)items[i]).StringId;
                }
            }

            Session.Synchronize(type, ids);

            // Now load reflections
            for (int i = 0; i < ids.Length; i++)
            {
                ids[i] = m_idMapping[ids[i]];
            }
            m_idMapping.Clear();
            if (type == SystemType.Tfs)
            {
                return GetWssItems(ids);
            }
            else
            {
                return GetTfsItems(ids);
            }
        }

        private object[] GetTfsItems(string[] ids)
        {
            object[] results = new object[ids.Length];
            StringBuilder query = new StringBuilder("SELECT [System.Id] FROM WorkItems WHERE ");
            Dictionary<string, int> itemMap = new Dictionary<string, int>(StringComparer.InvariantCulture);

            for (int i = 0; i < ids.Length; i++)
            {
                itemMap[ids[i]] = i;
                if (i > 0)
                {
                    query.Append(" OR ");
                }
                query.AppendFormat("[System.ID] = {0}", ids[i]);
            }

            WorkItemCollection items = TfsProject.Store.Query(query.ToString());

            foreach (WorkItem item in items)
            {
                results[itemMap[item.Id.ToString()]] = item;
            }
            return results;
        }

        private object[] GetWssItems(string[] ids)
        {
            object[] results = new object[ids.Length];

            for (int i = 0; i < ids.Length; i++)
            {
                results[i] = WssHelper.GetTask(ids[i]);
            }
            return results;
        }

        private void SetFieldValue(object src, string fieldName, object value)
        {
            if (src is WorkItem)
            {
                ((WorkItem)src).Fields[fieldName].Value = value;
            }
            else
            {
                fieldName = TranslateTfsFieldName(fieldName);
                ((WssTask)src).Fields[fieldName] = value;
            }
        }

        private void SaveItem(object item)
        {
            if (item is WorkItem)
            {
                ((WorkItem)item).Save();
            }
            else
            {
                WssHelper.SaveTasks((WssTask)item);
            }
        }

        private object GetFieldValue(object item, string fieldName)
        {
            if (item is WorkItem)
            {
                return ((WorkItem)item).Fields[fieldName].Value;
            }
            else
            {
                fieldName = TranslateTfsFieldName(fieldName);
                return ((WssTask)item).Fields[fieldName];
            }
        }

        private object CreateWorkItem(SystemType type, int attachCount)
        {
            object item = CreateCompleteWorkItem(type);
            AddAttachments(item, attachCount);
            return item;
        }

        /// <summary>
        /// Loads attachments from the given item.
        /// </summary>
        /// <param name="item">Source work item</param>
        /// <returns>Collection of attachments</returns>
        private LocalAttachments LoadAttachments(object item)
        {
            LocalAttachments files = new LocalAttachments();
            string tempDir = Path.GetTempPath();
            if (item is WorkItem)
            {
                WorkItem wi = (WorkItem)item;

                for (int i = 0; i < wi.Attachments.Count; i++)
                {
                    TfsMigrationFileAttachment a = new TfsMigrationFileAttachment(wi.Attachments[i], tempDir);
                    using (Stream stream = a.GetFileContents())
                    {
                        LocalAttachment file = new LocalAttachment(wi.Attachments[i].Name, stream);
                        files.Add(file);
                    }
                }
            }
            else
            {
                WssTask task = (WssTask)item;
                AttachmentsAttachment[] wssFiles = task.GetAttachments();

                for (int i = 0; i < wssFiles.Length; i++)
                {
                    WssMigrationFileAttachment wssFile = new WssMigrationFileAttachment(
                        task,
                        wssFiles[i].Value,
                        Path.GetTempPath());
                    using (Stream stream = wssFile.GetFileContents())
                    {
                        LocalAttachment file = new LocalAttachment(wssFile.Name, stream);
                        files.Add(file);
                    }
                }
            }
            return files;
        }

        private void AddAttachments(object src, int count)
        {
            using (LocalAttachments files = new LocalAttachments(count))
            {
                if (src is WorkItem)
                {
                    WorkItem item = (WorkItem)src;

                    for (int i = 0; i < files.Count; i++)
                    {
                        Attachment a = new Attachment(files[i].LocalFile, string.Empty);
                        item.Attachments.Add(a);
                    }
                    item.Save();
                }
                else
                {
                    WssTask task = (WssTask)src;
                    WssHelper.SaveTasks(task);
                    for (int i = 0; i < files.Count; i++)
                    {
                        WssHelper.AttachFile(task.StringId, files[i].Name, files[i].GetContent());
                    }
                    WssHelper.SaveTasks(task);
                }
            }
        }

        private void RemoveAttachment(object src)
        {
            if (src is WorkItem)
            {
                WorkItem item = (WorkItem)src;
                item.Attachments.RemoveAt(0);
                item.Save();
            }
            else
            {
                WssTask task = (WssTask)src;
                string url = task.GetAttachments()[0].Value;
                WssHelper.RemoveFiles(task.StringId, url);
            }
        }

        private void CompareWssTasks(WssTask t1, WssTask t2)
        {
            Assert.IsTrue(t1.Fields.Count == t2.Fields.Count, "Different number of fields!");

            foreach (KeyValuePair<string, object> pair in t1.Fields)
            {
                Compare(pair.Value, t2.Fields[pair.Key]);
            }
        }

        #endregion

        #region Implementation

        private void MigrateItemTest(SystemType type)
        {
            object src = CreateCompleteWorkItem(type);

            SaveItem(src);
            object dst = Synchronize(type, src)[0];

            CompareItems(src, dst);
        }

        private void MigrateEmptyFieldTest(SystemType type, string fieldName, object initialValue)
        {
            object src = CreateCompleteWorkItem(type);
            SetFieldValue(src, fieldName, initialValue);
            SaveItem(src);

            object dst = Synchronize(type, src)[0];
            Session.Policies.FieldConflict.MasterSystem = type;
            Session.Policies.FieldConflict.Reaction = WitConflictReaction.Master;

            SetFieldValue(src, fieldName, null);
            SaveItem(src);
            dst = Synchronize(type, src)[0];

            object newVal = GetFieldValue(dst, fieldName);
            Assert.IsTrue(Compare(newVal, null), "The new value is not null!");
            CompareItems(src, dst);
        }

        private void MigrateItemWithAttachmentsTest(SystemType type)
        {
            object src = CreateWorkItem(type, 3);
            object dst = Synchronize(type, src)[0];

            using (LocalAttachments srcFiles = LoadAttachments(src))
            {
                Assert.IsTrue(srcFiles.Count == 3, "Wrong number of attachments!");
                using (LocalAttachments dstFiles = LoadAttachments(dst))
                {
                    Assert.IsTrue(srcFiles.Equals(dstFiles), "Attachments are not identical!");
                }
            }
        }

        private void MigrateNewAttachmentTest(SystemType type)
        {
            object src = CreateWorkItem(type, 2);
            object dst = Synchronize(type, src)[0];

            AddAttachments(src, 1);
            Session.Policies.AttachmentsConflict.MasterSystem = type;
            Session.Policies.AttachmentsConflict.Reaction = WitConflictReaction.Master;
            dst = Synchronize(type, src)[0];

            using (LocalAttachments srcFiles = LoadAttachments(src))
            using (LocalAttachments dstFiles = LoadAttachments(dst))
            {
                Assert.IsTrue(dstFiles.Count == 3, "Wrong number of attachments!");
                Assert.IsTrue(srcFiles.Equals(dstFiles), "Different attachments!");
            }
        }

        private void MigrateRemovedAttachmentTest(SystemType type)
        {
            object src = CreateWorkItem(type, 2);
            object dst = Synchronize(type, src)[0];

            RemoveAttachment(src);
            Session.Policies.AttachmentsConflict.MasterSystem = type;
            Session.Policies.AttachmentsConflict.Reaction = WitConflictReaction.Master;
            dst = Synchronize(type, src)[0];

            using (LocalAttachments srcFiles = LoadAttachments(src))
            using (LocalAttachments dstFiles = LoadAttachments(dst))
            {
                Assert.IsTrue(srcFiles.Count == 1, "Wrong number of attachments!");
                Assert.IsTrue(srcFiles.Equals(dstFiles), "Different attachments!");
            }
        }

        #endregion

        /// <summary>
        /// Scenario: migration of a new work item from TFS.
        /// Expected result: the item is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migration of a new item from TFS")]
        public void WssWit_MigrateItemFromTfs()
        {
            MigrateItemTest(SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: migration of a new work item from WSS.
        /// Expected result: the item is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migration of a new work item from WSS")]
        public void WssWit_MigrateItemFromWss()
        {
            MigrateItemTest(SystemType.Other);
        }

        /// <summary>
        /// Scenario: moving an empty time field from TFS.
        /// Expected result: the field becomes empty on the opposite side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Moving an empty time field from TFS")]
        public void WssWit_MoveEmptyTimeFromTfs()
        {
            MigrateEmptyFieldTest(SystemType.Tfs, "Wss.DueDate", DateTime.Now.AddDays(-2));
        }

        /// <summary>
        /// Scenario: moving an empty time field from WSS.
        /// Expected result: the field becomes empty on the opposite side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Moving an empty time field from WSS")]
        public void WssWit_MoveEmptyTimeFromWss()
        {
            MigrateEmptyFieldTest(SystemType.Other, "Wss.DueDate", DateTime.Now.AddDays(-2));
        }

        /// <summary>
        /// Scenario: moving an empty percent field from TFS
        /// Expected result: the field becomes empty on the opposite side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Moving an empty percent field from TFS")]
        public void WssWit_MoveEmptyPercentFromTfs()
        {
            MigrateEmptyFieldTest(SystemType.Tfs, "Wss.PercentComplete", 35);
        }

        /// <summary>
        /// Scenario: moving an empty percent field from WSS
        /// Expected result: the field becomes empty on the opposite side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Moving an empty percent field from WSS")]
        public void WssWit_MoveEmptyPercentFromWss()
        {
            MigrateEmptyFieldTest(SystemType.Other, "Wss.PercentComplete", 35);
        }

        /// <summary>
        /// Scenario: moving an empty description field from TFS.
        /// Expected result: the field becomes empty on the opposite side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Moving an empty description field from TFS")]
        public void WssWit_MoveEmptyDescriptionFromTfs()
        {
            MigrateEmptyFieldTest(SystemType.Tfs, "System.Description", Guid.NewGuid().ToString());
        }

        /// <summary>
        /// Scenario: moving an empty description field from WSS.
        /// Expected result: the field becomes empty on the opposite side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Moving an empty description field from WSS")]
        public void WssWit_MoveEmptyDescriptionFromWss()
        {
            MigrateEmptyFieldTest(SystemType.Other, "System.Description", Guid.NewGuid().ToString());
        }

        /// <summary>
        /// Scenario: migrating an item with attachments from TFS.
        /// Expected result: all attachments are migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating an item with attachments from TFS")]
        public void WssWit_MigrateItemWithAttachmentsFromTfs()
        {
            MigrateItemWithAttachmentsTest(SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: migrating an item with attachments from WSS.
        /// Expected result: all attachments are migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating an item with attachments from WSS")]
        public void WssWit_MigrateItemWithAttachmentsFromWss()
        {
            MigrateItemWithAttachmentsTest(SystemType.Other);
        }

        /// <summary>
        /// Scenario: migrating a new attachment from TFS.
        /// Expected result: attachment is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a new attachment from TFS")]
        public void WssWit_MigrateNewAttachmentFromTfs()
        {
            MigrateNewAttachmentTest(SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: migrating a new attachment from WSS.
        /// Expected result: attachment is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a new attachment from WSS")]
        public void WssWit_MigrateNewAttachmentFromWss()
        {
            MigrateNewAttachmentTest(SystemType.Other);
        }

        /// <summary>
        /// Scenario: migrating a removed attachment from TFS.
        /// Expected result: attachment is removed from the opposite side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a removed attachment from TFS")]
        public void WssWit_MigrateDeletedAttachmentFromTfs()
        {
            MigrateRemovedAttachmentTest(SystemType.Tfs);
        }

        /// <summary>
        /// Scenario: migrating a removed attachment from WSS.
        /// Expected result: attachment is removed from the opposite side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a removed attachment from WSS")]
        public void WssWit_MigrateDeletedAttachmentFromWss()
        {
            MigrateRemovedAttachmentTest(SystemType.Other);
        }

        /// <summary>
        /// Scenario: creating multiple work items on WSS side in a single batch.
        /// Expected results: all items are created.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Tests creating several WSS items in a single batch")]
        public void WssWit_BulkInsert()
        {
            WorkItem[] src = new WorkItem[100];

            for (int i = 0; i < src.Length; i++)
            {
                src[i] = (WorkItem)CreateWorkItem(SystemType.Tfs, i % 3);
            }

            object[] dst = Synchronize(SystemType.Tfs, src);

            Assert.IsTrue(src.Length == dst.Length, "Wrong number of items!");
            for (int i = 0; i < src.Length; i++)
            {
                CompareItems(src[i], dst[i]);
            }
        }

        /// <summary>
        /// Scenario: getting new items from the WSS store.
        /// Expected results: only new items returned.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Getting updated items from WSS store")]
        public void WssWit_Watermark()
        {
            IMigrationWorkItemStore store = Session.OtherMigrationSource.CreateWorkItemStore();
            string hwm = null;

            // Get all items and initialize high watermark.
            store.GetItems(ref hwm);

            // Getting one more time should return no items
            List<IMigrationWorkItem> items = new List<IMigrationWorkItem>(
                store.GetItems(ref hwm));
            Assert.IsTrue(items.Count == 0, "Wrong number of items returned!");

            // Create 2 new tasks
            for (int i = 0; i < 2; i++)
            {
                WssTask task = (WssTask)CreateCompleteWorkItem(SystemType.Other);
                WssHelper.SaveTasks(task);
            }

            // Obtain new tasks
            items = new List<IMigrationWorkItem>(store.GetItems(ref hwm));
            Assert.IsTrue(items.Count == 2, "Wrong number of items returned!");

            // Obtain all tasks
            hwm = null;
            items = new List<IMigrationWorkItem>(store.GetItems(ref hwm));
            Assert.IsTrue(items.Count >= 2, "Wrong number of items returned!");
        }

        /// <summary>
        /// Description: creating a WSS task.
        /// Expected result: task must be created.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Creating a WSS task")]
        public void WssWit_CreateTask()
        {
            WssTask t1 = new WssTask(WssHelper);
            t1.Fields["Title"] = string.Format("WSS Task: {0}", Guid.NewGuid().ToString());
            t1.Save();

            WssTask t2 = WssHelper.GetTask(t1.StringId);
            CompareWssTasks(t1, t2);
        }

        /// <summary>
        /// Scenario: getting all tasks in the database.
        /// Expected results: non-zero number returned.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Getting all tasks in the database")]
        public void WssWit_GetAllTasks()
        {
            // Create 5 tasks to make sure the we have items to query
            WssTask[] tasks = new WssTask[5];
            for (int i = 0; i < tasks.Length; i++)
            {
                tasks[i] = new WssTask(WssHelper);
                tasks[i].Fields["Title"] = Guid.NewGuid().ToString();
            }

            WssHelper.SaveTasks(tasks);

            // Now get all items from the work item store
            IMigrationWorkItemStore store = Session.OtherMigrationSource.CreateWorkItemStore();
            string hwm = null;

            // Get all items and initialize high watermark.
            List<IMigrationWorkItem> items = new List<IMigrationWorkItem>(
                store.GetItems(ref hwm));

            Assert.IsTrue(items.Count >= tasks.Length, "Wrong number of items!");
        }
    }
}
