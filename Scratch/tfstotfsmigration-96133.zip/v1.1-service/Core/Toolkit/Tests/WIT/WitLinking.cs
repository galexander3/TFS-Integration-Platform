using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Linking;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Tests.WIT
{
    /// <summary>
    /// Unit tests for links synchronization during the normal synchronization process.
    /// </summary>
    [TestClass]
    public class WitLinking : WitTestBase
    {
        #region Internals

        private CollectionEventArgs m_failureArgs;

        /// <summary>
        /// Constructor
        /// </summary>
        public WitLinking()
            : base("Links")
        {
        }

        /// <summary>
        /// Deletes all deferred links before execution.
        /// </summary>
        protected override void OnTestInitialize()
        {
            base.OnTestInitialize();

            using (MigrationSqlTransaction trn = (MigrationSqlTransaction)DataAccessManager.Current.StartTransaction())
            {
                using (SqlCommand cmd = trn.CreateCommand())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "DELETE FROM DeferredLinks";

                    cmd.ExecuteNonQuery();
                }
                trn.Complete();
            }
        }

        /// <summary>
        /// Event handler for linking conflicts.
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="args">Arguments</param>
        private void OnLinksConflict(
            object sender,
            CollectionEventArgs args)
        {
            Assert.IsTrue(args != null, "Null arguments!");
            m_failureArgs = args;
        }

        /// <summary>
        /// Adds a hyperlink to the given work item.
        /// </summary>
        /// <param name="item">Work item</param>
        /// <param name="url">Hyperlink's URL</param>
        /// <param name="comment">Hyperlink's comment</param>
        private void AddHyperlink(
            WorkItem item,
            string url,
            string comment)
        {
            Hyperlink hl = new Hyperlink(url);
            if (!string.IsNullOrEmpty(comment))
            {
                hl.Comment = comment;
            }
            item.Links.Add(hl);
        }

        #endregion

        #region Test implementations

        /// <summary>
        /// Tests updating link's comment after links were synchronized.
        /// </summary>
        /// <param name="side"></param>
        private void CommentUpdate(
            Side side)
        {
            WorkItem src = CreateWorkItem(side, 1);
            string link = string.Format(CultureInfo.InvariantCulture, "http://www.microsoft.com/{0}", Guid.NewGuid().ToString());
            src.Links.Add(new Hyperlink(link));
            src.Save();

            WorkItem dst = Synchronize(side, src)[0];
            src.Links[0].Comment = "Foo";
            src.Save();
            dst.Links[0].Comment = "Bar";
            dst.Save();

            int sRev = src.Rev;
            int dRev = dst.Rev;

            dst = Synchronize(side, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(sRev == src.Rev, "Source item was updated!");
            Assert.IsTrue(dRev == dst.Rev, "Target item was updated!");
        }

        /// <summary>
        /// Tests migration of external links.
        /// </summary>
        /// <param name="side">Source side</param>
        private void MigrateExternal(
            Side side)
        {
            WorkItem src = CreateWorkItem(side, 1);
            RegisteredLinkType rlt = Store.RegisteredLinkTypes["Test Result"];

            for (int i = 0; i < 20; i++)
            {
                ExternalLink l = new ExternalLink(rlt, Guid.NewGuid().ToString());
                src.Links.Add(l);
            }
            src.Save();

            WorkItem dst = Synchronize(side, src)[0];
            src.SyncToLatest();
            CompareLinks(src.Links, dst.Links);

            int srcRev = src.Rev;
            int dstRev = dst.Rev;

            dst = Synchronize(side, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Rev == srcRev, "Source work item was updated!");
            Assert.IsTrue(dst.Rev == dstRev, "Target work item was updated!");
        }

        /// <summary>
        /// Migrates a work item with deferred link; link's target exists.
        /// </summary>
        /// <param name="side">Source side</param>
        private void MigrateWithDeferredExistingTarget(
            Side side)
        {
            SystemType st = side == Side.Left ? SystemType.Tfs : SystemType.Other;
            WorkItem lSrc = CreateWorkItem(Side.Left, 1);
            WorkItem lDst = CreateWorkItem(Side.Left, 1);

            WorkItem rDst = Synchronize(side, lDst)[0];

            lSrc.Links.Add(new RelatedLink(lDst.Id));
            lSrc.Save();

            WorkItemRelatedLink link = new WorkItemRelatedLink(lSrc.Uri.ToString(), lDst.Uri.ToString(), null);
            Session.LinkEngine.Defer(st, link);

            WorkItem rSrc = Synchronize(side, lSrc)[0];
            Assert.IsTrue(rSrc.Links.Count == 1, "Deferred link was not migrated!");

            // One more time (to delete deferred link)
            rSrc = Synchronize(side, lSrc)[0];
            ReadOnlyCollection<ILink> links = Session.LinkEngine.GetDeferredLinks(st, lSrc.Uri.ToString());
            Assert.IsTrue(links.Count == 0, "Deferred link was not removed!");
        }

        /// <summary>
        /// Migrates a work item with pending deferred link
        /// </summary>
        /// <param name="side">Source side</param>
        private void MigrateWithDeferredMissingTarget(
            Side side)
        {
            SystemType st = side == Side.Left ? SystemType.Tfs : SystemType.Other;
            WorkItem lSrc = CreateWorkItem(side, 1);
            WorkItem lDst = CreateWorkItem(side, 1);

            WorkItemRelatedLink link = new WorkItemRelatedLink(lSrc.Uri.ToString(), lDst.Uri.ToString(), null);
            Session.LinkEngine.Defer(st, link);

            WorkItem rSrc = Synchronize(side, lSrc)[0];

            Assert.IsTrue(rSrc.Links.Count == 0, "A link was migrated!");
            ReadOnlyCollection<ILink> links = Session.LinkEngine.GetDeferredLinks(st, lSrc.Uri.ToString());
            Assert.IsTrue(links.Count == 0, "Deferred link was not removed!");
        }

        /// <summary>
        /// Tests deletion of a deferred link which already exists on the target.
        /// </summary>
        /// <param name="side">Source side</param>
        private void DeferredAlreadyOnTarget(
            Side side)
        {
            SystemType st = side == Side.Left? SystemType.Tfs : SystemType.Other;
            WorkItem lSrc = CreateWorkItem(side, 1);
            WorkItem lDst = CreateWorkItem(side, 1);
            lSrc.Links.Add(new RelatedLink(lDst.Id));
            lSrc.Save();

            WorkItem[] rItems = Synchronize(side, lSrc, lDst);
            WorkItem rSrc = rItems[0];
            WorkItem rDst = rItems[1];

            Assert.IsTrue(rSrc.Links.Count == 0, "The link was not deferred!");
            rSrc.Links.Add(new RelatedLink(rDst.Id));
            rSrc.Save();

            lSrc.SyncToLatest();
            int lRev = lSrc.Rev;
            int rRev = rSrc.Rev;

            rSrc = Synchronize(side, lSrc)[0];
            lSrc.SyncToLatest();

            Assert.IsTrue(lRev == lSrc.Rev, "Source revision was changed!");
            Assert.IsTrue(rRev == rSrc.Rev, "Target revision was changed!");

            Assert.IsTrue(lSrc.Links.Count == 1, "Wrong number of revisions on the source!");
            Assert.IsTrue(rSrc.Links.Count == 1, "Wrong number of revisions on the target!");

            ReadOnlyCollection<ILink> links = Session.LinkEngine.GetDeferredLinks(st, lSrc.Uri.ToString());
            Assert.IsTrue(links.Count == 0, "Deferred link was not removed!");
        }

        /// <summary>
        /// Tests deletion of a deferred link which no longer exists on the source.
        /// </summary>
        /// <param name="side">Source side</param>
        private void DeferredNotExist(
            Side side)
        {
            SystemType st = side == Side.Left ? SystemType.Tfs : SystemType.Other;
            WorkItem oldSrc = CreateWorkItem(side, 1);
            WorkItem oldDst = CreateWorkItem(side, 1);
            oldSrc.Links.Add(new RelatedLink(oldDst.Id));
            oldSrc.Save();

            Synchronize(side, oldSrc, oldDst);
            ReadOnlyCollection<ILink> links = Session.LinkEngine.GetDeferredLinks(st, oldSrc.Uri.ToString());
            Assert.IsTrue(links.Count == 1, "The link was not deferred!");

            oldSrc.Links.Clear();
            oldSrc.Save();

            WorkItem newSrc = Synchronize(side, oldSrc)[0];
            oldSrc.SyncToLatest();

            Assert.IsTrue(newSrc.Links.Count == 0, "Wrong number of links on the target side!");
            Assert.IsTrue(oldSrc.Links.Count == 0, "Wrong number of links on the source side!");

            links = Session.LinkEngine.GetDeferredLinks(st, oldSrc.Uri.ToString());
            Assert.IsTrue(links.Count == 0, "Deferred link was not removed!");
        }

        /// <summary>
        /// Tests deferring a related link.
        /// </summary>
        /// <param name="side">Source side</param>
        private void DeferRelated(
            Side side)
        {
            SystemType st = side == Side.Left? SystemType.Tfs : SystemType.Other;
            WorkItem oldSrc = CreateWorkItem(side, 1);
            WorkItem oldDst = CreateWorkItem(side, 1);

            oldSrc.Links.Add(new RelatedLink(oldDst.Id));
            oldSrc.Save();

            WorkItem newSrc = Synchronize(side, oldSrc)[0];
            oldSrc.SyncToLatest();

            Assert.IsTrue(newSrc.Links.Count == 0, "Target item has links!");
            Assert.IsTrue(oldSrc.Links.Count == 1, "Source item doesn't have links!");

            ReadOnlyCollection<ILink> links = Session.LinkEngine.GetDeferredLinks(st, oldSrc.Uri.ToString());
            Assert.IsTrue(links.Count == 1, "Link was not deferred!");

            newSrc = Synchronize(side, oldSrc)[0];
            oldSrc.SyncToLatest();

            Assert.IsTrue(oldSrc.Links.Count == 1, "Wrong number of links on the source side!");
            Assert.IsTrue(newSrc.Links.Count == 0, "Deferred link was not migrated!");
        }

        /// <summary>
        /// Tests migration of a related link.
        /// </summary>
        /// <param name="side">Source side</param>
        private void MigrateRelated(
            Side side)
        {
            WorkItem oldDst = CreateWorkItem(side, 1);
            WorkItem newDst = Synchronize(side, oldDst)[0];

            WorkItem oldSrc = CreateWorkItem(side, 1);
            oldSrc.Links.Add(new RelatedLink(oldDst.Id));
            oldSrc.Save();

            WorkItem newSrc = Synchronize(side, oldSrc)[0];
            Assert.IsTrue(newSrc.Links.Count == 1, "Wrong number of links on the target side!");
            RelatedLink l = (RelatedLink)newSrc.Links[0];
            Assert.IsTrue(l.RelatedWorkItemId == newDst.Id, "Invalid target!");
        }

        /// <summary>
        /// Tests hyperlink migration.
        /// </summary>
        /// <param name="side">Source side</param>
        private void MigrateHyperlink(
            Side side)
        {
            WorkItem src = CreateWorkItem(side, 1);

            AddHyperlink(src, "http://www.microsoft.com", "Foo");
            AddHyperlink(src, "http://www.msn.com", null);
            AddHyperlink(src, "ftp://download.microsoft.com", "FTP link");

            src.Save();

            WorkItem dst = Synchronize(side, src)[0];
            src.SyncToLatest();

            Assert.IsTrue(src.Links.Count == 3, "Wrong number of links on the source!");
            CompareLinks(src.Links, dst.Links);
        }

        #endregion

        /// <summary>
        /// Scenario: migrating a hyperlink from master to slave.
        /// Expected result: hyperlink is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a hyperlink from master to slave")]
        public void Linking_WIT_MigrateHyperlinkMaster()
        {
            MigrateHyperlink(Side.Left);
        }

        /// <summary>
        /// Scenario: migrating a hyperlink from slave to master.
        /// Expected result: hyperlink is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a hyperlink from slave to master")]
        public void Linking_WIT_MigrateHyperlinkSlave()
        {
            MigrateHyperlink(Side.Left);
        }

        /// <summary>
        /// Scenario: migrating a related link from master.
        /// Expected result: link is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a related link from master to slave")]
        public void Linking_WIT_MigrateRelatedLinkMaster()
        {
            MigrateRelated(Side.Left);
        }

        /// <summary>
        /// Scenario: migrating a related link from slave.
        /// Expected result: link is migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a related link from slave to master")]
        public void Linking_WIT_MigrateRelatedLinkSlave()
        {
            MigrateRelated(Side.Right);
        }

        /// <summary>
        /// Scenario: new link on the master side.
        /// Expected result: link is copied to the other side.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("New link on the master side")]
        public void Linking_WIT_NewLinkMaster()
        {
            WorkItem src = CreateWorkItem(Side.Left, 1);
            AddHyperlink(src, "http://www.microsoft.com", "Microsoft");
            AddHyperlink(src, "http://www.msn.com", "MSN");
            src.Save();

            WorkItem dst = Synchronize(Side.Left, src)[0];

            AddHyperlink(src, "http://www.google.com", null);
            src.Save();
            dst = Synchronize(Side.Left, src)[0];

            Assert.IsTrue(dst.Links.Count == 3, "Wrong number of links on the slave side!");
            CompareLinks(src.Links, dst.Links);
        }

        /// <summary>
        /// Scenario: new link on the slave side.
        /// Expected result: link removed from the slave.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("New link on the slave side")]
        public void Linking_WIT_NewLinkSlave()
        {
            Session.Policies.LinksConflict.Reaction = WitConflictReaction.Master;
            WorkItem lSrc = CreateWorkItem(Side.Left, 1);
            WorkItem lDst = CreateWorkItem(Side.Left, 1);

            AddHyperlink(lSrc, "http://www.microsoft.com", "Microsoft");
            AddHyperlink(lSrc, "http://www.google.com", null);
            lSrc.Save();

            WorkItem[] newItems = Synchronize(Side.Left, lSrc, lDst);
            WorkItem rSrc = newItems[0];
            WorkItem rDst = newItems[1];

            rSrc.Links.Add(new RelatedLink(rDst.Id));
            rSrc.Save();

            lSrc = Synchronize(Side.Right, rSrc)[0];
            rSrc.SyncToLatest();

            Assert.IsTrue(lSrc.Links.Count == 2, "Wrong number of links on the master side");
            CompareLinks(lSrc.Links, rSrc.Links);
        }

        /// <summary>
        /// Scenario: deferring related link from the master side.
        /// Expected result: link gets deferred.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Deferring related link from master side")]
        public void Linking_WIT_DeferRelatedMaster()
        {
            DeferRelated(Side.Left);
        }

        /// <summary>
        /// Scenario: deferring related link from the slave side.
        /// Expected result: link gets deferred.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Deferring related link from slave side")]
        public void Linking_WIT_DeferRelatedSlave()
        {
            DeferRelated(Side.Right);
        }

        /// <summary>
        /// Scenario: obsolete deferred link on the master side.
        /// Expected result: link is deleted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Removing deferred link which no longer exists on the master")]
        public void Linking_WIT_DeferredNotExistMaster()
        {
            DeferredNotExist(Side.Left);
        }

        /// <summary>
        /// Scenario: obsolete deferred link on the slave side.
        /// Expected result: link is deleted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Removing deferred link which no longer exists on the slave")]
        public void Linking_WIT_DeferredNotExistSlave()
        {
            DeferredNotExist(Side.Right);
        }

        /// <summary>
        /// Scenario: obsolete deferred link on the master side.
        /// Expected result: link is deleted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Removing deferred link from the master because it already exists there")]
        public void Linking_WIT_DeferredAlreadyOnTargetMaster()
        {
            DeferredAlreadyOnTarget(Side.Left);
        }

        /// <summary>
        /// Scenario: obsolete deferred link on the slave side.
        /// Expected result: link is deleted.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Removing deferred link from the slave because it already exists there")]
        public void Linking_WIT_DeferredAlreadyOnTargetSlave()
        {
            DeferredAlreadyOnTarget(Side.Right);
        }

        /// <summary>
        /// Scenario: merging links of different types.
        /// Expected result: links are merged.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Merging links of different types")]
        public void Linking_WIT_MergeLinks()
        {
            Session.Policies.LinksConflict.Reaction = WitConflictReaction.Union;

            WorkItem lSrc = CreateWorkItem(Side.Left, 1);
            WorkItem lDst = CreateWorkItem(Side.Left, 1);

            WorkItem rSrc = Synchronize(Side.Left, lSrc, lDst)[0];

            lSrc.Links.Add(new RelatedLink(lDst.Id));
            lSrc.Save();

            AddHyperlink(rSrc, "http://www.microsoft.com", "Microsoft");
            AddHyperlink(rSrc, "http://www.google.com", null);
            rSrc.Save();

            rSrc = Synchronize(Side.Left, lSrc)[0];
            lSrc.SyncToLatest();

            Assert.IsTrue(lSrc.Links.Count == 3, "Wrong number of links on the source!");
            Assert.IsTrue(rSrc.Links.Count == 3, "Wrong number of links on the target!");
        }

        /// <summary>
        /// Scenario: no changes in links on both sides.
        /// Expected result: no new revisions.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("No changes on both sides")]
        public void Linking_WIT_NoLinkChanges()
        {
            WorkItem lSrc = CreateWorkItem(Side.Left, 1);
            AddHyperlink(lSrc, "http://www.microsoft.com", "Microsoft");
            AddHyperlink(lSrc, "http://www.msn.com", null);
            lSrc.Save();

            WorkItem rSrc = Synchronize(Side.Left, lSrc)[0];

            rSrc = Synchronize(Side.Left, lSrc)[0];
            lSrc.SyncToLatest();

            Assert.IsTrue(lSrc.Rev == 2, "Extra revisions on the source side!");
            Assert.IsTrue(rSrc.Rev == 1, "Extra revisions on the target side!");

            lSrc = Synchronize(Side.Right, rSrc)[0];
            rSrc.SyncToLatest();

            Assert.IsTrue(lSrc.Rev == 2, "Extra revisions on the source side!");
            Assert.IsTrue(rSrc.Rev == 1, "Extra revisions on the target side!");
        }

        /// <summary>
        /// Scenario: migrating a work item with a pending deferred link on master.
        /// Expected result: work item migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a work item with a deferred link on master; link's target does not exist")]
        public void Linking_WIT_MigrateWithDeferredMaster()
        {
            MigrateWithDeferredMissingTarget(Side.Left);
        }

        /// <summary>
        /// Scenario: migrating a work item with a pending deferred link on slave.
        /// Expected result: work item migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a work item with a deferred link on slave; link's target does not exist")]
        public void Linking_WIT_MigrateWithDeferredSlave()
        {
            MigrateWithDeferredMissingTarget(Side.Right);
        }

        /// <summary>
        /// Scenario: migrating a work item with a pending deferred link on master; link's target exists
        /// Expected result: work item migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a work item with a deferred link on master; link's target exists")]
        public void Linking_WIT_MigrateWithDeferredExistingTargetMaster()
        {
            MigrateWithDeferredExistingTarget(Side.Left);
        }

        /// <summary>
        /// Scenario: migrating a work item with a pending deferred link on slave; link's target exists
        /// Expected result: work item migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Migrating a work item with a deferred link on slave; link's target exists")]
        public void Linking_WIT_MigrateWithDeferredExistingTargetSlave()
        {
            MigrateWithDeferredExistingTarget(Side.Right);
        }

        /// <summary>
        /// Scenario: migrating external links from master to slave.
        /// Expected results: all links migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("External links migration from master to slave")]
        public void Linking_WIT_MigrateExternalMaster()
        {
            MigrateExternal(Side.Left);
        }

        /// <summary>
        /// Scenario: migrating external links from slave to master.
        /// Expected results: all links migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("External links migration from slave to master")]
        public void Linking_WIT_MigrateExternalSlave()
        {
            MigrateExternal(Side.Right);
        }

        /// <summary>
        /// Scenario: links are out of sync; polict is set to 'throw'.
        /// Expected result: work item is not migrated.
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Links out of sync with reaction set to 'throw'")]
        public void Linking_WIT_ThrowOnConflict()
        {
            Session.Policies.LinksConflict.Reaction = WitConflictReaction.Throw;
            WorkItem l = CreateWorkItem(Side.Left, 1);
            WorkItem r = Synchronize(Side.Left, l)[0];

            l.Links.Add(new Hyperlink("http://www.microsoft.com"));
            l.Title = Guid.NewGuid().ToString();
            l.Save();

            Session.WorkItemLinksOutOfSync += new EventHandler<CollectionEventArgs>(OnLinksConflict);
            m_failureArgs = null;
            try
            {
                int lRev = l.Rev;
                int rRev = r.Rev;

                r = Synchronize(Side.Left, l)[0];

                Assert.IsTrue(lRev == l.Rev, "Left item was updated!");
                Assert.IsTrue(rRev == r.Rev, "Right item was updated!");
                Assert.IsTrue(m_failureArgs != null, "Event was not fired!");
            }
            finally
            {
                Session.WorkItemLinksOutOfSync -= new EventHandler<CollectionEventArgs>(OnLinksConflict);
            }
        }

        /// <summary>
        /// Scenario: updating link's comment on the master side after links are in sync
        /// Expected result: the change remains unnoticed. 
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Updating link's comment")]
        public void Linking_WIT_CommentUpdateMaster()
        {
            CommentUpdate(Side.Left);
        }

        /// <summary>
        /// Scenario: updating link's comment on the slave side after links are in sync
        /// Expected result: the change remains unnoticed. 
        /// </summary>
        [TestMethod, Priority(1), Owner("aliakb")]
        [Description("Updating link's comment")]
        public void Linking_WIT_CommentUpdateSlave()
        {
            CommentUpdate(Side.Right);
        }
    }
}
