// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Tests.Framework;
using Microsoft.TeamFoundation.VersionControl.Client;
using System.IO;

namespace Tests
{
    [TestClass]
    public class TFSMigrationItemTest : MigrationTestCaseBase
    {
        #region Input Attacks
        ///<summary>
        ///Scenario: Create a TfsMigrationItem with an empty serverPath; Set Server path to Empty string
        ///Expected Result: ArgumentNullException
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Set Server path to Empty string")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void EmptyServerPathTest()
        {
            try
            {
                TfsMigrationItem item = new TfsMigrationItem(MasterTfsClient, string.Empty, CreateVcWssSession);
                Assert.Fail("ExpectedException ArgumentNullException");
            }
            catch (ArgumentNullException) { }
            TfsMigrationItem item2 = new TfsMigrationItem(MasterTfsClient, "$/path", CreateVcWssSession);
            item2.ServerPath = string.Empty;
        }

        ///<summary>
        ///Scenario: Create a TfsMigrationItem with null serverPath; Set Server path to null
        ///Expected Result: ArgumentNullException
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Set Server path to null")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullServerPathTest()
        {
            try
            {
                TfsMigrationItem item = new TfsMigrationItem(MasterTfsClient, null, CreateVcWssSession);
                Assert.Fail("ExpectedException ArgumentNullException");
            }
            catch (ArgumentNullException) { }
            TfsMigrationItem item2 = new TfsMigrationItem(MasterTfsClient, "$/path", CreateVcWssSession);
            item2.ServerPath = null;
        }

        ///<summary>
        ///Scenario: Create TFSMigrationItem with null server
        ///Expected Result: Server can be added later
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Create TFSMigrationItem with null server")]
        public void NullServerTest()
        {
            TfsMigrationItem item = new TfsMigrationItem(null, "path", CreateVcWssSession);
            item.TfsServerUrl = MasterTfsServer.Name;
            Assert.IsNotNull(item.Server);
        }

        ///<summary>
        ///Scenario: Create TFSMigrationItem with negative changesetId; Set changeSetId to a negative number
        ///Expected Result: ArgumentOutOfRangeException 
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("Set changeSetId to a negative number")]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void NegativeChangeSetIDTest()
        {
            try
            {
                TfsMigrationItem item = new TfsMigrationItem(MasterTfsClient, "path", CreateVcWssSession, -10);
                Assert.Fail("ExpectedException ArgumentNullException");
            }
            catch (ArgumentOutOfRangeException) { }
            TfsMigrationItem item2 = new TfsMigrationItem(MasterTfsClient, "path", CreateVcWssSession, 10);
            item2.Changeset = -20;
        }
        #endregion

        ///<summary>
        ///Scenario: A call to download generates an IOException
        ///Expected Result: IOException bubbles up
        ///</summary>
        [TestMethod(), Priority(2), Owner("curtisp")]
        [Description("A call to download generates an IOException")]
        [ExpectedException(typeof(IOException))]
        public void DownloadIOExceptionTest()
        {
            MigrationItemStrings file = new MigrationItemStrings("file.txt", null, TestContext.TestName, ConfigParameters);
            AddTFSFile(file.LocalPath);
            TfsMigrationItem item = new TfsMigrationItem(MasterTfsClient, file.ServerPath, CreateVcWssSession);
            using (File.Create("lockedFile"))
            {
                item.Download("lockedFile");
            }
        }

        ///<summary>
        ///Scenario: Call DisplayName on a valid item
        ///Expected Result: Returns "serverPath;CchangesetID"
        ///</summary>
        [TestMethod(), Priority(1), Owner("curtisp")]
        [Description("Call getDisplayName on a valid item")]
        public void DisplayNameTest()
        {
            string path = "$/path";
            string format = "{0}{1}C{2}";
            int changesetId = 1337;

            TfsMigrationItem item = new TfsMigrationItem(MasterTfsClient, path, CreateVcWssSession, changesetId);

            Assert.AreEqual(string.Format(format, path, VersionSpec.Separator, changesetId), item.DisplayName);
        }

        ///<summary>
        ///Scenario: Call ToString on a valid item
        ///Expected Result: Returns same as DisplayName
        ///</summary>
        [TestMethod(), Priority(1), Owner("curtisp")]
        [Description("Call ToString on a valid item")]
        public void ToStringTest()
        {
            string path = "$/path";
            int changesetId = 1337;

            TfsMigrationItem item = new TfsMigrationItem(MasterTfsClient, path, CreateVcWssSession, changesetId);

            Assert.AreEqual(item.DisplayName, item.ToString());
        }

        ///<summary>
        ///Scenario: A call to download generates an exception from the server
        ///Expected Result: Server Exception bubbles up 
        ///</summary>
        [TestMethod(), Priority(1), Owner("curtisp")]
        [Description("A call to download generates an exception from the server")]
        [ExpectedException(typeof(VersionControlException))]
        public void DownloadServerExceptionTest()
        {
            MigrationItemStrings file = new MigrationItemStrings("file.txt", null, TestContext.TestName, ConfigParameters);

            TfsMigrationItem item = new TfsMigrationItem(MasterTfsClient, file.ServerPath, CreateVcWssSession);
            item.Download("file");
        }
    }
}
