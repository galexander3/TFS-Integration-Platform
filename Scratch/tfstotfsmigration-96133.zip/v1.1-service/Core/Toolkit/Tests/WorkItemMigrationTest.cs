// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tests.Framework;

namespace Tests
{
    [TestClass()]
    public class WorkItemMigrationTest : MigrationTestCaseBase
    {
        [DeploymentItem("Microsoft.TeamFoundation.Migration.Toolkit.dll")]
        [TestMethod, Description("Test single work item migration")]
        public void SingleWorkItemMigrationTest()
        {
            WorkItemTrackingSession session = MigrationConfiguration.Current.Wit.Sessions["sessionkey"];
            
        }

        [TestMethod()]
        public void WorkItemOnlyMigrationTest()
        {

        }
        [TestMethod()]
        public void EmptyTargetProjectMigrationTest()
        {

        }
    }
}
