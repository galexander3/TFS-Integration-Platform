// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tests.Framework;


namespace Tests
{
    [TestClass()]
    public class WITLinkMigrationTest : MigrationTestCaseBase
    {
    }
}
