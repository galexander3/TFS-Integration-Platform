// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.IO;
using System.Xml.Serialization;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    [XmlType("Sql")]
    public class SqlConnectionDescription
    {
        /// <summary>
        /// Gets the database name specified in the configuration settings.  If the connection string
        /// specifies a database name then this can be empty or null.
        /// </summary>
        public string Database
        {
            get
            {
                return m_initialCatalog;
            }
            set
            {
                m_initialCatalog = value;
            }
        }

        /// <summary>
        /// Gets the connection string specified in the configuration settings.
        /// </summary>
        /// 
        public string ConnectionString
        {
            get
            {
                return getConnectionString();
            }
            set
            {
                m_connectionStringFromConfig = value;
            }
        }

        /// <summary>
        /// Gets the server name specified in the configuration settings.
        /// </summary>
        public string Server
        {
            get
            {
                return m_dataSource;
            }
            set
            {
                m_dataSource = value;
            }
        }

        private void BuildConnectionStringCache()
        {
            SqlConnectionStringBuilder builder;

            if (!string.IsNullOrEmpty(m_connectionStringFromConfig))
            {
                builder = new SqlConnectionStringBuilder(m_connectionStringFromConfig);
            }
            else
            {
                builder = new SqlConnectionStringBuilder();
                builder.IntegratedSecurity = true;
            }

            if (string.IsNullOrEmpty(builder.DataSource))
            {
                if (string.IsNullOrEmpty(m_dataSource))
                {
                    throw new InitializationException(MigrationToolkitResources.SQLReportMissingServer);
                }
                else
                {
                    builder.DataSource = m_dataSource;
                }
            }
            else
            {
                m_dataSource = builder.DataSource;
            }

            if (string.IsNullOrEmpty(builder.InitialCatalog) && !string.IsNullOrEmpty(m_initialCatalog))
            {
                if (string.IsNullOrEmpty(m_dataSource))
                {
                    throw new InitializationException(MigrationToolkitResources.SQLReportMissingDatabase);
                }
                else
                {
                    builder.InitialCatalog = m_initialCatalog;
                }
            }
            else
            {
                m_initialCatalog = builder.InitialCatalog;
            }

            m_connectionStringCache = builder.ToString();
        }

        private string getConnectionString()
        {
            if (string.IsNullOrEmpty(m_connectionStringCache))
            {
                BuildConnectionStringCache();
                
                if (string.IsNullOrEmpty(m_connectionStringCache))
                {
                    throw new InitializationException(MigrationToolkitResources.SQLMissingConnectionString);
                }
            }

            return m_connectionStringCache;
        }

        internal static SqlConnectionDescription Load(string xmlString)
        {
            using (StringReader sr = new StringReader(xmlString))
            {
                XmlSerializer xs = new XmlSerializer(typeof(SqlConnectionDescription));
                SqlConnectionDescription sqlConn = (SqlConnectionDescription)xs.Deserialize(sr);
                return sqlConn;
            }
        }

        string m_connectionStringFromConfig;
        string m_initialCatalog;
        string m_dataSource;

        string m_connectionStringCache;

    }
}
