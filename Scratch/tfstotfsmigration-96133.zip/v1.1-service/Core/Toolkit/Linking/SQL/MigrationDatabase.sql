-- Copyright (c) Microsoft Corporation. All rights reserved.

/****** Object:  Table [dbo].[Artifacts]    Script Date: 05/16/2007 09:13:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Artifacts](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[IsTfs] [bit] NOT NULL,
	[Uri] [nvarchar](400) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
    [IsTfs] ASC,
	[Uri] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[DeferredLinks]    Script Date: 05/16/2007 09:14:29 ******/
CREATE TABLE [dbo].[DeferredLinks](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[SessionId] [int] NOT NULL,
	[SourceId] [int] NOT NULL,
	[TargetId] [int] NOT NULL,
	[LinkType] [nvarchar](400) NOT NULL,
	[LinkData] [nvarchar](max) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[SessionId] ASC,
	[SourceId] ASC,
	[TargetId] ASC,
	[LinkType] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[DeferredLinks]  WITH CHECK ADD FOREIGN KEY([SessionId])
REFERENCES [dbo].[Sessions]  ([Id])
GO
ALTER TABLE [dbo].[DeferredLinks]  WITH CHECK ADD FOREIGN KEY([SourceId])
REFERENCES [dbo].[Artifacts] ([Id])
GO
ALTER TABLE [dbo].[DeferredLinks]  WITH CHECK ADD FOREIGN KEY([TargetId])
REFERENCES [dbo].[Artifacts] ([Id])