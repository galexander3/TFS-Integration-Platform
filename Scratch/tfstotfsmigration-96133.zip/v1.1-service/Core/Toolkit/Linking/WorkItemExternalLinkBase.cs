// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml;

using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Linking
{
    /// <summary>
    /// Generic external link.
    /// </summary>
    public abstract class WorkItemExternalLinkBase: WorkItemLink
    {
        private string m_linkType;                          // Link type

        /// <summary>
        /// Gets/sets the link type.
        /// </summary>
        public string ExternalLinkType { get { return m_linkType; } set { m_linkType = value; } }

        /// <summary>
        /// Parameterless constructor for serialization.
        /// </summary>
        protected WorkItemExternalLinkBase()
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="linkType">Link type</param>
        /// <param name="sourceUri">Source artifact</param>
        /// <param name="targetUri">Target artifacxt</param>
        /// <param name="comment">Link's comment</param>
        protected WorkItemExternalLinkBase(
            string linkType,
            string sourceUri,
            string targetUri,
            string comment)
            : base(sourceUri, targetUri, comment)
        {
            if (string.IsNullOrEmpty(linkType))
            {
                throw new ArgumentNullException("linkType");
            }
            m_linkType = linkType;
        }

        /// <summary>
        /// Submits changes to the TFS update package.
        /// </summary>
        /// <param name="action">Action on the link</param>
        /// <param name="target">Update package</param>
        public override void UpdateTfs(
            AssociationAction action, 
            object target)
        {
            TfsWorkItemUpdate u = target as TfsWorkItemUpdate;
            if (u == null)
            {
                throw new ToolkitArgException("target");
            }

            if (action == AssociationAction.Add)
            {
                u.AddExternalLink(m_linkType, LocationFromUri(TargetUri), Comment);
            }
            else
            {
                Debug.Assert(action == AssociationAction.Remove, "Unsupported action!");
                TraceManager.TraceError("Deleting external links is not supported!");
            }
        }

        /// <summary>
        /// Extracts location, which will be stored in the TFS database, from URI.
        /// </summary>
        /// <param name="uri">URI</param>
        /// <returns>Location</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1055:UriReturnValuesShouldNotBeStrings"), System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
        protected virtual string LocationFromUri(
            string uri)
        {
            return uri;
        }

    }
}
