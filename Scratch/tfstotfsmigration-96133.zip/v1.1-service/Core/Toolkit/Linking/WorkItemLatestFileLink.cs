// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Linking
{
    /// <summary>
    /// Work item link to the latest revision of a VC file.
    /// </summary>
    [Serializable]
    public class WorkItemLatestFileLink: WorkItemExternalLinkBase
    {
        /// <summary>
        /// Parameterless constructor for serialization.
        /// </summary>
        public WorkItemLatestFileLink()
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="sourceUri">Source artifact</param>
        /// <param name="targetUri">Target artifact</param>
        /// <param name="comment">Comment</param>
        public WorkItemLatestFileLink(
            string sourceUri,
            string targetUri,
            string comment)
            : base(LinkingConstants.VcFileLinkType, sourceUri, targetUri, comment)
        {
            if (!TfsLatestFileHandler.IsMyUri(targetUri))
            {
                throw new ToolkitArgException("targetUri");
            }
        }

        /// <summary>
        /// Creates a copy of the link pointing to the given target.
        /// </summary>
        /// <param name="targetUri">URI of the target item</param>
        /// <returns>Link's copy pointing to the new target</returns>
        public override ILink Redirect(
            string targetUri)
        {
            if (string.IsNullOrEmpty(targetUri))
            {
                throw new ArgumentNullException("targetUri");
            }
            return new WorkItemLatestFileLink(SourceUri, targetUri, Comment);
        }

        /// <summary>
        /// Checks whether given link points to the latest file revision.
        /// </summary>
        /// <param name="link">Link</param>
        /// <returns>True if link points to the latest revision of a file</returns>
        internal static bool IsMyLink(
            ExternalLink link)
        {
            return TFStringComparer.ArtifactType.Equals(link.ArtifactLinkType.Name, LinkingConstants.VcFileLinkType) &&
                TfsLatestFileHandler.IsMyUri(link.LinkedArtifactUri);
        }
    }
}
