// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Linking
{
    /// <summary>
    /// Artifact handler for TFS change lists.
    /// </summary>
    public class TfsChangelistHandler: IArtifactHandler
    {
        private ILinkEngine m_engine;                       // Linking engine

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="engine">Linking engine that owns the handler</param>
        public TfsChangelistHandler(
            ILinkEngine engine)
        {
            if (engine == null)
            {
                throw new ArgumentNullException("engine");
            }
            m_engine = engine;
        }

        #region IArtifactHandler Members

        public bool TryFindReflection(SystemType sourceSystem, string sourceUri, out string targetId)
        {

            if (string.IsNullOrEmpty(sourceUri))
            {
                throw new ArgumentNullException("sourceUri");
            }
            string changeId;
            targetId = null;

            if (TryTranslateUri(sourceUri, out changeId))
            {
                if (m_engine.VersionControlSession != null)
                {
                    targetId = TfsUtil.GetChangeIdFromConversionHistory(m_engine.VersionControlSession.Id, changeId, sourceSystem);
                }
                return true;
            }
            return false;
        }

        public bool TryTranslateUri(string uri, out string id)
        {
            if (string.IsNullOrEmpty(uri))
            {
                throw new ArgumentNullException("uri");
            }
            id = null;
            if (uri.StartsWith(LinkingConstants.VcChangelistPrefix, false, CultureInfo.InvariantCulture))
            {
                id = IdFromUri(uri);
                return id.Length > 0;
            }
            return false;
        }

        public string CreateUri(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                throw new ArgumentNullException("id");
            }
            return UriFromId(id);
        }

        #endregion

        /// <summary>
        /// Creates URI from the change list number
        /// </summary>
        /// <param name="id">Changelist number</param>
        /// <returns>URI</returns>
        internal static string UriFromId(
            string id)
        {
            return LinkingConstants.VcChangelistPrefix + id;
        }

        /// <summary>
        /// Extracts change list from the URI.
        /// </summary>
        /// <param name="uri">URI</param>
        /// <returns>change list</returns>
        internal static string IdFromUri(
            string uri)
        {
            Debug.Assert(uri.StartsWith(LinkingConstants.VcChangelistPrefix), "Invalid URI!");
            return uri.Substring(LinkingConstants.VcChangelistPrefix.Length);
        }

        /// <summary>
        /// Checks whether given URI belongs to a VC changelist.
        /// </summary>
        /// <param name="uri">URI</param>
        /// <returns>True if URI belongs to a VC changelist</returns>
        internal static bool IsMyUri(
            string uri)
        {
            return uri.StartsWith(LinkingConstants.VcChangelistPrefix, StringComparison.InvariantCulture);
        }
    }
}
