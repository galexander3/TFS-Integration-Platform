using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Linking
{
    /// <summary>
    /// Linking constants.
    /// </summary>
    internal static class LinkingConstants
    {
        public const string HyperlinkPrefix = "hyperlink:";             // Do not localize!
        public const string ExternalArtifactPrefix = "external:";       // Do not localize!
        public const string WorkItemPrefix = "vstfs:///WorkItemTracking/WorkItem/";     // Do not localize!
        public const string VcChangelistPrefix = "vstfs:///VersionControl/Changeset/";  // Do not localize!
        public const string VcLatestFilePrefix = "vstfs:///VersionControl/LatestItemVersion/";  // Do not localize!
        public const string VcRevisionFilePrefix = "vstfs:///VersionControl/VersionedItem/";    // Do not localize!

        public const string VcChangelistLinkType = "Fixed in Changeset";    // Do not localize!
        public const string VcFileLinkType = "Source Code File";            // Do not localize!
    }
}
