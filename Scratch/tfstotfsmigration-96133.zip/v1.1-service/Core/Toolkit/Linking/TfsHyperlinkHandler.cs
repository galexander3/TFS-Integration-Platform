// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Linking
{
    /// <summary>
    /// Link handler for TFS links
    /// </summary>
    public class TfsHyperlinkHandler : IArtifactHandler
    {
        #region IArtifactHandler Members

        public bool TryFindReflection(SystemType sourceSystem, string sourceUri, out string targetId)
        {
            return TryTranslateUri(sourceUri, out targetId);
        }

        public bool TryTranslateUri(string uri, out string id)
        {
            if (string.IsNullOrEmpty(uri))
            {
                throw new ArgumentNullException("uri");
            }

            id = null;
            if (uri.StartsWith(LinkingConstants.HyperlinkPrefix, false, CultureInfo.InvariantCulture))
            {
                id = IdFromUri(uri);
                return id.Length > 0;
            }
            return false;
        }

        public string CreateUri(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                throw new ArgumentNullException("id");
            }
            return UriFromId(id);
        }

        #endregion

        /// <summary>
        /// Creates URI from id.
        /// </summary>
        /// <param name="id">Id</param>
        /// <returns>URI</returns>
        internal static string UriFromId(
            string id)
        {
            return LinkingConstants.HyperlinkPrefix + id;
        }

        /// <summary>
        /// Extracts hyperlink id from URI.
        /// </summary>
        /// <param name="uri">Source URI</param>
        /// <returns>Id</returns>
        internal static string IdFromUri(
            string uri)
        {
            Debug.Assert(uri.StartsWith(LinkingConstants.HyperlinkPrefix), "Invalid hyperlink!");
            return uri.Substring(LinkingConstants.HyperlinkPrefix.Length);
        }
    }
}
