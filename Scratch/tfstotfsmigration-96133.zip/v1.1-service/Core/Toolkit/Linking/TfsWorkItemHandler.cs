// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;

using Microsoft.TeamFoundation.Migration.Toolkit;
using Microsoft.TeamFoundation.Migration.Toolkit.Wit;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Linking
{
    /// <summary>
    /// Artifact handler for TFS work items.
    /// </summary>
    public class TfsWorkItemHandler : IArtifactHandler
    {
        private ILinkEngine m_engine;                       // Linking engine

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="engine">Linking engine that owns the handler</param>
        public TfsWorkItemHandler(
            ILinkEngine engine)
        {
            if (engine == null)
            {
                throw new ArgumentNullException("engine");
            }
            m_engine = engine;
        }

        #region IArtifactHandler Members

        public bool TryFindReflection(SystemType sourceSystem, string sourceUri, out string targetId)
        {
            if (string.IsNullOrEmpty(sourceUri))
            {
                throw new ArgumentNullException("sourceUri");
            }

            targetId = null;
            string sourceId;
            if (TryTranslateUri(sourceUri, out sourceId))
            {
                targetId = m_engine.WorkItemTrackingSession.FindReflections(sourceSystem, sourceId)[0];
                return true;
            }
            return false;
        }

        public bool TryTranslateUri(string uri, out string id)
        {
            if (string.IsNullOrEmpty(uri))
            {
                throw new ArgumentNullException("uri");
            }
            id = null;

            if (uri.StartsWith(LinkingConstants.WorkItemPrefix, false, CultureInfo.InvariantCulture))
            {
                id = IdFromUri(uri);
                return id.Length > 0;
            }
            return false;
        }

        public string CreateUri(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                throw new ArgumentNullException("id");
            }
            return UriFromId(id);
        }

        #endregion

        /// <summary>
        /// Creates URI from id.
        /// </summary>
        /// <param name="id">work item id</param>
        /// <returns>Work item URI</returns>
        internal static string UriFromId(
            string id)
        {
            return LinkingConstants.WorkItemPrefix + id;
        }

        /// <summary>
        /// Extracts work item id from URI.
        /// </summary>
        /// <param name="uri">URI</param>
        /// <returns>ID</returns>
        internal static string IdFromUri(
            string uri)
        {
            Debug.Assert(uri.StartsWith(LinkingConstants.WorkItemPrefix), "Invalid URI!");
            return uri.Substring(LinkingConstants.WorkItemPrefix.Length);
        }
    }
}
