// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.TeamFoundation.Migration.Toolkit.Wit;


namespace Microsoft.TeamFoundation.Migration.Toolkit.Linking
{
    /// <summary>
    /// Handler for generic external artifacts which are not known VC artifacts.
    /// </summary>
    public class TfsExternalArtifactHandler: IArtifactHandler
    {
        #region IArtifactHandler Members

        public bool TryFindReflection(
            SystemType sourceSystem, 
            string sourceUri, 
            out string targetId)
        {
            return TryTranslateUri(sourceUri, out targetId);
        }

        public bool TryTranslateUri(
            string uri, 
            out string id)
        {
            if (string.IsNullOrEmpty(uri))
            {
                throw new ArgumentNullException("uri");
            }
            if (IsMyUri(uri))
            {
                id = uri;
                return true;
            }
            id = null;
            return false;
        }

        public string CreateUri(
            string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                throw new ArgumentNullException("id");
            }
            return id;
        }

        #endregion

        /// <summary>
        /// Checks whether URI describes an external artifact.
        /// </summary>
        /// <param name="uri">URI</param>
        /// <returns>True if URI belongs to an external artifact</returns>
        internal static bool IsMyUri(
            string uri)
        {
            return uri.StartsWith(
                LinkingConstants.ExternalArtifactPrefix, StringComparison.InvariantCulture);
        }
    }
}
