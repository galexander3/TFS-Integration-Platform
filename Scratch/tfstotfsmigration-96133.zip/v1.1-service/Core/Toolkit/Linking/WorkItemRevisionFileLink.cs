// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;

using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Linking
{
    /// <summary>
    /// Work item link to a specific revision of a VC file.
    /// </summary>
    [Serializable]
    public class WorkItemRevisionFileLink: WorkItemExternalLinkBase
    {
        /// <summary>
        /// Parameterless constructor for serialization.
        /// </summary>
        public WorkItemRevisionFileLink()
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="sourceUri">Source artifact</param>
        /// <param name="targetUri">Target artifact</param>
        /// <param name="comment">Link's comment</param>
        public WorkItemRevisionFileLink(
            string sourceUri,
            string targetUri,
            string comment)
            : base(LinkingConstants.VcFileLinkType, sourceUri, targetUri, comment)
        {
            if (!TfsRevisionFileHandler.IsMyUri(targetUri))
            {
                throw new ToolkitArgException("targetUri");
            }
        }

        /// <summary>
        /// Creates a copy of the link pointing to the given target.
        /// </summary>
        /// <param name="targetUri">Target artifact</param>
        /// <returns>Link pointing to the new target</returns>
        public override ILink Redirect(string targetUri)
        {
            if (string.IsNullOrEmpty(targetUri))
            {
                throw new ArgumentNullException("targetUri");
            }
            return new WorkItemRevisionFileLink(SourceUri, targetUri, Comment);
        }

        /// <summary>
        /// Checks whether link points to a specific revision of a file.
        /// </summary>
        /// <param name="link">Link to check</param>
        /// <returns>True if link points to a specific revision of a file</returns>
        internal static bool IsMyLink(
            ExternalLink link)
        {
            return TFStringComparer.ArtifactType.Equals(link.ArtifactLinkType.Name, LinkingConstants.VcFileLinkType) &&
                TfsRevisionFileHandler.IsMyUri(link.LinkedArtifactUri);
        }
    }
}
