// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Linking
{
    /// <summary>
    /// Comparer class for links
    /// </summary>
    class LinkComparer : IComparer<ILink>
    {
        private static LinkComparer s_current = new LinkComparer();

        /// <summary>
        /// Returns link comparer object.
        /// </summary>
        public static LinkComparer Current { get { return s_current; } }

        #region IComparer<ILink> Members

        /// <summary>
        /// Compares two links.
        /// </summary>
        /// <param name="x">Link 1</param>
        /// <param name="y">Link 2</param>
        /// <returns>-1 if x is less then y, 0 if x is identical to y, 1 if x is greater then y.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods")]
        public int Compare(ILink x, ILink y)
        {
            Debug.Assert(x != null && y != null, "Null link in comparer!");
            int res = string.CompareOrdinal(x.LinkType, y.LinkType);

            if (res == 0)
            {
                res = string.CompareOrdinal(x.TargetUri, y.TargetUri);
            }
            return res;
        }

        #endregion
    }
}
