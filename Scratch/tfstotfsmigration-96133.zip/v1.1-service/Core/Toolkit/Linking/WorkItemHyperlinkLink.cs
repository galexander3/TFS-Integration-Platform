// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

using Microsoft.TeamFoundation.Migration.Toolkit.Wit;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace Microsoft.TeamFoundation.Migration.Toolkit.Linking
{
    /// <summary>
    /// Hyperlink link class.
    /// </summary>
    public class WorkItemHyperlinkLink: WorkItemLink
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="source">Source work item</param>
        /// <param name="url">Hyperlink</param>
        /// <param name="comment">Link's comment</param>
        public WorkItemHyperlinkLink(
            string sourceUri,
            string targetUri,
            string comment)
            : base(sourceUri, targetUri, comment)
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="sourceUri">Source artifact</param>
        /// <param name="l">Hyperlink</param>
        internal WorkItemHyperlinkLink(
            string sourceUri,
            Hyperlink l)
            : base(sourceUri, TfsHyperlinkHandler.UriFromId(l.Location), l.Comment)
        {
        }

        /// <summary>
        /// Creates a copy of the link pointing to the given target.
        /// </summary>
        /// <param name="targetUri">Target item</param>
        /// <returns>Link copy</returns>
        public override ILink Redirect(
            string targetUri)
        {
            if (string.IsNullOrEmpty(targetUri))
            {
                throw new ArgumentNullException("targetUri");
            }
            return new WorkItemHyperlinkLink(SourceUri, TargetUri, Comment);
        }

        /// <summary>
        /// Submits linking operation into the update package.
        /// </summary>
        /// <param name="action">Link action</param>
        /// <param name="target">Target TFS object</param>
        public override void UpdateTfs(
            AssociationAction action,
            object target)
        {
            TfsWorkItemUpdate update = target as TfsWorkItemUpdate;
            if (update == null)
            {
                throw new ToolkitArgException("target");
            }
            if (action == AssociationAction.Add)
            {
                update.AddHyperlink(TfsHyperlinkHandler.IdFromUri(TargetUri), Comment);
            }
            else
            {
                Debug.Assert(action == AssociationAction.Remove, "Unsupported operation!");
                // <RemoveResourceLink LinkID="123"/>
                // We don't know link id.
                TraceManager.TraceWarning("Deleting hyperlinks is not supported!");
            }
        }

        /// <summary>
        /// Serializes the link.
        /// </summary>
        /// <returns>Serialized content</returns>
        public override string Serialize()
        {
            Debug.Fail("Deferring a hyperlink!");
            return base.Serialize();
        }
    }
}
