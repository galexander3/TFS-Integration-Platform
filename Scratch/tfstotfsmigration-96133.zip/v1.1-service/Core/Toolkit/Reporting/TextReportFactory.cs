// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{
    /*
     * -- provider interface example:
     * 
     * <Provider id="TextReport">
     *   <AssemblyQualifiedName>Microsoft.TeamFoundation.Migration.Toolkit.TextReportFactory, Microsoft.TeamFoundation.Migration.Toolkit, Version=1.0.0.0, Culture=neutral</AssemblyQualifiedName>
     * </Provider>
     * 
     */

    /// <summary>
    /// The factory object for the TextReport event sink.
    /// </summary>
    class TextReportFactory : IConfigFactory
    {
        #region IConfigFactory Members

        /// <summary>
        /// Instantiates and returns a new instance of the TextReport type.
        /// </summary>
        /// <param name="xmlFragment">The configuration data for the TextReport instance</param>
        /// <returns>The TextReport instance.</returns>
        public object CreateInstance(Type type, string xmlFragment)
        {
            if (type == typeof(IMigrationSessionEventSink))
            {
                if (string.IsNullOrEmpty(xmlFragment))
                {
                    throw new ArgumentNullException("xmlFragment");
                }

                using (StringReader sr = new StringReader(xmlFragment))
                {
                    XmlSerializer xs = new XmlSerializer(typeof(TextReportAdaptor));
                    return xs.Deserialize(sr);
                }
            }

            return null;
        }

        #endregion
    }
}
