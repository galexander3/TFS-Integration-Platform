// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Diagnostics;

namespace Microsoft.TeamFoundation.Migration.Toolkit
{

    /*
        <EventSink provider="SQLReport">
          <SQLReport>
            <ConnectionString>server=SERVERNAME;Integrated Security=SSPI</ConnectionString>
            <Database>MigrationToolkitTest2</Database>
          </SQLReport>
        </EventSink>

     */
    /// <summary>
    /// The factory for the SQL report provider type.
    /// </summary>
    public class SqlReportFactory : IConfigFactory
    {
        #region IConfigFactory Members

        public object CreateInstance(Type type, string xmlFragment)
        {
            if (type == typeof(IMigrationSessionEventSink))
            {
                using (StringReader sr = new StringReader(xmlFragment))
                {
                    XmlSerializer xs = new XmlSerializer(typeof(SqlReportAdaptor));
                    return xs.Deserialize(sr);
                }
            }

            return null;
        }

        #endregion
    }
}
