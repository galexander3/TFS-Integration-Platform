-- Copyright (c) Microsoft Corporation. All rights reserved.

/****** Object:  StoredProcedure [dbo].[prc_iiLogEvent]    Script Date: 06/04/2007 11:31:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC [dbo].[prc_iiLogEvent]
  @UTCWhen DATETIME,
  @PID INT,
  @TID INT,
  @Description NVARCHAR(MAX),
  @Exception NVARCHAR(MAX),
  @Id INT OUTPUT
AS BEGIN
  INSERT INTO Events(UTCWhen, PID, TID, Description, Exception) VALUES(@UTCWhen, @PID, @TID, @Description, @Exception);
  SELECT @Id = @@IDENTITY;
END
GO

/****** Object:  StoredProcedure [dbo].[prc_iiLogSessionEvent]    Script Date: 06/04/2007 11:31:40 ******/
CREATE PROC [dbo].[prc_iiLogSessionEvent]
  @UTCWhen DATETIME,
  @PID INT,
  @TID INT,
  @Description NVARCHAR(MAX),
  @Exception NVARCHAR(MAX),
  @SessionId NVARCHAR(MAX),
  @SessionType NVARCHAR(MAX),
  @ItemCount INT,
  @FailureCount INT
AS BEGIN
  DECLARE @Id INT;
  EXEC prc_iiLogEvent @UTCWhen, @PID, @TID, @Description, @Exception, @Id OUT;

  INSERT INTO SessionEvents(Id, SessionId, SessionType, ItemCount, FailureCount) VALUES (@Id, @SessionId, @SessionType, @ItemCount, @FailureCount);
END
GO

/****** Object:  StoredProcedure [dbo].[prc_iiLogWorkItemEvent]    Script Date: 06/04/2007 11:32:01 ******/
CREATE PROC [dbo].[prc_iiLogWorkItemEvent]
  @UTCWhen DATETIME,
  @PID INT,
  @TID INT,
  @Description NVARCHAR(MAX),
  @Exception NVARCHAR(MAX),
  @SessionId NVARCHAR(MAX),
  @PrimarySystem NVARCHAR(MAX),
  @SourceId NVARCHAR(MAX)
AS BEGIN
  DECLARE @Id INT;
  EXEC prc_iiLogEvent @UTCWhen, @PID, @TID, @Description, @Exception, @Id OUT;

  INSERT INTO WorkItemEvents(Id, SessionId, PrimarySystem, SourceId) VALUES (@Id, @SessionId, @PrimarySystem, @SourceId);
END
GO

/****** Object:  StoredProcedure [dbo].[prc_iiLogVersionControlEvent]    Script Date: 06/04/2007 11:32:01 ******/
CREATE PROC [dbo].[prc_iiLogVersionControlEvent]
  @UTCWhen DATETIME,
  @PID INT,
  @TID INT,
  @Description NVARCHAR(MAX),
  @Exception NVARCHAR(MAX),
  @SessionId NVARCHAR(MAX),
  @PrimarySystem NVARCHAR(MAX)
AS BEGIN
  DECLARE @Id INT;
  EXEC prc_iiLogEvent @UTCWhen, @PID, @TID, @Description, @Exception, @Id OUT;

  INSERT INTO VersionControlEvents(Id, SessionId, PrimarySystem) VALUES (@Id, @SessionId, @PrimarySystem);
END
GO