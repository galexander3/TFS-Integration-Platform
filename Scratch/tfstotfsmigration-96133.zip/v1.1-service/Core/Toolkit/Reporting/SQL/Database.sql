-- Copyright (c) Microsoft Corporation. All rights reserved.

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [dbo].[Events]    Script Date: 06/04/2007 11:27:12 ******/
CREATE TABLE [dbo].[Events](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UTCWhen] [datetime] NOT NULL DEFAULT (getutcdate()),
	[PID] [int] NOT NULL,
	[TID] [int] NOT NULL,
	[Description] [nvarchar](max),
	[Exception] [nvarchar](max),
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[SessionEvents]    Script Date: 06/04/2007 11:28:06 ******/
CREATE TABLE [dbo].[SessionEvents](
	[Id] [int] NOT NULL,
	[SessionId] [nvarchar](max) NOT NULL,
	[SessionType] [nvarchar](max) NOT NULL,
	[ItemCount] [int] NOT NULL DEFAULT ((0)),
	[FailureCount] [int] NOT NULL DEFAULT ((0))
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[SessionEvents]  WITH CHECK ADD FOREIGN KEY([Id])
REFERENCES [dbo].[Events] ([Id])
GO

/****** Object:  Table [dbo].[WorkItemEvents]    Script Date: 06/04/2007 11:28:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[WorkItemEvents](
	[Id] [int] NOT NULL,
	[SessionId] [nvarchar](max) NOT NULL,
	[PrimarySystem] [nvarchar](max) NOT NULL,
	[SourceId] [nvarchar](max) NOT NULL
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[WorkItemEvents]  WITH CHECK ADD FOREIGN KEY([Id])
REFERENCES [dbo].[Events] ([Id])
GO

/****** Object:  Table [dbo].[VersionControlEvents]    Script Date: 06/04/2007 11:28:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[VersionControlEvents](
	[Id] [int] NOT NULL,
	[SessionId] [nvarchar](max) NOT NULL,
	[PrimarySystem] [nvarchar](max) NOT NULL,
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[VersionControlEvents]  WITH CHECK ADD FOREIGN KEY([Id])
REFERENCES [dbo].[Events] ([Id])
GO
