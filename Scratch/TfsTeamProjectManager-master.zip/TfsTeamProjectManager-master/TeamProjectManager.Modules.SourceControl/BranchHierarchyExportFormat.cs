﻿
namespace TeamProjectManager.Modules.SourceControl
{
    public enum BranchHierarchyExportFormat
    {
        Dgml,
        Xml
    }
}