﻿
namespace TeamProjectManager.Modules.WorkItemConfiguration
{
    public enum WorkItemConfigurationItemType
    {
        WorkItemType,
        Categories,
        CommonConfiguration,
        AgileConfiguration,
        ProcessConfiguration
    }
}