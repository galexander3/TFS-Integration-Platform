﻿
namespace TeamProjectManager.Modules.WorkItemConfiguration
{
    public enum TransformationType
    {
        Xdt,
        Xslt
    }
}