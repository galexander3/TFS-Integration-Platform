﻿
namespace TeamProjectManager.Modules.WorkItemConfiguration.Compare
{
    public enum ComparisonStatus
    {
        AreEqual,
        AreDifferent,
        ExistsOnlyInSource,
        ExistsOnlyInTarget,
    }
}