﻿namespace TeamProjectManager.Modules.BuildAndRelease.BuildDefinitions
{
    public class BuildDefinitionUpdate
    {
        public bool UpdateBuildNumberFormat { get; set; }
        public string BuildNumberFormat { get; set; }
        public bool UpdatePath { get; set; }
        public string Path { get; set; }
        public bool UpdateAgentQueue { get; set; }
        public string AgentQueueName { get; set; }
    }
}