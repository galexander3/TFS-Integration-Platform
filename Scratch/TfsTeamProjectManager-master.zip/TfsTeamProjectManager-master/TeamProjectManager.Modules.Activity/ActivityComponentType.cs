﻿namespace TeamProjectManager.Modules.Activity
{
    public enum ActivityComponentType
    {
        Tfvc,
        WorkItemTracking,
        XamlBuild,
        Git,
        Build
    }
}