﻿
namespace TeamProjectManager.Modules.Security
{
    public enum PermissionChangeAction
    {
        None,
        Allow,
        Deny,
        Inherit
    }
}