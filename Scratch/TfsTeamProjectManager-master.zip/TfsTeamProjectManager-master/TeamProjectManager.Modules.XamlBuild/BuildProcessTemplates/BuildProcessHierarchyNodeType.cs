﻿
namespace TeamProjectManager.Modules.XamlBuild.BuildProcessTemplates
{
    public enum BuildProcessHierarchyNodeType
    {
        BuildProcessTemplateServerPath,
        TeamProject,
        BuildDefinition
    }
}