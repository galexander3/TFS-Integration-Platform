﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FP.Automation.Utilities
{
	public enum LoggingLevel
	{
		INFO,
		WARN,
		ERROR,
		FATAL,
		DEBUG,
		TRACE
	}
}
