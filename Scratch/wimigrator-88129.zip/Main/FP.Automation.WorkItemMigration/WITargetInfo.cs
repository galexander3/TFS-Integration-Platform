﻿using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System;

namespace FP.Automation.WorkItemMigration
{
	public class WITargetInfo
	{
		public WITargetInfo(string teamProjectName, string iterationPath="", bool createAreaPath=true, bool setState=false, ProcessTemplateType templateType=ProcessTemplateType.Scrum)
		{
			this.TeamProjectName = teamProjectName;
			this.IterationPath = iterationPath;
			this.CreateAreaPath = createAreaPath;
			this.SetState = setState;
			this.TemplateType = templateType;
		}
		
		private string _TeamProjectName;
		/// <summary>
		/// The Target TFS Team Project Name
		/// </summary>
		public string TeamProjectName
		{
			get { return _TeamProjectName; }
			set { _TeamProjectName = value; }
		}

		private string _IterationPath;
		/// <summary>
		/// The Well Formed Iteration Path String To Apply To The Migrated Work Item(s).
		/// The Path Will Be Created If Not Exists In Target. Path Will Be Ignored if
		/// The Root Of The Path ( StartsWith ) the Team Project Name.
		/// </summary>
		public string IterationPath
		{
			get { return _IterationPath; }
			set { _IterationPath = value; }
		}

		private bool _CreateAreaPath;
		/// <summary>
		/// Create Area Paths If Not Exists.
		/// Assign Created Paths To The Target
		/// Work Item.
		/// </summary>
		public bool CreateAreaPath
		{
			get { return _CreateAreaPath; }
			set { _CreateAreaPath = value; }
		}

		private bool _SetState;

		public bool SetState
		{
			get { return _SetState; }
			set { _SetState = value; }
		}

		private ProcessTemplateType _TemplateType;
		/// <summary>
		/// TFS Process Template The Target Team Project Is Using 
		/// </summary>
		public ProcessTemplateType TemplateType
		{
			get 
			{ 
				return _TemplateType; 
			}
			set 
			{
				_TemplateType = value;
			}
		}
		
		private int _WorkItemId = 0;
		/// <summary>
		/// The TFS Work Item Id Assigned To The Target.
		/// This property is assigned after the target is saved.
		/// </summary>
		public int WorkItemId
		{
			get { return _WorkItemId; }
			set { _WorkItemId = value; }
		}

		/// <summary>
		/// An instance of the Work Item created for the target team project. 
		/// </summary>
		public WorkItem TfsWorkItem
		{
			get;
			set;
		}

	}
}
