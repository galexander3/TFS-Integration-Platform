﻿using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System;

namespace FP.Automation.WorkItemMigration
{
	public class WISourceInfo
	{
		public WISourceInfo(string teamProjectName, int workItemId, bool migrateRelated=false, bool destroyOnSuccess=false, ProcessTemplateType templateType=ProcessTemplateType.Agile)
		{
			this.TeamProjectName = teamProjectName;
			this.WorkItemId = workItemId;
			this.MigrateRelatedWorkItems = migrateRelated;
			this.DestroyAfterMigrationSuccess = destroyOnSuccess;
			this.TemplateType = templateType;
		}
		
		private string _TeamProjectName;
		/// <summary>
		/// TFS Team Project Name That Contains The Source Work Item
		/// </summary>
		public string TeamProjectName
		{
			get { return _TeamProjectName; }
			set { _TeamProjectName = value; }
		}

		private int _WorkItemId = 0;
		/// <summary>
		/// The Assigned TFS Work Item Id Of The Source Work Item
		/// </summary>
		public int WorkItemId
		{
			get { return _WorkItemId; }
			set { _WorkItemId = value; }
		}

		private bool _MigrateRelatedWorkItems;
		/// <summary>
		/// Should The Related Work Items Be Migrated. 
		/// Defaults to False Unless Work Item Is User Story
		/// </summary>
		public bool MigrateRelatedWorkItems
		{
			get { return _MigrateRelatedWorkItems; }
			set { _MigrateRelatedWorkItems = value; }
		}

		private bool _DestroyAfterMigrationSuccess = false;
		/// <summary>
		/// Should The Source Work Item Be Destroyed After SuccessFull Migration Operation
		/// </summary>
		public bool DestroyAfterMigrationSuccess
		{
			get { return _DestroyAfterMigrationSuccess; }
			set { _DestroyAfterMigrationSuccess = value; }
		}

		private ProcessTemplateType _TemplateType;
		/// <summary>
		/// The Process Template The Source Team Project Is Using.
		/// This Is A Key Part Of Migrating Work Items As Each Template Has Differences In Work Items ( Types and Feilds )
		/// </summary>
		public ProcessTemplateType TemplateType
		{
			get
			{
				return _TemplateType;
			}
			set
			{
				_TemplateType = value;
			}
		}

		/// <summary>
		/// An instance of the Work Item from the source team project. 
		/// </summary>
		public WorkItem TfsWorkItem
		{
			get;
			set;
		}

	}
}
