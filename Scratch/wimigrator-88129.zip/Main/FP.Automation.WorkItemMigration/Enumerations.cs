﻿
namespace FP.Automation.WorkItemMigration
{
	/// <summary>
	/// The Process Template Type Used by a Team Project.It is 
	/// critical to know what Process the Source and Target Team 
	/// Projects are using. Agile, Scrum, Etc Work Items do not
	/// convert straight accross so this helps as a guide to migration.
	/// </summary>
	public enum ProcessTemplateType
	{
		Agile,
		Scrum
	}

	public enum PathStructureStatus
	{
		Exists,
		Created,
		Unknown
	}
}
