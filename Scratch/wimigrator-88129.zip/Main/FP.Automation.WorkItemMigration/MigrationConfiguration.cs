﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FP.Automation.WorkItemMigration
{
	public class MigrationConfiguration
	{
		
		public MigrationConfiguration(string projectCollectionUrl, WISourceInfo sourceInfo, WITargetInfo targetInfo)
		{
			this._ProjectCollectionUri = new Uri(projectCollectionUrl);
			this._SourceItemInfo = sourceInfo;
			this._TargetItemInfo = targetInfo;
		}
		
		public MigrationConfiguration(string projectCollectionUrl)
		{
			this._ProjectCollectionUri = new Uri(projectCollectionUrl);
		}

		public bool AddSourceItemInfo(string teamProjectName, int workItemId, bool migrateRelated, bool destroyOnSuccess, ProcessTemplateType templateType)
		{
			try
			{
				if (this.SourceItemInfo == null)
				{
					this._SourceItemInfo = new WISourceInfo(teamProjectName, workItemId, migrateRelated, destroyOnSuccess, templateType);
					return true;
				}
				else
				{
					return false;
				}
			}
			catch (Exception ex)
			{
				return false;
			}
		}

		public bool AddTargetItemInfo(string teamProjectName, string iterationPath, bool createAreaPath, bool setState, ProcessTemplateType templateType)
		{
			try
			{
				if (this.TargetItemInfo == null)
				{
					this._TargetItemInfo = new WITargetInfo(teamProjectName, iterationPath, createAreaPath, setState, templateType);
					return false;
				}
				else
				{
					return true;
				}
			}
			catch (Exception ex)
			{
				return false;
			}
		}

		private Uri _ProjectCollectionUri;
		public Uri ProjectCollectionUri
		{
			get { return _ProjectCollectionUri; }
		}

		private WISourceInfo _SourceItemInfo;
		public WISourceInfo SourceItemInfo
		{
			get { return _SourceItemInfo; }
		}

		private WITargetInfo _TargetItemInfo;
		public WITargetInfo TargetItemInfo
		{
			get { return _TargetItemInfo; }
		}

	}
}
