﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FP.Automation.WorkItemMigration;

namespace ConsoleTester
{
	public class Program
	{
		static void Main(string[] args)
		{
			string wids = "10181";
			
			foreach(var wid in wids.Split(','))
			{	
				int id = 0;

				if (!int.TryParse(wid, out id))
				{
					Console.WriteLine("Unable to parse {0} into int var, skipping", wid);
					continue;
				}
				else
				{
					Console.WriteLine("Attemptng to migrate Work Item {0}", id);
				}

				//variables describing source item
				var sTeamProject = "NetOpsRequests";
				var sItemId = id;
				var sMigrateRelated = false;
				var sDestroyOnSuccess = true;
				ProcessTemplateType sProcessTemplate = ProcessTemplateType.Agile;
				
				//variables describing target item
				var tTeamProject = "EngineeringServices";
				var tIterationPath = "CopyFromSource";
				var tCreateArea = true;
				var tSetState = true;
				ProcessTemplateType tProcessTemplate = ProcessTemplateType.Agile;

				//create WISourceInfo object based on s vars
				var sourceInfo = new WISourceInfo(sTeamProject, sItemId, sMigrateRelated, sDestroyOnSuccess, sProcessTemplate);

				//create WITargetInfo object based on t vars
				var targetInfo = new WITargetInfo(tTeamProject, tIterationPath, tCreateArea, tSetState, tProcessTemplate);

				//project collection uri
				var mCollectionUri = "http://fphq-tfs-app:8080/tfs/DefaultCollection";

				//create migrator instance
				var migrator = new WIMigrator(mCollectionUri, sourceInfo, targetInfo);

				//start migration
				if (migrator.Migrate())
				{
					Console.WriteLine("Successfully Migrated Work Item {0} To Team Project {1} with Id {2}", migrator.SourceInfo.WorkItemId, migrator.TargetInfo.TeamProjectName, migrator.TargetInfo.WorkItemId);
				}
				else
				{
					Console.WriteLine("Failed Migration of Work Item {0} to Team Project {1}", migrator.SourceInfo.WorkItemId, migrator.TargetInfo.TeamProjectName);
				}
				Console.WriteLine("Shall We Continue Processing Work Item Id's?");
				Console.WriteLine("enter: no - to stop the process. anything else entered will contine.");
				var answer = Console.ReadLine();
			}
			Console.WriteLine("Migratation has stopped. hit enter to exit.");
			Console.ReadKey(true);

		}
	}
}
