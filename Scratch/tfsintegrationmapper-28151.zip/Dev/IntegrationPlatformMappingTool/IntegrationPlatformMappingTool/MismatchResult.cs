﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IntegrationPlatformMappingTool
{
    public enum MismatchResult
    {
        /// <summary>
        /// Don't map it
        /// </summary>
        No,             
        /// <summary>
        /// Yes, map it because there isn't a mismatch
        /// </summary>
        YesNoMismatch,
        /// <summary>
        /// Yes, map it even though there is a mismatch
        /// </summary>
        YesMismatch 
    }
}
