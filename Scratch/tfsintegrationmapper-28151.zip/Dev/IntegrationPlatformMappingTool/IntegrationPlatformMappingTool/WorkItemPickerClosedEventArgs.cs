﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace IntegrationPlatformMappingTool
{
    public class WorkItemPickerClosedEventArgs: EventArgs
    {
        private XmlDocument _witd;
        private string _workItem;
        private WitLocation _witLocation;

        public WorkItemPickerClosedEventArgs(string workItem, XmlDocument xDoc, WitLocation location)
        {
            _witd = xDoc;
            _workItem = workItem;
            _witLocation = location;
        }

        public string WorkItem
        {
            get { return _workItem; }
            set { _workItem = value; }
        }     

        public XmlDocument WITD
        {
            get { return _witd; }
            set { _witd = value; }
        }

        public WitLocation WitLocation
        {
            get { return _witLocation; }
            set { _witLocation = value; }
        }
        
    }
}
