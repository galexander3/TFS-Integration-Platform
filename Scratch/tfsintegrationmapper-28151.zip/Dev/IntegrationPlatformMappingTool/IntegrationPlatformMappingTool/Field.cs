﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IntegrationPlatformMappingTool
{
    public class Field
    {
        public string Name { get; set; }
        public string DataType { get; set; }
        public string ReferenceName { get; set; }
        public bool Removed { get; set; }
    }
}
